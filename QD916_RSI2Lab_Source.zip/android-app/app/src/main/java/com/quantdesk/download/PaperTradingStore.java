package com.quantdesk.download;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.IOException;
import java.io.Writer;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Independent paper ledger. Never writes to MarketDb's actual market data. */
public final class PaperTradingStore extends SQLiteOpenHelper {
    public static final String NAME="quantdesk-paper-accounts.sqlite3";
    public static final String STRATEGY=SwingStrategy.VERSION;
    private static final double INITIAL_CASH=100000;
    public PaperTradingStore(Context context){super(context,NAME,null,1);setWriteAheadLoggingEnabled(true);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT,strategy TEXT NOT NULL UNIQUE,initial_cash REAL NOT NULL,cash REAL NOT NULL,created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE positions(account_id INTEGER NOT NULL,code TEXT NOT NULL,qty INTEGER NOT NULL,basis REAL NOT NULL,bought_day TEXT NOT NULL,PRIMARY KEY(account_id,code))");
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,account_id INTEGER NOT NULL,code TEXT NOT NULL,side TEXT NOT NULL,signal_day TEXT NOT NULL,qty INTEGER NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',fill_day TEXT,fill_price REAL,fee REAL,error TEXT,UNIQUE(account_id,code,side,signal_day))");
        db.execSQL("CREATE INDEX orders_status ON orders(account_id,status,signal_day)");
        db.execSQL("CREATE TABLE fills(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL UNIQUE,account_id INTEGER NOT NULL,code TEXT NOT NULL,side TEXT NOT NULL,day TEXT NOT NULL,qty INTEGER NOT NULL,price REAL NOT NULL,fee REAL NOT NULL,tax REAL NOT NULL,cash_change REAL NOT NULL)");
        db.execSQL("CREATE TABLE closed_trades(id INTEGER PRIMARY KEY AUTOINCREMENT,account_id INTEGER NOT NULL,code TEXT NOT NULL,buy_day TEXT NOT NULL,sell_day TEXT NOT NULL,qty INTEGER NOT NULL,pnl REAL NOT NULL)");
        db.execSQL("CREATE TABLE signals(account_id INTEGER NOT NULL,day TEXT NOT NULL,code TEXT NOT NULL,action TEXT NOT NULL,score REAL NOT NULL,close_price REAL NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(account_id,day,code))");
        db.execSQL("CREATE INDEX signals_by_day ON signals(account_id,day,action,score)");
        db.execSQL("CREATE TABLE equity_snapshots(account_id INTEGER NOT NULL,day TEXT NOT NULL,equity REAL NOT NULL,cash REAL NOT NULL,PRIMARY KEY(account_id,day))");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){throw new IllegalStateException("Paper account schema migration required");}
    private static String fmt(double x){return String.format(Locale.CHINA,"%.2f",x);}
    private static String money(double x){return String.format(Locale.CHINA,"%,.2f",x);}
    private static String str(Cursor c,int i){return c.isNull(i)?"":c.getString(i);}
    private static boolean valid(SwingStrategy.Candle b){return b!=null&&b.valid();}
    private static void safeDay(String s){LocalDate.parse(s);}

    public long account(){
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("INSERT OR IGNORE INTO accounts(strategy,initial_cash,cash,created_at) VALUES(?,?,?,?)",
            new Object[]{STRATEGY,INITIAL_CASH,INITIAL_CASH,System.currentTimeMillis()});
        try(Cursor c=db.rawQuery("SELECT id FROM accounts WHERE strategy=?",new String[]{STRATEGY})){
            if(c.moveToFirst())return c.getLong(0);
        }
        throw new IllegalStateException("无法建立模拟账户");
    }
    public static final class Position {
        public final String code,boughtDay;
        public final int qty;
        public final double basis;
        Position(String code,String boughtDay,int qty,double basis){
            this.code=code;this.boughtDay=boughtDay;this.qty=qty;this.basis=basis;
        }
    }
    public Map<String,Position> positions(long account){
        Map<String,Position> out=new HashMap<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT code,bought_day,qty,basis FROM positions WHERE account_id=?",new String[]{""+account})){
            while(c.moveToNext()){
                Position p=new Position(c.getString(0),c.getString(1),c.getInt(2),c.getDouble(3));out.put(p.code,p);
            }
        }
        return out;
    }
    public double cash(long account){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT cash FROM accounts WHERE id=?",new String[]{""+account})){
            return c.moveToFirst()?c.getDouble(0):0;
        }
    }
    public static final class Security {public final String code,name;
        Security(String code,String name){this.code=code;this.name=name;}}
    public static List<Security> universe(MarketDb market){
        List<Security> out=new ArrayList<>();
        try(Cursor c=market.getReadableDatabase().rawQuery("SELECT code,name FROM instruments WHERE exchange IN ('SH','SZ','BJ') ORDER BY code",null)){
            while(c.moveToNext())out.add(new Security(c.getString(0),c.getString(1)));
        }
        return out;
    }
    public static String asOf(MarketDb market){
        try(Cursor c=market.getReadableDatabase().rawQuery("SELECT MAX(b.day) FROM daily_bars b JOIN instruments i ON i.code=b.code WHERE i.exchange IN ('SH','SZ','BJ') AND b.day <= ?",
                new String[]{RangePlanner.safeEndDay(java.time.ZonedDateTime.now(java.time.ZoneId.of("Asia/Shanghai"))).toString()})){
            return c.moveToFirst()?str(c,0):"";
        }
    }
    public static List<SwingStrategy.Candle> history(MarketDb market,String code,String asOf){
        List<SwingStrategy.Candle> out=new ArrayList<>();
        try(Cursor c=market.getReadableDatabase().rawQuery(
            "SELECT day,o,h,l,c,vol FROM daily_bars WHERE code=? AND day<=? ORDER BY day DESC LIMIT 90",
            new String[]{code,asOf})){
            while(c.moveToNext())out.add(0,new SwingStrategy.Candle(c.getString(0),c.getDouble(1),c.getDouble(2),c.getDouble(3),c.getDouble(4),c.getDouble(5)));
        }
        return out;
    }
    private static SwingStrategy.Candle firstFutureBar(MarketDb market,String code,String after,String through){
        try(Cursor c=market.getReadableDatabase().rawQuery(
            "SELECT day,o,h,l,c,vol FROM daily_bars WHERE code=? AND day>? AND day<=? ORDER BY day LIMIT 1",
            new String[]{code,after,through})){
            if(c.moveToFirst())return new SwingStrategy.Candle(c.getString(0),c.getDouble(1),c.getDouble(2),c.getDouble(3),c.getDouble(4),c.getDouble(5));
        }
        return null;
    }
    public static String securityName(MarketDb market,String code){
        try(Cursor c=market.getReadableDatabase().rawQuery(
            "SELECT name FROM instruments WHERE code=? LIMIT 1",new String[]{code})){
            return c.moveToFirst()?str(c,0):"";
        }
    }
    private static String lastDay(MarketDb market,String code,String through){
        try(Cursor c=market.getReadableDatabase().rawQuery("SELECT MAX(day) FROM daily_bars WHERE code=? AND day<=?",
                new String[]{code,through})){
            return c.moveToFirst()?str(c,0):"";
        }
    }
    /** Ledger settlement runs only for previous-day orders with an actual next saved bar.
     * Missing or invalid next-session prices NEVER count as fills. No look-ahead.
     */
    public String settle(MarketDb market,long account,String through){
        if(through.isEmpty())return "行情数据库无已完成日K，不能结算";
        safeDay(through);
        List<long[]> ids=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT id FROM orders WHERE account_id=? AND status='PENDING' AND signal_day<? ORDER BY signal_day,id",
            new String[]{""+account,through})){
            while(c.moveToNext())ids.add(new long[]{c.getLong(0)});
        }
        int completed=0,skipped=0,pending=0;
        for(long[] ref:ids){
            SQLiteDatabase db=getWritableDatabase();
            db.beginTransaction();
            try(Cursor order=db.rawQuery("SELECT code,side,signal_day,qty FROM orders WHERE id=? AND status='PENDING'",
                    new String[]{""+ref[0]})){
                if(!order.moveToFirst()){db.setTransactionSuccessful();continue;}
                String code=order.getString(0),side=order.getString(1),signal=order.getString(2);
                int qty=order.getInt(3);
                SwingStrategy.Candle candle=firstFutureBar(market,code,signal,through);
                boolean expired=ChronoUnit.DAYS.between(LocalDate.parse(signal),LocalDate.parse(through))>15;
                if(candle==null){
                    if(expired){cancel(db,ref[0],"次日行情长期缺失/停牌，委托到期");skipped++;}else pending++;
                    db.setTransactionSuccessful();continue;
                }
                if(ChronoUnit.DAYS.between(LocalDate.parse(signal),LocalDate.parse(candle.day))>15){
                    cancel(db,ref[0],"停牌超过15自然日，本策略不模拟成交");skipped++;db.setTransactionSuccessful();continue;
                }
                if(!PaperTradeRules.validNextOpen(signal,candle.day,null,side,candle.open,candle.high,candle.low,candle.close,candle.volume)){
                    cancel(db,ref[0],"目标日 OHLCV 异常，不能模拟成交");skipped++;db.setTransactionSuccessful();continue;
                }
                // No claims of intraday execution for one-price sessions (likely untradeable limit orders).
                if(Math.abs(candle.high-candle.low)<1e-7){
                    cancel(db,ref[0],"开收高低同价，可能一字涨跌停，拒绝假成交");skipped++;db.setTransactionSuccessful();continue;
                }
                double price=PaperTradeRules.fillPrice(candle.open,side);
                if(price<=0){cancel(db,ref[0],"非法成交价");skipped++;db.setTransactionSuccessful();continue;}
                double fee,tax=0,cashChange=0;
                if("BUY".equals(side)){
                    int holdings=countPositions(db,account);
                    boolean exists=hasPosition(db,account,code);
                    if(exists){cancel(db,ref[0],"股票已有持仓，拒绝重复买入");skipped++;db.setTransactionSuccessful();continue;}
                    if(holdings>=5){cancel(db,ref[0],"持仓上限5只");skipped++;db.setTransactionSuccessful();continue;}
                    double cash=accountCash(db,account);
                    double maxBudget=Math.min(cash, equity(market,account,signal)*0.20);
                    int buyQty=Math.min(qty,SwingStrategy.buyLots(maxBudget,price,1));
                    while(buyQty>=100&&buyQty*price+SwingStrategy.commission(buyQty*price)>cash)buyQty-=100;
                    if(buyQty<100){cancel(db,ref[0],"现金不足购买100股（含手续费）");skipped++;db.setTransactionSuccessful();continue;}
                    qty=buyQty;double gross=qty*price;fee=SwingStrategy.commission(gross);cashChange=PaperTradeRules.cashFlow("BUY",qty,price);
                    db.execSQL("INSERT INTO positions(account_id,code,qty,basis,bought_day) VALUES(?,?,?,?,?)",
                        new Object[]{account,code,qty,(gross+fee)/qty,candle.day});
                }else{
                    Position p=position(db,account,code);
                    if(p==null){cancel(db,ref[0],"不存在可卖持仓");skipped++;db.setTransactionSuccessful();continue;}
                    if(p.boughtDay.compareTo(candle.day)>=0){cancel(db,ref[0],"T+1禁止买入当日卖出");skipped++;db.setTransactionSuccessful();continue;}
                    if(qty>p.qty||qty<100||qty%100!=0){
                        cancel(db,ref[0],"卖出数量超过剩余持仓或不是100股整数倍");skipped++;db.setTransactionSuccessful();continue;
                    }
                    double gross=qty*price;fee=SwingStrategy.commission(gross);
                    tax=SwingStrategy.sellTax(gross);cashChange=PaperTradeRules.cashFlow("SELL",qty,price);
                    double pnl=cashChange-p.basis*qty;
                    db.execSQL("INSERT INTO closed_trades(account_id,code,buy_day,sell_day,qty,pnl) VALUES(?,?,?,?,?,?)",
                        new Object[]{account,code,p.boughtDay,candle.day,qty,pnl});
                    if(qty==p.qty)db.execSQL("DELETE FROM positions WHERE account_id=? AND code=?",new Object[]{account,code});
                    else db.execSQL("UPDATE positions SET qty=qty-? WHERE account_id=? AND code=?",
                        new Object[]{qty,account,code});
                }
                db.execSQL("UPDATE accounts SET cash=cash+? WHERE id=?",new Object[]{cashChange,account});
                db.execSQL("INSERT INTO fills(order_id,account_id,code,side,day,qty,price,fee,tax,cash_change) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    new Object[]{ref[0],account,code,side,candle.day,qty,price,fee,tax,cashChange});
                db.execSQL("UPDATE orders SET status='FILLED',fill_day=?,fill_price=?,fee=?,qty=? WHERE id=?",
                    new Object[]{candle.day,price,fee+tax,qty,ref[0]});
                db.setTransactionSuccessful();completed++;
            }catch(RuntimeException ex){
                android.util.Log.e("QDPaper","Settlement failed for order "+ref[0],ex);
                pending++;
            }finally{db.endTransaction();}
        }
        markEquity(market,account,through);
        return "次日开盘模拟成交 "+completed+" 笔；到期/不可成交 "+skipped+"；待处理 "+pending+"（仅有后续真实日K时成交）";
    }
    private static void cancel(SQLiteDatabase db,long id,String error){
        db.execSQL("UPDATE orders SET status='CANCELLED',error=? WHERE id=? AND status='PENDING'",new Object[]{error,id});
    }
    private static double accountCash(SQLiteDatabase db,long a){
        try(Cursor c=db.rawQuery("SELECT cash FROM accounts WHERE id=?",new String[]{""+a})){return c.moveToFirst()?c.getDouble(0):0;}
    }
    private static int countPositions(SQLiteDatabase db,long a){
        try(Cursor c=db.rawQuery("SELECT count(*) FROM positions WHERE account_id=?",new String[]{""+a})){return c.moveToFirst()?c.getInt(0):0;}
    }
    private static boolean hasPosition(SQLiteDatabase db,long a,String code){return position(db,a,code)!=null;}
    private static boolean hasPendingSell(SQLiteDatabase db,long a,String code){
        try(Cursor c=db.rawQuery("SELECT 1 FROM orders WHERE account_id=? AND code=? AND side='SELL' AND status='PENDING' LIMIT 1",
            new String[]{""+a,code})){return c.moveToFirst();}
    }
    private static boolean hasPendingBuy(SQLiteDatabase db,long a,String code){
        try(Cursor c=db.rawQuery("SELECT 1 FROM orders WHERE account_id=? AND code=? AND side='BUY' AND status='PENDING' LIMIT 1",
            new String[]{""+a,code})){return c.moveToFirst();}
    }
    private static Position position(SQLiteDatabase db,long a,String code){
        try(Cursor c=db.rawQuery("SELECT qty,basis,bought_day FROM positions WHERE account_id=? AND code=?",new String[]{""+a,code})){
            return c.moveToFirst()?new Position(code,c.getString(2),c.getInt(0),c.getDouble(1)):null;
        }
    }
    /** mark price uses only stored days on or before asOf. */
    public double equity(MarketDb market,long account,String asOf){
        double equity=cash(account);
        for(Position p:positions(account).values()){
            double mark=p.basis;
            try(Cursor c=market.getReadableDatabase().rawQuery("SELECT c FROM daily_bars WHERE code=? AND day<=? ORDER BY day DESC LIMIT 1",
                new String[]{p.code,asOf})){
                if(c.moveToFirst()&&c.getDouble(0)>0)mark=c.getDouble(0);
            }
            equity+=p.qty*mark;
        }
        return equity;
    }
    private void markEquity(MarketDb market,long account,String day){
        double e=equity(market,account,day),c=cash(account);
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO equity_snapshots(account_id,day,equity,cash) VALUES(?,?,?,?)",
            new Object[]{account,day,e,c});
    }
    public static final class Signal {
        public final String code,day,action,reason;
        public final double score,price;
        Signal(String code,String day,String action,String reason,double score,double price){
            this.code=code;this.day=day;this.action=action;this.reason=reason;this.score=score;this.price=price;
        }
    }
    public interface ScanProgress {void onProgress(int current,int total);}
    /** Scan old bars only, account holdings are point-in-time; no external HTTP. */
    public String scan(MarketDb market,long account,String day,ScanProgress callback){
        if(day.isEmpty())return "数据库没有可用日K，无法扫描";
        Map<String,Position> held=positions(account);
        List<Signal> signals=new ArrayList<>();int eligible=0,stale=0;int universeCount=0;
        List<Security> stocks=universe(market);
        for(Security s:stocks){
            universeCount++;
            if(callback!=null&&(universeCount%100==0||universeCount==stocks.size()))
                callback.onProgress(universeCount,stocks.size());
            List<SwingStrategy.Candle> candles=history(market,s.code,day);
            Position p=held.get(s.code);
            int heldDays=0;
            if(p!=null)for(SwingStrategy.Candle k:candles)if(k.day.compareTo(p.boughtDay)>=0)heldDays++;
            SwingStrategy.Advice advice=SwingStrategy.evaluate(candles,day,p!=null,p==null?0:p.basis,heldDays);
            if("BUY".equals(advice.action)||"SELL".equals(advice.action)||"HOLD".equals(advice.action)){
                eligible++;signals.add(new Signal(s.code,day,advice.action,advice.reason,advice.score,advice.price));
            }else if(p!=null){
                signals.add(new Signal(s.code,day,"DATA_MISSING","持仓缺少最新或有效K线，需手动核查",0,candles.isEmpty()?0:candles.get(candles.size()-1).close));
                stale++;
            }
        }
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            db.execSQL("DELETE FROM signals WHERE account_id=? AND day=?",new Object[]{account,day});
            android.database.sqlite.SQLiteStatement st=db.compileStatement(
                "INSERT INTO signals(account_id,day,code,action,score,close_price,reason) VALUES(?,?,?,?,?,?,?)");
            try{
                for(Signal s:signals){st.clearBindings();st.bindLong(1,account);st.bindString(2,s.day);st.bindString(3,s.code);
                    st.bindString(4,s.action);st.bindDouble(5,s.score);st.bindDouble(6,s.price);st.bindString(7,s.reason);st.executeInsert();}
            }finally{st.close();}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        markEquity(market,account,day);
        return "已扫描A股 "+universeCount+" 只；有效买卖/持有信号 "+eligible+"，持仓缺K线 "+stale+"；信号日 "+day;
    }
    public List<Signal> signals(long account,String day){
        List<Signal> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT code,day,action,reason,score,close_price FROM signals WHERE account_id=? AND day=? AND action IN ('SELL','BUY','HOLD','DATA_MISSING') ORDER BY CASE action WHEN 'SELL' THEN 0 WHEN 'DATA_MISSING' THEN 1 WHEN 'BUY' THEN 2 ELSE 3 END,score DESC LIMIT 35",
                new String[]{""+account,day})){
            while(c.moveToNext())out.add(new Signal(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5)));
        }
        return out;
    }
    /** Explicit confirmation required; pending orders never fill from signal-day close. */
    public String placeSuggestedOrders(MarketDb market,long account,String day){
        if(day.isEmpty())return "信号日缺失，不能下单";
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        int sell=0,buy=0;
        try{
            int occupied=countPositions(db,account);
            try(Cursor c=db.rawQuery("SELECT count(*) FROM orders WHERE account_id=? AND status='PENDING' AND side='BUY'",
                new String[]{""+account})){if(c.moveToFirst())occupied+=c.getInt(0);}
            Map<String,Position> held=positions(account);
            try(Cursor c=db.rawQuery(
                "SELECT code,action,reason,close_price FROM signals WHERE account_id=? AND day=? AND action='SELL' ORDER BY score DESC",
                new String[]{""+account,day})){
                while(c.moveToNext()){
                    Position p=held.get(c.getString(0));
                    if(p==null||p.boughtDay.compareTo(day)>0||hasPendingSell(db,account,p.code))continue;
                    if(insertOrder(db,account,p.code,"SELL",day,p.qty,c.getString(2)))sell++;
                }
            }
            double plannedCash=accountCash(db,account);
            double startingEquity=equity(market,account,day);
            try(Cursor c=db.rawQuery(
                "SELECT code,reason,close_price FROM signals WHERE account_id=? AND day=? AND action='BUY' ORDER BY score DESC LIMIT 30",
                new String[]{""+account,day})){
                while(c.moveToNext()&&occupied<5&&buy<3){
                    String code=c.getString(0);double price=c.getDouble(2);
                    if(held.containsKey(code)||hasPendingBuy(db,account,code))continue;
                    List<SwingStrategy.Candle> past=history(market,code,day);
                    if(past.size()<75)continue;
                    double atr=SwingStrategy.atr14(past,past.size());
                    int qty=SwingStrategy.buyLotsRisk(plannedCash,startingEquity,price,atr);
                    if(qty<100)continue;
                    if(insertOrder(db,account,code,"BUY",day,qty,c.getString(1))){
                        occupied++;buy++;plannedCash-=qty*price+SwingStrategy.commission(qty*price);
                    }
                }
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return "已新建下一交易日模拟委托：买 "+buy+" / 卖 "+sell+"；请更新下一交易日日K后结算。重复点击不会重复下单。";
    }
    private static boolean insertOrder(SQLiteDatabase db,long a,String code,String side,String day,int qty,String reason){
        android.content.ContentValues values=new android.content.ContentValues();
        values.put("account_id",a);values.put("code",code);values.put("side",side);
        values.put("signal_day",day);values.put("qty",qty);values.put("reason",reason);values.put("status","PENDING");
        return db.insertWithOnConflict("orders",null,values,SQLiteDatabase.CONFLICT_IGNORE)!=-1;
    }
    /** Create a user-entered next-session simulation order. No brokerage integration. */
    public String manualOrder(MarketDb market,long account,String day,String enteredCode,String side,int requestedQty){
        if(day==null||day.isEmpty())return "缺少收盘日行情，不能委托";
        String code=enteredCode==null?"":enteredCode.trim();
        if(!code.matches("[0-9]{6}")||!("BUY".equals(side)||"SELL".equals(side)))
            return "股票代码必须是6位数字，方向只能买入或卖出";
        if(requestedQty<100||requestedQty%100!=0)return "模拟委托必须为100股整数倍";
        double price=0;
        try(Cursor c=market.getReadableDatabase().rawQuery(
            "SELECT b.c FROM daily_bars b JOIN instruments i ON i.code=b.code WHERE b.code=? AND b.day=? AND i.exchange IN ('SH','SZ','BJ') LIMIT 1",
            new String[]{code,day})){
            if(c.moveToFirst())price=c.getDouble(0);
        }
        if(!Double.isFinite(price)||price<=0)return "该A股在最新收盘日没有有效收盘价，无法模拟委托";
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            Position p=position(db,account,code);
            if("SELL".equals(side)){
                if(p==null)return "当前没有该股票持仓";
                if(p.boughtDay.compareTo(day)>=0)return "T+1限制：当天买入不能卖出";
                if(requestedQty>p.qty)return "卖出数量超过可用持仓（"+p.qty+"股）";
                if(hasPendingSell(db,account,code))return "已存在待卖委托，请先撤销";
            }else{
                if(p!=null||hasPendingBuy(db,account,code))return "已有该股票持仓或待买委托";
                int occupied=countPositions(db,account);
                try(Cursor c=db.rawQuery("SELECT count(*) FROM orders WHERE account_id=? AND side='BUY' AND status='PENDING'",new String[]{""+account})){
                    if(c.moveToFirst())occupied+=c.getInt(0);
                }
                if(occupied>=5)return "模拟持仓上限5只";
                double total=price*requestedQty+SwingStrategy.commission(price*requestedQty);
                if(total>accountCash(db,account))return "模拟现金不足";
                if(total>equity(market,account,day)*0.20)return "单只股票买入预算不得超过总权益20%";
            }
            boolean ok=insertOrder(db,account,code,side,day,requestedQty,"用户手动模拟委托（最新收盘价仅作估算）");
            if(ok)db.setTransactionSuccessful();
            return ok?"已提交模拟"+("BUY".equals(side)?"买入":"卖出")+"委托："+code+" ×"+requestedQty+
                "股；等待下个有效交易日开盘日K结算。":"同一信号日已有相同方向委托";
        }finally{db.endTransaction();}
    }
    public String cancelPending(long account,long orderId){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("status","CANCELLED");cv.put("error","用户主动撤销未成交模拟委托");
            int changes=db.update("orders",cv,"id=? AND account_id=? AND status='PENDING'",new String[]{""+orderId,""+account});
            db.setTransactionSuccessful();
            return changes==1?"已撤销未成交模拟委托 #"+orderId:"委托不存在或已成交/撤销";
        }finally{db.endTransaction();}
    }
    public static final class OrderView {
        public final long id;public final String code,side,day,status,fillDay,reason;
        public final int qty;public final double fillPrice;
        OrderView(long id,String code,String side,String day,int qty,String status,String fillDay,double fillPrice,String reason){
            this.id=id;this.code=code;this.side=side;this.day=day;this.qty=qty;this.status=status;
            this.fillDay=fillDay;this.fillPrice=fillPrice;this.reason=reason;
        }
    }
    public List<OrderView> orders(long account,int max){
        List<OrderView> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT id,code,side,signal_day,qty,status,coalesce(fill_day,''),coalesce(fill_price,0),coalesce(error,reason) FROM orders WHERE account_id=? ORDER BY id DESC LIMIT "+Math.max(1,Math.min(max,150)),
            new String[]{""+account})){
            while(c.moveToNext())out.add(new OrderView(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getString(5),c.getString(6),c.getDouble(7),c.getString(8)));
        }
        return out;
    }
    public String performance(long account){
        int trades=0,wins=0;double grossProfit=0,grossLoss=0,realized=0;
        try(Cursor c=getReadableDatabase().rawQuery("SELECT count(*),coalesce(sum(CASE WHEN pnl>0 THEN 1 ELSE 0 END),0),coalesce(sum(CASE WHEN pnl>0 THEN pnl ELSE 0 END),0),coalesce(sum(CASE WHEN pnl<0 THEN -pnl ELSE 0 END),0),coalesce(sum(pnl),0) FROM closed_trades WHERE account_id=?",new String[]{""+account})){
            if(c.moveToFirst()){trades=c.getInt(0);wins=c.getInt(1);grossProfit=c.getDouble(2);grossLoss=c.getDouble(3);realized=c.getDouble(4);}
        }
        double peak=INITIAL_CASH,drawdown=0;int snapshots=0;String first="",last="";
        try(Cursor c=getReadableDatabase().rawQuery("SELECT day,equity FROM equity_snapshots WHERE account_id=? ORDER BY day",new String[]{""+account})){
            while(c.moveToNext()){
                if(first.isEmpty())first=c.getString(0);last=c.getString(0);snapshots++;
                double e=c.getDouble(1);peak=Math.max(peak,e);drawdown=Math.min(drawdown,e/peak-1);
            }
        }
        return "已平仓 "+trades+" 笔  |  胜率 "+(trades==0?"暂无":fmt(wins*100.0/trades)+"%")+"\n"+
            "累计已实现盈亏 ¥"+money(realized)+"\n盈亏比 "+(grossLoss==0?"暂无":fmt(grossProfit/grossLoss))+
            "  |  已记录最大回撤 "+fmt(-100*drawdown)+"%\n净值采样日 "+snapshots+" 天（"+(first.isEmpty()?"暂无":first+" ~ "+last)+"）"+
            "\n提示：此统计只是模拟记录，不是完整历史回测、年化或策略胜率证明。";
    }
    public String summary(MarketDb market,long account,String day){
        double available=cash(account),eq=day.isEmpty()?available:equity(market,account,day);
        int closed=0,wins=0,pending=0;double realized=0,peak=INITIAL_CASH,maxDD=0;
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT count(*),coalesce(sum(CASE WHEN pnl>0 THEN 1 ELSE 0 END),0),coalesce(sum(pnl),0) FROM closed_trades WHERE account_id=?",
                new String[]{""+account})){
            if(c.moveToFirst()){closed=c.getInt(0);wins=c.getInt(1);realized=c.getDouble(2);}
        }
        try(Cursor c=getReadableDatabase().rawQuery("SELECT count(*) FROM orders WHERE account_id=? AND status='PENDING'",
            new String[]{""+account})){if(c.moveToFirst())pending=c.getInt(0);}
        try(Cursor c=getReadableDatabase().rawQuery("SELECT equity FROM equity_snapshots WHERE account_id=? ORDER BY day",new String[]{""+account})){
            while(c.moveToNext()){
                double value=c.getDouble(0);peak=Math.max(peak,value);
                maxDD=Math.min(maxDD,value/peak-1);
            }
        }
        StringBuilder b=new StringBuilder();
        b.append("模拟本金 ¥100,000.00 | 数据日 ").append(day.isEmpty()?"无":day).append("\n现金 ¥").append(money(available))
            .append(" | 当前权益 ¥").append(money(eq)).append("\n总收益 ").append(fmt((eq/INITIAL_CASH-1)*100))
            .append("% | 已实现盈亏 ¥").append(money(realized)).append("\n已完成平仓 ").append(closed)
            .append(" 笔 | 胜率 ").append(closed==0?"暂无":fmt(100.0*wins/closed)+"%")
            .append(" | 已记录最大回撤 ").append(fmt(-maxDD*100)).append("%\n未成交委托 ").append(pending)
            .append(" 笔（下一真实交易日开盘模拟结算）\n");
        for(Position p:positions(account).values()){
            String latest=day.isEmpty()?"":lastDay(market,p.code,day);
            b.append("持仓 ").append(p.code).append("  ").append(p.qty).append("股 | 成本 ").append(fmt(p.basis))
                .append(" | 买入 ").append(p.boughtDay).append(" | 行情 ").append(latest).append("\n");
        }
        return b.toString();
    }
    public String recentLedger(long account){
        StringBuilder b=new StringBuilder();
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT code,side,signal_day,qty,status,coalesce(fill_day,''),coalesce(fill_price,0),coalesce(error,'') FROM orders WHERE account_id=? ORDER BY id DESC LIMIT 35",
                new String[]{""+account})){
            while(c.moveToNext())b.append(c.getString(2)).append(" ").append(c.getString(0))
                .append(" ").append(c.getString(1)).append(" ").append(c.getInt(3)).append("股 ")
                .append(c.getString(4)).append(" ").append(c.getString(5)).append(" @")
                .append(fmt(c.getDouble(6))).append(" ").append(str(c,7)).append("\n");
        }
        return b.length()==0?"暂无委托记录":b.toString();
    }
    /** Flush account WAL before an independent user-selected backup copy. */
    public void checkpoint(){
        try(Cursor c=getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null)){
            if(c.moveToFirst()&&c.getInt(0)!=0)throw new IllegalStateException("模拟账本正在写入，WAL未能安全归档");
        }
    }
    public void exportLedger(long account,Writer out) throws IOException {
        out.write("\uFEFF账本类型,股票,方向,信号日期,成交日期,股数,成交价,手续费,印花税,现金变动,状态,已实现盈亏\n");
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT o.code,o.side,o.signal_day,coalesce(f.day,''),coalesce(f.qty,o.qty),coalesce(f.price,0),coalesce(f.fee,0),coalesce(f.tax,0),coalesce(f.cash_change,0),o.status,coalesce(t.pnl,0) FROM orders o LEFT JOIN fills f ON f.order_id=o.id LEFT JOIN closed_trades t ON t.account_id=o.account_id AND t.code=o.code AND t.sell_day=f.day WHERE o.account_id=? ORDER BY o.id",
                new String[]{""+account})){
            while(c.moveToNext()){
                out.write("委托成交,"+c.getString(0)+","+c.getString(1)+","+c.getString(2)+","+c.getString(3)+","+c.getInt(4)+","+
                    fmt(c.getDouble(5))+","+fmt(c.getDouble(6))+","+fmt(c.getDouble(7))+","+fmt(c.getDouble(8))+","+c.getString(9)+","+fmt(c.getDouble(10))+"\n");
            }
        }
    }
}
