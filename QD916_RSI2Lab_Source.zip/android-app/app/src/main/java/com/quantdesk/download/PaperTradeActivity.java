package com.quantdesk.download;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/** Separate, non-brokerage experimental portfolio. Interactive A-share paper trading dashboard. */
public final class PaperTradeActivity extends Activity {
    private static final int EXPORT=3101,EXPORT_DB=3102;
    private static final int NAVY=Color.rgb(17,32,57),BLUE=Color.rgb(41,96,216);
    private static final int BG=Color.rgb(245,247,251),MUTED=Color.rgb(99,113,137);
    private static final int RED=Color.rgb(204,55,64),GREEN=Color.rgb(23,140,102);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private TextView message,accountInfo,sectionName;
    private LinearLayout tabRow,listPane;
    private EditText search;
    private String activeTab="持仓",latestDay="",filter="";
    private Dashboard current;
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable surface(int color,int radius){
        GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(dp(radius));return b;
    }
    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private LinearLayout.LayoutParams margins(int width,int height,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,height);p.bottomMargin=dp(bottom);return p;
    }
    private Button button(String label,int color,View.OnClickListener onClick){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(Color.WHITE);
        b.setBackground(surface(color,12));b.setPadding(dp(9),dp(8),dp(9),dp(8));b.setOnClickListener(onClick);return b;
    }
    private LinearLayout card(){
        LinearLayout box=column();box.setBackground(surface(Color.WHITE,16));box.setPadding(dp(15),dp(14),dp(15),dp(14));return box;
    }
    private void addCard(LinearLayout root,LinearLayout card){root.addView(card,margins(-1,-2,12));}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(Color.WHITE);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout screen=column();screen.setPadding(dp(14),0,dp(14),dp(26));scroll.addView(screen);setContentView(scroll);
        LinearLayout toolbar=column();toolbar.setBackground(surface(NAVY,0));toolbar.setPadding(dp(16),dp(16),dp(16),dp(16));
        screen.addView(toolbar,margins(-1,-2,14));
        TextView back=text("‹  返回行情数据库",13,Color.rgb(185,204,239),false);back.setOnClickListener(v->finish());toolbar.addView(back);
        gap(toolbar,13);
        toolbar.addView(text("策略实验室  /  A股模拟仓",22,Color.WHITE,true));
        gap(toolbar,5);
        toolbar.addView(text("独立账户 · RSI(2) 趋势回调 · 非真实交易",12,Color.rgb(181,201,234),false));
        gap(toolbar,12);
        accountInfo=text("读取模拟资产中…",16,Color.WHITE,true);
        accountInfo.setLineSpacing(dp(5),1);toolbar.addView(accountInfo);
        message=text("准备读取本地日K",12,MUTED,false);screen.addView(message,margins(-1,-2,12));
        LinearLayout actions=card();actions.addView(text("快捷交易",16,NAVY,true));gap(actions,8);
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);
        Button buy=button("＋ 模拟买入",RED,v->manualDialog("BUY","",100));
        Button sell=button("－ 模拟卖出",GREEN,v->manualDialog("SELL","",100));
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(49),1);half.rightMargin=dp(5);
        a.addView(buy,half);
        LinearLayout.LayoutParams other=new LinearLayout.LayoutParams(0,dp(49),1);other.leftMargin=dp(5);
        a.addView(sell,other);actions.addView(a);gap(actions,8);
        actions.addView(button("扫描行情 · 更新策略信号",BLUE,v->runAction("SCAN")),margins(-1,dp(46),8));
        actions.addView(button("确认候选策略委托",NAVY,v->new AlertDialog.Builder(this).setTitle("确认自动模拟委托")
            .setMessage("使用已扫描的最新收盘日信号创建下一交易日模拟委托。每只预算不超过权益20%，总体最多5只持仓；成交价、手续费以实际下一日K线模拟。是否继续？")
            .setNegativeButton("返回",null).setPositiveButton("创建模拟委托",(d,w)->runAction("ORDER")).show()),margins(-1,dp(46),8));
        actions.addView(button("下一日K结算待成交委托",GREEN,v->runAction("SETTLE")),margins(-1,dp(44),0));
        addCard(screen,actions);
        LinearLayout table=card();sectionName=text("模拟账户明细",16,NAVY,true);table.addView(sectionName);
        gap(table,10);tabRow=new LinearLayout(this);tabRow.setOrientation(LinearLayout.HORIZONTAL);table.addView(tabRow);
        gap(table,8);
        search=new EditText(this);search.setTextSize(13);search.setSingleLine(true);
        search.setHint("按股票代码筛选（例如 600519）");search.setBackground(surface(BG,10));
        search.setPadding(dp(12),dp(9),dp(12),dp(9));table.addView(search,margins(-1,dp(46),6));
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filter=s.toString().trim();renderRows();}
            @Override public void afterTextChanged(Editable e){}
        });
        listPane=column();table.addView(listPane);addCard(screen,table);
        LinearLayout files=card();files.addView(text("导出及实验说明",16,NAVY,true));gap(files,9);
        files.addView(button("导出模拟委托与成交 CSV",BLUE,v->exportFile(EXPORT)),margins(-1,dp(44),7));
        files.addView(button("备份独立模拟账本 SQLite",NAVY,v->exportFile(EXPORT_DB)),margins(-1,dp(44),10));
        files.addView(text("信号在日K收盘后产生，委托仅在后续有效日K开盘模拟成交；支持T+1、100股整数倍、手续费、滑点、撤单。市场数据库只读、账本独立保存。",12,MUTED,false));
        gap(files,8);
        files.addView(text("实验算法可能连续亏损；未复权、停牌、涨跌停排队、退市样本及完整历史回测尚未充分验证，模拟胜率不能视为实盘承诺。",12,MUTED,false));
        addCard(screen,files);
        refreshTabs();runAction("SCAN");
    }
    private static final class Holding {
        String code,name,boughtDay,quoteDay;int qty;double basis,price;
        Holding(String code,String name,int qty,double basis,double price,String boughtDay,String quoteDay){
            this.code=code;this.name=name;this.qty=qty;this.basis=basis;this.price=price;
            this.boughtDay=boughtDay;this.quoteDay=quoteDay;
        }
    }
    private static final class Dashboard {
        String day,summary,performance,ledger,message;
        List<Holding> holdings=new ArrayList<>();
        List<PaperTradingStore.Signal> signals=Collections.emptyList();
        List<PaperTradingStore.OrderView> orders=Collections.emptyList();
    }
    private void runAction(String action){
        if(!busy.compareAndSet(false,true)){message.setText("后台操作中，请完成后再试");return;}
        message.setText("正在处理 " + action + " · 仅访问本地行情与模拟账本");
        new Thread(()->{
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore paper=new PaperTradingStore(getApplicationContext())){
                long account=paper.account();String day=PaperTradingStore.asOf(market),note="";
                if(day.isEmpty())note="市场数据库暂无有效A股日K，不能生成订单";
                else if("SCAN".equals(action)){
                    String settlement=paper.settle(market,account,day);
                    note=settlement+"；"+paper.scan(market,account,day,(now,total)->{
                        if(now%300==0||now==total)ui.post(()->message.setText("扫描本地A股 " + now + "/"+total));
                    });
                }else if("ORDER".equals(action)){
                    note=paper.signals(account,day).isEmpty()?"无本日策略信号，请先扫描":paper.placeSuggestedOrders(market,account,day);
                }else if("SETTLE".equals(action))note=paper.settle(market,account,day);
                Dashboard next=readDashboard(market,paper,account,day);next.message=note;
                ui.post(()->show(next));
            }catch(Exception ex){
                android.util.Log.e("QDPaper","模拟仓异常",ex);
                ui.post(()->message.setText("模拟仓操作失败："+ex.getClass().getSimpleName()+"  "+ex.getMessage()));
            }finally{busy.set(false);}
        },"qd-lab-"+action).start();
    }
    private Dashboard readDashboard(MarketDb market,PaperTradingStore paper,long account,String day){
        Dashboard d=new Dashboard();d.day=day;
        d.summary=paper.summary(market,account,day);
        d.performance=paper.performance(account);d.ledger=paper.recentLedger(account);
        d.signals=paper.signals(account,day);d.orders=paper.orders(account,100);
        for(Map.Entry<String,PaperTradingStore.Position> e:paper.positions(account).entrySet()){
            PaperTradingStore.Position p=e.getValue();
            List<SwingStrategy.Candle> bars=PaperTradingStore.history(market,p.code,day);
            SwingStrategy.Candle last=bars.isEmpty()?null:bars.get(bars.size()-1);
            d.holdings.add(new Holding(p.code,PaperTradingStore.securityName(market,p.code),p.qty,p.basis,
                last==null?p.basis:last.close,p.boughtDay,last==null?"无":last.day));
        }
        Collections.sort(d.holdings,(a,b)->a.code.compareTo(b.code));
        return d;
    }
    private void show(Dashboard d){
        current=d;latestDay=d.day;
        accountInfo.setText(d.summary.split("\n持仓 ")[0]);
        message.setText(d.message==null?"模拟账户已更新":d.message);
        refreshTabs();renderRows();
    }
    private void refreshTabs(){
        if(tabRow==null)return;tabRow.removeAllViews();
        for(String name:new String[]{"持仓","信号","委托","战绩","流水"}){
            TextView t=text(name,13,name.equals(activeTab)?BLUE:MUTED,name.equals(activeTab));
            t.setGravity(Gravity.CENTER);t.setPadding(dp(3),dp(10),dp(3),dp(10));
            t.setBackground(surface(name.equals(activeTab)?Color.rgb(233,239,255):BG,10));
            t.setOnClickListener(v->{activeTab=name;refreshTabs();renderRows();});
            LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(0,dp(42),1);layout.rightMargin=dp(3);
            tabRow.addView(t,layout);
        }
    }
    private boolean match(String code){return filter.isEmpty()||code.contains(filter);}
    private void detail(String header,String sub,int color,View.OnClickListener action,String label){
        LinearLayout box=column();box.setPadding(dp(11),dp(12),dp(11),dp(12));
        box.setBackground(surface(BG,12));
        box.addView(text(header,15,color,true));gap(box,4);
        TextView explanation=text(sub,12,MUTED,false);explanation.setLineSpacing(dp(3),1);box.addView(explanation);
        if(action!=null){gap(box,8);box.addView(button(label,BLUE,action),margins(-1,dp(40),0));}
        listPane.addView(box,margins(-1,-2,8));
    }
    private void renderRows(){
        if(listPane==null)return;
        listPane.removeAllViews();if(current==null){listPane.addView(text("本地模拟账户读取中…",13,MUTED,false));return;}
        int count=0;
        if("持仓".equals(activeTab)){
            sectionName.setText("持仓明细 · " + current.holdings.size()+" 只");
            for(Holding p:current.holdings){if(!match(p.code))continue;count++;
                double pnl=(p.price/p.basis-1)*100;
                detail(p.code+"  "+p.name+"    " +String.format(Locale.CHINA,"%+.2f%%",pnl),
                    "持仓 "+p.qty+" 股 | 成本 ¥"+fmt(p.basis)+" | 最新 ¥"+fmt(p.price)+
                        "\n买入 "+p.boughtDay+" | 行情 "+p.quoteDay,pnl>=0?RED:GREEN,
                    v->manualDialog("SELL",p.code,p.qty),"卖出该持仓");
            }
        }else if("信号".equals(activeTab)){
            sectionName.setText("策略选股 · "+current.day);
            for(PaperTradingStore.Signal s:current.signals){if(!match(s.code))continue;count++;
                int color="BUY".equals(s.action)?RED:"SELL".equals(s.action)?GREEN:NAVY;
                detail(("BUY".equals(s.action)?"候选买入":"SELL".equals(s.action)?"候选卖出":"HOLD".equals(s.action)?"持仓观察":"数据警告")+
                    "  "+s.code+"  ¥"+fmt(s.price),
                    "分数 "+fmt(s.score)+" | "+s.reason,color,
                    "BUY".equals(s.action)?v->manualDialog("BUY",s.code,100):null,"按此股票手动下单");
            }
        }else if("委托".equals(activeTab)){
            sectionName.setText("模拟委托 · 最近100笔");
            for(PaperTradingStore.OrderView o:current.orders){if(!match(o.code))continue;count++;
                String status="PENDING".equals(o.status)?"待成交":"FILLED".equals(o.status)?"已成交":"已撤销";
                detail("#"+o.id+"  "+o.code+"   "+("BUY".equals(o.side)?"买入":"卖出")+"  "+status,
                    "委托日 "+o.day+" · "+o.qty+"股\n"+("FILLED".equals(o.status)?"成交 "+o.fillDay+" @ ¥"+fmt(o.fillPrice):o.reason),
                    "BUY".equals(o.side)?RED:GREEN,
                    "PENDING".equals(o.status)?v->confirmCancel(o.id):null,"撤销未成交委托");
            }
        }else if("战绩".equals(activeTab)){
            sectionName.setText("收益风险分析");
            detail("策略实验统计",current.performance,NAVY,null,"");count++;
        }else{
            sectionName.setText("最近交易流水");detail("模拟成交与委托",current.ledger,NAVY,null,"");count++;
        }
        if(count==0)detail("暂无内容","没有符合条件的记录；策略允许空仓，不会强制交易。",MUTED,null,"");
    }
    private static String fmt(double n){return String.format(Locale.CHINA,"%.2f",n);}
    private void manualDialog(String side,String presetCode,int defaultQty){
        if(latestDay.isEmpty()){Toast.makeText(this,"请先载入有效行情",Toast.LENGTH_SHORT).show();return;}
        LinearLayout form=column();form.setPadding(dp(22),dp(10),dp(22),dp(3));
        form.addView(text("股票代码（A股6位）",13,NAVY,true));
        EditText code=new EditText(this);code.setSingleLine(true);code.setInputType(2);
        code.setHint("600519");code.setText(presetCode);form.addView(code);
        form.addView(text("股数（100股整数倍）",13,NAVY,true));
        EditText qty=new EditText(this);qty.setSingleLine(true);qty.setInputType(2);
        qty.setText(""+defaultQty);form.addView(qty);
        form.addView(text("最新信号日："+latestDay+"。这是次交易日开盘的模拟委托，不会发送真实订单。",12,MUTED,false));
        new AlertDialog.Builder(this).setTitle("BUY".equals(side)?"模拟买入":"模拟卖出").setView(form)
            .setNegativeButton("取消",null).setPositiveButton("确认委托",(dlg,which)->{
                int shares;
                try{shares=Integer.parseInt(qty.getText().toString().trim());}catch(Exception ex){message.setText("请输入有效股数");return;}
                manualOrder(side,code.getText().toString().trim(),shares);
            }).show();
    }
    private void manualOrder(String side,String code,int qty){
        if(!busy.compareAndSet(false,true)){message.setText("后台任务运行中，请完成后操作");return;}
        message.setText("正在校验模拟委托与持仓…");
        new Thread(()->{
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore p=new PaperTradingStore(getApplicationContext())){
                long a=p.account();String day=PaperTradingStore.asOf(market);
                String result=p.manualOrder(market,a,day,code,side,qty);
                Dashboard d=readDashboard(market,p,a,day);d.message=result;
                ui.post(()->{activeTab="委托";show(d);});
            }catch(Exception ex){ui.post(()->message.setText("下单失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-manual-order").start();
    }
    private void confirmCancel(long id){
        new AlertDialog.Builder(this).setTitle("撤销委托 #"+id)
            .setMessage("只能撤销还未模拟成交的委托；已成交无法撤销。")
            .setNegativeButton("返回",null).setPositiveButton("确认撤销",(dlg,which)->cancel(id)).show();
    }
    private void cancel(long id){
        if(!busy.compareAndSet(false,true)){message.setText("后台任务运行中，暂不能撤单");return;}
        new Thread(()->{
            try(MarketDb m=new MarketDb(getApplicationContext());PaperTradingStore p=new PaperTradingStore(getApplicationContext())){
                long a=p.account();String msg=p.cancelPending(a,id);String day=PaperTradingStore.asOf(m);
                Dashboard d=readDashboard(m,p,a,day);d.message=msg;ui.post(()->show(d));
            }catch(Exception ex){ui.post(()->message.setText("撤单失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-cancel").start();
    }
    private void exportFile(int kind){
        if(busy.get()){message.setText("模拟任务运行中，请完成后导出");return;}
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(kind==EXPORT?"text/csv":"application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE,kind==EXPORT?"QD-RSI2Lab-模拟交易.csv":"QD-RSI2Lab-模拟账本.sqlite3");
        try{startActivityForResult(intent,kind);}catch(Exception ex){message.setText("无法打开文件保存窗口："+ex.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if((request!=EXPORT&&request!=EXPORT_DB)||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri target=data.getData();
        if(!busy.compareAndSet(false,true)){message.setText("模拟任务仍在运行，暂不能导出");return;}
        message.setText("正在导出模拟账户…");
        new Thread(()->{
            try(PaperTradingStore p=new PaperTradingStore(getApplicationContext());
                OutputStream stream=getContentResolver().openOutputStream(target,"w")){
                if(stream==null)throw new IllegalStateException("保存地址不可写");
                if(request==EXPORT){
                    OutputStreamWriter writer=new OutputStreamWriter(stream,StandardCharsets.UTF_8);
                    p.exportLedger(p.account(),writer);writer.flush();
                }else{
                    p.account();p.checkpoint();
                    File source=getDatabasePath(PaperTradingStore.NAME);
                    try(FileInputStream input=new FileInputStream(source)){
                        byte[] buffer=new byte[65536];int n;
                        while((n=input.read(buffer))!=-1)stream.write(buffer,0,n);
                    }stream.flush();
                }
                ui.post(()->{message.setText("模拟账户导出完成");Toast.makeText(this,"文件已保存",Toast.LENGTH_LONG).show();});
            }catch(Exception ex){ui.post(()->message.setText("导出失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-lab-export").start();
    }
}
