"""V9.0.5 no-personal-API-token release contract. No network or synthetic quotes."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'

def test_no_credential_ui_or_tushare_http_client():
    ui=(J/'MainActivity.java').read_text()
    fin=(J/'FinancialSources.java').read_text()
    svc=(J/'HarvestService.java').read_text()
    assert 'tokenInput' not in ui and '保存 Token' not in ui
    assert 'api.tushare.pro' not in fin
    assert 'new TokenVault' not in svc
    assert not (J/'TokenVault.java').exists()
    assert '① A股全量补齐｜历史日K缺口 + 财报' in ui

def test_public_financial_source_has_explicit_provenance_and_limits():
    finance=(J/'FinancialSources.java').read_text()
    for x in ['lrbDateAjaxNew','zcfzbDateAjaxNew','xjllbDateAjaxNew']:
        # dynamic type + suffix, so verify combined construction, not literals
        assert x.replace('DateAjaxNew','') in finance
    for name in ['hk_indicator','hk_dividend','RPT_HKF10_MAIN_DIVBASIC','RPT_CUSTOM_HKF10_FN_MAININDICATORMAX']:
        assert name in finance
    assert 'HK full three financial statements are not verified' in finance
    assert 'verifiedRow' in finance and '_qd_provider' in finance
    db=(J/'MarketDb.java').read_text()
    assert 'row.optString("_qd_provider"' in db
    assert 'INSERT OR IGNORE INTO dataset_rows' in db

def test_db_identity_and_stable_update_signing_preserved():
    db=(J/'MarketDb.java').read_text();build=(R/'android-app/app/build.gradle').read_text()
    assert 'quantdesk-a-share-2y.sqlite3' in db
    assert 'DROP TABLE' not in db
    assert 'versionCode 916' in build
    assert "applicationId 'com.quantdesk.lab.rsi2paper916'" in build
    wf=(R/'.github/workflows/QD916_RSI2Lab_Build.yml').read_text()
    assert "z=Path('QD916_RSI2Lab_Source.zip')" in wf
    assert 'PublicFinanceTest.java' in wf
    assert 'QD_KEYSTORE_B64' in wf
