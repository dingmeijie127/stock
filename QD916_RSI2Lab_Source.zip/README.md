# QuantDesk RSI2 Lab01 — 独立 A 股算法 / 模拟交易实验 APK

本实验基于 QD 9.1.6：**行情数据库与下载业务原封保留**，只更换策略、模拟仓界面以及 APK 实验身份和 GitHub Actions 签名配置。未开始多策略集成，策略账户仅用于本实验。与任何券商无关，不会真实下单。

## 使用本次交付构建 APK

将 `QD916_RSI2Lab_Source.zip` 放在 GitHub 仓库**根目录**，把 `QD916_RSI2Lab_Build.yml` 放在 `.github/workflows/`（不要改名）；工作流只读取这个实验 ZIP，并要求 ZIP 内同路径的 YML 与上传的 YML 字节完全一致。通过 Actions 运行 `QuantDesk RSI2 Lab01 - independent APK signature`，完成测试、拉取 A 股股票清单、Gradle 构建后，下载名为 `QuantDesk916-RSI2Lab01-Ashare-Paper-APK` 的产物。

新 APK 包名：`com.quantdesk.lab.rsi2paper916`，可与原版 `com.quantdesk.asharecollector88` 分开安装。包名不同意味着**数据目录独立**：原版市场 SQLite 不会自动出现到此实验版中；如需复用历史日 K，请先从原版导出行情数据库，再通过本实验版主页的“导入备份”操作导入，行情入库表结构不变。模拟仓账本是自己的 `quantdesk-paper-accounts.sqlite3`，需要另行导出。

## 为此实验配置独立签名（必须）

务必为 **RSI2Lab01** 生成**新的 keystore**，不要拷贝其他实验或正式版 JKS。示例（请自己设置强密码，JKS 及密码不要传进源码仓库）：

```bash
keytool -genkeypair -keystore RSI2Lab01.jks -alias qd_rsi2lab01 \
  -keyalg RSA -keysize 3072 -validity 10000 \
  -dname "CN=RSI2Lab01,OU=Experiment,O=QuantDesk,C=US"
```

在当前 GitHub 仓库的 Settings → Secrets and variables → Actions 中新增以下**四个互不与其他软件混用**的 repository secrets：

- `QD_RSI2LAB01_KEYSTORE_B64`：上面的 JKS 文件 Base64（Linux：`base64 -w0 RSI2Lab01.jks`；macOS：`base64 -i RSI2Lab01.jks | tr -d '\n'`）
- `QD_RSI2LAB01_SIGNING_ALIAS`：`qd_rsi2lab01`
- `QD_RSI2LAB01_SIGNING_STORE_PASSWORD`：JKS 库密码
- `QD_RSI2LAB01_SIGNING_KEY_PASSWORD`：私钥密码（可与库密码相同）

不配置四项会**主动终止构建**，不会静默使用每次变化的 debug 签名。Gradle 仍以构建步骤内部的 `QD_SIGNING_*` 环境变量读密钥；GitHub Secrets 引用已按此实验命名隔离。GitHub 工作流末尾会打印 APK 签名证书指纹，请记录以便核对后续版本。不同 secret 名称**本身不能阻止复制同一 JKS**，务必真的新生成。

## 新策略：TREND_RSI2_ATR_LAB_V1

- **多指标过滤**：至少 75 根有效日 K、60 日均线上行与 20 日均线非下降；仅在上行趋势中寻找靠近 20 日线的回调。
- **逆势中做短线反转**：RSI(2) 前一日 ≤18，最新日明显反弹（+5），且当天价格与 K 线验证止跌，ATR14 波动率须处于约 1.2%～7.5% 区间。
- **仓位纪律**：候选订单每笔计划亏损风险最多占权益约 0.75%，每只占权益不超过 20%，最多持有 5 只；按沪深北 A 股 100 股整数倍模拟。手工买入委托最多 20% 权益；手工卖出可以按 100 股整数倍部分卖出，默认需要有效日 K。
- **离场保护**：ATR 相关止损约 4%～8%，约 10% 固定止盈、20 日线失守或 9 个交易日到期时发出退出信号。实际成交于下一可用交易日开盘，可能跳空，**止损阈值不是损失上限**。
- **成交假设**：按下一有效日开盘价、0.1% 不利滑点，最低 5 元佣金（万三）、卖出印花税万五计算，禁止当日买卖、无有效量/一字板不模拟成交。不联网发委托，不使用信号日收盘即成交的未来数据。

这不是经过严谨历史回测或实盘验证的“高胜率策略”。胜率应按有退市样本、复权校验、时点可得信息、成本滑点与样本外测试的分年分市场统计评估。不要把实验胜率当作可保证的收益。

## 模拟仓交互

资产总览、模拟买入/卖出、候选信号、持仓卖出按钮、委托状态、待成交撤单、交易流水、单独胜率和最大回撤统计、股票代码筛选以及 CSV / SQLite 导出。策略建议的批量订单需用户确认，手动买卖均是虚拟订单。后台数据同步和行情数据库逻辑未触及。

## 本地验证

纯 Java 可运行 `javac` 编译 `SwingStrategy` / `PaperTradeRules` 与测试后 `java` 执行用例；Python 回归执行 `python -m pytest -q tests`。完整 Android APK 需由 GitHub Actions 安装 Android SDK/Gradle 并在配置好独立密钥后构建。CI 上的实际数据源下载可能因为公开接口失效而失败，不代表策略合格性得到验证。
