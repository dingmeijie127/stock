# 潮汐量化 V0.3.4 · GitHub Actions Android APK

本项目是独立 Android App，包名 `cn.tidelab.quantpilot`，不会覆盖旧 QuantDesk。默认只做行情研究和模拟交易，不连接券商、不下真实订单。

## 手机操作（推荐）

1. 把本文件对应的 ZIP `TideQuant-v0.3.4-Android-Project.zip` 上传到仓库根目录，保持文件名不变。
2. 把随 ZIP 单独提供的 `build-apk.yml` 放到仓库路径 `.github/workflows/build-apk.yml`。如果该文件已经存在，用本版内容替换它。**只上传 ZIP 不会让 GitHub 执行 ZIP 里面的 workflow；仓库根目录必须有 `.github/workflows/build-apk.yml`。**
3. 在 GitHub 打开 **Actions → TideQuant Android APK → Run workflow**。也可以在提交 ZIP/YML 后自动触发。
4. 成功后在运行记录的 **Artifacts** 下载 `TideQuant-v0.3.4-Debug-APK`，解压得到 `TideQuant-v0.3.4-debug.apk`。

工作流会优先识别根目录的 `TideQuant-v0.3.4-Android-Project.zip`，自动解压后编译；也兼容旧文件名 `TideQuant-Android-Project.zip` 和 `TideQuant-Android-GitHub-Ready.zip`。如没有 ZIP，则从仓库根目录已展开的源码编译。

## 构建环境

- JDK 17
- Android SDK Platform 35 / Build Tools 35.0.0
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- GitHub Actions `android-actions/setup-android@v4`，避免旧版 SDK 初始化尝试安装废弃的 `tools` 包

工作流先校验项目结构、JavaScript 和模拟界面，再编译 APK；编译后会检查 APK 包名并上传产物。Python研究测试在APK上传后运行，因此研究测试失败时仍可下载已成功构建的APK，并查看Actions的测试日志。

## 可选的稳定 Release 签名

默认会构建Debug APK，GitHub Runner 自动签名。不同运行的Debug证书可能变化，更新时有可能需要先卸载旧Debug版（请先导出本地数据）。如果要长期覆盖升级，可配置仓库 Secrets：

- `TIDE_KEYSTORE_BASE64`
- `TIDE_STORE_PASSWORD`
- `TIDE_KEY_ALIAS`
- `TIDE_KEY_PASSWORD`

提供全部四项后，工作流会额外构建 `TideQuant-v0.3.4-Release-signed-APK`。绝不要把 `.jks`、密码或真实证券数据库提交到公开仓库。

## 数据导入与偏差提示

- 可从手机文件选择器导入 SQLite；旧 QuantDesk 的 `daily_bars` 和 `instruments` 可以自动识别。
- 导入时先复制到应用私有目录，做 SQLite `quick_check`，只有校验成功才替换之前导入的数据库。
- 如果 SQLite 文件头显示 WAL 模式，App会提示：只复制主 `.db` 可能漏掉仍留在 `-wal` 旁文件里的最新记录。请先从旧App完整导出，或确认已 checkpoint。
- 手机端只读取近期高成交股票子集，不能将其当作两年全市场回测；静态行业映射回填历史有前视偏差。
- 旧版 `dataset_rows.raw_json` 的供应商字段尚未经过实际数据核对，不会自动伪造成 TTM 财务指标。
- 当前没有随项目附带用户真实数据库。内置行情只用于程序测试，不代表真实A股胜率或收益。

## 研究测试

```bash
python -m pip install -r requirements-research.txt
python -m pytest research/tests -q
```

本环境能运行Python与JavaScript测试，但没有Android SDK/Gradle，不能宣称本地已编译APK。最终编译结果以GitHub Actions日志和产物为准。
