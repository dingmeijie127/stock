/* Native Android SQLite reader adapter. CSV fallback remains available for web previews. */
'use strict';
(function(){
  let schema=[], nativeRows=[], nativeFinancials=[], legacyQuantDesk=false, walWarning=false;
  let sectorByCode=new Map();
  try{sectorByCode=new Map(JSON.parse(localStorage.getItem('tide-sector-map-v03')||'[]'));}catch(e){sectorByCode=new Map();}
  const $e=id=>document.getElementById(id);
  const klineNames={code:['code','ts_code','symbol','stock_code','security_code','ticker','sec_code'],date:['date','trade_date','day','dt','trading_date'],open:['open','o','open_price'],high:['high','h','high_price'],low:['low','l','low_price'],close:['close','c','close_price'],amount:['amount','turnover','trade_amount','turnover_value','value'],volume:['volume','vol','trade_volume'],name:['name','stock_name','security_name'],sector:['sector','industry','industry_name','sector_name','concept','plate']};
  const fundamentalNames={code:klineNames.code,announcement_date:['announcement_date','announcement_day','ann_date','publish_date','disclosure_date'],revenue_yoy:['revenue_yoy','rev_yoy','revenue_growth'],net_profit_ttm:['net_profit_ttm','profit_ttm','net_profit','netprofit_ttm'],ocf_ttm:['ocf_ttm','operating_cashflow_ttm','cashflow_ttm','operating_cash_flow']};
  const needed=['code','date','open','high','low','close','amount'];
  const financeNeeded=['code','announcement_date','revenue_yoy','net_profit_ttm','ocf_ttm'];
  const isNative=!!window.TideBridge?.chooseSqlite;
  function status(s){$e('sqliteStatus').textContent=s;}
  function chooseKey(cols, candidates){const low=new Map(cols.map(c=>[c.toLowerCase(),c]));for(let c of candidates||[]){if(low.has(c))return low.get(c)}return ''}
  function fieldBox(target, names,tableName){
    const t=schema.find(x=>x.name===tableName),cols=t?.columns||[];
    target.innerHTML=Object.entries(names).map(([key,candidates])=>{
      const auto=chooseKey(cols,candidates);return `<label class="column-entry">${key}${(needed.includes(key)||financeNeeded.includes(key))?' *':''}<select data-col="${key}"><option value="">${auto?'不映射':'请选择对应字段'}</option>${cols.map(c=>`<option ${c===auto?'selected':''} value="${esc(c)}">${esc(c)}</option>`).join('')}</select></label>`;
    }).join('');
  }
  function selectedFields(container,table){const fields={table};for(let el of container.querySelectorAll('[data-col]')){if(el.value)fields[el.dataset.col]=el.value}return fields;}
  function renderTableChoices(){
    let current=$e('sqliteTable').value;
    for(let id of ['sqliteTable','sqliteFinTable']){
      let sel=$e(id);sel.innerHTML=schema.map(t=>`<option value="${esc(t.name)}">${esc(t.name)}</option>`).join('');
      if(schema.some(t=>t.name===current)&&id==='sqliteTable')sel.value=current;
      else{
        const candidates=id==='sqliteTable'?['bars','daily_bars','stock_daily','daily','kline','k_line','stock_kline','ohlcv']:['fundamentals','financial','finance','financials','fina_indicator','finance_metrics'];
        const hit=schema.find(t=>candidates.includes(t.name.toLowerCase()));if(hit)sel.value=hit.name;
      }
    }
    fieldBox($e('sqliteColumns'),klineNames,$e('sqliteTable').value);
    fieldBox($e('sqliteFinColumns'),fundamentalNames,$e('sqliteFinTable').value);
    $e('sqliteConfigure').hidden=false;
  }
  function nativeMessage(m){
    let p=m.payload||{};
    if(m.type==='schema'){
      schema=p.tables||[];legacyQuantDesk=!!p.legacyQuantDesk;walWarning=!!p.walWarning;renderTableChoices();
      const walNote=walWarning?' ⚠ 文件头显示WAL模式：若只导出.db而未checkpoint，最新数据可能仍在-wal文件中。请从旧App完整导出或先checkpoint。':'';
      if(legacyQuantDesk){
        status(`✓ 检测到旧QuantDesk：${p.fileName}，可自动关联日线与名称。行业映射 ${sectorByCode.size}只；财报raw_json仍须验证转换。${walNote}`);
        $e('sqliteLoad').textContent='一键读取旧QuantDesk日线（无需手动映射）';
        $e('finMsg').textContent='旧版dataset_rows是原始财报JSON，并非直接可用的TTM财务指标；须验证转换，不能误判基本面。';
      } else {
        $e('sqliteLoad').textContent='从SQLite加载近期行情';
        status(`✓ ${p.fileName} · ${(p.sizeBytes/1048576).toFixed(1)}MB · 检查到 ${schema.length} 张表。请确认字段映射和金额单位。${walNote}`);
      }
    }
    if(m.type==='progress'||m.type==='start')status(p.message||'执行中…');
    if(m.type==='error'){status('错误：'+p.message);nativeRows=[];nativeFinancials=[];toast(p.message||'导入出错');}
    if(m.type==='batch'){
      if(p.mode==='finance')nativeFinancials.push(...(p.rows||[]));
      else nativeRows.push(...(p.rows||[]));
      if(p.done%5000===0)status('已读取 '+p.done.toLocaleString()+' 行…');
    }
    if(m.type==='barsDone'){
      const rows=nativeRows;nativeRows=[];
      if(p.legacy){for(const r of rows)r.sector=sectorByCode.get(normalizeCode(r.code))||'未分类';}
      status(`已读取 ${p.count} 条行情（${p.symbols}只，${p.start}—${p.end}），正在分析…`);
      // Native callback comes after each prior batch on the Android UI queue.
      (async()=>{
        const computed=normalizeBars(rows); // shared validation and 180k upper bound
        finance=[];refreshFinanceIndex();
        bars=computed;info={demo:false,origin:'SQLite:'+p.source+'（活跃股近期子集）'};
        study=buildStudy(computed);
        await dbPut('bars',computed);await dbPut('info',info);await dbDel('finance');
        $e('finMsg').textContent='尚未导入该数据库的财报，真实买入信号将被限制。';
        $e('uploadMsg').textContent='SQLite子集：'+computed.length.toLocaleString()+' 条';
        renderMain();runAll(false);
        status((p.legacy
          ? `✓ 旧库日线${computed.length}条；缺成交额跳过${p.missingAmount}条；行业分类覆盖${sectorByCode.size}只。静态行业映射有历史前视偏差；财报raw_json仍须转换。`
          : `✓ 已加载 ${computed.length} 条日线，${study.days.length}日，股票 ${study.byCode.size}只。请再加载财报，才可进行基本面过滤。`) + (walWarning?' ⚠ 数据库文件头为WAL模式，需确认导出时已checkpoint。':''));
        toast('SQLite行情已加载');
      })().catch(e=>{status('分析失败：'+e.message);toast(e.message)});
    }
    if(m.type==='financeDone'){
      const rows=nativeFinancials;nativeFinancials=[];
      (async()=>{
        finance=normalizeFin(rows);refreshFinanceIndex();await dbPut('finance',finance);
        $e('finMsg').textContent='✓ SQLite财报 '+finance.length+' 条';renderMain();runAll(false);
        status('✓ SQLite财报 '+finance.length+' 条已加载，候选股基于公告日可得数据筛选');
        toast('财报加载完成');
      })().catch(e=>{status('财报分析失败：'+e.message);toast(e.message)});
    }
  }
  window.tideDbReceive=nativeMessage;
  $e('sectorMapStatus').textContent=sectorByCode.size
    ? `已保存在本机的行业映射：${sectorByCode.size}只。注意：现在的行业划分用于过去回测有前视偏差。`
    : '尚未导入行业分类；旧数据库自身没有行业字段。';
  $e('sectorFile').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try {
      const rows=parseCSV(await file.text());const map=new Map();
      for(const r of rows){const code=normalizeCode(r.code||''),sector=String(r.sector||'').trim();
        if(/^\d{6}$/.test(code)&&sector)map.set(code,sector);}
      if(!map.size)throw Error('必须包含code,sector两列，代码为6位');
      sectorByCode=map;localStorage.setItem('tide-sector-map-v03',JSON.stringify([...map]));
      $e('sectorMapStatus').textContent=`✓ 行业映射${map.size}只。请重新读取SQLite日线以应用映射；当前静态映射存在历史前视偏差。`;
      toast('行业映射已载入：'+map.size+'只');
    }catch(err){toast('行业CSV解析失败：'+err.message)}
  });
  $e('sqliteChoose').addEventListener('click',()=>{if(!isNative){status('请安装Android App后使用此功能；浏览器版可导入CSV。');return;}status('正在打开文件选择器…');window.TideBridge.chooseSqlite()});
  $e('sqliteTable').addEventListener('change',()=>fieldBox($e('sqliteColumns'),klineNames,$e('sqliteTable').value));
  $e('sqliteFinTable').addEventListener('change',()=>fieldBox($e('sqliteFinColumns'),fundamentalNames,$e('sqliteFinTable').value));
  $e('sqliteLoad').addEventListener('click',()=>{
    if(!isNative)return toast('请在Android App里执行');
    const fields=selectedFields($e('sqliteColumns'),$e('sqliteTable').value);
    const missing=needed.filter(f=>!fields[f]);
    if(!legacyQuantDesk && missing.length)return toast('缺少映射：'+missing.join(','));
    const days=+$e('sqliteDays').value,symbols=+$e('sqliteSymbols').value;
    if(days*symbols>180000)return toast('窗口×股票数量不能超过180000，请缩小范围');
    const accept=confirm('请确认amount单位是人民币元、价格是历史真实可交易价（并非仅前复权的虚拟价）；错误单位会让成交筛选和回测失真。将导入近期活跃股票子集，而不是完整两年全市场。继续吗？');
    if(!accept)return;
    nativeRows=[];fields.days=days;fields.symbols=symbols;status('正从SQLite加载近期窗口…');
    if(legacyQuantDesk)window.TideBridge.readLegacySqliteSnapshot(JSON.stringify({days,symbols}));
    else window.TideBridge.readSqliteSnapshot(JSON.stringify(fields));
  });
  $e('sqliteLoadFin').addEventListener('click',()=>{
    if(!isNative)return toast('请在Android App里执行');
    if(legacyQuantDesk)return toast('旧库财报使用dataset_rows.raw_json，尚不能直接当成TTM；需先做财务字段转换与公告日验证');
    const fields=selectedFields($e('sqliteFinColumns'),$e('sqliteFinTable').value);
    const missing=financeNeeded.filter(f=>!fields[f]);if(missing.length)return toast('财报字段不齐：'+missing.join(','));
    nativeFinancials=[];status('正在读取财报…');window.TideBridge.readSqliteFinance(JSON.stringify(fields));
  });
  if(isNative){window.TideBridge.restoreSqlite();}else{status('浏览器演示不支持直接读取SQLite；安装Android版后可选择.db文件，或使用下方CSV导入。');}
})();
