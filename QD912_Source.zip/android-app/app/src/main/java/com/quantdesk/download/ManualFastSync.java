package com.quantdesk.download;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

/** Explicit foreground fast sync: no WorkManager KEEP queue, no fake 100% success.
 *  Downloads only the latest closed day's quotes and limited missing recent tails.
 *  Historical or old/long gaps are explicitly left for the full-repair action.
 */
public final class ManualFastSync {
    private ManualFastSync(){}
    public interface Status {void show(String message,int processed,int total);}
    private static final class Page {
        final List<String> symbols;
        final Map<String,Bar> bars;
        final String error;
        Page(List<String> symbols,Map<String,Bar> bars,String error){
            this.symbols=symbols;this.bars=bars;this.error=error;
        }
    }
    private static Future<Page> submit(CompletionService<Page> done,List<String> symbols,LocalDate date){
        return done.submit(()->{
            try{return new Page(symbols,TencentBatchQuotes.fetch(symbols,date),null);}
            catch(Exception e){return new Page(symbols,new HashMap<>(),e.getClass().getSimpleName()+": "+e.getMessage());}
        });
    }
    public static void run(MarketDb db,LocalDate day,BooleanSupplier paused,Status status) throws Exception {
        String target=day.toString();
        MarketDb.FastPlan plan=db.planManualDaily(target);
        int total=plan.pending.size(),saved=0,failedPages=0,received=0;
        status.show("本地SQLite已查询：已有目标日K线 "+plan.alreadyCurrent+" 只；待增量 "+total+" 只",0,total);
        if(total==0){
            String detail="快速增量结束：全部股票已有目标日 "+target+" 的K线；未核实历史内部缺口，请用全量补齐";
            db.autoState(target,"done","",detail);db.log("FAST",detail);
            status.show(detail,0,0);return;
        }
        List<String> symbols=new ArrayList<>();
        for(MarketDb.FastCandidate s:plan.pending){
            try{symbols.add(TencentBatchQuotes.symbol(s.code,s.exchange));}
            catch(IllegalArgumentException unsupported){
                // BJ historical provider is handled by full repair; do not pretend that quote was checked.
            }
        }
        List<List<String>> pages=TencentBatchQuotes.pages(symbols);
        ExecutorService pool=Executors.newFixedThreadPool(4);
        CompletionService<Page> completion=new ExecutorCompletionService<>(pool);
        List<Future<Page>> pending=new ArrayList<>();
        long deadline=System.currentTimeMillis()+4L*60*1000;
        int next=0,finished=0;
        try{
            while(next<pages.size()&&pending.size()<8)pending.add(submit(completion,pages.get(next++),day));
            while(!pending.isEmpty()&&!paused.getAsBoolean()&&System.currentTimeMillis()<deadline){
                Future<Page> future=completion.poll(1000,TimeUnit.MILLISECONDS);
                if(future==null)continue;
                pending.remove(future);
                Page result=future.get();finished++;
                if(result.error!=null){
                    failedPages++;
                    db.log("FAST_ERROR","行情批次 "+finished+"/"+pages.size()+" "+result.error);
                }else{
                    Set<String> requested=new HashSet<>();
                    for(String symbol:result.symbols)requested.add(symbol.substring(2));
                    result.bars.keySet().retainAll(requested);
                    if(!result.bars.isEmpty())saved+=db.saveFastQuoteBatch(result.bars,target);
                    received+=result.bars.size();
                }
                if(finished%2==0||finished==pages.size())status.show(
                    "快速增量：批次 "+finished+"/"+pages.size()+"，有效收盘报价 "+received+
                    "，新入库K线 "+saved+"，网络错误批次 "+failedPages,
                    Math.min(total,finished*TencentBatchQuotes.BATCH_SIZE),total);
                if(next<pages.size())pending.add(submit(completion,pages.get(next++),day));
            }
        }finally{
            for(Future<Page> f:pending)f.cancel(true);
            pool.shutdownNow();
        }
        // Append missed recent trading sessions. Do not let a new last-day quote hide
        // 2-10 day holes: use the original SQLite last day from BEFORE the quote stage.
        int tailAttempted=0,tailFailed=0,deferred=0;
        List<String> aSessions=db.referenceDays("A",day.minusDays(14).toString(),target);
        List<String> hkSessions=db.referenceDays("HK",day.minusDays(14).toString(),target);
        for(MarketDb.FastCandidate stock:plan.pending){
            if(paused.getAsBoolean()||System.currentTimeMillis()>=deadline)break;
            if(stock.latest==null||stock.latest.compareTo(day.minusDays(14).toString())<0){
                deferred++;continue; // Do not turn a quick update into a 2-year backfill.
            }
            List<String> sessions="HK".equals(stock.exchange)?hkSessions:aSessions;
            if(sessions.isEmpty())continue;
            Set<String> nowStored=new HashSet<>(db.barDays(stock.code,stock.latest,target));
            boolean hasHole=false;
            for(String session:sessions){
                if(session.compareTo(stock.latest)>0&&session.compareTo(target)<=0&&!nowStored.contains(session)){
                    hasHole=true;break;
                }
            }
            if(!hasHole)continue;
            if(tailAttempted>=80){deferred++;continue;}
            tailAttempted++;
            try{
                LocalDate first=LocalDate.parse(stock.latest).plusDays(1);
                DailySources.Result bars=DailySources.downloadFast(stock.code,stock.exchange,first,day);
                int newBars=db.appendDailyBars(stock.code,first.toString(),target,bars.bars);
                saved+=newBars;
                if(bars.skippedBars>0){tailFailed++;db.log("FAST_PARTIAL",stock.code+" 最近尾部有无效日K "+bars.skippedBars+" 根");}
            }catch(Exception e){
                tailFailed++;
                if(tailFailed<=12)db.log("FAST_ERROR",stock.code+" 最近日K补尾失败："+e.getMessage());
            }
            if(tailAttempted%10==0)status.show("正在补最近交易日缺口："+tailAttempted+
                " 只，新增 "+saved+" 根，失败 "+tailFailed,total,total);
        }
        int stillMissing=db.autoMissingBars(target);
        String detail="快速增量结束：目标已收盘日 "+target+"；新增 "+saved+
            " 根，批量请求 "+finished+"/"+pages.size()+"，请求错误 "+failedPages+
            " 批，近期补尾 "+tailAttempted+" 只，补尾失败 "+tailFailed+
            "，需全量历史处理 "+deferred+" 只，目标日未取得收盘价 "+stillMissing+
            " 只（含停牌/未上市/源延迟）；可再次点快速增量重试";
        String phase=paused.getAsBoolean()?"paused":
            finished<pages.size()||failedPages>0||tailFailed>0||deferred>0||stillMissing>0?"partial":"done";
        db.autoState(target,phase,"",detail);
        db.log("FAST",detail);
        status.show(detail,Math.min(total,finished*TencentBatchQuotes.BATCH_SIZE),total);
    }
}
