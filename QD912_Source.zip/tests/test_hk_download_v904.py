"""Check HK downloader regression by source and partial checkpoint SQL contract.
Actual provider networking and Android runtime still require device acceptance.
"""
from pathlib import Path
import re,sqlite3
P=Path(__file__).resolve().parents[1]
J=P/'android-app/app/src/main/java/com/quantdesk/download'


def test_hk_independent_sources_and_order():
    src=(J/'HongKongSources.java').read_text()
    assert '/appstock/app/hkfqkline/get?param=hk' in src
    assert 'parseTencent(new JSONObject(payload)' in src
    assert 'stock.optJSONArray("day")' in src
    assert 'adjusted series refused' in src
    assert 'parseYahooChecked' in src
    assert 'HKBarQuality.validOrNull' in src
    assert src.index('try{return eastmoney(code,from,to,fast);}') < src.index('try{return tencent(code,from,to,fast);}') < src.index('try{return yahoo(code,from,to,fast);}')


def test_partial_rows_save_and_stay_retryable():
    db=(J/'MarketDb.java').read_text()
    service=(J/'HarvestService.java').read_text()
    worker=(J/'DailyUpdateWorker.java').read_text()
    assert 'void writePartial(' in db
    assert "status='partial'" in db
    assert "oldestIncompleteStart" in db
    assert 'HistoryGapPlanner.plan' in service
    assert 'TencentBatchQuotes.symbol(c.code,c.exchange)' in worker  # historical gaps or IPOs do not block latest-day quote
    assert 'result.skippedBars>0' in service and 'db.appendDailyBars' in service and 'db.writeFailure' in service
    assert 'result.data.skippedBars>0' in worker and 'db.saveFastTail' in worker
    assert 'db.verifiedCount(from,to)' in service
    sql="INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'partial',?,1,?,?)"
    c=sqlite3.connect(':memory:')
    c.execute('CREATE TABLE tasks(code TEXT,start_day TEXT,end_day TEXT,status TEXT,rows INTEGER,attempts INTEGER,error TEXT,updated INTEGER,PRIMARY KEY(code,start_day,end_day))')
    c.execute(sql,('00700','2024-10-24','2026-10-24',490,'invalid Yahoo bar:1',123))
    assert c.execute("SELECT count(*) FROM tasks WHERE status='complete'").fetchone()[0] == 0
    assert c.execute("SELECT min(start_day) FROM tasks WHERE code=? AND status='partial'",('00700',)).fetchone()[0]=='2024-10-24'


def test_git_hk_parser_runs_in_ci():
    wf=(P/'.github/workflows/QD912_Build.yml').read_text()
    assert 'HKProvidersTest' in wf and 'jsonstub/org/json' in wf
    assert "z=Path('QD912_Source.zip')" in wf
