潮汐量化 v0.5.0 · 手机GitHub编译

下载总包，只解压总ZIP一次。
上传：TideQuant-v0.5.0-Android-Project.zip 到仓库根目录（不要解压第二层）。
上传：.github/workflows/build-apk.yml 到仓库相同路径。旧工作流请替换。仓库已有v0.4压缩包不用删除，工作流优先选择v0.5。
Actions -> TideQuant Android APK -> Run workflow -> Artifacts -> TideQuant-v0.5.0-Debug-APK。
注意：只上传一个总ZIP而没有把YML放到.github/workflows时，GitHub不会自动识别和运行工作流。

安装后：数据中心导入旧QuantDesk SQLite；如果要启用完整热点与基本面策略，再导入按历史日期的行业CSV和已披露TTM财报CSV，或者经核对的原库JSON键映射。
导出整库报告JSON，然后分析每个模型已平仓笔数、样本外表现和最大回撤，不要先投入真钱。

当前未收到你的真实大数据库，也尚未真正编译过GitHub APK；本交付是已测试的工程文件，不是可保证盈利的成品。
