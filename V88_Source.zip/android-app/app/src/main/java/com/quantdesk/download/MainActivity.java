package com.quantdesk.download;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Collection-only UI: no analytics, webview, or ornamental buttons. */
public final class MainActivity extends Activity {
    private static final int EXPORT_DB=2101, EXPORT_LOG=2102, POST_NOTIFICATIONS_REQUEST=2103;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status,counts,log,diagnostic;
    private ProgressBar progress;
    private boolean visible;
    private final Runnable refresh = new Runnable(){
        @Override public void run(){if(visible){refreshUI();handler.postDelayed(this,1600);}}
    };
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setPadding(dp(4),dp(7),dp(4),dp(7));return t;}
    private void addButton(LinearLayout root,String name,View.OnClickListener click){
        Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setOnClickListener(click);
        root.addView(b,new LinearLayout.LayoutParams(-1,-2));
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(12),dp(16),dp(12));
        ScrollView scroll=new ScrollView(this);scroll.addView(page);setContentView(scroll);
        TextView title=text("QuantDesk 8.8 · A 股两年日 K 采集",21);page.addView(title);
        page.addView(text("只做一件事：真实股票目录 → 历史日线 → SQLite。需要网络；可用 Wi-Fi 或移动数据。",14));
        status=text("检查数据库中…",16);page.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);page.addView(progress);
        counts=text("股票：0  成功：0  失败：0  日K：0",15);page.addView(counts);
        diagnostic=text("当前：尚未开始",14);page.addView(diagnostic);
        addButton(page,"开始 / 继续下载",v->start());
        addButton(page,"暂停下载",v->pause());
        addButton(page,"导出 SQLite",v->export(EXPORT_DB));
        addButton(page,"导出日志",v->export(EXPORT_LOG));
        page.addView(text("最新采集日志（自动刷新）",17));
        log=text("暂无记录",12);log.setTextIsSelectable(true);page.addView(log);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},POST_NOTIFICATIONS_REQUEST);
        }
    }
    private void start(){
        try{
            Intent action=new Intent(this,HarvestService.class);action.setAction(HarvestService.START);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(action);else startService(action);
            Toast.makeText(this,"已启动采集，请查看进度与日志",Toast.LENGTH_SHORT).show();
            status.setText("已请求启动，正在加载本地股票目录…");
        }catch(Exception e){status.setText("启动失败："+e.getMessage());}
    }
    private void pause(){
        Intent action=new Intent(this,HarvestService.class);action.setAction(HarvestService.PAUSE);
        try{startService(action);status.setText("正在暂停，等待当前股票请求结束…");}
        catch(Exception e){status.setText("暂停失败："+e.getMessage());}
    }
    private void refreshUI(){
        try(MarketDb db=new MarketDb(this)){
            JSONObject result=db.overview();
            int total=result.optInt("total"),done=result.optInt("done"),failed=result.optInt("failed"),bars=result.optInt("bars");
            String phase=result.optString("phase","not_started"),detail=result.optString("detail","");
            progress.setProgress(total==0?0:Math.min(100,(done+failed)*100/total));
            counts.setText(String.format(Locale.CHINA,"股票目录：%,d   已成功：%,d   失败：%,d   日K：%,d",total,done,failed,bars));
            status.setText("状态："+phase+"   采集范围："+result.optString("start","")+" 至 "+result.optString("end",""));
            diagnostic.setText("当前："+result.optString("active","")+"\n"+detail);
            if(HarvestService.RUNNING.get())diagnostic.append("\n"+HarvestService.LIVE);
            String recent=db.logs(35);log.setText(recent.isEmpty()?"暂无日志":recent);
        }catch(Exception e){status.setText("数据库读取错误："+e.getMessage());}
    }
    private void export(int type){
        if(type==EXPORT_DB && HarvestService.RUNNING.get()){
            Toast.makeText(this,"请先暂停并等待状态变成已暂停，再导出完整数据库",Toast.LENGTH_LONG).show();return;
        }
        Intent picker=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        picker.setType(type==EXPORT_DB?"application/octet-stream":"text/plain");
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.putExtra(Intent.EXTRA_TITLE,type==EXPORT_DB?"QuantDesk88-Ashare.sqlite3":"QuantDesk88-采集日志.txt");
        try{startActivityForResult(picker,type);}catch(ActivityNotFoundException ex){
            Toast.makeText(this,"没有可用的文件保存应用",Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try(OutputStream output=getContentResolver().openOutputStream(uri,"w")){
            if(output==null)throw new IllegalStateException("无法打开保存文件");
            if(request==EXPORT_DB){
                if(HarvestService.RUNNING.get())throw new IllegalStateException("后台仍在采集，请先暂停");
                try(MarketDb db=new MarketDb(this)){db.checkpoint();}
                File database=getDatabasePath(MarketDb.NAME);
                try(FileInputStream in=new FileInputStream(database)){
                    byte[] b=new byte[65536];int n;while((n=in.read(b))>=0){if(n>0)output.write(b,0,n);}
                }
            }else if(request==EXPORT_LOG){
                String txt;
                try(MarketDb db=new MarketDb(this)){txt=db.logs(3000);}
                output.write(txt.getBytes(StandardCharsets.UTF_8));
            }
            output.flush();Toast.makeText(this,"已导出到所选位置",Toast.LENGTH_LONG).show();
        }catch(Exception ex){Toast.makeText(this,"导出失败："+ex.getMessage(),Toast.LENGTH_LONG).show();}
    }
    @Override protected void onResume(){super.onResume();visible=true;handler.removeCallbacks(refresh);refresh.run();}
    @Override protected void onPause(){visible=false;handler.removeCallbacks(refresh);super.onPause();}
}
