package com.quantdesk.download;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import org.json.JSONObject;
import java.util.List;
import java.util.ArrayList;

/** Android-local SQLite. Each security's daily bars and success checkpoint commit atomically. */
public final class MarketDb extends SQLiteOpenHelper {
    public static final String NAME="quantdesk-a-share-2y.sqlite3";
    public MarketDb(Context context){super(context,NAME,null,1);setWriteAheadLoggingEnabled(true);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE instruments(code TEXT PRIMARY KEY,name TEXT NOT NULL,exchange TEXT NOT NULL,source TEXT NOT NULL)");
        d.execSQL("CREATE TABLE daily_bars(code TEXT NOT NULL,day TEXT NOT NULL,o REAL NOT NULL,h REAL NOT NULL,l REAL NOT NULL,c REAL NOT NULL,vol REAL NOT NULL,vol_unit TEXT NOT NULL,amount REAL,provider TEXT NOT NULL,raw TEXT NOT NULL,PRIMARY KEY(code,day))");
        d.execSQL("CREATE INDEX daily_by_day ON daily_bars(day,code)");
        d.execSQL("CREATE TABLE tasks(code TEXT NOT NULL,start_day TEXT NOT NULL,end_day TEXT NOT NULL,status TEXT NOT NULL,rows INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,error TEXT,updated INTEGER NOT NULL,PRIMARY KEY(code,start_day,end_day))");
        d.execSQL("CREATE TABLE log(id INTEGER PRIMARY KEY AUTOINCREMENT,at INTEGER NOT NULL,level TEXT NOT NULL,message TEXT NOT NULL)");
        d.execSQL("CREATE TABLE state(id INTEGER PRIMARY KEY CHECK(id=1),start_day TEXT,end_day TEXT,phase TEXT,active TEXT,detail TEXT,updated INTEGER)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int old,int updated) { throw new IllegalStateException("No destructive migrations permitted"); }
    public int countSymbols(){return count("SELECT count(*) FROM instruments",null);}
    public int countBars(){return count("SELECT count(*) FROM daily_bars",null);}
    private int count(String sql,String[] args){try(Cursor c=getReadableDatabase().rawQuery(sql,args)){return c.moveToFirst()?c.getInt(0):0;}}
    public int completed(String start,String end){return count("SELECT count(*) FROM tasks WHERE start_day=? AND end_day=? AND status='complete'",new String[]{start,end});}
    public int failed(String start,String end){return count("SELECT count(*) FROM tasks WHERE start_day=? AND end_day=? AND status='failed'",new String[]{start,end});}
    public String[] windowOrNew(String newStart,String newEnd){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT start_day,end_day,phase FROM state WHERE id=1",null)){
            if(c.moveToFirst()){
                String prior=c.getString(2);
                if(("running".equals(prior)||"paused".equals(prior)||"error".equals(prior)||"partial".equals(prior)) &&
                    c.getString(0)!=null&&c.getString(1)!=null) return new String[]{c.getString(0),c.getString(1)};
            }
        }
        return new String[]{newStart,newEnd};
    }
    public void state(String start,String end,String phase,String active,String detail){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO state(id,start_day,end_day,phase,active,detail,updated) VALUES(1,?,?,?,?,?,?)",
             new Object[]{start,end,phase,active,detail,System.currentTimeMillis()});
    }
    public JSONObject overview(){
        JSONObject o=new JSONObject();
        try {
            String start="",end="",phase="not_started",active="",detail="";
            try(Cursor c=getReadableDatabase().rawQuery("SELECT start_day,end_day,phase,active,detail FROM state WHERE id=1",null)){
                if(c.moveToFirst()) { start=c.getString(0);end=c.getString(1);phase=c.getString(2);active=c.getString(3);detail=c.getString(4); }
            }
            o.put("start",start);o.put("end",end);o.put("phase",phase);o.put("active",active);o.put("detail",detail);
            o.put("total",countSymbols());o.put("bars",countBars());
            o.put("done",completed(start,end));o.put("failed",failed(start,end));
        }catch(Exception ignored){}
        return o;
    }
    public static final class Security {
        public final String code,exchange;
        Security(String code,String exchange){this.code=code;this.exchange=exchange;}
    }
    /** Snapshot the pending list BEFORE committing new task rows; avoids a mutable SQLite cursor. */
    public List<Security> remaining(String start,String end){
        List<Security> result=new ArrayList<>();
        try(Cursor cursor=getReadableDatabase().rawQuery(
            "SELECT s.code,s.exchange FROM instruments s WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.code=s.code AND t.start_day=? AND t.end_day=? AND t.status='complete') ORDER BY s.code",
            new String[]{start,end})){
            while(cursor.moveToNext())result.add(new Security(cursor.getString(0),cursor.getString(1)));
        }
        return result;
    }
    public void writeSuccess(String code,String start,String end,List<Bar> rows) {
        if(rows.isEmpty())throw new IllegalArgumentException("Empty history cannot be complete");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            SQLiteStatement stmt=db.compileStatement("INSERT OR REPLACE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            try {
                for(Bar b:rows){
                    if(b.date.compareTo(start)<0||b.date.compareTo(end)>0)throw new IllegalArgumentException("Out of range K-line");
                    stmt.clearBindings();stmt.bindString(1,code);stmt.bindString(2,b.date);
                    stmt.bindDouble(3,b.open);stmt.bindDouble(4,b.high);stmt.bindDouble(5,b.low);
                    stmt.bindDouble(6,b.close);stmt.bindDouble(7,b.volume);stmt.bindString(8,b.volumeUnit);
                    if(b.amount!=null)stmt.bindDouble(9,b.amount);else stmt.bindNull(9);
                    stmt.bindString(10,b.source);stmt.bindString(11,b.raw);
                    stmt.executeInsert();
                }
            }finally{stmt.close();}
            db.execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',?,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,NULL,?)",
                    new Object[]{code,start,end,rows.size(),code,start,end,System.currentTimeMillis()});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public void writeFailure(String code,String start,String end,String message){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'failed',0,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,?,?)",
                new Object[]{code,start,end,code,start,end,message,System.currentTimeMillis()});
    }
    public void log(String level,String message){
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("INSERT INTO log(at,level,message) VALUES(?,?,?)",new Object[]{System.currentTimeMillis(),level,message});
        db.execSQL("DELETE FROM log WHERE id < (SELECT coalesce(max(id),0)-3000 FROM log)");
    }
    public String logs(int limit){
        StringBuilder out=new StringBuilder();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT datetime(at/1000,'unixepoch','localtime'),level,message FROM log ORDER BY id DESC LIMIT "+Math.max(1,Math.min(limit,3000)),null)){
            while(c.moveToNext()){out.append(c.getString(0)).append(' ').append(c.getString(1)).append(' ').append(c.getString(2)).append('\n');}
        }
        return out.toString();
    }
    public void checkpoint(){SQLiteDatabase db=getWritableDatabase();try(Cursor c=db.rawQuery("PRAGMA wal_checkpoint(FULL)",null)){if(c.moveToFirst()&&c.getInt(0)!=0)throw new IllegalStateException("SQLite checkpoint busy");}}
}
