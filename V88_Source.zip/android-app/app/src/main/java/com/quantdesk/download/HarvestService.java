package com.quantdesk.download;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicBoolean;

/** Foreground harvest: persistent job status and per-stock atomic SQLite transactions. */
public final class HarvestService extends Service {
    public static final String START="com.quantdesk.download.START",PAUSE="com.quantdesk.download.PAUSE";
    public static final AtomicBoolean RUNNING=new AtomicBoolean(false);
    public static volatile String LIVE="尚未开始";
    private final AtomicBoolean paused=new AtomicBoolean(false);
    private PowerManager.WakeLock wake;
    private String from="",to="";
    private long lastNotify;
    private long lastWakeRenew;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent==null)return START_NOT_STICKY;
        if(PAUSE.equals(intent.getAction())){
            if(RUNNING.get()){
                paused.set(true);LIVE="正在暂停（当前请求完成后停止）";notifyProgress(0,0);
            }
            return START_NOT_STICKY;
        }
        if(!START.equals(intent.getAction()))return START_NOT_STICKY;
        if(!RUNNING.compareAndSet(false,true))return START_NOT_STICKY;
        paused.set(false);LIVE="服务启动，准备本地股票清单";
        notifyProgress(0,0); // startForeground is called immediately, before network and database work
        try{
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"qd88:daily-download");wake.setReferenceCounted(false);wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();}
        }catch(Exception e){Log.w("QD88","Wake lock unavailable",e);}
        new Thread(this::harvest,"qd88-fetch-thread").start();
        return START_NOT_STICKY;
    }
    private void notifyProgress(int complete,int total){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(manager==null)return;
        String channel="qd88_history";
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(channel,"A股历史数据下载",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,3,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("QuantDesk · 两年A股日线")
            .setContentText(LIVE.length()>85?LIVE.substring(0,85):LIVE)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
            .setProgress(Math.max(1,total),complete,total<=0).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(880,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(880,n);
    }
    private void update(MarketDb db,String stage,String code,String detail,int completed,int total){
        LIVE=detail;db.state(from,to,stage,code,detail);
        long now=System.currentTimeMillis();
        if(now-lastNotify>=2500 || !"running".equals(stage)){
            lastNotify=now;notifyProgress(completed,total);
        }
    }
    private void harvest() {
        MarketDb db=new MarketDb(getApplicationContext());
        int consecutiveFailed=0;
        try{
            LocalDate today=LocalDate.now(ZoneId.of("Asia/Shanghai"));
            String[] dates=db.windowOrNew(today.minusYears(2).toString(),today.toString());
            from=dates[0];to=dates[1];
            db.state(from,to,"running","","正在导入安装包内 A 股清单");
            db.log("INFO","开始/恢复："+from+" 至 "+to);
            int total=Universe.install(getApplicationContext(),db);
            db.log("INFO","本地A股目录加载完成："+total+"只；无需联网请求股票目录");
            update(db,"running","","已加载 "+total+" 只股票，开始下载历史日K",db.completed(from,to),total);
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            if(cm==null||cm.getActiveNetwork()==null)
                throw new IllegalStateException("网络未连接：股票目录已加载，但无法下载K线；联网后继续");
            int done=db.completed(from,to);
            LocalDate a=LocalDate.parse(from),b=LocalDate.parse(to);
            java.util.List<MarketDb.Security> pending=db.remaining(from,to);
            {
                int counter=0;
                for(MarketDb.Security stock:pending){
                    if(paused.get()){
                        db.log("INFO","用户暂停。已完成 "+done+"/"+total);
                        update(db,"paused","","已暂停，下次点击开始继续",done,total);return;
                    }
                    if(wake!=null && System.currentTimeMillis()-lastWakeRenew>8L*60*1000){
                        wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();
                    }
                    String code=stock.code,exchange=stock.exchange;
                    update(db,"running",code,"下载 "+code+"  ("+done+"/"+total+")",done,total);
                    try {
                        DailySources.Result result=DailySources.downloadBars(code,exchange,a,b);
                        db.writeSuccess(code,from,to,result.bars);
                        done++;consecutiveFailed=0;
                        db.log("OK",code+" "+result.provider+" 写入 "+result.bars.size()+" 根日K ("+done+"/"+total+")");
                        if(done%10==0)update(db,"running",code,"成功 "+done+"/"+total+"；日K累计 "+db.countBars(),done,total);
                    }catch(Exception e){
                        consecutiveFailed++;
                        String error=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
                        if(error.length()>500)error=error.substring(0,500);
                        db.writeFailure(code,from,to,error);
                        db.log("ERROR",code+" " +error);
                        if(consecutiveFailed>=15){
                            String stop="连续15只股票的所有接口失败，已停止以避免空跑；查看日志中的HTTP/网络错误";
                            db.log("ERROR",stop);
                            update(db,"error",code,stop,done,total);return;
                        }
                    }
                    counter++;
                    if(counter%10==0)update(db,"running",code,"进度 "+done+"/"+total+"；失败 "+db.failed(from,to),done,total);
                    Thread.sleep(550L);
                }
            }
            String finish="采集批次结束：成功 "+db.completed(from,to)+"/"+total+
                "，失败 "+db.failed(from,to)+"，日K "+db.countBars()+" 条；失败股票可再次重试";
            db.log("INFO",finish);
            update(db,db.failed(from,to)>0?"partial":"complete","",finish,db.completed(from,to),total);
        }catch(InterruptedException e){
            Thread.currentThread().interrupt();
            update(db,"paused","","任务被系统中断，已保存完成检查点",db.completed(from,to),db.countSymbols());
        }catch(Exception e){
            String reason=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
            db.log("ERROR","采集中断："+reason);
            update(db,"error","","采集中断："+reason,db.completed(from,to),db.countSymbols());
        }finally{
            db.close();RUNNING.set(false);
            if(wake!=null&&wake.isHeld())wake.release();
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    @Override public void onDestroy(){paused.set(true);if(wake!=null&&wake.isHeld())wake.release();super.onDestroy();}
}
