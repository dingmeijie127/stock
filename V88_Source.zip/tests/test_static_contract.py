from pathlib import Path

P=Path(__file__).resolve().parents[1]
J=P/'android-app/app/src/main/java/com/quantdesk/download'

def test_no_runtime_universe_network_gate():
    svc=(J/'HarvestService.java').read_text()
    assert 'Universe.install' in svc
    assert 'downloadBars' in svc
    assert 'startForeground' in svc
    assert 'writeSuccess' in svc
    assert 'writeFailure' in svc
    assert 'stock_zh_a_spot_em' not in svc

def test_manifest_service_permissions():
    text=(P/'android-app/app/src/main/AndroidManifest.xml').read_text()
    for required in ['android.permission.INTERNET','android.permission.FOREGROUND_SERVICE_DATA_SYNC','foregroundServiceType="dataSync"']:
        assert required in text

def test_build_does_not_use_old_sources():
    text=(P/'.github/workflows/QD88_Build.yml').read_text()
    assert 'QD88_Source.zip' in text
    assert 'build_universe.py' in text
    assert 'upload-artifact@v4' in text
    assert 'workflow_dispatch:' in text
    assert 'QD872_Source.zip' not in text

def test_ui_only_collection_controls():
    text=(J/'MainActivity.java').read_text()
    for phrase in ['开始 / 继续下载','暂停下载','导出 SQLite','导出日志']:
        assert phrase in text
    assert 'AnalysisActivity' not in text
