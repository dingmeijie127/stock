# 潮汐量化 V0.3 · GitHub Actions APK 构建版

**本ZIP已经包含 `.github/workflows/build-apk.yml`，GitHub仓库根目录直接可识别。**

## A. GitHub Actions 打包（不需要本机Android Studio）

1. 解压ZIP。创建一个新的**私有** GitHub 仓库（建议私有，因为策略代码属于你的资产）。
2. 将解压后的**文件夹里的内容**上传到仓库根目录，务必能在仓库根目录看到 `settings.gradle`、`app/`、`research/` 和隐藏目录 `.github/workflows/build-apk.yml`。
   **不要只上传ZIP**，也不要多嵌套一层文件夹。网页直接上传文件时可能丢失目录结构，推荐 GitHub Desktop 或 `git push`。
3. 在GitHub打开 **Actions → Build TideQuant Android APK → Run workflow**，或向 `main`/`master` 推送提交。
4. 打开成功的工作流运行记录，展开下方 **Artifacts → TideQuant-v0.3-debug-apk** 下载压缩包，解压得到 `app-debug.apk`。
5. 将 APK 传到手机并安装。App包名为 `cn.tidelab.quantpilot`，**与旧QuantDesk独立共存**。

首次无需设置签名密钥：GitHub Actions 的 `assembleDebug` 会自动用debug证书签名。不同工作流运行环境的debug证书可能不同，后续更新可能提示签名冲突，必须卸载该新App后再安装（本地数据将丢失，先导出研究数据）。

## B. 可选：持久独立Release签名（推荐长期使用）

用你自己保管的keystore签名。不要在仓库公开私钥。先在自己电脑用`keytool -genkeypair -v -keystore tide-release.jks -alias tide -keyalg RSA -keysize 3072 -validity 10000`生成。把密钥库base64编码为GitHub仓库Secrets中的`TIDE_KEYSTORE_BASE64`，并设置`TIDE_STORE_PASSWORD`、`TIDE_KEY_ALIAS`、`TIDE_KEY_PASSWORD`。重新运行工作流，会额外得到`TideQuant-v0.3-release-signed`。

**更新应用必须一直用同一个包名和签名密钥**。换一把签名密钥无法直接覆盖升级，而不同包名才是与旧App并存的决定因素。

## C. 旧 APK 数据库兼容性

对最早上传的`QuantDesk922-FiveStrategies-Ashare-Paper.apk`中的DEX字符串进行结构检查，确认以下原表：

- `daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw)`
- `instruments(code,name,exchange,source)`
- `dataset_rows(code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at)`

本版手机端自动识别**旧日线+股票信息**，只读取沪、深、北A股，不将港股混入A股规则；严格丢弃缺失有效`amount`的行，不使用`volume*close`伪造真实成交额。为防止内存不足，手机只读取近期高成交股子集，不能拿此作为两年全市场策略胜率。

**旧版APK并不包含实际.db文件**；Android新App也不能直接读取旧App沙盒内私有db。必须由旧App导出数据库，再在新App里通过系统文件选择器打开。WAL模式请确保备份已checkpoint，不能只复制未同步的主.db。

旧版`daily_bars`/`instruments`没有行业/概念归属，主线策略需要在数据中心额外导入`code,sector` CSV（本版支持手机端静态行业映射）；使用今天的分类回填历史有前视偏差。财报在`dataset_rows.raw_json`里，但不同供应商字段含义未知，尚不能可靠将它自动转换成季度同比和TTM财报指标，故不会伪造基本面信号。

## D. 两年整库电脑回测

```bash
python -m pip install pandas numpy pytest
python research/sqlite_batch.py --database /PATH/YOUR_EXPORTED.db --action inspect --output experiments/inspect
# 需提供code,sector列；静态行业分类仅作初步研究
python research/sqlite_batch.py --database /PATH/YOUR_EXPORTED.db --action backtest --sector-csv sectors.csv --allow-no-finance --output experiments/quick_test
```

如果明确有经过公告日验证的财报，请先将原始JSON按各供应商定义转换成 `code,announcement_date,revenue_yoy,net_profit_ttm,ocf_ttm` 再回测。`--allow-no-finance`只做**不包含基本面过滤**的技术对照研究，不能宣传为基本面合格策略。

输出`backtest/comparison.json`可在手机App「验证」页面导入。没有历史退市股、历史行业成分、复权因子与逐笔/分钟行情时，结果仍有偏差，不能保证盈利。

## E. 本次验收范围与构建状态

- Python离线测试、JS语法检查和旧数据库结构兼容单测可在CI运行。
- APK需GitHub Actions在线下载JDK/Android SDK/Gradle依赖并实际构建；**当前执行环境没有Android SDK，未能本机验证安装成品**。
- 当前没有真实的用户SQLite文件，未完成真实A股回测，策略胜率未知。

**隐私**：不要将包含个人证券信息的SQLite文件直接提交到公开GitHub仓库。`.gitignore`默认排除`.db/.sqlite/.sqlite3`，也请确认GitHub网页上传时未手动绕过。
