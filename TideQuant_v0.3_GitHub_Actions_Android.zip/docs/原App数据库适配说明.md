# 与最早QuantDesk APK兼容情况

本项目只从用户授权提供的APK读取了DEX中明确保存的`CREATE TABLE`定义，**并未获得另一App的Java源码及数据库实体文件**。旧版数据库不是单张`daily_bars`包含全部信息：行情表与`instruments`要按code联表，财经相关供应商JSON存在`dataset_rows.raw_json`。

### 已支持
- 自动识别旧数据库表/列，按code联表取股票名称。
- 仅读取沪深北交易所股票，排除港股以免混合交易规则。
- 只有`amount`存在且大于0才进入行情模型；空成交额记录跳过。
- 手机端最大180000条近期日线，电脑端`sqlite_batch.py`支持全历史逐批导出。
- 手机端可额外导入`code,sector` CSV对股票分类，不从股票名字猜板块。
- 电脑端`inspect`列出`dataset_rows`包含的dataset类别和JSON顶层键名，不假定原始JSON就是同口径TTM财报。

### 尚不支持/不应误报
- 缺少行业分类与历史动态板块成分时，主线轮动没有真实的板块分组依据。
- 财报JSON未按供应商财务口径验证TTM，因此不会自动声称完成基本面筛选。
- 原有APP内部数据库不得凭应用包名越权访问；必须走用户选择的导出文件。
- APK工程是否能在GitHub Actions成功生成安装包，须看实际CI运行结果。没有跑过时不应说已生成APK。
