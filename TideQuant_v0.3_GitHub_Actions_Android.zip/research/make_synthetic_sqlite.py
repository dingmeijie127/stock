#!/usr/bin/env python3
"""Creates a clearly marked fake SQLite sample so database import can be exercised.
This NEVER represents real market performance.
"""
import sqlite3,csv
from pathlib import Path
root=Path(__file__).resolve().parent
src=root/'sample'
path=src/'FAKE_MARKET_SQLITE_ONLY.db'
if path.exists():path.unlink()
con=sqlite3.connect(path)
for tab,name in [('daily_bars','DEMO_SYNTHETIC_576_bars.csv'),('fundamentals','DEMO_SYNTHETIC_576_finance.csv')]:
    with (src/name).open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);columns=reader.fieldnames
        con.execute('CREATE TABLE '+tab+' ('+', '.join('"'+k+'" TEXT' for k in columns)+')')
        queue=[]
        for row in reader:
            queue.append([row.get(c,'') for c in columns])
            if len(queue)==10000:
                con.executemany('INSERT INTO '+tab+' VALUES ('+','.join('?' for _ in columns)+')',queue);queue=[]
        if queue:con.executemany('INSERT INTO '+tab+' VALUES ('+','.join('?' for _ in columns)+')',queue)
con.commit();con.close()
print('FAKE / SYNTHETIC demo only:',path)
