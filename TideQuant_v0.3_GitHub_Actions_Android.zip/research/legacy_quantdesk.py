#!/usr/bin/env python3
"""Compatibility with SQLite schema visible in original QuantDesk APK's DEX.

APK DOES NOT CONTAIN USER DB. Only names and CREATE TABLE definitions could be recovered.
This exporter never invents a sector, amount, or valid TTM finances.
"""
from __future__ import annotations
import csv
import json
from collections import Counter


def is_legacy(schema):
    return {'daily_bars','instruments'}.issubset(schema) and \
        {'code','day','o','h','l','c','vol','vol_unit','amount'}.issubset(schema['daily_bars']) and \
        {'code','name','exchange'}.issubset(schema['instruments'])


def normalized_code(code):
    text=str(code or '').strip()
    if text[:2].lower() in ('sh','sz','bj'):text=text[2:]
    if '.' in text and text.split('.')[-1].lower() in ('sh','sz','bj'):text=text.split('.')[0]
    return text.zfill(6) if text.isdigit() else text


def inspect_finance_json(db):
    try:
        datasets=dict(db.execute('SELECT dataset,COUNT(*) FROM dataset_rows GROUP BY dataset'))
        missing=db.execute("SELECT COUNT(*) FROM dataset_rows WHERE announcement_day IS NULL OR trim(announcement_day)='' ").fetchone()[0]
        sample=[]
        for dataset, raw in db.execute('SELECT dataset, raw_json FROM dataset_rows WHERE raw_json IS NOT NULL GROUP BY dataset LIMIT 12'):
            try:
                o=json.loads(raw)
                keys=list(o.keys())[:35] if isinstance(o,dict) else ['raw_json root='+type(o).__name__]
            except (ValueError,TypeError):keys=['invalid_JSON']
            sample.append({'dataset':dataset,'json_fields_sample':keys})
        return {'table':'dataset_rows','dataset_counts':datasets,
                'rows_missing_announcement_day':missing,'field_samples':sample,
                'finance_ready':False,
                'warning':'raw_json来自供应商，不代表已计算好的同比、TTM净利、TTM现金流；必须核对字段/期间与公告日期后才可用'}
    except Exception as exc:
        return {'warning':'无法检查旧版财报：'+str(exc),'finance_ready':False}


def export_legacy_bars(db,path,sector_map=None,allow_estimated_amount=False):
    sector_map=sector_map or {}
    counters=Counter()
    symbols=set()
    min_day=max_day=None
    query="""SELECT b.code,b.day,b.o,b.h,b.l,b.c,b.vol,b.vol_unit,b.amount,i.name,i.exchange
             FROM daily_bars b JOIN instruments i ON b.code=i.code
             WHERE i.exchange IN ('SH','SZ','BJ') ORDER BY b.day,b.code"""
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['code','date','open','high','low','close','volume','amount','sector','name'])
        w.writeheader()
        cursor=db.execute(query)
        while True:
            chunk=cursor.fetchmany(5000)
            if not chunk:break
            for code,day,o,h,l,c,vol,vol_unit,amount,name,exchange in chunk:
                counters['read']+=1
                if not day or len(str(day))<8 or not code:
                    counters['invalid_dates']+=1;continue
                date=str(day).replace('/','-')[:10]
                if len(date)==8 and date.isdigit():date=date[:4]+'-'+date[4:6]+'-'+date[6:]
                if not (len(date)==10 and date[4]=='-' and date[7]=='-'):
                    counters['invalid_dates']+=1;continue
                try:
                    o,h,l,c=(float(x) for x in (o,h,l,c))
                    if not (min(o,h,l,c)>0 and h>=max(o,c) and l<=min(o,c)):
                        raise ValueError('inconsistent prices')
                    v=float(vol or 0)
                    if amount is None or float(amount)<=0:
                        if not allow_estimated_amount:
                            counters['missing_amount']+=1;continue
                        if str(vol_unit).upper() not in ('SHARES','SHARE'):
                            counters['unknown_volume_units']+=1;continue
                        amount=c*v # APPROXIMATION: bad for accurate turnover, explicit opt-in only.
                        counters['estimated_amount']+=1
                    amount=float(amount)
                    if amount<=0:raise ValueError('bad amount')
                except (ValueError,TypeError):
                    counters['invalid_prices']+=1;continue
                code=normalized_code(code)
                sector=sector_map.get(code,'未分类')
                if sector=='未分类':counters['no_sector']+=1
                w.writerow({'code':code,'date':date,'open':o,'high':h,'low':l,'close':c,
                            'volume':v,'amount':amount,'sector':sector,'name':name or code})
                symbols.add(code)
                counters['exported']+=1
                min_day=min(min_day,date) if min_day else date
                max_day=max(max_day,date) if max_day else date
    result=dict(counters)
    result.update(table='daily_bars JOIN instruments',unique_stocks=len(symbols),first=min_day,last=max_day,
                  output=str(path),source='legacy_quantdesk_apk_schema',
                  sector_ready=counters['no_sector']==0,
                  amount_estimate_enabled=allow_estimated_amount)
    return result
