#!/usr/bin/env python3
"""潮汐量化 · A股情绪 + 行业轮动 research engine.

Not connected to brokers. No guaranteed win rate.
CSV order: code,date,open,high,low,close,volume,amount,sector,name
Finance: code,announcement_date,revenue_yoy,net_profit_ttm,ocf_ttm

Important: data must include delisted stocks, historical membership, corporate actions,
actual announcement dates and historically available industry mapping to avoid biases.
Output separates chronological test windows, but is not a walk-forward optimization system.
"""
from __future__ import annotations
import argparse, json, math, os, sys
from pathlib import Path
from dataclasses import dataclass
import bisect
import pandas as pd
import numpy as np


def normalize_code(v):
    v=str(v).strip()
    if '.' in v:
        v=v.split('.')[0] if v.split('.')[-1].lower() in ('sh','sz','bj') else v.split('.')[-1]
    if v.lower().startswith(('sh','sz','bj')): v=v[2:]
    return v.zfill(6)

def read_csv_bars(path):
    b=pd.read_csv(path,dtype={'code':'string','sector':'string','name':'string'},low_memory=False)
    needed={'code','date','open','high','low','close','amount','sector'}
    if not needed<=set(b.columns):
        raise ValueError('行情CSV缺少 '+','.join(sorted(needed-set(b.columns))))
    b=b.rename(columns={'date':'day','open':'o','high':'h','low':'l','close':'c','volume':'vol'})
    if 'vol' not in b.columns: b['vol']=0
    if 'name' not in b.columns: b['name']=''
    b['code']=b['code'].map(normalize_code)
    b['day']=pd.to_datetime(b['day'],errors='coerce')
    for c in ['o','h','l','c','vol','amount']:
        b[c]=pd.to_numeric(b[c],errors='coerce')
    b=b.dropna(subset=['day','o','h','l','c','amount'])
    b=b[(b['l']>0)&(b['amount']>0)&(b['h']>=b[['o','c']].max(axis=1))&(b['l']<=b[['o','c']].min(axis=1))]
    b['sector']=b['sector'].fillna('')
    b=b[b['sector'].str.len()>0]
    b=b.drop_duplicates(['day','code'],keep='last').sort_values(['code','day']).reset_index(drop=True)
    if b.empty: raise ValueError('无有效日K线')
    if b['day'].nunique()<60: raise ValueError('需要至少60个交易日（日K线指标需要预热）')
    if b['sector'].nunique()<3: raise ValueError('板块分类至少包含3个行业，否则不能识别相对主线')
    return b

def prepare(b: pd.DataFrame):
    g = b.groupby('code',sort=False)
    b['prev_c'] = g['c'].shift(1)
    b['ret1'] = b['c']/b['prev_c']-1
    for p in [5,10,20]:
        b[f'ret{p}'] = b['c']/g['c'].shift(p)-1
    b['ma5'] = g['c'].transform(lambda x:x.rolling(5,min_periods=5).mean())
    b['ma20'] = g['c'].transform(lambda x:x.rolling(20,min_periods=20).mean())
    b['prev_ma5'] = b.groupby('code')['ma5'].shift(1)
    b['high20_prev'] = g['h'].transform(lambda x:x.shift(1).rolling(20,min_periods=20).max())
    b['amount_ma20'] = g['amount'].transform(lambda x:x.shift(1).rolling(20,min_periods=20).mean())
    b['amount_ratio'] = (b['amount']/b['amount_ma20']).clip(0,10)
    b['tr'] = np.maximum.reduce([ (b['h']-b['l']).to_numpy(),
        (b['h']-b['prev_c']).abs().fillna(0).to_numpy(),
        (b['l']-b['prev_c']).abs().fillna(0).to_numpy() ])
    b['atr14'] = b.groupby('code')['tr'].transform(lambda x:x.rolling(14,min_periods=14).mean())
    b['close_loc'] = ((b['c']-b['l'])/(b['h']-b['l']).replace(0,np.nan)).fillna(.5)
    # "Market mood": broad-market advance/decline and medium-term breadth.
    valid = b.loc[b['ma20'].notna() & b['ret1'].notna()]
    m = valid.groupby('day').agg(n=('code','nunique'),
              adv=('ret1',lambda x:(x>0).mean()))
    # Avoid positional mistakes in aggregated groups: compute close > MA20 rowwise.
    m['above20'] = valid.assign(positive=valid['c']>valid['ma20']).groupby('day')['positive'].mean()
    m['adv3'] = m['adv'].rolling(3,min_periods=3).mean()
    m['regime'] = np.select([
        (m['above20']<.35) | ((m['adv3']<.32)&(m['above20']<.48)),
        (m['above20']>.52)&(m['adv3']>.50),
        ], ['RISK_OFF','RISK_ON'], default='NEUTRAL')
    m.loc[(m['n']<500) | m['adv3'].isna(),'regime'] = 'DATA_INSUFFICIENT'
    # Compute equally-weighted per-sector price action; NOT vendor "main net inflow".
    universe = b.dropna(subset=['sector','ret10','ma20','amount_ratio']).copy()
    universe['above20'] = universe['c']>universe['ma20']
    sec = universe.groupby(['day','sector']).agg(n=('code','nunique'),
        ret5=('ret5','mean'),ret10=('ret10','mean'),
        breadth=('above20','mean'),liquidity=('amount_ratio','median')).reset_index()
    sec = sec.loc[sec['n']>=5].copy()
    for col in ['ret5','ret10','breadth','liquidity']:
        sec[f'pct_{col}'] = sec.groupby('day')[col].rank(pct=True)
    sec['heat'] = (.35*sec['pct_ret5']+.25*sec['pct_ret10']+
                   .25*sec['pct_breadth']+.15*sec['pct_liquidity'])
    sec = sec.sort_values(['sector','day']).reset_index(drop=True)
    sec['active'] = ((sec['heat']>=.75)&(sec['ret5']>.02)&(sec['breadth']>=.55)&
                     (sec['liquidity']>=1.05))
    sec['cool'] = (sec['heat']<.50) | (sec['ret5']<0)
    sec['cool2'] = sec.groupby('sector')['cool'].transform(lambda x: x & x.shift(1,fill_value=False))
    # Consecutive hot days: maturity warning, NOT a perfect theme-top predictor.
    sec['hot_streak'] = 0
    for _, idx in sec.groupby('sector').groups.items():
        count=0
        for i in idx:
            count = count+1 if bool(sec.at[i,'active']) else 0
            sec.at[i,'hot_streak']=count
    return b,m,sec


def fin_guard(fin_map, code, day, required=False):
    if not fin_map:
        return not required
    v = fin_map.get(code)
    if not v:
        return not required
    j = bisect.bisect_right(v[0],day)-1
    if j<0:
        return not required
    rec = v[1][j]
    # All values as-of announcement date: no future earnings leakage.
    for col, min_val in [('net_profit_ttm',0),('revenue_yoy',-0.20)]:
        val = rec.get(col)
        if pd.isna(val):
            if required: return False
        elif val <= min_val: return False
    if 'ocf_ttm' in rec and pd.notna(rec['ocf_ttm']) and rec['ocf_ttm']<=0:
        return False
    return True


def load_fin(path: str | None):
    if not path: return None
    f = pd.read_csv(path,dtype={'code':'str'})
    needed={'code','announcement_day','net_profit_ttm','revenue_yoy','ocf_ttm'}
    if not needed.issubset(f.columns):
        raise ValueError('fundamentals.csv 需要 '+', '.join(sorted(needed)))
    f['code']=f['code'].map(normalize_code)
    f['announcement_day']=pd.to_datetime(f['announcement_day'],errors='coerce')
    for c in ['net_profit_ttm','revenue_yoy','ocf_ttm']:
        f[c]=pd.to_numeric(f[c],errors='coerce')
    f=f.dropna(subset=['announcement_day']).sort_values(['code','announcement_day'])
    out={}
    for code,g in f.groupby('code'):
        out[code]=(list(g['announcement_day']),g[['net_profit_ttm','revenue_yoy','ocf_ttm']].to_dict('records'))
    return out


def allowed_stock(row, allow_growth):
    code=row['code']
    if str(row.get('name','')).upper().find('ST')>=0:
        return False
    if not (code.startswith(('600','601','603','605','000','001','002','003')) or
            (allow_growth and code.startswith(('300','301','688','689')))):
        return False
    return True


def calculate_candidate(row, sec_row, regime, finance, require_fin, allow_growth):
    if regime=='RISK_OFF' or regime=='DATA_INSUFFICIENT': return None
    if sec_row is None or not bool(sec_row['active']): return None
    if int(sec_row['hot_streak'])>12 and sec_row['ret5']<sec_row['ret10']*.45: return None
    if not allowed_stock(row,allow_growth): return None
    p=float(row['c']); price_ok=3<=p<=80
    # Financial unit assumption: amount stored in CNY yuan, not thousands.
    if not price_ok or row['amount_ma20']<8e7: return None
    if not (1.15<=row['amount_ratio']<=3.5): return None
    if pd.isna(row['atr14']) or pd.isna(row['ma20']) or pd.isna(row['high20_prev']): return None
    if not (row['c']>row['ma5']>row['ma20']): return None
    if not (.01 <= row['ret5'] <= .15) or not (row['close_loc']>=.65): return None
    if row['ret1']>=.094: return None  # avoid main-board limit-up chase
    recovered = (row['prev_c']<=row['prev_ma5']) and (row['c']>row['ma5'])
    breakout = (row['c']>row['high20_prev']) and (row['c']<row['high20_prev']*1.05)
    if not (recovered or breakout): return None
    if regime=='NEUTRAL' and float(sec_row['heat'])<.90: return None
    if not fin_guard(finance,row['code'],row['day'],require_fin): return None
    atr_pct = row['atr14']/p
    if not (.015<=atr_pct<=.085): return None
    stop_pct = max(.027,1.25*atr_pct)
    # A 100-share lot risks >200 CNY: skip rather than widen budget.
    if p*100*stop_pct>200: return None
    score=(.55*float(sec_row['heat']) +
           .18*min(float(row['ret5'])/.12,1) +
           .15*min(float(row['amount_ratio'])/2.5,1) +
           .12*float(row['close_loc']))
    return {'day':row['day'],'code':row['code'],'name':row['name'],
            'sector':row['sector'],'signal_close':p,'stop_pct':stop_pct,
            'score':score,'market':regime,'sector_heat':sec_row['heat'],
            'signal_type':'BREAKOUT' if breakout else 'RECLAIM'}



@dataclass(frozen=True)
class Model:
    key:str
    name:str
    mode:str
    rr:float
    max_sessions:int

MODELS=[Model('ROTATION','主线动量','rotation',2.0,8),
        Model('BREAKOUT','趋势突破','breakout',2.3,10),
        Model('PULLBACK','强势回踩','pullback',1.8,6),
        Model('CASH','空仓基准','cash',0,0)]


def actual_fee(value:float, side:str, commission_rate:float=.00025,
               min_commission:float=5, transfer_rate:float=.00001,
               stamp_sell_rate:float=.0005)->float:
    return max(min_commission,value*commission_rate)+value*transfer_rate+ (value*stamp_sell_rate if side=='SELL' else 0)


def signal_mode(row, mode):
    # Signals use same-day close, prior day's 5-day mean, and PREVIOUS 20-bar high only.
    recovered=bool(row['prev_c']<=row['prev_ma5'] and row['c']>row['ma5'])
    breakout=bool(row['c']>row['high20_prev'] and row['c']<row['high20_prev']*1.055)
    if mode=='breakout': return breakout
    if mode=='pullback': return recovered
    return breakout or recovered


def candidate_for_model(row,sector,regime,finance,model,risk_budget,require_fin=True):
    # Core regime/sector/liquidity checks are shared by all strategies.
    sig=calculate_candidate(row,sector,regime,finance,require_fin,False)
    if sig is None: return None
    if not signal_mode(row,model.mode): return None
    if row['c']*100*sig['stop_pct']>risk_budget:return None
    sig['model']=model.key
    return sig


def limit_on_open(row,direction,strict=True):
    """Conservative opening-limit proxy; cannot infer exact book liquidity from daily bars.
    Strict mode deliberately rejects opening near the board's price limit.
    Only main-board stocks are permitted in this research engine.
    """
    if not strict:return False
    pc=row['prev_c']
    if not np.isfinite(pc) or pc<=0:return True
    change=row['o']/pc-1
    return change>=.098 if direction=='BUY' else change<=-.098


def simulate(b,m,sec,model:Model,finance,initial=100000,
             risk_budget=200,max_position_value=8000,strict=True,require_fin=True):
    cash=float(initial); pos=None; pending_buy=None; pending_sell=None
    trades=[]; equity=[]; last_close={}
    sector_by_day={day:g.set_index('sector') for day,g in sec.groupby('day',sort=False)}
    days=b.sort_values('day').groupby('day',sort=True)
    for day,group in days:
        daily=group.set_index('code',drop=False)
        for code,x in daily.iterrows():last_close[code]=float(x['c'])
        regime=m['regime'].get(day,'DATA_INSUFFICIENT')
        sectors=sector_by_day.get(day)
        def sell(px,why):
            nonlocal cash,pos,pending_sell
            val=px*pos['qty']; cost=actual_fee(val,'SELL'); cash+=val-cost
            pnl=val-cost-pos['paid']
            trades.append({'buy_date':pos['day'].date().isoformat(),'sell_date':day.date().isoformat(),
                           'code':pos['code'],'sector':pos['sector'],'qty':pos['qty'],
                           'entry':round(pos['price'],4),'exit':round(px,4),'pnl':round(pnl,2),
                           'reason':why,'model':model.key})
            pos=None;pending_sell=None
        # Prior-close sell signal -> earliest next-session opening.
        if pos and pending_sell and pos['code'] in daily.index:
            x=daily.loc[pos['code']]
            if not limit_on_open(x,'SELL',strict):
                sell(float(x['o'])*.999,pending_sell)
        # Intraday stop/target allowed ONLY on sessions AFTER buy day (T+1).
        if pos and pos['code'] in daily.index and day>pos['day']:
            x=daily.loc[pos['code']]
            if not limit_on_open(x,'SELL',strict):
                stop=pos['stop'];target=pos['target'];px=None;reason=''
                if x['o']<=stop: px=float(x['o'])*.999;reason='GAP_STOP'
                elif x['l']<=stop: px=stop*.999;reason='STOP_FIRST'
                elif x['o']>=target: px=float(x['o'])*.999;reason='GAP_TARGET'
                elif x['h']>=target: px=target*.999;reason='TARGET'
                if px is not None:sell(px,reason)
        # Prior-close buy signal -> next opening; no day-T high/low/close used to decide fill.
        if not pos and pending_buy and model.mode!='cash':
            if pending_buy['code'] in daily.index:
                x=daily.loc[pending_buy['code']]
                gap=float(x['o'])/pending_buy['signal_close']-1
                if -.04<=gap<=.02 and not limit_on_open(x,'BUY',strict):
                    px=float(x['o'])*1.001; stop_pct=pending_buy['stop_pct']
                    max_lots=int(risk_budget//(px*100*stop_pct))
                    lots=min(max_lots,int(max_position_value//(px*100)),int((cash-10)//(px*100)),1)
                    if lots>=1:
                        qty=100*lots;spent=qty*px;paid=spent+actual_fee(spent,'BUY')
                        if paid<=cash:
                            cash-=paid
                            pos={'code':pending_buy['code'],'sector':pending_buy['sector'],
                                 'day':day,'price':px,'qty':qty,'paid':paid,
                                 'stop':px*(1-stop_pct),'target':px*(1+model.rr*stop_pct),
                                 'held':0}
            pending_buy=None
        if pos:
            # Sell signals are generated at CLOSE, not filled at that same close.
            row=daily.loc[pos['code']] if pos['code'] in daily.index else None
            secrow=sectors.loc[pos['sector']] if sectors is not None and pos['sector'] in sectors.index else None
            if day>pos['day']:pos['held']+=1
            if regime=='RISK_OFF':pending_sell='REGIME_OFF'
            elif secrow is not None and bool(secrow['cool2']):pending_sell='SECTOR_COOL'
            elif pos['held']>=model.max_sessions:pending_sell='TIME_EXIT'
            elif row is not None and row['ma20']==row['ma20'] and row['c']<row['ma20']:
                pending_sell='MA20_EXIT'
            elif row is not None and row['amount_ratio']>1.6 and row['close_loc']<.22 and row['ret1']<-.025:
                pending_sell='DISTRIBUTION'
        elif model.mode!='cash' and regime not in ('RISK_OFF','DATA_INSUFFICIENT') and sectors is not None:
            candidates=[]
            for _,row in group.iterrows():
                if not isinstance(row['sector'],str) or row['sector'] not in sectors.index:continue
                sig=candidate_for_model(row,sectors.loc[row['sector']],regime,finance,model,
                                        risk_budget,require_fin)
                if sig:candidates.append(sig)
            if candidates:
                pending_buy=max(candidates,key=lambda x:x['score'])
        val=cash+(pos['qty']*last_close.get(pos['code'],pos['price']) if pos else 0)
        equity.append({'date':day.date().isoformat(),'equity':round(val,2),
                       'cash':round(cash,2),'holding':pos['code'] if pos else '',
                       'market':regime})
    return pd.DataFrame(equity),pd.DataFrame(trades)


def summary(eq,tr):
    e=eq['equity'].astype(float).to_numpy()
    r=e[1:]/e[:-1]-1
    peak=np.maximum.accumulate(e)
    winners=tr.loc[tr['pnl']>0,'pnl'] if len(tr) else pd.Series(dtype=float)
    losers=tr.loc[tr['pnl']<=0,'pnl'] if len(tr) else pd.Series(dtype=float)
    return {'total_return_pct':round((e[-1]/e[0]-1)*100,3),
            'max_drawdown_pct':round(float(np.min(e/peak-1))*100,3),
            'win_rate_pct':round(len(winners)/len(tr)*100,2) if len(tr) else None,
            'payoff_ratio':round(float(winners.mean()/abs(losers.mean())),3)
                 if len(winners) and len(losers) else None,
            'trades':len(tr),
            'sharpe_annualized_rf0':round(float(np.sqrt(252)*np.mean(r)/np.std(r)),3)
                 if len(r)>10 and np.std(r)>1e-12 else None}


def run(args):
    b=read_csv_bars(args.bars)
    b,m,sec=prepare(b)
    finance=None
    if args.finance:
        f=pd.read_csv(args.finance,dtype={'code':'string'}).rename(columns={'announcement_date':'announcement_day'})
        temp=Path(args.output);temp.mkdir(parents=True,exist_ok=True)
        temporary=temp/'_converted_finance.csv';f.to_csv(temporary,index=False)
        finance=load_fin(str(temporary));temporary.unlink()
    if not finance and not args.allow_no_finance:
        raise ValueError('无财报数据，不能验证“基本面筛选”；请传 --finance 或显式使用 --allow-no-finance (仅技术研究)')
    folder=Path(args.output);folder.mkdir(parents=True,exist_ok=True)
    results=[]
    for model in MODELS:
        eq,tr=simulate(b,m,sec,model,finance,initial=args.capital,
                       risk_budget=args.risk,max_position_value=args.max_value,
                       strict=not args.relaxed_fill,require_fin=not args.allow_no_finance)
        eq.to_csv(folder/f'{model.key}_equity.csv',index=False,encoding='utf-8-sig')
        tr.to_csv(folder/f'{model.key}_trades.csv',index=False,encoding='utf-8-sig')
        full=summary(eq,tr)
        # Strict chronological splits. Diagnostic only, not automatically tuned OOS.
        split=int(len(eq)*.6)
        metrics={}
        for label,part in [('research_60pct',eq.iloc[:split]),('holdout_40pct',eq.iloc[split:])]:
            if len(part)<3:continue
            if len(tr):
                tx=tr[(tr['sell_date']>=part.iloc[0]['date'])&(tr['sell_date']<=part.iloc[-1]['date'])]
            else:tx=tr
            metrics[label]=summary(part,tx)
        results.append({'model':model.key,'label':model.name, 'full':full, **metrics})
    with open(folder/'comparison.json','w',encoding='utf8') as f:
        json.dump({'disclaimer':'研究原型，不保证胜率或回报；示例样本不可用于真实买卖。',
                   'first_date':str(b['day'].min().date()),'last_date':str(b['day'].max().date()),
                   'stock_count':int(b['code'].nunique()),'bar_count':int(len(b)),
                   'finance_asof':bool(finance),'historical_membership_verified':False,
                   'parameters':vars(args),'results':results},f,ensure_ascii=False,indent=2)
    print(json.dumps(results,ensure_ascii=False,indent=2))
    print('输出：',folder.resolve())
    if b['code'].nunique()<300:
        print('警告：股票池不足300只，市场广度及主线识别可能存在明显偏差。',file=sys.stderr)
    print('警告：本脚本无法从CSV本身保证覆盖历史退市、停牌、除权、真实盘口；回测仅供研究。',file=sys.stderr)


def main():
    p=argparse.ArgumentParser(description='潮汐量化 大样本A股短线主线轮动多账户模拟')
    p.add_argument('--bars',required=True,help='历史日K线CSV')
    p.add_argument('--finance',help='含实际公告日的财报CSV（默认必需）')
    p.add_argument('--allow-no-finance',action='store_true',help='不做基本面过滤（仅技术回测，需明确同意）')
    p.add_argument('--capital',type=float,default=100000)
    p.add_argument('--risk',type=float,default=200,help='每笔交易计划最大风险（元）')
    p.add_argument('--max-value',type=float,default=8000,help='单笔最大投入（元）')
    p.add_argument('--relaxed-fill',action='store_true',help='关闭涨跌停保守拒单（仅对照）')
    p.add_argument('--output',default='experiment_results')
    args=p.parse_args()
    if args.risk<=0 or args.capital<=0 or args.max_value<=0:p.error('本金和风险预算必须大于0')
    run(args)

if __name__=='__main__':main()
