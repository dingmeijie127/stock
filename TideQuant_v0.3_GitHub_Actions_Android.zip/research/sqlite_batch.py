#!/usr/bin/env python3
"""Read-only SQLite schema explorer and data exporter for TideQuant v0.2.

This tool does not infer investment profitability and never edits the source db.
It exports *all* historical daily bars so the research model can backtest the full
universe rather than the Android app's selective recent-window preview.
"""
from __future__ import annotations
import argparse, csv, json, sqlite3, sys, subprocess
from pathlib import Path
from collections import Counter
from urllib.parse import quote
from legacy_quantdesk import is_legacy, inspect_finance_json, export_legacy_bars

BARS={
 'code':['code','ts_code','stock_code','symbol','ticker','security_code','sec_code'],
 'date':['date','trade_date','day','trading_date','dt'],
 'open':['open','o','open_price'], 'high':['high','h','high_price'],
 'low':['low','l','low_price'], 'close':['close','c','close_price'],
 'amount':['amount','turnover','turnover_value','trade_amount','trade_value'],
 'volume':['volume','vol','trade_volume'],
 'sector':['sector','industry','industry_name','sector_name','concept','plate'],
 'name':['name','stock_name','security_name']}
FIN={
 'code':BARS['code'],
 'announcement_date':['announcement_date','announcement_day','ann_date','publish_date','disclosure_date'],
 'revenue_yoy':['revenue_yoy','rev_yoy','revenue_growth'],
 'net_profit_ttm':['net_profit_ttm','profit_ttm','net_profit'],
 'ocf_ttm':['ocf_ttm','operating_cashflow_ttm','cashflow_ttm','operating_cash_flow']}
REQ_BARS=['code','date','open','high','low','close','amount']
REQ_FIN=['code','announcement_date','revenue_yoy','net_profit_ttm','ocf_ttm']

def open_readonly(path):
    p=Path(path).resolve()
    if not p.is_file():raise FileNotFoundError(f'数据库不存在: {p}')
    return sqlite3.connect('file:'+quote(str(p),safe='/')+'?mode=ro', uri=True)

def ident(x):return '"'+str(x).replace('"','""')+'"'

def tables(db):
    out={}
    for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
        out[name]=[row[1] for row in db.execute('PRAGMA table_info('+ident(name)+')')]
    return out

def find_field(fields,aliases):
    lookup={c.lower():c for c in fields}
    return next((lookup[a] for a in aliases if a in lookup),'')

def mappings(cols,kind='bars',overrides=None):
    aliases=BARS if kind=='bars' else FIN
    result={key:find_field(cols,possible) for key,possible in aliases.items()}
    for k,v in (overrides or {}).items():
        if k not in aliases:raise ValueError('未知映射字段 '+k)
        if v not in cols:raise ValueError(f'映射目标 {v} 不在表内')
        result[k]=v
    required=REQ_BARS if kind=='bars' else REQ_FIN
    missing=[k for k in required if not result.get(k)]
    if missing:raise ValueError('缺少必填字段映射：'+','.join(missing))
    return result

def choose_table(schema,kind,explicit=None):
    if explicit:
        if explicit not in schema:raise ValueError('找不到表：'+explicit)
        return explicit
    keys=REQ_BARS if kind=='bars' else REQ_FIN
    candidates=[]
    for t,cols in schema.items():
        score=sum(bool(find_field(cols,(BARS if kind=='bars' else FIN)[key])) for key in keys)
        candidates.append((score,len(cols),t))
    best=max(candidates,default=(0,0,''))
    if best[0]<len(keys):
        raise ValueError(f'未能自动找到含必要列的{kind}表；用 --{kind}-table 和 --{kind}-map 指定')
    return best[-1]

def iso_date(x):
    if x is None:return ''
    v=str(x).strip()
    if len(v)==8 and v.isdigit():return f'{v[:4]}-{v[4:6]}-{v[6:8]}'
    if len(v)>=10 and v[4]=='-' and v[7]=='-':return v[:10]
    return ''

def normal_code(x):
    s=str(x).strip()
    if s.lower().startswith(('sh','sz','bj')):s=s[2:]
    if '.' in s:
        a,b=s.split('.',1)
        if b.lower() in ('sh','sz','bj'):s=a
    return s.zfill(6) if s.isdigit() else s

def load_sector_map(path):
    if not path:return {}
    result={}
    with open(path,encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):
            code=normal_code(row.get('code',''));sector=row.get('sector','').strip()
            if code and sector:result[code]=sector
    if not result:raise ValueError('行业分类文件为空，请提供 code,sector 两列')
    return result

def parse_json_mapping(s):
    if not s:return {}
    if s.startswith('@'):s=Path(s[1:]).read_text(encoding='utf8')
    obj=json.loads(s)
    if not isinstance(obj,dict):raise ValueError('字段映射必须是JSON对象')
    return obj

def export(db,tab,field_map,path,kind='bars',sector_map=None,amount_scale=1.,revenue_scale=1.):
    if kind=='bars':
        head=['code','date','open','high','low','close','volume','amount','sector','name']
    else:head=REQ_FIN
    keys=list(field_map)
    sql='SELECT '+','.join(ident(field_map[k]) if field_map[k] else 'NULL' for k in keys)+' FROM '+ident(tab)
    if kind=='bars':sql+=' ORDER BY '+ident(field_map['date'])+','+ident(field_map['code'])
    elif kind=='finance':sql+=' ORDER BY '+ident(field_map['announcement_date'])
    count=0;invalid=0;missing_sector=0;unique=set();period=[None,None];sector_map=sector_map or {}
    with open(path,'w',newline='',encoding='utf-8-sig') as out:
        w=csv.DictWriter(out,fieldnames=head);w.writeheader()
        cur=db.execute(sql)
        while True:
            rows=cur.fetchmany(5000)
            if not rows:break
            for row in rows:
                d=dict(zip(keys,row));code=normal_code(d['code']);day=iso_date(d['date'] if kind=='bars' else d['announcement_date'])
                if not code or not day:invalid+=1;continue
                if kind=='bars':
                    sector=d.get('sector') or sector_map.get(code,'')
                    if not sector:missing_sector+=1;invalid+=1;continue
                    try:
                        prices=[float(d[k]) for k in ('open','high','low','close')]
                        amt=float(d['amount'])*amount_scale
                        vol=float(d.get('volume') or 0)
                        if min(prices)<=0 or prices[1]<max(prices[0],prices[3]) or prices[2]>min(prices[0],prices[3]) or amt<=0:raise ValueError()
                    except (ValueError,TypeError):invalid+=1;continue
                    w.writerow(dict(code=code,date=day,open=prices[0],high=prices[1],low=prices[2],close=prices[3],amount=amt,volume=vol,sector=sector,name=d.get('name') or code))
                    unique.add(code)
                else:
                    try:
                        vals={k:float(d[k]) for k in ('revenue_yoy','net_profit_ttm','ocf_ttm')}
                    except (ValueError,TypeError):invalid+=1;continue
                    vals['revenue_yoy']*=revenue_scale
                    w.writerow(dict(code=code,announcement_date=day,**vals))
                count+=1
                period[0]=min(period[0],day) if period[0] else day
                period[1]=max(period[1],day) if period[1] else day
    return {'table':tab,'rows':count,'invalid':invalid,'excluded_without_sector':missing_sector,'unique_stocks':len(unique),'first':period[0],'last':period[1], 'output':str(path)}

def main(argv=None):
    p=argparse.ArgumentParser(description='潮汐量化 SQLite只读导出/大样本回测工具')
    p.add_argument('--database',required=True)
    p.add_argument('--action',choices=['inspect','export','backtest'],default='inspect')
    p.add_argument('--bars-table');p.add_argument('--bars-map',help='JSON映射或@json文件')
    p.add_argument('--finance-table');p.add_argument('--finance-map')
    p.add_argument('--sector-csv',help='仅代码到行业映射，会引入历史分类偏差')
    p.add_argument('--amount-scale',type=float,default=1.,help='成交额转换到人民币元，默认1')
    p.add_argument('--revenue-scale',type=float,default=1.,help='同比数据如果存35代表35%%，设0.01')
    p.add_argument('--allow-no-finance',action='store_true')
    p.add_argument('--allow-estimated-amount',action='store_true',help='仅缺成交额时按成交量×收盘价近似；会影响回测有效性')
    p.add_argument('--output',default='tidequant_sqlite_results')
    p.add_argument('--capital',type=float,default=100000)
    p.add_argument('--risk',type=float,default=200)
    p.add_argument('--max-value',type=float,default=8000)
    args=p.parse_args(argv)
    if args.amount_scale<=0 or args.revenue_scale<=0:p.error('单位转换系数必须大于0')
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    with open_readonly(args.database) as db:
        schema=tables(db)
        legacy=is_legacy(schema)
        if args.action=='inspect':
            info={'database':str(Path(args.database).resolve()),'tables':schema,
                  'legacy_quantdesk_compatible':legacy,
                  'legacy_finance_json':inspect_finance_json(db) if legacy and 'dataset_rows' in schema else None,
                  'hints':{
                'bars':'字段应包括代码/日期/OHLC/成交额/行业','finance':'财报必须有实际公告日期','units':'确认成交额单位是人民币元、涨跌幅为小数'}}
            path=out/'sqlite_schema.json';path.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8')
            print(json.dumps(info,ensure_ascii=False,indent=2));print('保存：',path);return info
        sector=load_sector_map(args.sector_csv)
        bpath=out/'full_history_bars.csv'
        if legacy and (not args.bars_table or args.bars_table=='daily_bars'):
            if args.amount_scale!=1:
                raise ValueError('旧QuantDesk的amount预期为人民币元，--amount-scale应保持1；请先核验数据来源')
            bar_result=export_legacy_bars(db,bpath,sector,args.allow_estimated_amount)
            if args.action=='backtest' and not bar_result['sector_ready']:
                raise ValueError('旧库没有行业/概念历史归属：必须提供 --sector-csv code_sector.csv 才能做主线回测。今日静态行业分类可能带来前视偏差。')
        else:
            bt=choose_table(schema,'bars',args.bars_table)
            bm=mappings(schema[bt],'bars',parse_json_mapping(args.bars_map))
            if not bm.get('sector') and not sector:raise ValueError('没有历史行业字段。请 --sector-csv 提供行业分类，但要注意历史变动的偏差。')
            bar_result=export(db,bt,bm,bpath,'bars',sector,args.amount_scale,args.revenue_scale)
        results={'bars':bar_result, 'source_provenance':'unverified; may be synthetic, real, adjusted, or incomplete'}
        if legacy:results['legacy_finance_json']=inspect_finance_json(db) if 'dataset_rows' in schema else None
        fpath=None
        try:
            ft=choose_table(schema,'finance',args.finance_table)
            fm=mappings(schema[ft],'finance',parse_json_mapping(args.finance_map))
            fpath=out/'full_history_finance.csv'
            results['finance']=export(db,ft,fm,fpath,'finance',None,args.amount_scale,args.revenue_scale)
        except ValueError as e:
            results['finance_warning']=str(e)
            if not args.allow_no_finance and args.action=='backtest':
                if legacy:
                    raise ValueError('原App财报是dataset_rows.raw_json，不能直接当成TTM。先核验供应商字段后转换，或使用--allow-no-finance仅测试量价模型')
                raise
        if results['bars']['rows']<100:
            raise ValueError('有效历史行情不足100条，请检查列映射、行业及成交额单位')
        (out/'source_quality.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(results,ensure_ascii=False,indent=2))
    if args.action=='backtest':
        script=Path(__file__).with_name('market_rotation.py')
        cmd=[sys.executable,str(script),'--bars',str(bpath),'--output',str(out/'backtest'),
             '--capital',str(args.capital),'--risk',str(args.risk),'--max-value',str(args.max_value)]
        if fpath:cmd+=['--finance',str(fpath)]
        if args.allow_no_finance:cmd+=['--allow-no-finance']
        print('执行研究回测（真实数据未经源头完整性审计）：',' '.join(cmd))
        subprocess.run(cmd,check=True)
    return results

if __name__=='__main__':main()
