import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from market_rotation import (actual_fee,fin_guard,MODELS,read_csv_bars,prepare,
                             simulate,limit_on_open,normalize_code)

ROOT=Path(__file__).resolve().parents[1]/'sample'

def test_trade_costs_nonzero():
    assert actual_fee(5500,'BUY')>=5
    assert actual_fee(5500,'SELL')>actual_fee(5500,'BUY')

def test_announcement_date_no_future_leakage():
    rec={'600584':([pd.Timestamp('2026-10-28')],
                   [{'net_profit_ttm':1e9,'revenue_yoy':0.2,'ocf_ttm':2e8}])}
    assert not fin_guard(rec,'600584',pd.Timestamp('2026-10-27'),True)
    assert fin_guard(rec,'600584',pd.Timestamp('2026-10-28'),True)

def test_open_limit_conservative():
    row={'prev_c':50.0,'o':55.0}
    assert limit_on_open(row,'BUY',True)
    assert not limit_on_open(row,'SELL',True)
    row['o']=45
    assert limit_on_open(row,'SELL',True)

def test_t_plus_one_and_independent_models():
    b=read_csv_bars(ROOT/'DEMO_SYNTHETIC_576_bars.csv')
    b,m,s=prepare(b)
    assert b.code.nunique()>=500
    eq,tr=simulate(b,m,s,MODELS[0],None,require_fin=False)
    assert len(eq)>=60
    assert len(tr)>0  # demo dataset is engineered to exercise the simulator
    assert (tr['sell_date']>tr['buy_date']).all(), 'T+1 violation: sold on entry day'
    assert (tr['qty']%100==0).all()
    cash_eq,cash_tr=simulate(b,m,s,MODELS[-1],None,require_fin=False)
    assert cash_eq.equity.iloc[-1]==100000.0
    assert cash_tr.empty

def test_future_bar_does_not_change_past_indicators():
    b=read_csv_bars(ROOT/'DEMO_SYNTHETIC_576_bars.csv')
    date=sorted(b.day.unique())[75]
    cut=b[b.day<=date].copy()
    _,market_full,sector_full=prepare(b)
    _,market_cut,sector_cut=prepare(cut)
    assert market_full.loc[date,'regime']==market_cut.loc[date,'regime']
    x=sector_full[sector_full.day==date].sort_values('sector')['heat'].to_numpy()
    y=sector_cut[sector_cut.day==date].sort_values('sector')['heat'].to_numpy()
    assert len(x)==len(y)
    assert all(abs(a-c)<1e-12 for a,c in zip(x,y))
