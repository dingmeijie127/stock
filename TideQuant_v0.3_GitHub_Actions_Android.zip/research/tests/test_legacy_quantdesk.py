import sys,sqlite3,tempfile,csv,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from legacy_quantdesk import is_legacy,inspect_finance_json,export_legacy_bars
from sqlite_batch import tables

def test_original_apk_schema_exports_only_eligible_rows(tmp_path):
    db=sqlite3.connect(':memory:')
    db.executescript("""
    CREATE TABLE instruments(code TEXT PRIMARY KEY,name TEXT NOT NULL,exchange TEXT NOT NULL,source TEXT NOT NULL);
    CREATE TABLE daily_bars(code TEXT NOT NULL,day TEXT NOT NULL,o REAL NOT NULL,h REAL NOT NULL,l REAL NOT NULL,c REAL NOT NULL,vol REAL NOT NULL,vol_unit TEXT NOT NULL,amount REAL,provider TEXT NOT NULL,raw TEXT NOT NULL,PRIMARY KEY(code,day));
    CREATE TABLE dataset_rows(code TEXT,dataset TEXT,record_id TEXT,period TEXT,announcement_day TEXT,event_day TEXT,provider TEXT,raw_json TEXT,received_at INTEGER);
    """)
    db.executemany('INSERT INTO instruments VALUES(?,?,?,?)',[('600584','长电科技','SH','test'),('01810','港股','HK','test')])
    db.executemany('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',[
      ('600584','2026-10-27',53,55,52,54,100000,'SHARES',95000000,'test','{}'),
      ('600584','2026-10-28',54,56,53,55,120000,'SHARES',None,'test','{}'),
      ('01810','2026-10-27',15,15,14,14.5,200000,'SHARES',3000000,'test','{}'),
    ])
    db.execute('INSERT INTO dataset_rows VALUES(?,?,?,?,?,?,?,?,?)',('600584','income','one','2026-Q3','2026-10-22',None,'test','{"OPERATE_INCOME":123}',0))
    assert is_legacy(tables(db))
    report=inspect_finance_json(db)
    assert report['dataset_counts']['income']==1
    assert report['finance_ready'] is False
    out=tmp_path/'daily.csv'
    quality=export_legacy_bars(db,out,{'600584':'半导体封测'})
    assert quality['exported']==1 and quality['missing_amount']==1 and quality['sector_ready']
    with open(out,encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
    assert rows[0]['name']=='长电科技' and rows[0]['sector']=='半导体封测'
    assert rows[0]['date']=='2026-10-27'
    no_sector=export_legacy_bars(db,tmp_path/'unclassified.csv')
    assert not no_sector['sector_ready']
