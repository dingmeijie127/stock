import csv
import sqlite3
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sqlite_batch import (mappings,choose_table,tables,open_readonly,export,
                          iso_date,normal_code)


def create_test_db(p):
    with sqlite3.connect(p) as db:
        db.execute('CREATE TABLE "daily_ticks" ("ts_code" TEXT, "trade_date" INTEGER,"open" REAL,"high" REAL,"low" REAL,"close" REAL,"turnover_value" REAL,"volume" REAL,"industry" TEXT)')
        db.execute('CREATE TABLE financial_report (code TEXT, announce_date TEXT, net_profit_ttm REAL)')
        db.executemany('INSERT INTO daily_ticks VALUES (?,?,?,?,?,?,?,?,?)',[
            ('SH600584',20261027,53,55,52,54,1e9,1e7,'半导体'),
            ('SH600584',20261028,54,57,53,56,1.4e9,1e7,'半导体'),
            ('SH600584',20261029,56,55,55,56,1e9,1e7,'半导体')])


def test_maps_and_export_and_readonly(tmp_path):
    dbp=tmp_path/'market.sqlite'
    create_test_db(dbp)
    with open_readonly(dbp) as db:
        schema=tables(db)
        assert choose_table(schema,'bars')=='daily_ticks'
        m=mappings(schema['daily_ticks'])
        assert m['code']=='ts_code' and m['date']=='trade_date' and m['amount']=='turnover_value'
        result=export(db,'daily_ticks',m,tmp_path/'out.csv')
        assert result['rows']==2 and result['invalid']==1
        with (tmp_path/'out.csv').open(encoding='utf-8-sig') as f:
            a=list(csv.DictReader(f))
        assert a[0]['code']=='600584' and a[0]['date']=='2026-10-27'
        assert a[1]['close']=='56.0'
        with pytest.raises(sqlite3.OperationalError):db.execute('CREATE TABLE hack (x INT)')


def test_malicious_identifier_rejected(tmp_path):
    dbp=tmp_path/'market.sqlite';create_test_db(dbp)
    with open_readonly(dbp) as db:
        schema=tables(db)
        with pytest.raises(ValueError):mappings(schema['daily_ticks'],overrides={'code':'x; DROP TABLE daily_ticks;'})


def test_date_normalization():
    assert iso_date(20261028)=='2026-10-28'
    assert iso_date('2026-10-28T00:00:00')=='2026-10-28'
    assert iso_date('28/10/2026')==''
    assert normal_code('SZ002475')=='002475'
