// node research/tests/app_smoke.js
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const file=require('path').resolve(__dirname,'../../app/src/main/assets/app.js');
let js=fs.readFileSync(file,'utf8').replace(/init\(\)\.catch\(e=>\{console\.error\(e\);toast\('启动失败：'\+e\.message\)\}\);\s*$/,'');
const ctx={console,Math,Date,Map,Set,JSON,Number,String,Error};vm.createContext(ctx);vm.runInContext(js,ctx);
const r=vm.runInContext(`bars=sample();finance=demoFinance();refreshFinanceIndex();study=buildStudy(bars);({barCount:bars.length,days:study.days.length,models:CFG.map(x=>{let a=runAccount(study,x);return {model:x.id,trades:a.tradeCount,wrongLots:a.trades.some(t=>t.qty%100!==0),tplus:a.trades.every(t=>t.sellDate>t.buyDate),wins:a.winrate}})})`,ctx,{timeout:30000});
assert(r.days>=100 && r.barCount>10000);assert.equal(r.models.length,4);
for(const m of r.models){assert(!m.wrongLots,`not a 100-stock lot ${m.model}`);assert(m.tplus,`T+1 failure ${m.model}`)}
assert.equal(r.models.find(x=>x.model==='CASH').trades,0);
console.log('UI simulation smoke passed, synthetic data only:',JSON.stringify(r));
