/* Historical OHLC candlestick inspector and independently produced full-history report viewer. */
'use strict';
(function(){
 const $e=id=>document.getElementById(id);
 let fullReport=null;
 const price=x=>Number(x).toFixed(2);
 function showStock(code){
   if(!study?.byCode.has(code))return;
   const all=study.byCode.get(code),b=all.at(-1),bars=all.slice(-54);
   const hi=Math.max(...bars.map(x=>x.high)),lo=Math.min(...bars.map(x=>x.low));
   const diff=Math.max(.01,hi-lo),w=720,h=360,top=30,chartH=220,volY=275,volumeH=58;
   const maxA=Math.max(...bars.map(x=>x.amount));
   const x=(i)=>(30+i*((w-55)/bars.length)),cy=n=>(top+(hi-n)/diff*chartH);
   const candles=bars.map((bar,i)=>{
     const up=bar.close>=bar.open,c=up?'#ef7373':'#35c6a3',xx=x(i),bodyY=Math.min(cy(bar.open),cy(bar.close)),bodyH=Math.max(1.5,Math.abs(cy(bar.open)-cy(bar.close)));
     return `<line x1="${xx+3}" y1="${cy(bar.high)}" x2="${xx+3}" y2="${cy(bar.low)}" stroke="${c}" stroke-width="1.5"/><rect x="${xx}" y="${bodyY}" width="6" height="${bodyH}" rx=".5" fill="${c}"/><rect x="${xx}" y="${volY+volumeH*(1-bar.amount/maxA)}" width="6" height="${volumeH*bar.amount/maxA}" fill="${c}" opacity=".65"/>`;
   }).join('');
   const lines=[0,.25,.5,.75,1].map(t=>{const yy=top+t*chartH;return `<line x1="24" x2="700" y1="${yy}" y2="${yy}" stroke="#324b67" stroke-dasharray="4 7"/><text x="700" y="${yy-4}" font-size="10" fill="#9bb3cf" text-anchor="end">${price(hi-t*diff)}</text>`}).join('');
   const start=bars[0].date,end=b.date;
   $e('detailHeading').innerHTML=`<strong>${esc(b.name)}</strong><div class="muted" style="font-size:12px">${esc(b.code)} · ${esc(b.sector)}</div>`;
   $e('detailSummary').innerHTML=`<span>收盘 <b>${price(b.close)}</b></span><span>5日 <b>${b.ret5==null?'—':pct(b.ret5)}</b></span><span>量比 <b>${b.amountRatio==null?'—':price(b.amountRatio)}</b></span><span>最高 <b>${price(hi)}</b></span>`;
   $e('detailChart').innerHTML=`<svg role="img" aria-label="${esc(b.name)}最近日K线及成交额图" viewBox="0 0 720 360" xmlns="http://www.w3.org/2000/svg">${lines}${candles}<text x="30" y="352" fill="#90aac6" font-size="12">${esc(start)}</text><text x="695" y="352" fill="#90aac6" font-size="12" text-anchor="end">${esc(end)}</text><text x="30" y="270" fill="#90aac6" font-size="12">成交额</text></svg>`;
   $e('detailPanel').hidden=false;
 }
 $e('stockList').addEventListener('click',e=>{const row=e.target.closest('[data-stock]');if(row)showStock(row.dataset.stock)});
 $e('detailClose').addEventListener('click',()=>$e('detailPanel').hidden=true);
 document.addEventListener('keydown',e=>{if(e.key==='Escape')$e('detailPanel').hidden=true});
 $e('fullReport').addEventListener('change',async e=>{
   const file=e.target.files?.[0];if(!file)return;
   try{
     if(file.size>10e6)throw Error('报告超过10MB限制');
     let r=JSON.parse(await file.text());
     if(!Array.isArray(r.results)||typeof r.bar_count!=='number'||typeof r.first_date!=='string')throw Error('不是受支持的comparison.json格式');
     fullReport=r;
     const intro=`<div><b>全历史样本：</b>${esc(r.first_date)} 至 ${esc(r.last_date)} · ${r.stock_count}只 · ${r.bar_count.toLocaleString()}条K线</div>`;
     let warn=`<p class="serious-hint">${r.historical_membership_verified?'报告标记已校验历史成分':'报告尚未证实历史成分股完整性；不能把回测当实盘承诺。'} 不同于App近期活跃股子集。</p>`;
     const models=r.results.map(m=>{let a=m.full||{},o=m.holdout_40pct||{};
       return `<div class="report-card"><b>${esc(m.label||m.model)}</b><div class="report-grid"><div><span>全程收益</span><b>${a.total_return_pct??'—'}%</b></div><div><span>全程胜率</span><b>${a.win_rate_pct??'无成交'}${a.win_rate_pct==null?'':'%'}</b></div><div><span>最大回撤</span><b>${a.max_drawdown_pct??'—'}%</b></div><div><span>样本外收益</span><b>${o.total_return_pct??'—'}%</b></div><div><span>样本外交易数</span><b>${o.trades??'—'}</b></div><div><span>盈亏比</span><b>${a.payoff_ratio??'—'}</b></div></div></div>`;
     }).join('');
     $e('fullReportView').innerHTML=intro+warn+models;
     toast('整库研究报告已加载');
   }catch(err){$e('fullReportView').textContent='报告导入失败：'+err.message;toast(err.message)}
 });
})();
