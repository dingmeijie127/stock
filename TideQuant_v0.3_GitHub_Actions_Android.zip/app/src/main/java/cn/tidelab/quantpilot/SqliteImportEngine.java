package cn.tidelab.quantpilot;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Read-only SQLite data adapter. No network, broker actions, or SQL from WebView is executed verbatim. */
final class SqliteImportEngine {
    private final Activity activity;
    private final WebView web;
    private final ExecutorService jobs=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final File dbFile;
    private volatile boolean busy=false;
    private Map<String,Set<String>> schema=new HashMap<>();
    private String originalName="";
    private static final long MAX_FILE_BYTES=1_500_000_000L;
    private static final int MAX_ROWS=180000;

    SqliteImportEngine(Activity a,WebView w) {
        activity=a;web=w;dbFile=new File(a.getFilesDir(),"readonly_market_import.sqlite");
    }
    private void event(String type,JSONObject payload) {
        JSONObject message=new JSONObject();
        try{message.put("type",type);message.put("payload",payload);}catch(Exception ignored){}
        String script="window.tideDbReceive&&window.tideDbReceive("+message.toString()+")";
        main.post(()->web.evaluateJavascript(script,null));
    }
    private JSONObject error(String explanation) {
        JSONObject x=new JSONObject();try{x.put("message",explanation);}catch(Exception ignored){}return x;
    }
    private static String quoted(String s){return "\""+s.replace("\"","\"\"")+"\"";}
    private String validated(String table,String field) {
        Set<String> cols=schema.get(table);
        if(cols==null||field==null||!cols.contains(field))throw new IllegalArgumentException("字段不属于已检查的表: "+field);
        return quoted(field);
    }
    private String table(String raw) {
        if(!schema.containsKey(raw))throw new IllegalArgumentException("未检查的SQLite表: "+raw);
        return quoted(raw);
    }
    private static String str(JSONObject map,String key) {return map.optString(key,"").trim();}
    private String optional(JSONObject map,String tbl,String key,String fallback) {
        String v=str(map,key);return v.isEmpty()?fallback:validated(tbl,v);
    }
    void copyAndInspect(Uri uri,String displayName) {
        if(busy)return;busy=true;originalName=displayName==null?"SQLite文件":displayName;
        event("progress",status("正在读取SQLite文件（只读副本）…"));
        jobs.execute(()->{
            try {
                File temp=new File(dbFile.getAbsolutePath()+".tmp");
                long size=0;byte[] buf=new byte[65536];
                try(InputStream in=activity.getContentResolver().openInputStream(uri);
                    FileOutputStream out=new FileOutputStream(temp)) {
                    if(in==null)throw new IllegalArgumentException("未能读取所选文件");
                    int n;while((n=in.read(buf))!=-1){size+=n;if(size>MAX_FILE_BYTES)throw new IllegalArgumentException("数据库超过1.5GB安全限制");out.write(buf,0,n);}
                }
                byte[] h=new byte[16];try(FileInputStream in=new FileInputStream(temp)){if(in.read(h)!=16||!Arrays.equals(h,"SQLite format 3\000".getBytes("UTF-8")))throw new IllegalArgumentException("文件不是标准未加密SQLite3数据库");}
                if(dbFile.exists()&&!dbFile.delete())throw new IllegalStateException("无法替换之前的临时副本");
                if(!temp.renameTo(dbFile))throw new IllegalStateException("数据库副本保存失败");
                inspectInternal();
                JSONObject p=schemaPayload();p.put("sizeBytes",size);p.put("fileName",originalName);event("schema",p);
            } catch(Exception e){event("error",error(e.getMessage()));}
            finally{busy=false;}
        });
    }
    void restoreMetadata(){jobs.execute(()->{try{if(dbFile.exists()){inspectInternal();JSONObject p=schemaPayload();p.put("fileName",originalName.isEmpty()?"已导入SQLite":originalName);p.put("sizeBytes",dbFile.length());event("schema",p);}}catch(Exception e){event("error",error("已保存数据库不能读取："+e.getMessage()));}});}
    private void inspectInternal() throws Exception {
        Map<String,Set<String>> map=new HashMap<>();
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
            try(Cursor tables=db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null)){
                while(tables.moveToNext()){
                    String t=tables.getString(0);Set<String> fields=new HashSet<>();
                    try(Cursor columns=db.rawQuery("PRAGMA table_info("+quoted(t)+")",null)){
                        int index=columns.getColumnIndexOrThrow("name");while(columns.moveToNext())fields.add(columns.getString(index));
                    }
                    if(!fields.isEmpty())map.put(t,fields);
                }
            }
        }
        if(map.isEmpty())throw new IllegalArgumentException("数据库没有可读取的数据表");
        schema=map;
    }
    private JSONObject schemaPayload() throws Exception {
        JSONObject p=new JSONObject();JSONArray tables=new JSONArray();
        ArrayList<String> names=new ArrayList<>(schema.keySet());java.util.Collections.sort(names);
        for(String name:names){JSONObject o=new JSONObject();o.put("name",name);
            JSONArray cols=new JSONArray();ArrayList<String> items=new ArrayList<>(schema.get(name));java.util.Collections.sort(items);
            for(String c:items)cols.put(c);o.put("columns",cols);tables.put(o);
        }
        p.put("tables",tables);
        p.put("legacyQuantDesk",isLegacyQuantDesk());
        if(isLegacyQuantDesk()) p.put("legacyNote","旧版daily_bars/instruments可直接联表读取；dataset_rows财报JSON与行业标签需要单独转换验证");
        return p;
    }
    /** Exact original QuantDesk schema recovered from the supplied APK's DEX strings.
     * The original SQLite database file was NOT included in that APK.
     * NO finance/sector values are invented; unknown sector stays unknown.
     */
    private boolean isLegacyQuantDesk() {
        Set<String> bars=schema.get("daily_bars"), instruments=schema.get("instruments");
        return bars!=null && instruments!=null &&
            bars.containsAll(Arrays.asList("code","day","o","h","l","c","vol","vol_unit","amount")) &&
            instruments.containsAll(Arrays.asList("code","name","exchange"));
    }
    void loadLegacySnapshot(String json) {
        if(busy){event("error",error("数据库任务正运行"));return;}
        busy=true;
        jobs.execute(()->{
            try {
                if(!isLegacyQuantDesk())throw new IllegalArgumentException("数据库不属于旧QuantDesk架构，请改用标准字段映射");
                JSONObject opts=new JSONObject(json);
                int days=Math.max(70,Math.min(240,opts.optInt("days",120)));
                int symbols=Math.max(100,Math.min(750,opts.optInt("symbols",500)));
                if(days*symbols>MAX_ROWS) throw new IllegalArgumentException("近期样本超出180000行限制");
                String firstDay=null,lastDay=null;
                ArrayList<String> codes=new ArrayList<>();
                int missingAmount=0, unknownVolumeUnit=0, omittedRows=0,count=0;
                try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
                    // Strictly A shares. Old APK also tracked HK shares; do not mix them with A-share limit rules.
                    try(Cursor c=db.rawQuery(
                        "SELECT DISTINCT b.day FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                        "WHERE i.exchange IN ('SH','SZ','BJ') ORDER BY b.day DESC LIMIT " + days,null)) {
                        while(c.moveToNext()){
                            if(lastDay==null) lastDay=c.getString(0);
                            firstDay=c.getString(0);
                        }
                    }
                    if(firstDay==null||lastDay==null) throw new IllegalArgumentException("旧数据库里没有A股日线");
                    try(Cursor c=db.rawQuery(
                        "SELECT b.code FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                        "WHERE b.day=? AND i.exchange IN ('SH','SZ','BJ') " +
                        "GROUP BY b.code ORDER BY COALESCE(MAX(b.amount),0) DESC LIMIT " + symbols,
                        new String[]{lastDay})){
                        while(c.moveToNext())codes.add(c.getString(0));
                    }
                    if(codes.isEmpty())throw new IllegalArgumentException("旧数据库最近交易日没有A股记录");
                    StringBuilder marks=new StringBuilder();for(int k=0;k<codes.size();k++){if(k>0)marks.append(',');marks.append('?');}
                    String sql="SELECT b.code,b.day,b.o,b.h,b.l,b.c,b.amount,b.vol,b.vol_unit,i.name " +
                        "FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                        "WHERE b.day>=? AND i.exchange IN ('SH','SZ','BJ') " +
                        "AND b.code IN ("+marks+") ORDER BY b.day,b.code";
                    ArrayList<String> args=new ArrayList<>();args.add(firstDay);args.addAll(codes);
                    event("start",status("识别旧QuantDesk：读取A股日线并联表名称；无行业标签不生成真实热点排名"));
                    JSONArray batch=new JSONArray();
                    try(Cursor c=db.rawQuery(sql,args.toArray(new String[0]))){
                        while(c.moveToNext()){
                            String volUnit=c.getString(8);
                            if(volUnit!=null && !("SHARES".equalsIgnoreCase(volUnit) || "SHARE".equalsIgnoreCase(volUnit))) {unknownVolumeUnit++;}
                            // Require actual exchange-reported amount, NEVER silently fabricate amount from c*volume.
                            if(c.isNull(6)||c.getDouble(6)<=0){missingAmount++;omittedRows++;continue;}
                            JSONObject row=new JSONObject();
                            row.put("code",c.getString(0));row.put("date",normalDate(c.getString(1)));
                            row.put("open",c.getDouble(2));row.put("high",c.getDouble(3));row.put("low",c.getDouble(4));row.put("close",c.getDouble(5));
                            row.put("amount",c.getDouble(6));row.put("volume",c.getDouble(7));
                            row.put("name",c.getString(9));row.put("sector","未分类");
                            batch.put(row);count++;
                            if(batch.length()>=500){sendBatch("bars",batch,count);batch=new JSONArray();}
                        }
                    }
                    if(batch.length()>0)sendBatch("bars",batch,count);
                }
                JSONObject done=new JSONObject();done.put("count",count);done.put("symbols",codes.size());
                done.put("start",normalDate(firstDay));done.put("end",normalDate(lastDay));done.put("source",originalName);
                done.put("missingAmount",missingAmount);done.put("omittedRows",omittedRows);
                done.put("unknownVolumeUnit",unknownVolumeUnit);done.put("legacy",true);
                event("barsDone",done);
            } catch(Exception ex){event("error",error("旧QuantDesk解析失败："+ex.getMessage()));}
            finally{busy=false;}
        });
    }

    private JSONObject status(String msg){JSONObject x=new JSONObject();try{x.put("message",msg);}catch(Exception ignored){}return x;}
    private void sendBatch(String mode,JSONArray data,int done){
        try{JSONObject p=new JSONObject();p.put("mode",mode);p.put("rows",data);p.put("done",done);event("batch",p);}catch(Exception ignored){}
    }
    void loadSnapshot(String json) {
        if(busy){event("error",error("已有数据库任务在运行"));return;}
        busy=true;
        jobs.execute(()->{
            try{
                JSONObject map=new JSONObject(json);String t=str(map,"table");String tab=table(t);
                String date=validated(t,str(map,"date"));String code=validated(t,str(map,"code"));
                String open=validated(t,str(map,"open")),high=validated(t,str(map,"high")),low=validated(t,str(map,"low")),close=validated(t,str(map,"close")),amount=validated(t,str(map,"amount"));
                String volume=optional(map,t,"volume","0"),name=optional(map,t,"name",code),sector=optional(map,t,"sector","'未分类'");
                int days=Math.max(70,Math.min(240,map.optInt("days",150)));int symbols=Math.max(100,Math.min(750,map.optInt("symbols",600)));
                if(days*symbols>MAX_ROWS)throw new IllegalArgumentException("时间窗口×股票数量不能超过180000，避免手机内存不足");
                String lastDay=null,firstDay=null;ArrayList<String> symbolList=new ArrayList<>();
                try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
                    try(Cursor d=db.rawQuery("SELECT DISTINCT "+date+" FROM "+tab+" WHERE "+date+" IS NOT NULL ORDER BY "+date+" DESC LIMIT "+days,null)) {
                        int n=0;while(d.moveToNext()){if(n==0)lastDay=d.getString(0);firstDay=d.getString(0);n++;}
                        if(n<60)throw new IllegalArgumentException("数据库不足60个交易日，无法计算中期指标");
                    }
                    try(Cursor symbolsCur=db.rawQuery("SELECT "+code+" FROM "+tab+" WHERE "+date+"=? GROUP BY "+code+" ORDER BY SUM(CAST("+amount+" AS REAL)) DESC LIMIT "+symbols,new String[]{lastDay})){
                        while(symbolsCur.moveToNext())if(symbolsCur.getString(0)!=null)symbolList.add(symbolsCur.getString(0));
                    }
                    if(symbolList.isEmpty())throw new IllegalArgumentException("最新交易日无股票可用");
                    StringBuilder ph=new StringBuilder();for(int i=0;i<symbolList.size();i++){if(i>0)ph.append(',');ph.append('?');}
                    String sql="SELECT "+code+" AS qcode,"+date+" AS qdate,"+open+" AS qo,"+high+" AS qh,"+low+" AS ql,"+close+" AS qc,"+amount+" AS qa,"+volume+" AS qv,"+name+" AS qn,"+sector+" AS qs FROM "+tab+" WHERE "+date+">=? AND "+code+" IN ("+ph+") ORDER BY "+date+","+code;
                    ArrayList<String> args=new ArrayList<>();args.add(firstDay);args.addAll(symbolList);
                    event("start",status("已选取最近"+days+"日、成交活跃的"+symbolList.size()+"只股票；这是探索子集，不是全市场回测"));
                    int count=0;JSONArray batch=new JSONArray();
                    try(Cursor cursor=db.rawQuery(sql,args.toArray(new String[0]))){
                        while(cursor.moveToNext()){
                            JSONObject row=new JSONObject();row.put("code",cursor.getString(0));row.put("date",normalDate(cursor.getString(1)));
                            row.put("open",cursor.getDouble(2));row.put("high",cursor.getDouble(3));row.put("low",cursor.getDouble(4));row.put("close",cursor.getDouble(5));
                            row.put("amount",cursor.getDouble(6));row.put("volume",cursor.getDouble(7));row.put("name",cursor.getString(8));row.put("sector",cursor.getString(9));
                            batch.put(row);count++;
                            if(batch.length()>=500){sendBatch("bars",batch,count);batch=new JSONArray();}
                            if(count>=MAX_ROWS)break;
                        }
                    }
                    if(batch.length()>0)sendBatch("bars",batch,count);
                    JSONObject complete=new JSONObject();complete.put("count",count);complete.put("symbols",symbolList.size());complete.put("start",normalDate(firstDay));complete.put("end",normalDate(lastDay));complete.put("source",originalName);event("barsDone",complete);
                }
            }catch(Exception e){event("error",error("行情导入失败："+e.getMessage()));}
            finally{busy=false;}
        });
    }
    void loadFinance(String json) {
        if(busy){event("error",error("已有数据库任务在运行"));return;}busy=true;
        jobs.execute(()->{
            try{
                JSONObject map=new JSONObject(json);String t=str(map,"table"),tab=table(t),code=validated(t,str(map,"code")),date=validated(t,str(map,"announcement_date"));
                String revenue=validated(t,str(map,"revenue_yoy")),profit=validated(t,str(map,"net_profit_ttm")),ocf=validated(t,str(map,"ocf_ttm"));
                String sql="SELECT "+code+","+date+","+revenue+","+profit+","+ocf+" FROM "+tab+" ORDER BY "+date;
                int count=0;JSONArray batch=new JSONArray();event("start",status("正在读取按公告日可得的财务指标…"));
                try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
                    Cursor cur=db.rawQuery(sql,null)){
                    while(cur.moveToNext()){
                        JSONObject row=new JSONObject();row.put("code",cur.getString(0));row.put("announcement_date",normalDate(cur.getString(1)));
                        row.put("revenue_yoy",cur.getDouble(2));row.put("net_profit_ttm",cur.getDouble(3));row.put("ocf_ttm",cur.getDouble(4));batch.put(row);count++;
                        if(batch.length()>=500){sendBatch("finance",batch,count);batch=new JSONArray();}
                        if(count>=300000)throw new IllegalArgumentException("财报行数超过30万，请先在电脑上按公告日整理");
                    }
                }
                if(batch.length()>0)sendBatch("finance",batch,count);
                JSONObject p=new JSONObject();p.put("count",count);event("financeDone",p);
            }catch(Exception e){event("error",error("财报导入失败："+e.getMessage()));}finally{busy=false;}
        });
    }
    private static String normalDate(String text){
        if(text==null)return "";
        String x=text.trim();if(x.matches("\\d{8}"))return x.substring(0,4)+"-"+x.substring(4,6)+"-"+x.substring(6,8);
        return x.length()>=10?x.substring(0,10):x;
    }
    void close(){jobs.shutdownNow();}
}
