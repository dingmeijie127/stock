package com.quantdesk.download;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import org.json.JSONObject;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/** Android-local SQLite. Each security's daily bars and success checkpoint commit atomically. */
public final class MarketDb extends SQLiteOpenHelper {
    public static final java.util.concurrent.atomic.AtomicBoolean IMPORT_IN_PROGRESS=new java.util.concurrent.atomic.AtomicBoolean(false);
    public static final String NAME="quantdesk-a-share-2y.sqlite3";
    public MarketDb(Context context){super(context,NAME,null,5);setWriteAheadLoggingEnabled(true);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE instruments(code TEXT PRIMARY KEY,name TEXT NOT NULL,exchange TEXT NOT NULL,source TEXT NOT NULL)");
        d.execSQL("CREATE TABLE daily_bars(code TEXT NOT NULL,day TEXT NOT NULL,o REAL NOT NULL,h REAL NOT NULL,l REAL NOT NULL,c REAL NOT NULL,vol REAL NOT NULL,vol_unit TEXT NOT NULL,amount REAL,provider TEXT NOT NULL,raw TEXT NOT NULL,PRIMARY KEY(code,day))");
        d.execSQL("CREATE INDEX daily_by_day ON daily_bars(day,code)");
        d.execSQL("CREATE TABLE tasks(code TEXT NOT NULL,start_day TEXT NOT NULL,end_day TEXT NOT NULL,status TEXT NOT NULL,rows INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,error TEXT,updated INTEGER NOT NULL,PRIMARY KEY(code,start_day,end_day))");
        d.execSQL("CREATE TABLE log(id INTEGER PRIMARY KEY AUTOINCREMENT,at INTEGER NOT NULL,level TEXT NOT NULL,message TEXT NOT NULL)");
        d.execSQL("CREATE TABLE state(id INTEGER PRIMARY KEY CHECK(id=1),start_day TEXT,end_day TEXT,phase TEXT,active TEXT,detail TEXT,updated INTEGER)");
        createQuantTables(d);
        createMarketTables(d);
        createAutoSyncTables(d);
        createCoverageTables(d);
    }
    // v1→v2 is additive; NEVER drop daily_bars, instruments, tasks or logs.
    @Override public void onUpgrade(SQLiteDatabase d,int old,int updated) {
        if(old<=1 && updated>=2) createQuantTables(d);
        if(old<=2 && updated>=3) createMarketTables(d);
        if(old<=3 && updated>=4) createAutoSyncTables(d);
        if(old<=4 && updated>=5) createCoverageTables(d);
    }
    private static void createQuantTables(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS dataset_rows(code TEXT NOT NULL,dataset TEXT NOT NULL,record_id TEXT NOT NULL,period TEXT,announcement_day TEXT,event_day TEXT,provider TEXT NOT NULL,raw_json TEXT NOT NULL,received_at INTEGER NOT NULL,PRIMARY KEY(code,dataset,record_id))");
        d.execSQL("CREATE INDEX IF NOT EXISTS data_rows_lookup ON dataset_rows(dataset,code,announcement_day,event_day)");
        d.execSQL("CREATE TABLE IF NOT EXISTS data_jobs(code TEXT NOT NULL,dataset TEXT NOT NULL,from_day TEXT NOT NULL,to_day TEXT NOT NULL,status TEXT NOT NULL,rows INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,error TEXT,checked_at INTEGER NOT NULL,PRIMARY KEY(code,dataset,from_day,to_day))");
        d.execSQL("CREATE TABLE IF NOT EXISTS finance_state(id INTEGER PRIMARY KEY CHECK(id=1),phase TEXT,active TEXT,detail TEXT,total INTEGER DEFAULT 0,complete INTEGER DEFAULT 0,failed INTEGER DEFAULT 0,updated INTEGER)");
    }
    // v3 market audit: additive tables only, no deletion of v8.8.1/v8.9 historical records.
    private static void createMarketTables(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS market_audit(market TEXT NOT NULL,day TEXT NOT NULL,checked_at INTEGER NOT NULL,symbols INTEGER NOT NULL,bars INTEGER NOT NULL,missing INTEGER NOT NULL,detail TEXT,PRIMARY KEY(market,day))");
        d.execSQL("CREATE INDEX IF NOT EXISTS instruments_market ON instruments(exchange,code)");
    }
    /** v4: automatic daily update checkpoint, append only. No old K lines are dropped. */
    private static void createAutoSyncTables(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS auto_daily_attempts(code TEXT NOT NULL,target_day TEXT NOT NULL,status TEXT NOT NULL,added INTEGER NOT NULL,error TEXT,updated INTEGER NOT NULL,PRIMARY KEY(code,target_day))");
        d.execSQL("CREATE INDEX IF NOT EXISTS auto_attempt_day ON auto_daily_attempts(target_day,status)");
        d.execSQL("CREATE TABLE IF NOT EXISTS auto_daily_state(id INTEGER PRIMARY KEY CHECK(id=1),target_day TEXT,phase TEXT,active TEXT,detail TEXT,updated INTEGER)");
        d.execSQL("CREATE TABLE IF NOT EXISTS auto_daily_block(target_day TEXT NOT NULL,market TEXT NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(target_day,market))");
    }
    /** New v5 checkpoints are separate from legacy tasks, whose completion semantics were unreliable. */
    private static void createCoverageTables(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS verified_history(code TEXT PRIMARY KEY,from_day TEXT NOT NULL,to_day TEXT NOT NULL,checked_at INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE IF NOT EXISTS manual_sync_state(id INTEGER PRIMARY KEY CHECK(id=1),mode TEXT,phase TEXT,processed INTEGER,total INTEGER,detail TEXT,updated INTEGER)");
        d.execSQL("CREATE TABLE IF NOT EXISTS finance_full_coverage(code TEXT NOT NULL,dataset TEXT NOT NULL,from_day TEXT NOT NULL,to_day TEXT NOT NULL,checked_at INTEGER NOT NULL,PRIMARY KEY(code,dataset))");
    }
    public void manualState(String mode,String phase,int processed,int total,String detail){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO manual_sync_state(id,mode,phase,processed,total,detail,updated) VALUES(1,?,?,?,?,?,?)",
            new Object[]{mode,phase,processed,total,detail,System.currentTimeMillis()});
    }
    public JSONObject manualOverview(){
        JSONObject o=new JSONObject();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT mode,phase,processed,total,detail,updated FROM manual_sync_state WHERE id=1",null)){
            if(c.moveToFirst()){
                o.put("mode",c.getString(0));o.put("phase",c.getString(1));
                o.put("processed",c.getInt(2));o.put("total",c.getInt(3));
                o.put("detail",c.getString(4));o.put("updated",c.getLong(5));
            }
        }catch(Exception e){try{o.put("detail","状态读取失败："+e.getMessage());}catch(Exception ignored){}}
        return o;
    }
    public java.util.List<String> savedFinancePeriods(String code,String dataset){
        java.util.List<String> rows=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT DISTINCT CASE WHEN length(period)>=10 THEN replace(substr(period,1,10),'/','-') ELSE period END " +
            "FROM dataset_rows WHERE code=? AND dataset=? AND period IS NOT NULL AND period<>''",
            new String[]{code,dataset})){
            while(c.moveToNext())rows.add(c.getString(0));
        }
        return rows;
    }
    public boolean fullFinanceVerified(String code,String dataset,String from,String to){
        return count("SELECT count(*) FROM finance_full_coverage WHERE code=? AND dataset=? AND from_day<=? AND to_day>=?",
            new String[]{code,dataset,from,to})>0;
    }
    public void markFinanceVerified(String code,String dataset,String from,String to){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO finance_full_coverage(code,dataset,from_day,to_day,checked_at) VALUES(?,?,?,?,?)",
            new Object[]{code,dataset,from,to,System.currentTimeMillis()});
    }
    public String[] verifiedHistory(String code){
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT from_day,to_day FROM verified_history WHERE code=?",new String[]{code})){
            return c.moveToFirst()?new String[]{c.getString(0),c.getString(1)}:null;
        }
    }
    public int verifiedCount(String from,String to){
        return count("SELECT count(*) FROM verified_history h JOIN instruments i ON i.code=h.code WHERE i.exchange IN ('SH','SZ','BJ') AND h.from_day<=? AND h.to_day>=?",new String[]{from,to});
    }
    public void markVerifiedHistory(String code,String from,String to){
        if(latestBarDay(code)==null)throw new IllegalStateException("无K线不能确认历史覆盖");
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{
            d.execSQL("INSERT OR REPLACE INTO verified_history(code,from_day,to_day,checked_at) VALUES(?,?,?,?)",
                new Object[]{code,from,to,System.currentTimeMillis()});
            d.execSQL("UPDATE tasks SET status='complete',error=NULL WHERE code=? AND start_day=? AND end_day=? AND status='failed'",
                new Object[]{code,from,to});
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
    }
    /** Exact saved session dates, read from the (code, day) SQLite primary key. */
    public java.util.List<String> barDays(String code,String from,String to){
        java.util.List<String> days=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT day FROM daily_bars WHERE code=? AND day>=? AND day<=? ORDER BY day",
            new String[]{code,from,to})){
            while(c.moveToNext())days.add(c.getString(0));
        }
        return days;
    }
    /** Calendar built only from liquid, previously saved real bars (not synthetic weekdays). */
    public java.util.List<String> referenceDays(String exchange,String from,String to){
        String[] anchors="HK".equals(exchange)?new String[]{"00700","00005"}:
            new String[]{"000001","600000"};
        java.util.TreeSet<String> sessions=new java.util.TreeSet<>();
        for(String code:anchors)sessions.addAll(barDays(code,from,to));
        return new ArrayList<>(sessions);
    }
    /** Manual incremental must ignore old attempt rows: a deliberate tap actually retries. */
    public FastPlan planManualDaily(String targetDay){
        FastPlan plan=new FastPlan();
        String sql="SELECT s.code,s.exchange,"+
            "(SELECT max(b.day) FROM daily_bars b WHERE b.code=s.code) "+
            "FROM instruments s WHERE s.exchange IN ('SH','SZ','BJ') ORDER BY s.code";
        try(Cursor c=getReadableDatabase().rawQuery(sql,null)){
            while(c.moveToNext()){
                String latest=c.getString(2);
                if(latest!=null&&latest.compareTo(targetDay)>=0){plan.alreadyCurrent++;continue;}
                plan.pending.add(new FastCandidate(c.getString(0),c.getString(1),latest,null));
            }
        }
        return plan;
    }
    /** Append only, never overwrite a user's previously imported market prices. */
    public int appendDailyBars(String code,String from,String to,List<Bar> rows){
        if(rows.isEmpty())return 0;
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();int n=0;
        try{
            SQLiteStatement put=d.compileStatement("INSERT OR IGNORE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            try{
                for(Bar b:rows){
                    if(b.date.compareTo(from)<0||b.date.compareTo(to)>0)continue;
                    put.clearBindings();put.bindString(1,code);put.bindString(2,b.date);
                    put.bindDouble(3,b.open);put.bindDouble(4,b.high);put.bindDouble(5,b.low);
                    put.bindDouble(6,b.close);put.bindDouble(7,b.volume);put.bindString(8,b.volumeUnit);
                    if(b.amount==null)put.bindNull(9);else put.bindDouble(9,b.amount);
                    put.bindString(10,b.source);put.bindString(11,b.raw);
                    if(put.executeInsert()!=-1)n++;
                }
            }finally{put.close();}
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
        return n;
    }
    public void autoAttempt(String code,String day,String status,int added,String error){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO auto_daily_attempts(code,target_day,status,added,error,updated) VALUES(?,?,?,?,?,?)",
            new Object[]{code,day,status,added,error,System.currentTimeMillis()});
    }
    public void autoState(String day,String phase,String active,String detail){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO auto_daily_state(id,target_day,phase,active,detail,updated) VALUES(1,?,?,?,?,?)",
            new Object[]{day,phase,active,detail,System.currentTimeMillis()});
    }
    public void autoBlock(String day,String market,String reason){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO auto_daily_block(target_day,market,reason) VALUES(?,?,?)",
            new Object[]{day,market,reason});
    }
    /** A user-initiated retry resets only transient DAILY checkpoints and this day's circuit breaker.
     *  Historical tasks, bars, financials and immutable backfill work remain untouched. */
    public int resetFastTransientFailures(String day){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();int retried=0;
        try{
            try(Cursor c=db.rawQuery("SELECT count(*) FROM auto_daily_attempts a JOIN instruments i ON i.code=a.code WHERE i.exchange IN ('SH','SZ','BJ') AND a.target_day=? AND a.status IN ('failed','stale')",new String[]{day})){
                if(c.moveToFirst())retried=c.getInt(0);
            }
            db.execSQL("DELETE FROM auto_daily_attempts WHERE target_day=? AND status IN ('failed','stale') " +
                "AND code IN (SELECT code FROM instruments WHERE exchange IN ('SH','SZ','BJ'))",new Object[]{day});
            db.execSQL("DELETE FROM auto_daily_block WHERE target_day=? AND market='A'",new Object[]{day});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return retried;
    }
    /** Real missing close-of-day bars, including failed and market-paused candidates. */
    public int autoMissingBars(String day){
        return count("SELECT count(*) FROM instruments s WHERE NOT EXISTS "+
            "(SELECT 1 FROM daily_bars b WHERE b.code=s.code AND b.day>=?) AND s.exchange IN ('SH','SZ','BJ')",new String[]{day});
    }
    public java.util.List<Security> autoPending(String day,int eachMarket){
        java.util.List<Security> a=autoPendingMarket(day,eachMarket,false);
        java.util.List<Security> hk=java.util.Collections.emptyList(); // A-only release
        java.util.List<Security> merged=new ArrayList<>();
        for(int i=0;i<Math.max(a.size(),hk.size());i++){
            if(i<a.size())merged.add(a.get(i));
            if(i<hk.size())merged.add(hk.get(i));
        }
        return merged;
    }
    private java.util.List<Security> autoPendingMarket(String day,int limit,boolean hk){
        java.util.List<Security> result=new ArrayList<>();
        String market=hk?"HK":"A";
        // Once a provider fails repeatedly, skip only its market until the next target day.
        String sql="SELECT s.code,s.exchange FROM instruments s WHERE "+(hk?"s.exchange='HK'":"s.exchange!='HK'")+
            " AND NOT EXISTS (SELECT 1 FROM auto_daily_attempts a WHERE a.code=s.code AND a.target_day=?)"+
            " AND NOT EXISTS (SELECT 1 FROM auto_daily_block b WHERE b.target_day=? AND b.market=?)"+
            " ORDER BY s.code LIMIT ?";
        try(Cursor c=getReadableDatabase().rawQuery(sql,new String[]{day,day,market,String.valueOf(limit)})){
            while(c.moveToNext())result.add(new Security(c.getString(0),c.getString(1)));
        }
        return result;
    }
    /** A single indexed SQLite cursor plans ALL securities; no per-symbol database round trips.
     * The (code,day) daily_bars primary key makes the scalar latest-date lookup indexed.
     */
    public static final class FastCandidate {
        public final String code,exchange,latest,partial;
        FastCandidate(String code,String exchange,String latest,String partial){
            this.code=code;this.exchange=exchange;this.latest=latest;this.partial=partial;
        }
    }
    public static final class FastPlan {
        public final java.util.List<FastCandidate> pending=new java.util.ArrayList<>();
        public int alreadyCurrent,alreadyAttempted;
    }
    public FastPlan planFastDaily(String targetDay){
        FastPlan plan=new FastPlan();
        String sql="SELECT s.code,s.exchange,"+
            "(SELECT b.day FROM daily_bars b WHERE b.code=s.code ORDER BY b.day DESC LIMIT 1),"+
            "(SELECT min(t.start_day) FROM tasks t WHERE t.code=s.code AND t.status='partial'),"+
            "(SELECT a.status FROM auto_daily_attempts a WHERE a.code=s.code AND a.target_day=?) "+
            "FROM instruments s WHERE s.exchange IN ('SH','SZ','BJ') ORDER BY s.code";
        try(Cursor c=getReadableDatabase().rawQuery(sql,new String[]{targetDay})){
            while(c.moveToNext()){
                String latest=c.getString(2);
                if(latest!=null && latest.compareTo(targetDay)>=0){plan.alreadyCurrent++;continue;}
                if(c.getString(4)!=null){plan.alreadyAttempted++;continue;}
                plan.pending.add(new FastCandidate(c.getString(0),c.getString(1),latest,c.getString(3)));
            }
        }
        return plan;
    }
    /** One transaction for a complete quote page, no REPLACE of previously stored data. */
    public int saveFastQuoteBatch(java.util.Map<String,Bar> bars,String day){
        if(bars.isEmpty())return 0;
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();int inserted=0;
        try{
            SQLiteStatement put=db.compileStatement("INSERT OR IGNORE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            SQLiteStatement mark=db.compileStatement("INSERT OR REPLACE INTO auto_daily_attempts(code,target_day,status,added,error,updated) VALUES(?,?,'saved',?,NULL,?)");
            try{
                for(java.util.Map.Entry<String,Bar> entry:bars.entrySet()){
                    String code=entry.getKey();Bar b=entry.getValue();
                    if(!day.equals(b.date))throw new IllegalArgumentException("wrong snapshot trading date");
                    put.clearBindings();put.bindString(1,code);put.bindString(2,day);
                    put.bindDouble(3,b.open);put.bindDouble(4,b.high);put.bindDouble(5,b.low);
                    put.bindDouble(6,b.close);put.bindDouble(7,b.volume);put.bindString(8,b.volumeUnit);
                    if(b.amount==null)put.bindNull(9);else put.bindDouble(9,b.amount);
                    put.bindString(10,b.source);put.bindString(11,b.raw);
                    int added=put.executeInsert()==-1?0:1;inserted+=added;
                    mark.clearBindings();mark.bindString(1,code);mark.bindString(2,day);
                    mark.bindLong(3,added);mark.bindLong(4,System.currentTimeMillis());mark.executeInsert();
                }
            }finally{put.close();mark.close();}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return inserted;
    }
    /** Remember checked batch symbols with no valid target-day bar.
     *  The fallback lane runs BEFORE this. INSERT OR IGNORE preserves successful
     *  tail checkpoints; stale snapshots can only be reopened by explicit retry.
     *  Do not mark unqueried pages, which need to remain eligible next pass.
     */
    public int markFastQuoteChecks(String day,java.util.Map<String,String> statuses){
        if(statuses.isEmpty())return 0;
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();int marked=0;
        try{
            SQLiteStatement check=d.compileStatement(
                "INSERT OR IGNORE INTO auto_daily_attempts(code,target_day,status,added,error,updated) "+
                "SELECT ?,?,?,0,?,? WHERE NOT EXISTS "+
                "(SELECT 1 FROM daily_bars WHERE code=? AND day>=?)");
            try{
                for(java.util.Map.Entry<String,String> item:statuses.entrySet()){
                    check.clearBindings();String code=item.getKey(),status=item.getValue();
                    check.bindString(1,code);check.bindString(2,day);check.bindString(3,status);
                    check.bindString(4,"批量源"+("failed".equals(status)?"请求失败":"无有效目标日收盘K线"));
                    check.bindLong(5,System.currentTimeMillis());
                    check.bindString(6,code);check.bindString(7,day);
                    if(check.executeInsert()!=-1)marked++;
                }
            }finally{check.close();}
            d.setTransactionSuccessful();
        }finally{d.endTransaction();}
        return marked;
    }
    /** Incremental rows are not proof of a complete historical 2-year K-line window. */
    public int saveFastTail(String code,String start,String day,List<Bar> bars,
                            String state,String info){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();int inserted=0;
        try{
            SQLiteStatement put=db.compileStatement("INSERT OR IGNORE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            try{
                for(Bar b:bars){
                    if(b.date.compareTo(start)<0||b.date.compareTo(day)>0)continue;
                    put.clearBindings();put.bindString(1,code);put.bindString(2,b.date);
                    put.bindDouble(3,b.open);put.bindDouble(4,b.high);put.bindDouble(5,b.low);
                    put.bindDouble(6,b.close);put.bindDouble(7,b.volume);put.bindString(8,b.volumeUnit);
                    if(b.amount!=null)put.bindDouble(9,b.amount);else put.bindNull(9);
                    put.bindString(10,b.source);put.bindString(11,b.raw);
                    if(put.executeInsert()!=-1)inserted++;
                }
            }finally{put.close();}
            db.execSQL("INSERT OR REPLACE INTO auto_daily_attempts(code,target_day,status,added,error,updated) VALUES(?,?,?,?,?,?)",
                    new Object[]{code,day,state,inserted,info,System.currentTimeMillis()});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return inserted;
    }
    public int autoRemaining(String day){
        String sql="SELECT count(*) FROM instruments s WHERE "+
            "s.exchange IN ('SH','SZ','BJ') AND NOT EXISTS (SELECT 1 FROM daily_bars b WHERE b.code=s.code AND b.day>=?) "+
            "AND NOT EXISTS (SELECT 1 FROM auto_daily_attempts a WHERE a.code=s.code AND a.target_day=?) "+
            "AND NOT EXISTS (SELECT 1 FROM auto_daily_block b WHERE b.target_day=? AND b.market=(CASE WHEN s.exchange='HK' THEN 'HK' ELSE 'A' END))";
        return count(sql,new String[]{day,day,day});
    }
    public boolean fastMarketBlocked(String day,String market){
        return count("SELECT count(*) FROM auto_daily_block WHERE target_day=? AND market=?",new String[]{day,market})>0;
    }
    public int autoBlocked(String day){return count("SELECT count(*) FROM auto_daily_block WHERE target_day=? AND market='A'",new String[]{day});}
    /** Failed, no-current-bar, and historical backfill are NOT full-market success. */
    public int autoUnresolved(String day){
        return count("SELECT count(*) FROM auto_daily_attempts a JOIN instruments s ON s.code=a.code WHERE s.exchange IN ('SH','SZ','BJ') AND a.target_day=? AND a.status IN ('failed','stale','partial','backfill')",new String[]{day});
    }
    public int autoFailures(String day){return count("SELECT count(*) FROM auto_daily_attempts a JOIN instruments s ON s.code=a.code WHERE s.exchange IN ('SH','SZ','BJ') AND a.target_day=? AND a.status='failed'",new String[]{day});}
    public int autoProcessed(String day){return count("SELECT count(*) FROM auto_daily_attempts a JOIN instruments s ON s.code=a.code WHERE s.exchange IN ('SH','SZ','BJ') AND a.target_day=?",new String[]{day});}
    public int autoNewBars(String day){return count("SELECT coalesce(sum(a.added),0) FROM auto_daily_attempts a JOIN instruments s ON s.code=a.code WHERE s.exchange IN ('SH','SZ','BJ') AND a.target_day=? AND a.status IN ('saved','partial','stale')",new String[]{day});}
    public JSONObject autoOverview(){
        JSONObject out=new JSONObject();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT target_day,phase,active,detail,updated FROM auto_daily_state WHERE id=1",null)){
            if(c.moveToFirst()){
                String day=c.getString(0);
                out.put("target",day);out.put("phase",c.getString(1));out.put("active",c.getString(2));
                out.put("detail",c.getString(3));out.put("updated",c.getLong(4));
                out.put("processed",autoProcessed(day));out.put("failures",autoFailures(day));
                out.put("new_bars",autoNewBars(day));out.put("remaining",autoRemaining(day));out.put("blocked_markets",autoBlocked(day));
            }
        }catch(Exception ignored){}
        return out;
    }
    /** Batch completeness is based on successfully committed per-symbol tasks, not claimed
     * exchange trading-day completeness. An empty/permission-denied result is NOT success. */
    public void auditMarket(String market,String start,String end){
        boolean hk="HK".equals(market);
        String marketWhere=hk?"s.exchange='HK'":"s.exchange!='HK'";
        int symbols=hk?countHK():countA();
        int done=count("SELECT count(*) FROM instruments s JOIN tasks t ON t.code=s.code WHERE "+marketWhere+
            " AND t.start_day=? AND t.end_day=? AND t.status='complete'",new String[]{start,end});
        int missing=Math.max(0,symbols-done);
        String detail="本次批次股票任务完成 "+done+"/"+symbols+"，并非逐交易日完整率；未完成 "+missing;
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO market_audit(market,day,checked_at,symbols,bars,missing,detail) VALUES(?,?,?,?,?,?,?)",
            new Object[]{market,end,System.currentTimeMillis(),symbols,hk?countHKBars():countABars(),missing,detail});
    }
    public int countHK(){return count("SELECT count(*) FROM instruments WHERE exchange='HK'",null);}
    public int countA(){return count("SELECT count(*) FROM instruments WHERE exchange!='HK'",null);}
    public int countHKBars(){return count("SELECT count(*) FROM daily_bars WHERE code IN (SELECT code FROM instruments WHERE exchange='HK')",null);}
    public int countABars(){return count("SELECT count(*) FROM daily_bars WHERE code IN (SELECT code FROM instruments WHERE exchange!='HK')",null);}
    public int countSymbols(){return count("SELECT count(*) FROM instruments",null);}
    public int countBars(){return count("SELECT count(*) FROM daily_bars",null);}
    private int count(String sql,String[] args){try(Cursor c=getReadableDatabase().rawQuery(sql,args)){return c.moveToFirst()?c.getInt(0):0;}}
    public int completed(String start,String end){return count("SELECT count(*) FROM tasks WHERE start_day=? AND end_day=? AND status='complete'",new String[]{start,end});}
    public int failed(String start,String end){return count("SELECT count(*) FROM tasks t JOIN instruments i ON i.code=t.code WHERE i.exchange IN ('SH','SZ','BJ') AND t.start_day=? AND t.end_day=? AND t.status='failed'",new String[]{start,end});}
    public String[] windowOrNew(String newStart,String newEnd){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT start_day,end_day,phase FROM state WHERE id=1",null)){
            if(c.moveToFirst()){
                String prior=c.getString(2);
                // Resume the saved window only while its end day is still current.
                // Otherwise progress into a NEW daily window; the actual daily_bars
                // rows are persistent and per-security max(day) prevents re-download.
                if(("running".equals(prior)||"paused".equals(prior)||"error".equals(prior)||"partial".equals(prior)) &&
                    newEnd.equals(c.getString(1)) && c.getString(0)!=null)
                    return new String[]{c.getString(0),c.getString(1)};
            }
        }
        return new String[]{newStart,newEnd};
    }
    public void state(String start,String end,String phase,String active,String detail){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO state(id,start_day,end_day,phase,active,detail,updated) VALUES(1,?,?,?,?,?,?)",
             new Object[]{start,end,phase,active,detail,System.currentTimeMillis()});
    }
    public JSONObject overview(){
        JSONObject o=new JSONObject();
        try {
            String start="",end="",phase="not_started",active="",detail="";
            try(Cursor c=getReadableDatabase().rawQuery("SELECT start_day,end_day,phase,active,detail FROM state WHERE id=1",null)){
                if(c.moveToFirst()) { start=c.getString(0);end=c.getString(1);phase=c.getString(2);active=c.getString(3);detail=c.getString(4); }
            }
            o.put("start",start);o.put("end",end);o.put("phase",phase);o.put("active",active);o.put("detail",detail);
            int aSymbols=countA(), aBars=countABars();
            o.put("total",aSymbols);o.put("bars",aBars);
            o.put("a_count",aSymbols);o.put("hk_count",0); // Historical HK rows preserved but excluded
            o.put("a_bars",aBars);o.put("hk_bars",0);
            o.put("done",start!=null && !start.isEmpty() ? verifiedCount(start,end):0);o.put("failed",failed(start,end));
        }catch(Exception ignored){}
        return o;
    }
    public static final class Security {
        public final String code,exchange;
        Security(String code,String exchange){this.code=code;this.exchange=exchange;}
    }
    /** Snapshot the pending list BEFORE committing new task rows; avoids a mutable SQLite cursor. */
    public List<Security> allASecurities(){
        List<Security> securities=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT code,exchange FROM instruments WHERE exchange IN ('SH','SZ','BJ') ORDER BY code",null)){
            while(c.moveToNext())securities.add(new Security(c.getString(0),c.getString(1)));
        }
        return securities;
    }
    public List<Security> allSecurities(){
        List<Security> securities=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT code,exchange FROM instruments ORDER BY CASE WHEN exchange='HK' THEN 1 ELSE 0 END,code",null)){
            while(c.moveToNext())securities.add(new Security(c.getString(0),c.getString(1)));
        }
        return securities;
    }
    public List<Security> remaining(String start,String end){
        List<Security> result=new ArrayList<>();
        try(Cursor cursor=getReadableDatabase().rawQuery(
            "SELECT s.code,s.exchange FROM instruments s WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.code=s.code AND t.start_day=? AND t.end_day=? AND t.status='complete') ORDER BY CASE WHEN s.exchange='HK' THEN 1 ELSE 0 END,s.code",
            new String[]{start,end})){
            while(cursor.moveToNext())result.add(new Security(cursor.getString(0),cursor.getString(1)));
        }
        return result;
    }
    /** Return start of any incomplete stored interval so a rerun can retry missing days. */
    public String oldestIncompleteStart(String code){
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT min(start_day) FROM tasks WHERE code=? AND status='partial'",new String[]{code})){
            return c.moveToFirst()?c.getString(0):null;
        }
    }
    public void writeSuccess(String code,String start,String end,List<Bar> rows) {
        writeBars(code,start,end,rows,false,"");
    }
    public void writePartial(String code,String start,String end,List<Bar> rows,int invalidCount) {
        if(invalidCount<=0)throw new IllegalArgumentException("Partial requires invalid records");
        writeBars(code,start,end,rows,true,"Provider skipped invalid daily bars: "+invalidCount);
    }
    private void writeBars(String code,String start,String end,List<Bar> rows,boolean partial,String note){
        if(rows.isEmpty())throw new IllegalArgumentException("Empty history cannot be complete");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            String insert="INSERT OR IGNORE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
            if(partial)insert=insert.replace("INSERT OR REPLACE","INSERT OR IGNORE");
            SQLiteStatement stmt=db.compileStatement(insert);
            try {
                for(Bar b:rows){
                    if(b.date.compareTo(start)<0||b.date.compareTo(end)>0)throw new IllegalArgumentException("Out of range K-line");
                    stmt.clearBindings();stmt.bindString(1,code);stmt.bindString(2,b.date);
                    stmt.bindDouble(3,b.open);stmt.bindDouble(4,b.high);stmt.bindDouble(5,b.low);
                    stmt.bindDouble(6,b.close);stmt.bindDouble(7,b.volume);stmt.bindString(8,b.volumeUnit);
                    if(b.amount!=null)stmt.bindDouble(9,b.amount);else stmt.bindNull(9);
                    stmt.bindString(10,b.source);stmt.bindString(11,b.raw);
                    stmt.executeInsert();
                }
            }finally{stmt.close();}
            if(!partial){
                db.execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',?,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,NULL,?)",
                    new Object[]{code,start,end,rows.size(),code,start,end,System.currentTimeMillis()});
                // A successful full-range retry resolves earlier partial checkpoints.
                db.execSQL("UPDATE tasks SET status='complete',error=NULL WHERE code=? AND status='partial' AND start_day>=? AND end_day<=?",
                    new Object[]{code,start,end});
            }else{
                db.execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'partial',?,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,?,?)",
                    new Object[]{code,start,end,rows.size(),code,start,end,note,System.currentTimeMillis()});
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    /** Mark a current window as satisfied by already-stored bars; no network request. */
    public void markDailyReused(String code,String start,String end){
        if(latestBarDay(code)==null)throw new IllegalStateException("Cannot reuse without saved bars");
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',0,0,NULL,?)",
            new Object[]{code,start,end,System.currentTimeMillis()});
    }
    /** A full prior download already contains the latest requested date. Do not make any HTTP request. */
    public void markUpToDate(String code,String start,String end){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',0,0,NULL,?)",
                new Object[]{code,start,end,System.currentTimeMillis()});
    }
    /** One indexed cursor loads finance checkpoints, regardless of daily-changing task
     *  range strings. The newest attempt determines cooldown; the newest successful
     *  job determines whether a 2-year initial fetch is needed. */
    public static final class FinanceCheckpoint {
        public final String status;
        public final long checkedAt;
        public String lastSuccessfulEnd;
        // Actual saved rows are authoritative, including databases imported without data_jobs.
        public boolean hasSavedRows;
        public String lastSavedPeriod;
        FinanceCheckpoint(String status,long checkedAt){this.status=status;this.checkedAt=checkedAt;}
    }
    public java.util.Map<String,FinanceCheckpoint> financeCheckpoints(){
        java.util.Map<String,FinanceCheckpoint> map=new java.util.HashMap<>();
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT j.code,j.dataset,j.status,j.checked_at,j.to_day FROM data_jobs j " +
            "JOIN instruments i ON i.code=j.code WHERE i.exchange IN ('SH','SZ','BJ') ORDER BY j.checked_at DESC",null)){
            while(c.moveToNext()){
                String key=c.getString(0)+"|"+c.getString(1),status=c.getString(2);
                FinanceCheckpoint checkpoint=map.get(key);
                if(checkpoint==null){
                    checkpoint=new FinanceCheckpoint(status,c.getLong(3));map.put(key,checkpoint);
                }
                if("complete".equals(status)){
                    String end=c.getString(4);
                    if(end!=null && (checkpoint.lastSuccessfulEnd==null || end.compareTo(checkpoint.lastSuccessfulEnd)>0))
                        checkpoint.lastSuccessfulEnd=end;
                }
            }
        }
        // A backup may have dataset_rows but no data_jobs at all. Consult REAL saved
        // reports in one grouped SQL scan rather than treating those stocks as missing.
        // Normalize YYYY-MM-DD and YYYYMMDD into the same sortable YYYYMMDD key.
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT r.code,r.dataset,MAX(REPLACE(REPLACE(SUBSTR(r.period,1,10),'-',''),'/','')),"+
            "MAX(r.received_at) FROM dataset_rows r JOIN instruments i ON i.code=r.code " +
            "WHERE i.exchange IN ('SH','SZ','BJ') GROUP BY r.code,r.dataset",null)){
            while(c.moveToNext()){
                String key=c.getString(0)+"|"+c.getString(1);
                FinanceCheckpoint checkpoint=map.get(key);
                if(checkpoint==null){
                    checkpoint=new FinanceCheckpoint("cached",0L);
                    map.put(key,checkpoint);
                }
                checkpoint.hasSavedRows=true;
                checkpoint.lastSavedPeriod=c.getString(2);
            }
        }
        return map;
    }
    /** History repair is intentionally distinct from daily quote updates.
     *  A failed provider gets 48h rest; a partial/invalid row gets a 7d rest.
     *  These are deferred, NOT marked complete or deleted. */
    public long historyRetryWaitMillis(String code){
        try(Cursor c=getReadableDatabase().rawQuery(
            "SELECT status,updated FROM tasks WHERE code=? AND status IN ('failed','partial') ORDER BY updated DESC LIMIT 1",
            new String[]{code})){
            if(!c.moveToFirst())return 0;
            long cooldown="partial".equals(c.getString(0))?7L*86400000L:2L*86400000L;
            long remaining=cooldown-(System.currentTimeMillis()-c.getLong(1));
            return Math.max(0L,remaining);
        }
    }
    /** A legitimate zero-row finance response is not proof a company has no history. Recheck later. */
    public void saveEmptyDataJob(String code,String dataset,String start,String end){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,'empty',0,1,NULL,?)",
            new Object[]{code,dataset,start,end,System.currentTimeMillis()});
    }
    public boolean recentlyCheckedDataJob(String code,String dataset,String start,String end){
        long weekAgo=System.currentTimeMillis()-7L*86400*1000;
        // Legacy API: do not compare moving from/to dates; a finished report request
        // is still a recent request tomorrow. Main financial runner uses bulk planner.
        return count("SELECT count(*) FROM data_jobs WHERE code=? AND dataset=? AND status IN ('complete','empty') AND checked_at>?",
            new String[]{code,dataset,String.valueOf(weekAgo)})>0;
    }
    public void writeFailure(String code,String start,String end,String message){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'failed',0,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,?,?)",
                new Object[]{code,start,end,code,start,end,message,System.currentTimeMillis()});
    }
    public void log(String level,String message){
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("INSERT INTO log(at,level,message) VALUES(?,?,?)",new Object[]{System.currentTimeMillis(),level,message});
        db.execSQL("DELETE FROM log WHERE id < (SELECT coalesce(max(id),0)-3000 FROM log)");
    }
    public String logs(int limit){
        StringBuilder out=new StringBuilder();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT datetime(at/1000,'unixepoch','localtime'),level,message FROM log ORDER BY id DESC LIMIT "+Math.max(1,Math.min(limit,3000)),null)){
            while(c.moveToNext()){out.append(c.getString(0)).append(' ').append(c.getString(1)).append(' ').append(c.getString(2)).append('\n');}
        }
        return out.toString();
    }
    public void checkpoint(){SQLiteDatabase db=getWritableDatabase();try(Cursor c=db.rawQuery("PRAGMA wal_checkpoint(FULL)",null)){if(c.moveToFirst()&&c.getInt(0)!=0)throw new IllegalStateException("SQLite checkpoint busy");}}

    /** Existing bar dates are authoritative: extending the two-year window does NOT reload saved years. */
    public String latestBarDay(String code){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT max(day) FROM daily_bars WHERE code=?",new String[]{code})){
            return c.moveToFirst()?c.getString(0):null;
        }
    }
    /** A-only local data quality snapshot. This does not claim historical completeness. */
    public JSONObject aQuantHealth(String asOf){
        JSONObject o=new JSONObject();
        try{
            int securities=countA();
            int bars=countABars();
            int financial=count("SELECT count(*) FROM dataset_rows r JOIN instruments i ON i.code=r.code " +
                "WHERE i.exchange IN ('SH','SZ','BJ')",null);
            int recent=count("SELECT count(DISTINCT b.code) FROM daily_bars b JOIN instruments i ON i.code=b.code " +
                "WHERE i.exchange IN ('SH','SZ','BJ') AND b.day BETWEEN ? AND ?",
                new String[]{java.time.LocalDate.parse(asOf).minusDays(15).toString(),asOf});
            int invalid=count("SELECT count(*) FROM daily_bars b JOIN instruments i ON i.code=b.code " +
                "WHERE i.exchange IN ('SH','SZ','BJ') AND (b.o<=0 OR b.h<b.l OR b.l<=0 " +
                "OR b.o>b.h OR b.o<b.l OR b.c>b.h OR b.c<b.l OR b.vol<0)",null);
            o.put("securities",securities);o.put("bars",bars);o.put("financial",financial);
            o.put("recent",recent);o.put("staleOrMissing",Math.max(0,securities-recent));
            o.put("invalidBars",invalid);
        }catch(Exception e){try{o.put("error",e.toString());}catch(Exception ignored){}}
        return o;
    }
    private static String csv(String value){
        if(value==null)return "";
        if(!value.isEmpty() && "=+-@".indexOf(value.charAt(0))>=0)value="'"+value;
        return "\""+value.replace("\"","\"\"")+"\"";
    }
    private static String number(double n){
        return Double.isFinite(n)?String.format(java.util.Locale.US,"%.8f",n):"";
    }
    /** Export per-symbol diagnostic factors from local daily_bars without network access.
     *  Uses the latest 61 saved sessions <= asOf and never modifies SQLite.
     */
    public void exportAQuantCsv(java.io.Writer output,java.time.LocalDate asOf) throws java.io.IOException {
        output.write("code,exchange,name,last_day,sample_count,quality,raw_close,raw_return_20,raw_return_60,raw_ma20,raw_ma60,raw_volatility_20_annualized,raw_drawdown_60\n");
        SQLiteDatabase database=getReadableDatabase();
        int rows=0,eligible=0;
        try(Cursor stocks=database.rawQuery("SELECT code,exchange,name FROM instruments " +
            "WHERE exchange IN ('SH','SZ','BJ') ORDER BY code",null)){
            while(stocks.moveToNext()){
                String code=stocks.getString(0),exchange=stocks.getString(1),name=stocks.getString(2);
                java.util.ArrayList<AQuantFactors.Candle> candles=new java.util.ArrayList<>();
                try(Cursor bars=database.rawQuery("SELECT day,o,h,l,c,vol FROM daily_bars WHERE code=? " +
                    "AND day<=? ORDER BY day DESC LIMIT 61",new String[]{code,asOf.toString()})){
                    while(bars.moveToNext()){
                        candles.add(new AQuantFactors.Candle(bars.getString(0),bars.getDouble(1),
                            bars.getDouble(2),bars.getDouble(3),bars.getDouble(4),bars.getDouble(5)));
                    }
                }
                java.util.Collections.reverse(candles);
                AQuantFactors.Result f=AQuantFactors.compute(candles,asOf);
                if(f.eligible())eligible++;
                output.write(csv(code)+","+csv(exchange)+","+csv(name)+","+csv(f.day)+","+
                    f.observations+","+csv(f.status)+","+number(f.close)+","+
                    number(f.ret20)+","+number(f.ret60)+","+number(f.ma20)+","+
                    number(f.ma60)+","+number(f.volatility20)+","+number(f.drawdown60)+"\n");
                rows++;
            }
        }
        output.flush();
        log("QUANT","本地A股因子CSV导出："+rows+"只、通过基本质量检查"+eligible+
            "只；价格未复权，不能直接用于投资回测");
    }
    public int countDataRows(){return count("SELECT count(*) FROM dataset_rows",null);}
    public int countDataJobs(){return count("SELECT count(*) FROM data_jobs WHERE status='complete'",null);}
    public boolean hasDataJob(String code,String dataset,String start,String end){
        return count("SELECT count(*) FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=? AND status='complete'",new String[]{code,dataset,start,end})>0;
    }
    public String latestDataJobEnd(String code,String dataset){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT max(to_day) FROM data_jobs WHERE code=? AND dataset=? AND status='complete'",new String[]{code,dataset})){
            return c.moveToFirst()?c.getString(0):null;
        }
    }
    private static String digest(String s){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] result=md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder();
            for(byte b:result)out.append(String.format(java.util.Locale.ROOT,"%02x",b & 255));
            return out.toString();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    /** Full provider fields and announcement dates are retained for point-in-time analysis.
        SHA256 primary keys make repeat imports idempotent; revisions are kept as distinct snapshots. */
    public int saveData(String code,String dataset,String start,String end,List<JSONObject> rows){
        if(!code.matches("[0-9]{5}|[0-9]{6}"))throw new IllegalArgumentException("Bad stock code");
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{
            SQLiteStatement st=d.compileStatement("INSERT OR IGNORE INTO dataset_rows(code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at) VALUES(?,?,?,?,?,?,?,?,?)");
            int total=0;
            try{
                for(JSONObject row:rows){
                    String identity=row.optString("ts_code",code);
                    if(!identity.startsWith(code+"."))throw new IllegalArgumentException("Provider returned another stock: "+identity);
                    String raw=row.toString(),period=row.optString("_qd_report_date",row.optString("end_date","")),
                           announcement=row.optString("NOTICE_DATE",row.optString("ANN_DATE",row.optString("ann_date",row.optString("f_ann_date","")))),
                           event=row.optString("EX_DIVIDEND_DATE",row.optString("trade_date",row.optString("ex_date",row.optString("record_date",""))));
                    if(raw.length()>300000)throw new IllegalArgumentException("Oversized data row");
                    st.clearBindings();st.bindString(1,code);st.bindString(2,dataset);st.bindString(3,digest(raw));
                    st.bindString(4,period);st.bindString(5,announcement);st.bindString(6,event);
                    st.bindString(7,row.optString("_qd_provider","legacy_tushare"));st.bindString(8,raw);st.bindLong(9,System.currentTimeMillis());
                    if(st.executeInsert()!=-1)total++;
                }
            }finally{st.close();}
            d.execSQL("INSERT OR REPLACE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,'complete',?,COALESCE((SELECT attempts FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=?),0)+1,NULL,?)",
                new Object[]{code,dataset,start,end,total,code,dataset,start,end,System.currentTimeMillis()});
            d.setTransactionSuccessful();return total;
        }finally{d.endTransaction();}
    }
    public void dataFailure(String code,String dataset,String start,String end,String error){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,'failed',0,COALESCE((SELECT attempts FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=?),0)+1,?,?)",
                new Object[]{code,dataset,start,end,code,dataset,start,end,error,System.currentTimeMillis()});
    }
    public void financeState(String phase,String active,String detail,int total,int done,int failed){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO finance_state(id,phase,active,detail,total,complete,failed,updated) VALUES(1,?,?,?,?,?,?,?)",
                new Object[]{phase,active,detail,total,done,failed,System.currentTimeMillis()});
    }
    public JSONObject financeOverview(){
        JSONObject out=new JSONObject();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT phase,active,detail,total,complete,failed FROM finance_state WHERE id=1",null)){
            if(c.moveToFirst()){
                out.put("phase",c.getString(0));out.put("active",c.getString(1));out.put("detail",c.getString(2));
                out.put("total",c.getInt(3));out.put("complete",c.getInt(4));out.put("failed",c.getInt(5));
            }
            out.put("records",count("SELECT count(*) FROM dataset_rows r JOIN instruments i ON i.code=r.code WHERE i.exchange IN ('SH','SZ','BJ')",null));out.put("jobs",countDataJobs());
        }catch(Exception ignored){}
        return out;
    }
    public interface ImportProgress {
        void report(String message);
        default void onProgress(String table,long inspected,long total,long inserted){
            report("合并 "+table+"：检查 "+inspected+"/"+total+"，新增 "+inserted);
        }
    }
    private static void requireColumns(SQLiteDatabase db,String table,String... columns){
        java.util.HashSet<String> names=new java.util.HashSet<>();
        try(Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null)){
            while(c.moveToNext())names.add(c.getString(1));
        }
        for(String column:columns)if(!names.contains(column))throw new IllegalArgumentException("备份缺少表/字段 "+table+"."+column);
    }
    private static boolean tableExists(SQLiteDatabase db,String table){
        try(Cursor c=db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name=?",new String[]{table})){
            return c.moveToFirst()&&c.getInt(0)>0;
        }
    }
    /** Merge a legacy v1 or v2 SQLite export WITHOUT overwriting already-collected records.
        The input must be a local temporary file copied from Android SAF by the caller. */
    public void mergeBackup(File archive,ImportProgress callback){
        SQLiteDatabase old=SQLiteDatabase.openDatabase(archive.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        try{
            requireColumns(old,"instruments","code","name","exchange","source");
            requireColumns(old,"daily_bars","code","day","o","h","l","c","vol","vol_unit","provider","raw");
            try(Cursor c=old.rawQuery("PRAGMA quick_check(1)",null)){
                if(!c.moveToFirst()||!"ok".equalsIgnoreCase(c.getString(0)))throw new IllegalArgumentException("SQLite备份完整性校验失败");
            }
            // Validate every present source table's columns BEFORE starting any import transaction.
            if(tableExists(old,"tasks"))requireColumns(old,"tasks","code","start_day","end_day","status","rows","attempts","error","updated");
            if(tableExists(old,"dataset_rows"))requireColumns(old,"dataset_rows","code","dataset","record_id","period","announcement_day","event_day","provider","raw_json","received_at");
            if(tableExists(old,"data_jobs"))requireColumns(old,"data_jobs","code","dataset","from_day","to_day","status","rows","attempts","error","checked_at");
            SQLiteDatabase target=getWritableDatabase();
            String[] tables={"instruments","daily_bars","tasks","dataset_rows","data_jobs"};
            String[] inserts={
                "INSERT OR IGNORE INTO instruments(code,name,exchange,source) VALUES(?,?,?,?)",
                "INSERT OR IGNORE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                "INSERT OR IGNORE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,?,?,?,?,?)",
                "INSERT OR IGNORE INTO dataset_rows(code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at) VALUES(?,?,?,?,?,?,?,?,?)",
                "INSERT OR IGNORE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,?,?,?,?,?)"
            };
            String[] columns={
                "code,name,exchange,source","code,day,o,h,l,c,vol,vol_unit,amount,provider,raw",
                "code,start_day,end_day,status,rows,attempts,error,updated",
                "code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at",
                "code,dataset,from_day,to_day,status,rows,attempts,error,checked_at"
            };
            callback.report("正在统计待导入的记录数量…");
            long overallTotal=0,overallInspected=0,overallMerged=0;
            for(String table:tables){
                if(!tableExists(old,table))continue;
                try(Cursor size=old.rawQuery("SELECT count(*) FROM "+table,null)){
                    if(size.moveToFirst())overallTotal+=size.getLong(0);
                }
            }
            callback.onProgress("准备合并",0,overallTotal,0);
            for(int ti=0;ti<tables.length;ti++){
                if(!tableExists(old,tables[ti]))continue;
                String[] fields=columns[ti].split(",");
                requireColumns(old,tables[ti],fields);
                callback.report("正在合并 "+tables[ti]+"；已下载行情不会删除");
                int merged=0, inspected=0, batch=0;
                SQLiteStatement st=target.compileStatement(inserts[ti]);
                try(Cursor c=old.rawQuery("SELECT "+columns[ti]+" FROM "+tables[ti],null)){
                    try {
                        while(c.moveToNext()){
                            if(batch==0)target.beginTransaction();
                            st.clearBindings();
                            for(int k=0;k<fields.length;k++){
                                int pos=k+1,type=c.getType(k);
                                if(type==Cursor.FIELD_TYPE_NULL)st.bindNull(pos);
                                else if(type==Cursor.FIELD_TYPE_INTEGER)st.bindLong(pos,c.getLong(k));
                                else if(type==Cursor.FIELD_TYPE_FLOAT)st.bindDouble(pos,c.getDouble(k));
                                else st.bindString(pos,c.getString(k));
                            }
                            if(st.executeInsert()!=-1)merged++;
                            inspected++;batch++;
                            if(batch==1000){
                                target.setTransactionSuccessful();target.endTransaction();
                                batch=0;callback.onProgress(tables[ti],overallInspected+inspected,overallTotal,overallMerged+merged);
                            }
                        }
                        if(batch>0){target.setTransactionSuccessful();target.endTransaction();}
                    }finally{if(target.inTransaction())target.endTransaction();}
                }finally{st.close();}
                overallInspected+=inspected;overallMerged+=merged;
                callback.onProgress(tables[ti],overallInspected,overallTotal,overallMerged);
                callback.report("已合并 "+tables[ti]+"：检查 "+inspected+" 行，新增 "+merged+" 行（重复数据已跳过）");
            }
        }finally{old.close();}
    }

}
