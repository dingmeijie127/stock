package com.quantdesk.download;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** V9.1.4: update A shares only. Legacy HK SQLite rows remain preserved but unused. */
public final class MainActivity extends Activity {
    private static final int EXPORT_DB=2101, EXPORT_LOG=2102, POST_NOTIFICATIONS_REQUEST=2103, IMPORT_DB=2104, EXPORT_A_QUANT=2105;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status,counts,log,diagnostic,financeCount,autoCount,importStatus,importCounts,tapNotice,manualStatus,quantStatus;
    private ProgressBar progress, importProgressBar,manualProgress;
    private boolean visible;
    private final AtomicBoolean refreshing = new AtomicBoolean(false);
    private static final AtomicBoolean IMPORTING = MarketDb.IMPORT_IN_PROGRESS;
    private final Runnable refresh = new Runnable(){
        @Override public void run(){if(visible){if(!IMPORTING.get())refreshUI();handler.postDelayed(this,5000);}}
    };
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setPadding(dp(4),dp(7),dp(4),dp(7));return t;}
    private void addButton(LinearLayout root,String name,View.OnClickListener click){
        Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setOnClickListener(click);
        root.addView(b,new LinearLayout.LayoutParams(-1,-2));
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(12),dp(16),dp(12));
        ScrollView scroll=new ScrollView(this);scroll.addView(page);setContentView(scroll);
        page.addView(text("QuantDesk V9.1.4 · A股数据维护与量化体检",21));
        page.addView(text("当前数据库："+MarketDb.NAME+"。仅采集和分析上证/深证/北交所A股；旧港股数据保留但不更新、不同步、不参与因子计算。",14));
        tapNotice=text("操作反馈：尚未点击按钮",16);page.addView(tapNotice);
        manualStatus=text("任务：正在读取本地SQLite状态…",15);page.addView(manualStatus);
        manualProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        manualProgress.setMax(100);manualProgress.setProgress(0);page.addView(manualProgress);
        addButton(page,"① A股全量补齐｜历史日K缺口 + 财报",v->start(HarvestService.START));
        addButton(page,"② A股快速增量｜只追加最新缺失日K",v->start(HarvestService.START_FAST));
        addButton(page,"暂停当前任务（已写入SQLite的数据保留）",v->pause());
        page.addView(text("快速增量只处理最新已收盘日K，不提供盘中实时行情。历史缺失、停牌、上市前日期不算成功补齐；网络失败要查看日志。",13));
        status=text("历史K线：读取中…",15);page.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);page.addView(progress);
        counts=text("股票、K线统计读取中…",15);page.addView(counts);
        diagnostic=text("当前：尚未开始",14);page.addView(diagnostic);
        financeCount=text("财报：读取中…",14);page.addView(financeCount);
        page.addView(text("③ A股数据质量与量化指标（只读本地SQLite）",17));
        quantStatus=text("点击『数据质量体检』，查看最新数据覆盖、异常价格和财报行数。",14);
        page.addView(quantStatus);
        addButton(page,"A股数据库质量体检（不联网）",v->inspectAQuant());
        addButton(page,"导出A股量化指标 CSV（20/60日收益、均线、波动、回撤）",v->export(EXPORT_A_QUANT));
        page.addView(text("注意：导出的收益/波动基于未复权收盘价，除权除息可能导致虚假跳空；CSV是研究体检数据，不是已验证的回测收益。",13));
        page.addView(text("其他操作与自动化（不影响上面两个手动按钮）",16));
        addButton(page,"单独补财报（可选）",v->startFinance());
        autoCount=text("自动日更：读取中…",14);page.addView(autoCount);
        addButton(page,"开启每天自动日更",v->{
            try{DailyUpdateScheduler.setEnabled(this,true);tapNotice.setText("每日自动日更已安排；系统会按网络与电量条件择时执行");refreshUI();}
            catch(Exception e){tapNotice.setText("开启自动日更失败："+e.getMessage());}
        });
        addButton(page,"关闭每天自动日更",v->{
            try{DailyUpdateScheduler.setEnabled(this,false);tapNotice.setText("已关闭定时日更；已有数据不受影响");refreshUI();}
            catch(Exception e){tapNotice.setText("关闭自动日更失败："+e.getMessage());}
        });
        addButton(page,"导出 SQLite（换版本前先备份）",v->export(EXPORT_DB));
        addButton(page,"导入旧版 SQLite（合并、不覆盖）",v->importOld());
        importStatus=text("数据库导入：尚未执行",14);page.addView(importStatus);
        importProgressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        importProgressBar.setMax(100);importProgressBar.setProgress(0);
        importProgressBar.setVisibility(View.GONE);page.addView(importProgressBar);
        importCounts=text("",13);page.addView(importCounts);
        addButton(page,"导出日志",v->export(EXPORT_LOG));
        page.addView(text("最新采集日志（自动刷新）",17));
        log=text("暂无记录",12);log.setTextIsSelectable(true);page.addView(log);
        new Thread(()->{
            try{DailyUpdateScheduler.ensureScheduled(getApplicationContext());}
            catch(Exception ex){android.util.Log.e("QuantDesk","自动任务恢复失败，不影响手动下载",ex);}
        },"qd-schedule-init").start();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},POST_NOTIFICATIONS_REQUEST);
        }
    }
    private void start(String act){
        try{
            if(IMPORTING.get()){tapNotice.setText("不能启动：正在导入数据库");return;}
            if(HarvestService.RUNNING.get()){
                tapNotice.setText("已有任务执行中："+HarvestService.LIVE+"。请等待或点击暂停");return;
            }
            String mode=HarvestService.START_FAST.equals(act)?"快速增量":
                HarvestService.START_FINANCE.equals(act)?"财报补齐":"全量补齐";
            tapNotice.setText("已经点击「"+mode+"」，正在交给前台采集服务；请关注下面任务状态");
            Intent command=new Intent(this,HarvestService.class);command.setAction(act);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(command);else startService(command);
            refreshUI();
        }catch(Exception e){tapNotice.setText("启动失败："+e.getClass().getSimpleName()+" "+e.getMessage());}
    }
    private void startFinance(){
        if(IMPORTING.get()){tapNotice.setText("数据库正在导入，财报任务暂不能启动");return;}
        if(HarvestService.RUNNING.get()){
            tapNotice.setText("当前有采集任务在运行，请先暂停/完成后再启动财报");
            return;
        }
        start(HarvestService.START_FINANCE);
    }
    private void pause(){
        try{
            Intent command=new Intent(this,HarvestService.class);command.setAction(HarvestService.PAUSE);
            startService(command);tapNotice.setText("已发送暂停命令；当前网络请求结束后停止，数据不会删除");
        }catch(Exception e){tapNotice.setText("暂停失败："+e.getMessage());}
    }
    /** Never COUNT millions of SQLite K lines on the Android main/UI thread. */
    private void refreshUI(){
        if(!refreshing.compareAndSet(false,true))return;
        new Thread(()->{
            try(MarketDb db=new MarketDb(getApplicationContext())){
                JSONObject o=db.overview(),f=db.financeOverview(),auto=db.autoOverview(),manual=db.manualOverview();
                String recent=db.logs(35);
                runOnUiThread(()->{
                    try{
                        int total=o.optInt("total"),verified=o.optInt("done"),failed=o.optInt("failed");
                        progress.setIndeterminate(HarvestService.RUNNING.get() && total==0);
                        progress.setProgress(total==0?0:Math.min(100,verified*100/total));
                        counts.setText(String.format(Locale.CHINA,
                            "本地A股 %,d只；历史检查记录 %,d/%,d（不代表逐日完整率）\n已存A股日K %,d根（旧港股不参与）",
                            o.optInt("a_count"),verified,o.optInt("a_count"),o.optInt("a_bars")));
                        status.setText("历史K线："+o.optString("phase","未开始")+
                            " · 范围 "+o.optString("start","")+" 至 "+o.optString("end",""));
                        diagnostic.setText("历史进度："+o.optString("active","")+"\n"+o.optString("detail",""));
                        financeCount.setText("财报："+f.optString("phase","未开始")+
                            " · SQLite已有 "+f.optInt("records")+" 行；本轮处理 "+f.optInt("complete")+
                            "/"+f.optInt("total")+" · 失败 "+f.optInt("failed")+
                            "\n"+f.optString("active","")+" "+f.optString("detail",""));
                        autoCount.setText("定时日更："+(DailyUpdateScheduler.enabled(this)?"已开启":"已关闭")+
                            " · 最新检查 "+auto.optString("target","尚无")+
                            " · "+auto.optString("phase","未执行")+
                            "\n"+auto.optString("detail",""));
                        int handled=manual.optInt("processed"),planned=manual.optInt("total");
                        String phase=manual.optString("phase","尚未启动");
                        String mode=manual.optString("mode","无");
                        if("running".equals(phase)&&!HarvestService.RUNNING.get()){
                            long age=System.currentTimeMillis()-manual.optLong("updated",0);
                            phase=age<15000?"已提交，等待前台服务启动":"任务上次被系统中断，可以重新点击继续";
                        }
                        boolean running="running".equals(phase)&&HarvestService.RUNNING.get();
                        manualProgress.setIndeterminate(running&&planned==0);
                        if(!manualProgress.isIndeterminate())
                            manualProgress.setProgress(planned<=0?0:Math.min(100,handled*100/planned));
                        manualStatus.setText("手动任务："+mode+" · "+phase+
                            " · 处理 "+handled+"/"+planned+"\n"+manual.optString("detail","尚未开始"));
                        if(HarvestService.RUNNING.get())manualStatus.append("\n正在运行："+HarvestService.LIVE);
                        log.setText(recent.isEmpty()?"暂无记录":recent);
                    }finally{refreshing.set(false);}
                });
            }catch(Exception e){
                android.util.Log.e("QD-UI","SQLite刷新失败",e);
                runOnUiThread(()->{tapNotice.setText("数据库读取失败："+e.getClass().getSimpleName()+" "+e.getMessage());refreshing.set(false);});
            }
        },"qd-ui-sqlite-refresh").start();
    }
    private void inspectAQuant(){
        quantStatus.setText("正在只读检查本地A股数据库，不会联网或修改行情…");
        new Thread(()->{
            String message;
            try(MarketDb db=new MarketDb(getApplicationContext())){
                String day=RangePlanner.safeEndDay(java.time.ZonedDateTime.now(
                    java.time.ZoneId.of("Asia/Shanghai"))).toString();
                JSONObject quality=db.aQuantHealth(day);
                message=quality.has("error")?"A股数据库体检失败："+quality.optString("error"):
                    "截至 "+day+"，A股证券 "+quality.optInt("securities")+" 只，保存日K "+
                    String.format(Locale.CHINA,"%,d",quality.optInt("bars"))+" 根；A股财报原始行 "+
                    quality.optInt("financial")+"。近15自然日有数据 "+quality.optInt("recent")+
                    " 只，缺失或停牌/退市/旧数据 "+quality.optInt("staleOrMissing")+
                    " 只；OHLCV规则异常行 "+quality.optInt("invalidBars")+
                    "。这不是历史完整率，导出 CSV 可逐股票查看数据是否达到61根及基础量化指标。";
            }catch(Exception e){message="A股数据库体检失败："+e.getClass().getSimpleName()+" "+e.getMessage();}
            final String finalMessage=message;
            runOnUiThread(()->quantStatus.setText(finalMessage));
        },"qd-a-quant-health").start();
    }
    private void export(int type){
        if(type==EXPORT_DB && (HarvestService.RUNNING.get() || IMPORTING.get())){
            Toast.makeText(this,"请先暂停并等待采集结束，再导出完整数据库",Toast.LENGTH_LONG).show();return;
        }
        Intent picker=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        picker.setType(type==EXPORT_DB?"application/octet-stream":type==EXPORT_A_QUANT?"text/csv":"text/plain");
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.putExtra(Intent.EXTRA_TITLE,type==EXPORT_DB?"QuantDesk-A股-原库备份.sqlite3":type==EXPORT_A_QUANT?"QuantDesk-A股-量化体检.csv":"QuantDesk-A股-采集日志.txt");
        try{startActivityForResult(picker,type);}catch(ActivityNotFoundException ex){
            Toast.makeText(this,"没有文件保存应用",Toast.LENGTH_LONG).show();
        }
    }
    private void importOld(){
        if(HarvestService.RUNNING.get() || IMPORTING.get()){
            Toast.makeText(this,"采集或导入正在进行，请先暂停并等待结束",Toast.LENGTH_LONG).show();return;
        }
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("*/*");
        try{startActivityForResult(pick,IMPORT_DB);}catch(Exception e){importStatus.setText("无法打开文件选择器："+e.getMessage());}
    }
    private void importAsync(Uri uri){
        // Prevent simultaneous imports and block WorkManager/foreground collection while importing.
        if(!IMPORTING.compareAndSet(false,true)){
            importStatus.setText("已有数据库导入正在运行，请不要重复点击");return;
        }
        if(HarvestService.RUNNING.get()){
            IMPORTING.set(false);importStatus.setText("采集仍在运行，请先暂停后导入");return;
        }
        importStatus.setText("准备复制备份（不会清空现有日K）…");
        importProgressBar.setVisibility(View.VISIBLE);
        importProgressBar.setIndeterminate(true);
        importCounts.setText("复制备份 → 校验 → 逐表合并；此处显示真实处理进度");
        new Thread(()->{
            File folder=new File(getFilesDir(),"imports");
            File temp=new File(folder,"incoming-"+System.nanoTime()+".sqlite3");
            try{
                if(!folder.isDirectory()&&!folder.mkdirs())throw new java.io.IOException("无法创建数据库临时目录");
                long copied=0,lastUpdate=0;
                long expectedBytes=-1;
                try(android.database.Cursor meta=getContentResolver().query(uri,
                    new String[]{android.provider.OpenableColumns.SIZE},null,null,null)){
                    if(meta!=null && meta.moveToFirst() && !meta.isNull(0))expectedBytes=meta.getLong(0);
                }catch(Exception ignored){} // Some document providers cannot supply a size.
                final long fileSize=expectedBytes;
                try(InputStream in=getContentResolver().openInputStream(uri);
                    FileOutputStream out=new FileOutputStream(temp)){
                    if(in==null)throw new IllegalArgumentException("备份文件无法打开");
                    byte[] buf=new byte[131072];int n;
                    while((n=in.read(buf))!=-1){
                        if(n==0)continue;
                        copied+=n;
                        if(copied>4L*1024*1024*1024)throw new IllegalArgumentException("备份超过4GB，停止导入");
                        if(temp.getUsableSpace()<128L*1024*1024)throw new IllegalStateException("手机存储空间不足128MB，已安全停止");
                        out.write(buf,0,n);
                        long now=System.currentTimeMillis();
                        if(now-lastUpdate>450){
                            final long copiedBytes=copied;
                            final int pct=ImportProgressMeter.copyPercent(copiedBytes,fileSize);
                            runOnUiThread(()->{
                                importProgressBar.setIndeterminate(pct<0);
                                if(pct>=0)importProgressBar.setProgress(pct);
                                importStatus.setText("复制备份："+copiedBytes/1048576+" MB"+
                                    (fileSize>0?" / "+fileSize/1048576+" MB":"（大小未知）"));
                                importCounts.setText("阶段 1/3：复制源数据库（不覆盖原有数据库）");
                            });
                            lastUpdate=now;
                        }
                    }
                    out.getFD().sync();
                }
                runOnUiThread(()->{
                    importStatus.setText("正在校验 SQLite 文件及源数据库结构…");
                    importCounts.setText("阶段 2/3：安全校验");
                    importProgressBar.setIndeterminate(true);
                });
                SqliteBackupFormat.requireValidFile(temp);
                final long started=System.currentTimeMillis();
                final java.util.concurrent.atomic.AtomicLong lastReport=new java.util.concurrent.atomic.AtomicLong(0);
                try(MarketDb db=new MarketDb(getApplicationContext())){
                    db.mergeBackup(temp,new MarketDb.ImportProgress(){
                        @Override public void report(String message){
                            runOnUiThread(()->importStatus.setText(message));
                        }
                        @Override public void onProgress(String table,long inspected,long total,long inserted){
                            long now=System.currentTimeMillis();
                            if(inspected<total && now-lastReport.get()<400)return;
                            lastReport.set(now);
                            final int pct=ImportProgressMeter.mergePercent(inspected,total);
                            runOnUiThread(()->{
                                importProgressBar.setIndeterminate(false);
                                importProgressBar.setProgress(pct);
                                importStatus.setText("阶段 3/3：合并 "+table+" · "+pct+"%");
                                importCounts.setText("已检查 "+String.format(Locale.CHINA,"%,d",inspected)+
                                    " / "+String.format(Locale.CHINA,"%,d",total)+" 行，新增 "+
                                    String.format(Locale.CHINA,"%,d",inserted)+" 行（重复自动跳过）");
                            });
                        }
                    });
                    db.log("INFO","导入SQLite成功；已下载日K和财务记录不删除；耗时 "+(System.currentTimeMillis()-started)/1000+"秒");
                }
                runOnUiThread(()->{importProgressBar.setIndeterminate(false);importProgressBar.setProgress(100);
                    importStatus.setText("数据库合并完成：100%，原K线保留、重复自动跳过");
                    Toast.makeText(this,"导入完成，可以继续增量下载",Toast.LENGTH_LONG).show();});
            }catch(Throwable e){
                // Android may otherwise kill an unhandled import thread without showing an error.
                String error=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
                android.util.Log.e("QuantDeskImport","数据库合并失败",e);
                runOnUiThread(()->{
                    importProgressBar.setIndeterminate(false);
                    importStatus.setText("导入失败（当前数据库已提交的记录保留）："+error);
                    importCounts.setText("导入中断；可重新导入同一文件，已有行将自动跳过");
                });
            }finally{
                if(temp.exists()&&!temp.delete())android.util.Log.w("QuantDeskImport","Temporary SQLite cleanup failed");
                new File(temp.getPath()+"-wal").delete();
                new File(temp.getPath()+"-shm").delete();
                IMPORTING.set(false);
            }
        },"qd903-safe-import").start();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==IMPORT_DB){importAsync(uri);return;}
        new Thread(()->{
            try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                if(out==null)throw new IllegalStateException("无法创建输出文件");
                if(request==EXPORT_DB){
                    if(HarvestService.RUNNING.get())throw new IllegalStateException("任务仍在运行，请先暂停");
                    try(MarketDb db=new MarketDb(this)){db.checkpoint();}
                    File database=getDatabasePath(MarketDb.NAME);
                    try(FileInputStream in=new FileInputStream(database)){
                        byte[] b=new byte[65536];int n;long copied=0;
                        while((n=in.read(b))!=-1){
                            out.write(b,0,n);copied+=n;
                            if(copied%(10L*1024*1024)<65536){
                                final long mb=copied/1048576;
                                runOnUiThread(()->status.setText("正在导出数据库："+mb+" MB"));
                            }
                        }
                    }
                }else if(request==EXPORT_A_QUANT){
                    try(MarketDb db=new MarketDb(this)){
                        java.io.OutputStreamWriter writer=new java.io.OutputStreamWriter(out,StandardCharsets.UTF_8);
                        writer.write("\uFEFF"); // Excel UTF-8 Chinese names
                        db.exportAQuantCsv(writer,RangePlanner.safeEndDay(
                            java.time.ZonedDateTime.now(java.time.ZoneId.of("Asia/Shanghai"))));
                        writer.flush();
                    }
                }else if(request==EXPORT_LOG){
                    try(MarketDb db=new MarketDb(this)){
                        out.write(db.logs(3000).getBytes(StandardCharsets.UTF_8));
                    }
                }
                out.flush();
                runOnUiThread(()->Toast.makeText(this,request==EXPORT_A_QUANT?"A股本地因子报告已导出（未复权）":"文件已导出，请确认保存成功",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                String message="导出失败："+e.getMessage();
                runOnUiThread(()->status.setText(message));
            }
        },"qd89-export").start();
    }
    @Override protected void onResume(){super.onResume();visible=true;handler.removeCallbacks(refresh);refresh.run();}
    @Override protected void onPause(){visible=false;handler.removeCallbacks(refresh);super.onPause();}
}
