/* Separate simulated book, append-only decisions at application level.
 * No future fills and no fake machine learning. Users can export whole log.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.QuantPaper=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';const VERSION='QD7.0-paper-v1';
const round=n=>Math.round((n+Number.EPSILON)*10000)/10000;
function account(type='rules',seed=100000){if(!['rules','ml','practice'].includes(type)||!Number.isFinite(seed)||seed<=0)throw Error('模拟参数不正确');return {type,seed,cash:seed,positions:[],orders:[],fills:[],nav:[],modelVersion:type==='ml'?'untrained':VERSION};}
function propose(existing,sig){
 if(!sig?.strategy||!sig?.date||!sig.code||!sig.market||!['BUY','SELL'].includes(sig.side))throw Error('推荐字段不完整');
 if(existing.some(x=>x.strategy===sig.strategy&&x.date===sig.date&&x.code===sig.code&&x.side===sig.side))return {added:false,signals:existing};
 if(!/^\d{4}-\d{2}-\d{2}$/.test(sig.date)||!sig.generatedAt||!sig.dataCutoff||Date.parse(sig.dataCutoff)>Date.parse(sig.generatedAt))throw Error('推荐日期或数据时点异常');
 const order={...sig,status:'pending',createdAt:sig.generatedAt};return {added:true,signals:[...existing,order]};
}
function tradeDayAfter(order,bar){const generatedDay=new Intl.DateTimeFormat('sv-SE',{timeZone:order.market==='HK'?'Asia/Hong_Kong':'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(order.generatedAt));return bar?.date>order.date&&bar.date>generatedDay && Date.parse(bar.date+'T00:00:00Z')>Date.parse(order.dataCutoff.slice(0,10)+'T00:00:00Z');}
function execute(book,order,bar,{buyFee=0.001,sellFee=0.0015,slippage=0.001,lotSize=null}={}){
 if(order.status!=='pending'||!tradeDayAfter(order,bar))return {book,order,reason:'没有后续交易日完整K线或已成交'};
 const unit=order.market==='A'?100:Number(lotSize||order.lotSize||0);if(!Number.isSafeInteger(unit)||unit<1)return {book,order:{...order,status:'blocked',blockedReason:'交易单位未知'},reason:'交易单位未知'};
 const px=Number(bar.open),vol=Number(bar.volume);if(!Number.isFinite(px)||px<=0||!Number.isFinite(vol)||vol<=0)return {book,order:{...order,status:'blocked',blockedReason:'停牌或无成交'},reason:'不可成交'};
 const isBuy=order.side==='BUY',trigger=Number(order.limit),hasLimit=Number.isFinite(trigger)&&trigger>0;
 if(hasLimit&&((isBuy&&px>trigger)||( !isBuy&&px<trigger)))return{book,order:{...order,status:'pending'},reason:'未达到限价条件，未模拟成交'};
 // Daily OHLC doesn't tell order book liquidity; approximate no fill at stock price limit.
 const price=round(px*(1+(isBuy?slippage:-slippage))),shares=Number(order.qty);
 if(!Number.isSafeInteger(shares)||shares<=0||shares%unit!==0)return{book,order:{...order,status:'blocked',blockedReason:'股数未满足交易单位'},reason:'股数不合法'};
 const b={...book,positions:book.positions.map(x=>({...x})),fills:book.fills.slice(),orders:book.orders.slice(),nav:book.nav.slice()};let pos=b.positions.find(x=>x.market===order.market&&x.code===order.code),fee=0;
 if(isBuy){fee=round(shares*price*buyFee);if(b.cash+1e-8 < shares*price+fee)return {book,order:{...order,status:'blocked',blockedReason:'模拟现金不足'},reason:'现金不足'};
  if(!pos){pos={market:order.market,code:order.code,shares:0,cost:0};b.positions.push(pos);}pos.cost=(pos.cost*pos.shares+shares*price+fee)/(pos.shares+shares);pos.shares+=shares;b.cash=round(b.cash-shares*price-fee);
 }else{if(!pos||pos.shares<shares)return {book,order:{...order,status:'blocked',blockedReason:'模拟持股不足'},reason:'无足够模拟持股'};
   if(order.market==='A'&&pos.lastBuyDate===bar.date)return {book,order:{...order,status:'blocked',blockedReason:'A股T+1'},reason:'T+1不可卖'};
   fee=round(shares*price*sellFee);b.cash=round(b.cash+shares*price-fee);var realized=round((price-pos.cost)*shares-fee);pos.shares-=shares;}
 if(isBuy)pos.lastBuyDate=bar.date;
 const fill={orderKey:order.key,market:order.market,code:order.code,side:order.side,shares,price,fee,date:bar.date,realized:isBuy?null:realized,source:'模拟成交(次日开盘价+滑点假设)'};
 b.fills.push(fill);const settled={...order,status:'filled',fillDate:bar.date,fillPrice:price};return {book:b,order:settled,fill,reason:'成交仅是模型模拟，不是券商回报'};
}
function mark(book,day,quotes){let eq=book.cash,missing=[];for(const h of book.positions.filter(x=>x.shares>0)){
 const q=quotes[h.market+':'+h.code],p=Number(q?.close??q?.price);if(!Number.isFinite(p)||p<=0){missing.push(h.code);continue;}eq+=h.shares*p;
 }if(missing.length)return {book,completed:false,missing};
 const nav={date:day,equity:round(eq),cash:round(book.cash)};const old=book.nav.find(x=>x.date===day);if(old)return{book,completed:true,already:true};return {book:{...book,nav:[...book.nav,nav]},completed:true,nav};
}
function metrics(book){const closed=book.fills.filter(x=>x.side==='SELL'&&Number.isFinite(x.realized)),wins=closed.filter(x=>x.realized>0);const a=book.nav,initial=book.seed;let peak=initial,worst=0;
 for(const v of a){peak=Math.max(peak,v.equity);worst=Math.min(worst,v.equity/peak-1);}return {totalReturn:a.length?(a.at(-1).equity/initial-1)*100:null,maxDrawdown:a.length?worst*100:null,closedTrades:closed.length,winRate:closed.length>=30?wins.length/closed.length*100:null,why:closed.length<30?'已平仓模拟交易少于30笔，暂不公布胜率':'按实际模拟平仓盈亏计算，未验证真实可成交性'};}
return {VERSION,account,propose,tradeDayAfter,execute,mark,metrics};
});
