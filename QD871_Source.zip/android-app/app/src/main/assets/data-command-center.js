/* V8.3 unified data command centre. The SINGLE normal-user action is
 * '建立 / 更新数据库'. Native downloads, import and quality audit are stages,
 * never competing init buttons. No claims of official 100% coverage.
 */
(function(root,factory){const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;root.QuantDataCommand=api;})(typeof globalThis!=='undefined'?globalThis:this,function(root){
'use strict';
const defaults=Object.freeze({bars:true,finance:true,quarters:8,limit:650,concurrency:3});
const el=id=>document.getElementById(id),num=x=>(Number(x)||0).toLocaleString('zh-CN');
const safe=s=>String(s==null?'':s).slice(0,220);
let mounted=false,updating=false,commandPending=false,message='',interval=null;
function healthSummary(stats={},market={A:{},HK:{}},quality={}){
 const q=stats||{},A=market.A||{},HK=market.HK||{};
 const queues=Number(q.pending||0)+Number(q.running||0),ready=Number(q.ready||0),failed=Number(q.failed||0)+Number(q.import_failed||0);
 let state='未建库',detail='点击“建立 / 更新数据库”，软件会自动执行下载、导入和数据校验。';
 if(q.startError){state='启动失败';detail='原生后台未成功启动：'+safe(q.startError);}
 else if(q.serviceActive){state='正在下载';detail='可以切换其他应用；回到这里会自动导入并检查数据。';}
 else if(ready>0){state='待导入';detail='原生数据库已收到下载结果，正在向选股分析库导入。';}
 else if(queues>0){state='已暂停 / 待续传';detail='后台队列还有任务，点击主按钮继续。';}
 else if(failed>0){state='部分任务失败';detail='部分数据未获取成功，可重新运行补缺；查看错误详情。';}
 else if(Number(q.total||0)>0){state='任务队列暂时结束';detail='仍需核对数据覆盖与最近更新日期，不能据此认定全市场完整。';}
 else if(Number(A.directory||0)+Number(HK.directory||0)>0){state='仅有部分本地数据';detail='尚未建立原生任务清单，可启动统一数据同步。';}
 const eligible=Number(quality.eligible||0),qualityChecked=Number(quality.checked||0);
 const kinds=q.byKind||{},progress=k=>{const n=kinds[k]||{};return `${num(n.imported)}页已入分析库 / ${num(Object.values(n).reduce((a,v)=>a+(Number(v)||0),0))}项已排队`;};
 return{state,detail,eligible,qualityChecked,buttonDisabled:!!q.serviceActive||commandPending,
   lines:[
    `① 股票目录：A股 ${num(A.directory)} 只，港股 ${num(HK.directory)} 只（目录任务 ${progress('catalog')}）`,
    `② 已存报价：A股 ${num(A.knownQuotes)} 只，港股 ${num(HK.knownQuotes)} 只`,
    `③ 历史日K：${num(quality.bars||0)} 根；≥220根且近期检查合格 ${num(eligible)} 只（检查点 ${num(qualityChecked)} 只；K线任务 ${progress('bars')}）`,
    `④ 财报：${num(quality.finance||0)} 条记录（任务 ${progress('finance')}）；未核实每家公司四类报表完整度`,
    `后台任务：等待 ${num(q.pending)}，请求中 ${num(q.running)}，待导入 ${num(q.ready)}，已入库确认 ${num(q.imported)}，失败 ${num(q.failed)}，导入校验失败 ${num(q.import_failed)}`
   ]};
}
// Meta snapshots are produced only AFTER a validated bars transaction. They
// are NOT an official enumeration of all listed firms or an absolute completeness proof.
function auditBars(meta=[],now=new Date()){
 let eligible=0,checked=0;const known=new Map(),nowMs=now.getTime();
 for(const m of meta||[]){if(!/^bootBar:(A|HK):\d{5,6}$/.test(m?.key||''))continue;
  const code=m.key,existing=known.get(code);if(existing&&Date.parse(existing.updatedAt||'')>=Date.parse(m.updatedAt||''))continue;
  known.set(code,m);
 }
 for(const m of known.values()){
   checked++;
   const days=(nowMs-Date.parse(String(m.latest||'').slice(0,10)+'T00:00:00Z'))/86400000;
   if(m.done&&Number(m.count)>=220&&Number.isFinite(days)&&days>=-1&&days<=14)eligible++;
 }
 return{eligible,checked};
}
async function getStatus(){const bridge=root.QuantDeskBackground;let native={};
 try{if(bridge)native=JSON.parse(bridge.status());else native={startError:'本APK缺少原生后台下载组件，无法保证全市场采集'};}
 catch(e){native={startError:'读取原生队列失败：'+safe(e.message)}}
 const db=root.QuantDB;if(!db||!root.QuantDataHealth)throw Error('分析库或统一诊断脚本未装载');
 await db.open();const [snapshot,allMeta]=await Promise.all([root.QuantDataHealth.inspect(db,native),db.all('meta')]);
 const q=auditBars(allMeta);return{snapshot,quality:{...q,bars:snapshot.counts.bars,finance:snapshot.counts.finance},native};
}
async function render(){if(!mounted||updating)return;updating=true;
 try{const {snapshot,quality,native}=await getStatus(),p=healthSummary(native,snapshot.markets,quality);
  el('qd83State').textContent=p.state;
  el('qd83Explanation').textContent=message?message+'\n'+p.detail:p.detail;
  const invalid=snapshot.discrepancies;
  el('qd83Numbers').textContent=p.lines.join('\n')+(invalid.invalidDirectory||invalid.invalidQuotes?`\n\n注意：另有 ${num(invalid.invalidDirectory)} 条目录记录、${num(invalid.invalidQuotes)} 条报价记录缺少有效市场代码/名称，不能算作合格A/H股票。`:'');
  el('qd83Run').disabled=p.buttonDisabled;
  el('qd83Run').textContent=p.buttonDisabled?'后台下载中 · 可切换应用':'建立 / 更新数据库';
  const exceptions=(snapshot.queue.errors||[]).slice(0,5).map(e=>`· ${safe(e.kind)} ${safe(e.market)}:${safe(e.code)} 页 ${safe(e.page)}：${safe(e.error)}`).join('\n');
  el('qd83Details').textContent=`数据来源是已入库记录而非任务队列推测。\n${snapshot.warning}\n当前系统状态：${snapshot.phase}\n${exceptions||'暂无最近失败样例。'}\nA股财报只覆盖已有授权/公开数据；V8.5多源模式可采集部分港股三大财报（部分需授权）；请按具体股票及报告期核查，不能宣称已建齐。\n任何已保存记录都不等于最终可作为短线买入信号。`;
 }catch(e){el('qd83State').textContent='诊断失败';el('qd83Explanation').textContent='无法核验数据库：'+safe(e.message);}
 finally{updating=false;}}
async function seedSymbols(){const bridge=root.QuantDeskBackground,db=root.QuantDB;if(!bridge||!db)return 0;
 await db.open();const [universe,stocks]=await Promise.all([db.all('universe'),db.all('stocks')]);
 const seen=new Set(),symbols=[];
 for(const x of [...universe,...stocks]){const m=x?.market,c=String(x?.code||'');if(!((m==='A'&&/^\d{6}$/.test(c))||(m==='HK'&&/^\d{5}$/.test(c))))continue;
  const id=m+':'+c;if(seen.has(id))continue;seen.add(id);symbols.push({market:m,code:c});}
 let sum=0;for(let i=0;i<symbols.length;i+=100)sum+=Number(bridge.seedSymbols(JSON.stringify(symbols.slice(i,i+100))))||0;
 return sum;
}
async function start(){if(commandPending)return;commandPending=true;message='正在提交建库请求……';
 const button=el('qd83Run');if(button)button.disabled=true;
 try{const bridge=root.QuantDeskBackground;if(!bridge)throw Error('当前安装包没有原生下载模块。请安装已通过原生构建的版本。');
  const seeded=await seedSymbols();const result=bridge.start(JSON.stringify(defaults));
  if(result!=='start_requested')throw Error('启动请求被拒绝：'+safe(result));
  message=`已提交建库请求。旧数据继续保留；本地已知股票补入 ${num(seeded)} 个日K任务（排队不等于下载成功）。`;
 }catch(e){message='建库未启动：'+safe(e.message);}finally{commandPending=false;await render();}
}
async function pause(){try{if(!root.QuantDeskBackground)throw Error('没有原生后台模块');
  root.QuantDeskBackground.pause();message='已提交暂停请求。已下载内容与任务检查点保留。';}
 catch(e){message='暂停失败：'+safe(e.message);}await render();}
let lastFullAudit=null,fullAuditBusy=false;
async function fullAudit(){
 if(fullAuditBusy)return;fullAuditBusy=true;const button=el('qd84Audit');if(button)button.disabled=true;
 const out=el('qd84AuditResult');if(out)out.textContent='正在逐只检查已有目录、K线记录与四类财报……';
 try{
  const db=root.QuantDB,bridge=root.QuantDeskBackground;if(!db||!root.QuantCoverageAudit)throw Error('数据核验模块缺失');
  await db.open();const [universe,stocks,allMeta,finance]=await Promise.all([db.all('universe'),db.all('stocks'),db.all('meta'),db.all('finance')]);
  let native={};try{native=bridge?JSON.parse(bridge.status()):{}}catch(_){}
  const report=root.QuantCoverageAudit.audit({universe,stocks,barMeta:allMeta,finance,native});
  lastFullAudit=root.QuantCoverageAudit.format(report);
  if(out)out.textContent=lastFullAudit+'\n\n这是本机持久化数据的审计，不代表供应商数据真实完整。';
 }catch(e){lastFullAudit=null;if(out)out.textContent='核验失败：'+safe(e.message);}
 finally{fullAuditBusy=false;if(button)button.disabled=false;}
}
async function copyAudit(){
 if(!lastFullAudit){const out=el('qd84AuditResult');if(out)out.textContent='请先点击“逐只核验真实数据”，再复制结果。';return;}
 try{if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(lastFullAudit);
 else {const field=document.createElement('textarea');field.value=lastFullAudit;document.body.append(field);field.select();const ok=document.execCommand('copy');field.remove();if(!ok)throw Error('复制被系统拒绝');}
  message='诊断报告已复制，不包含你的持仓和账户数据。';}
 catch(e){message='复制失败：'+safe(e.message)+'，你仍可手动长按诊断文本复制。';}
 const status=el('qd84AuditResult');if(status&&message)status.textContent+='\n'+message;
}
function mount(){if(mounted||!el('page-data')||!el('qd77BgPanel')||!el('v7AHInit'))return false;
 const card=el('page-data').querySelector(':scope > .card');if(!card)return false;
 const legacy=document.createElement('div');legacy.id='qd83LegacyInternal';legacy.className='qd83-internal';legacy.hidden=true;
 for(const child of [...card.childNodes])legacy.appendChild(child);
 const panel=document.createElement('section');panel.id='qd83Command';panel.className='qd83-command';
 panel.innerHTML=`<h2>全市场研究数据库 · 数据优先版</h2><p class="hint">只需点击一次，系统优先取得股票目录，并自动安排历史日K和财报下载、导入分析库与质量检查。以后还是点同一个按钮：自动续传、更新与补缺，不会清空原有数据。</p>
 <div class="qd83-statusline"><strong id="qd83State">正在核对</strong><span>记录以本地真实落库为准</span></div>
 <button type="button" id="qd83Run" class="primary qd83-primary">建立 / 更新数据库</button>
 <button type="button" id="qd83Pause" class="qd83-secondary">暂停下载（保留已完成数据）</button>
 <p id="qd83Explanation" class="status" aria-live="polite">正在核对原生下载队列和分析库……</p>
 <h3>数据完成情况</h3><p id="qd83Numbers" class="status" aria-live="polite">正在读取真实记录……</p>
 <div class="qd84-audit"><h3>逐只核验真实数据</h3><p class="hint">建议在同步后进行：逐只识别缺K线、K线根数不足、日期过旧、财报四类不齐。不会生成虚假的官方全量覆盖率。</p><button type="button" id="qd84Audit" class="primary">逐只核验真实数据</button><button type="button" id="qd84Copy">复制核验结果</button><p id="qd84AuditResult" class="status" aria-live="polite">尚未核验。本模块不包含买卖信号。</p></div>
 <details><summary>为什么还没达到可选股标准？查看失败原因和技术诊断</summary><p id="qd83Details" class="status">等待检测……</p></details>
 <p class="hint">重要：目前不能保证公开接口返回全部A/H数据。港股完整财报还缺已验收的数据源；数据不全时，雷达不得宣称“全市场已完成”。</p>`;
 card.append(panel,legacy);mounted=true;
 el('qd83Run').addEventListener('click',start);el('qd83Pause').addEventListener('click',pause);el('qd84Audit').addEventListener('click',fullAudit);el('qd84Copy').addEventListener('click',copyAudit);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)render();});
 document.addEventListener('quantdesk:dataImported',render);
 interval=setInterval(()=>{if(!document.hidden)render();},12500);
 render();return true;
}
if(typeof document!=='undefined'){
 let retries=0,t=setInterval(()=>{if(mount()||++retries>=160)clearInterval(t);},180);
}
return{defaults,healthSummary,auditBars,getStatus,seedSymbols,start,pause,render,mount,fullAudit,copyAudit};
});
