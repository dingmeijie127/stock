/* QuantDesk Data-First 8.4: auditable coverage, zero synthetic records. */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantCoverageAudit=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const VALID={A:/^\d{6}$/,HK:/^\d{5}$/};
const BARKEY=/^bootBar:(A|HK):(\d{5,6})$/;
const REPORT_TYPES=['summary','income','balance','cashflow'];
const clean=v=>String(v==null?'':v).trim();
const isoDay=s=>/^\d{4}-\d{2}-\d{2}$/.test(clean(s).slice(0,10))?clean(s).slice(0,10):null;
function isSymbol(x){return x&&VALID[x.market]?.test(clean(x.code))&&!!clean(x.name)&&clean(x.name)!==clean(x.code);}
function safeTime(v){const t=Date.parse(v||'');return Number.isFinite(t)?t:0;}
function validBarMeta(m){const x=BARKEY.exec(clean(m?.key));return x&&VALID[x[1]].test(x[2])&&m?.done===true&&Number.isInteger(Number(m.count))&&Number(m.count)>0&&isoDay(m.latest)&&safeTime(m.updatedAt)>0;}
function audit({universe=[],stocks=[],barMeta=[],finance=[],native={},now=new Date(),maxErrorExamples=30}={}){
 const result={schema:'quantdesk-data-audit-v1',asOf:now.toISOString(),coverageIsOfficial:false,
  note:'只衡量当前本机可识别证券，不等于交易所官方完整上市证券总量。未接入有授权的数据源前，不能保证A/H全部行情与财报。',
  markets:{},sources:{},errors:[],nativeQueue:{}};
 const dirs={A:new Map(),HK:new Map()},quotes={A:new Set(),HK:new Set()},meta=new Map(),fin=new Map();
 let invalidDirectory=0,invalidQuotes=0,invalidBarsMeta=0,invalidFinance=0;
 for(const x of universe){if(!isSymbol(x)){invalidDirectory++;continue;}const id=x.market+':'+x.code,previous=dirs[x.market].get(id);
   if(!previous||safeTime(x.catalogFetchedAt)>=safeTime(previous.catalogFetchedAt))dirs[x.market].set(id,x);}
 for(const x of stocks){if(!isSymbol(x)){invalidQuotes++;continue;}quotes[x.market].add(x.market+':'+x.code);}
 for(const x of barMeta){if(!clean(x?.key).startsWith('bootBar:'))continue;if(!validBarMeta(x)){invalidBarsMeta++;continue;}
  const [,market,code]=BARKEY.exec(x.key),id=market+':'+code,old=meta.get(id);
  if(!old||safeTime(x.updatedAt)>=safeTime(old.updatedAt))meta.set(id,x);}
 for(const r of finance){const market=clean(r?.market||'A'),code=clean(r?.code),type=clean(r?.type),dt=isoDay(r?.reportDate);
   if(!VALID[market]?.test(code)||!REPORT_TYPES.includes(type)||!dt){invalidFinance++;continue;}
   const id=market+':'+code,byDate=fin.get(id)||new Map(),types=byDate.get(dt)||new Set();types.add(type);byDate.set(dt,types);fin.set(id,byDate);}
 const nativeKeys=['pending','running','ready','imported','failed','import_failed','total'];
 for(const key of nativeKeys)result.nativeQueue[key]=Math.max(0,Number(native?.[key])||0);
 result.nativeQueue.errors=(Array.isArray(native?.errors)?native.errors:[]).slice(0,10).map(x=>({kind:clean(x.kind).slice(0,40),market:clean(x.market).slice(0,5),code:clean(x.code).slice(0,8),error:clean(x.error).slice(0,160)}));
 result.nativeQueue.serviceActive=!!native?.serviceActive;
 result.invalid={directory:invalidDirectory,quotes:invalidQuotes,barMeta:invalidBarsMeta,finance:invalidFinance};
 for(const market of ['A','HK']){
  const dir=dirs[market],joined=new Set([...dir.keys(),...quotes[market]]),p={known:joined.size,directory:dir.size,quotes:quotes[market].size,quoteWithoutDirectory:0,barsObserved:0,bars220:0,bars500:0,barsRecent220:0,missingBars:0,shortBars:0,staleBars:0,financeThreeTypes:0,financeFourTypes:0,financeMissing:0,financialCoverageSupported:true,missingExamples:[],shortExamples:[],staleExamples:[],missingFinanceExamples:[]};
  for(const id of joined){if(!dir.has(id)&&quotes[market].has(id))p.quoteWithoutDirectory++;
    const m=meta.get(id),code=id.split(':')[1];
    if(!m){p.missingBars++;if(p.missingExamples.length<maxErrorExamples)p.missingExamples.push(code);}else{
     const len=Number(m.count);p.barsObserved++;if(len>=220)p.bars220++;else {p.shortBars++;if(p.shortExamples.length<maxErrorExamples)p.shortExamples.push(code+'('+len+'根)');}
     if(len>=500)p.bars500++;
     // Calendar-day staleness is indicative only; prolonged exchange closure/suspension requires calendar verification.
     const last=safeTime(m.latest+'T00:00:00Z'),age=(now.getTime()-last)/86400000;
     if(len>=220&&age>=-1&&age<=14)p.barsRecent220++;
     else if(len>=220){p.staleBars++;if(p.staleExamples.length<maxErrorExamples)p.staleExamples.push(code+'('+m.latest+')');}
    }
    {
     const periods=fin.get(id),hasThree=periods&&[...periods.values()].some(set=>['income','balance','cashflow'].every(type=>set.has(type))),hasFour=periods&&[...periods.values()].some(set=>REPORT_TYPES.every(type=>set.has(type)));
     if(hasThree)p.financeThreeTypes++;else {p.financeMissing++;if(p.missingFinanceExamples.length<maxErrorExamples)p.missingFinanceExamples.push(code);}
     if(hasFour)p.financeFourTypes++;
    }
  }
  // Limit ratios to KNOWN local symbols only. No official denominator is available.
  p.localBarCoverage=p.known?Number((100*p.bars220/p.known).toFixed(2)):null;
  p.localFinanceThreeCoverage=p.known?Number((100*p.financeThreeTypes/p.known).toFixed(2)):null;
  p.localFinanceFourCoverage=p.known?Number((100*p.financeFourTypes/p.known).toFixed(2)):null;
  result.markets[market]=p;
 }
 return result;
}
function format(a){const lines=[`QuantDesk 数据核验 · ${a.asOf}`,'注意：分母为本地已知股票，未核验交易所官方全量，百分比不是全市场真实覆盖率。'];
 for(const market of ['A','HK']){const x=a.markets[market];lines.push(`${market==='A'?'A股':'港股'}：已知 ${x.known}只（目录${x.directory}、报价${x.quotes}）；有效K线≥220根 ${x.bars220}只（其中近期${x.barsRecent220}只），≥500根 ${x.bars500}只；完全缺K线 ${x.missingBars}只、历史不足 ${x.shortBars}只、历史过旧 ${x.staleBars}只。`);
  lines.push(`${market==='A'?'A股':'港股'}财报：同一报告期收入/资产负债/现金流三表 ${x.financeThreeTypes}/${x.known}，含摘要四类 ${x.financeFourTypes}/${x.known}；未取得 ${x.financeMissing}。仅指已有记录，不代表历史各期完整；港股部分数据需单独授权。`);
  if(x.missingExamples.length)lines.push('缺K线举例：'+x.missingExamples.slice(0,12).join('、'));}
 lines.push('原生队列：'+['pending','running','ready','imported','failed','import_failed'].map(k=>k+'='+a.nativeQueue[k]).join('；'));
 lines.push('异常记录：'+JSON.stringify(a.invalid));
 for(const x of a.nativeQueue.errors||[])lines.push(`失败样例：${x.kind} ${x.market}:${x.code} ${x.error}`);
 return lines.join('\n');}
return{audit,format,isSymbol,validBarMeta};
});
