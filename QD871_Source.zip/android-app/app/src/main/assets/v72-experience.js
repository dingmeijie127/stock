/* V7.2 mobile experience: visible bootstrap progress, safe ledger migration,
 * independently funded practice trade tickets (T+1 future-bar simulation).
 * No real broker execution, no invented holdings or fills. */
(function(){'use strict';
const $=id=>document.getElementById(id),DB=window.QuantDB,Core=window.QuantV72Core,Paper=window.QuantPaper;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt=v=>Number(v||0).toLocaleString('zh-CN',{maximumFractionDigits:2});
const marketKey=m=>'practice:'+m;
function addPanel(){
 const risk=$('v7HoldRisk');if(!risk||$('v72Portfolio'))return false;
 const section=risk.closest('.subpane')||$('page-positions');
 const pnl=document.createElement('div');pnl.id='v72Portfolio';pnl.className='card';
 pnl.innerHTML='<h2>我的真实持仓 · 自动读取</h2><p class="hint">覆盖安装且应用标识与签名相同：自动读取原账本。不同应用私有数据不能擅自读取，请选择之前导出的 JSON 备份；绝不使用虚构持仓。</p><div class="row"><button id="v72LedgerRefresh" class="primary">刷新本机真实持仓</button><button id="v72ImportButton">选择备份并导入</button></div><input type="file" id="v72ImportFile" accept=".json,application/json" style="display:none"><div id="v72LedgerStatus" class="status">正在读取账本…</div>';
 section.insertBefore(pnl,section.firstChild);
 $('v72LedgerRefresh').onclick=showLedger;
 $('v72ImportButton').onclick=()=>$('v72ImportFile').click();
 $('v72ImportFile').onchange=importLedger;
 const init=$('v7AHInit');if(init&&!$('v72InitStatus')){
  const status=document.createElement('div');status.id='v72InitStatus';status.className='init-monitor';
  status.innerHTML='<div class="init-monitor-title">建库任务进度与诊断</div><p id="v72InitSummary">尚未启动。点击后会立刻显示状态，失败也会显示原因。</p><div id="v72InitLog" class="status" aria-live="polite">尚无本轮日志。</div><div class="row"><button id="v72StopInit">暂停任务（保留数据）</button><button id="v72CheckInit">核对实际已入库数量</button></div>';
  init.insertAdjacentElement('afterend',status);
  $('v72CheckInit').onclick=auditData;
  $('v72StopInit').onclick=()=>{$('v7Stop')?.click();$('cancelRun')?.click();$('v72InitSummary').textContent='已请求停止，网络请求完成后保留已写入数据。'};
  init.addEventListener('click',()=>{$('v72InitSummary').textContent='建库指令已接收：开始检查本地数据库与联网接口…';$('v72InitLog').textContent='点击时间：'+new Date().toLocaleString('zh-CN')+'\n'+$('v72InitLog').textContent;},{capture:true});
 }
 showLedger();setupPractice();return true;
}
async function showLedger(){try{await DB.open();const x=await DB.get('ledger','main');const owned=(x?.holdings||[]).filter(h=>Number(h.shares)>0);
 $('v72LedgerStatus').textContent=owned.length?`已自动读取手机现有账本：${owned.length}只持仓，${x.trades?.length||0}笔交易。请对照券商核查股数和成本。\n`+owned.map(h=>`${h.market==='HK'?'港股':'A股'} ${h.name||h.code} ${h.code}：${h.shares}股，成本${fmt(h.cost)}`).join('\n'):'当前应用存储里未发现有效持仓。旧版是独立安装包时，请选择备份文件导入；我无法自动读取另一个App的私有数据。';
 }catch(e){$('v72LedgerStatus').textContent='读取账本失败：'+e.message}}
async function importLedger(){const file=$('v72ImportFile').files?.[0];if(!file)return;
 try{const x=Core.normalizeLedger(JSON.parse(await file.text()));await DB.open();const old=await DB.get('ledger','main');const existing=(old?.holdings||[]).filter(h=>h.shares>0);
 const summary=`将导入 ${x.holdings.length} 只股票、${x.trades.length} 笔交易。${existing.length?'当前已有'+existing.length+'只持仓，会被替换！':'当前无有效持仓。'} 请先备份原账本并核对来源。确认继续？`;
 if(!window.confirm(summary))return;
 if(old)await DB.put('meta',{key:'v72:ledgerBeforeImport',snapshot:old,savedAt:new Date().toISOString()});
 await DB.put('ledger',x);$('v72LedgerStatus').textContent='已导入并保存。正在刷新账本…';await showLedger();
 if(window.confirm('导入成功。要现在刷新 App 中的持仓、成本和风险模块吗？'))location.reload();
 }catch(e){$('v72LedgerStatus').textContent='导入失败，原持仓没有被修改：'+e.message;}finally{$('v72ImportFile').value='';}}
async function auditData(){try{await DB.open();const [catalog,stocks,fin,bars]=await Promise.all(['universe','stocks','finance','bars'].map(x=>DB.count(x)));$('v72InitSummary').textContent=`真实本地记录：股票目录${catalog}、报价${stocks}、财报${fin}、K线${bars}。这些记录不等于全市场已完成，详情请看覆盖核对。`;
 const state=await DB.get('meta','v7:ahInit');$('v72InitLog').textContent='上次建库：'+(state?JSON.stringify(state,null,2):'暂无检查点')+'\n'+$('v72InitLog').textContent;
 }catch(e){$('v72InitSummary').textContent='本地检查失败：'+e.message}}
function setupPractice(){if(!$('page-sim')||$('v72Practice'))return;
 const el=document.createElement('div');el.id='v72Practice';el.className='card';el.innerHTML=`<h2>模拟交易 · 买入 / 卖出</h2><p class="hint">参照常用证券App的委托习惯：账户资金、持仓、价格、手数、订单历史分开展示。委托只进入模拟盘，下一个真实交易日的K线满足条件才模拟成交；不会立即假成交。</p>
 <div class="two"><label>模拟账户市场<select id="v72Market"><option value="A">A股模拟盘 · 人民币</option><option value="HK">港股模拟盘 · 港币</option></select></label><label>买卖方向<select id="v72Side"><option value="BUY">买入</option><option value="SELL">卖出</option></select></label></div>
 <div class="two"><label>股票代码<input id="v72Code" placeholder="A股6位 / 港股5位" inputmode="numeric"></label><label>每手股数<input id="v72Lot" type="number" value="100" min="1" placeholder="港股依券商公告"></label></div>
 <div class="two"><label>委托限价<input id="v72Price" type="number" step="0.001" min="0" placeholder="限价，仅模拟"></label><label>股数<input id="v72Qty" type="number" step="1" min="1" placeholder="输入整手数量"></label></div>
 <div class="row"><button id="v72Place" class="primary">提交模拟委托</button><button id="v72Settle">根据后续交易日K线模拟成交</button><button id="v72PracticeRefresh">刷新账户</button></div>
 <p id="v72PracticeStatus" class="status" aria-live="polite">尚未提交模拟委托。</p><h3>资金与模拟持仓</h3><div id="v72Account" class="status">读取中…</div><h3>最近委托及状态</h3><div id="v72Orders" class="status">暂无记录</div>`;
 $('page-sim').append(el);
 $('v72Market').onchange=()=>{$('v72Lot').value=$('v72Market').value==='A'?'100':'';refreshPractice()};
 $('v72Place').onclick=()=>action(placePractice);
 $('v72Settle').onclick=()=>action(settlePractice);
 $('v72PracticeRefresh').onclick=()=>action(refreshPractice);
 refreshPractice();
}
async function action(fn){const b=$('v72Place');try{b.disabled=true;await fn();}catch(e){$('v72PracticeStatus').textContent='操作未完成：'+(e.message||e)}finally{b.disabled=false}}
async function loadBook(m){await DB.open();return (await DB.get('paper',marketKey(m)))||{...Paper.account('practice',100000),key:marketKey(m),market:m};}
async function refreshPractice(){await DB.open();const m=$('v72Market').value,book=await loadBook(m),ss=(await DB.all('signals')).filter(s=>s.strategy==='practice'&&s.market===m),events=await DB.all('paper_events'),byKey=new Map(events.map(e=>[e.signal,e]));
 $('v72Account').textContent=`模拟资金（${m==='A'?'CNY':'HKD'}）：${fmt(book.cash)}，初始${fmt(book.seed)}，已模拟成交${book.fills.length}笔。\n`+(book.positions.filter(p=>p.shares>0).map(p=>`${p.code}：${p.shares}股，成本${fmt(p.cost)}`).join('\n')||'暂无模拟持仓。真实持仓不会受影响。');
 $('v72Orders').textContent=ss.slice(-15).reverse().map(s=>`${s.date} ${s.code} ${s.side==='BUY'?'买入':'卖出'} ${s.qty}股 限价${fmt(s.limit)} · ${byKey.get(s.key)?.status||'待后续交易日价格验证'}`).join('\n')||'暂无模拟委托。';}
function localDate(){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
async function placePractice(){const market=$('v72Market').value,side=$('v72Side').value,code=$('v72Code').value.trim(),qty=Number($('v72Qty').value),limit=Number($('v72Price').value),lotSize=Number($('v72Lot').value),date=localDate(),book=await loadBook(market),signals=await DB.all('signals');
 const existing=signals.some(s=>s.strategy==='practice'&&s.market===market&&s.code===code&&s.date===date&&s.side===side);
 const held=book.positions.find(p=>p.market===market&&p.code===code)?.shares||0;
 const order=Core.validateOrder({market,code,qty,limit,lotSize,side},held,existing);
 if(side==='BUY'&&book.cash<qty*limit*1.002)throw Error('按委托限价估算模拟现金不足');
 if(!window.confirm(`仅模拟委托：${market}:${code} ${side==='BUY'?'买':'卖'} ${qty}股，限价${limit}。需要后续交易日行情才能确认模拟成交。继续？`))return;
 const now=new Date().toISOString(),snapshot=await DB.get('stocks',market+':'+code);
 const key=`practice:${market}:${code}:${date}:${side}`,sig={...order,key,strategy:'practice',version:'QD7.2',date,market,code,side,qty,limit,lotSize,generatedAt:now,dataCutoff:now,priceSource:snapshot?.source||'未记录',status:'pending'};
 await DB.put('signals',Paper.propose([],sig).signals[0]);await DB.put('paper',book);
 $('v72PracticeStatus').textContent='已保存模拟委托（待成交，不是已买入）。生成时间'+now+'，后续需有实际交易日数据。';await refreshPractice();}
async function settlePractice(){const market=$('v72Market').value,all=await DB.all('signals'),events=await DB.all('paper_events'),seen=new Set(events.map(e=>e.signal)),list=all.filter(s=>s.strategy==='practice'&&s.market===market&&!seen.has(s.key)&&s.status==='pending');let book=await loadBook(market),filled=0,blocked=0,awaiting=0;
 for(const order of list){const bars=await DB.withPrefix('bars',market+':'+order.code+':');const bar=bars.filter(b=>Paper.tradeDayAfter(order,b)).sort((a,b)=>a.date.localeCompare(b.date))[0];if(!bar){awaiting++;continue;}
 const out=Paper.execute(book,order,bar,{lotSize:order.lotSize});if(out.order.status==='pending'){awaiting++;continue;}
 if(out.order.status==='filled'){book={...out.book,key:marketKey(market),market};filled++;}else blocked++;
 await DB.put('paper_events',{key:'execution:'+order.key,signal:order.key,status:out.order.status,reason:out.reason,at:new Date().toISOString(),fill:out.fill||null});
 }
 await DB.put('paper',book);$('v72PracticeStatus').textContent=`新模拟成交${filled}笔，受限${blocked}笔，等待后续K线${awaiting}笔。成交仅用后续交易日开盘价+假设滑点，不是券商成交回报。`;
 await refreshPractice();}
function boot(){let attempts=0;const id=setInterval(()=>{attempts++;if(addPanel()||attempts>90)clearInterval(id)},120)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
