/* QD7.4 user screenshot holdings + per-stock network diagnostics */
(function(){'use strict';
const $=id=>document.getElementById(id),D=window.QuantDB,C=window.QuantV74,P=window.QuantProvider;
const clean=t=>String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>Number(n).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:3});
function isReady(){return !!($('v72Portfolio')&&$('v73Overlay')&&$('v73LiveFetch')&&$('v73Rows')&&D&&P&&C)}
async function showStatus(){const target=$('v74LedgerStatus');if(!target)return;try{await D.open();const old=await D.get('ledger','main');const held=(old?.holdings||[]).filter(x=>Number(x.shares)>0);target.textContent=held.length?`本机现有 ${held.length} 只真实持仓。导入截图前请先核对，按钮不会静默覆盖。`:'尚未发现有效真实账本，可以从券商截图建立7只持仓快照；无历史成交明细。';}catch(e){target.textContent='读取本地账本失败：'+e.message}}
async function importSnapshot(){const status=$('v74LedgerStatus'),button=$('v74Import');button.disabled=true;try{await D.open();const previous=await D.get('ledger','main'),p=C.plan(C.SNAPSHOT,previous);
 const msg=(p.willReplace?`当前已有 ${p.existingCount} 只持仓，导入会替换！已存成交记录将另行备份。\n`:'当前没有真实持仓记录。\n')+`本次券商剩余7只（瑞芯微已卖出）：通富微电、天齐锂业、立讯精密、创业板ETF、招商银行、长江电力、豪威集团。\n截图股票股数和成本将作为“快照”保存；旧现金余额不会冒充卖出后的最新余额；没有历史成交日期与手续费。确认导入吗？`;
 if(!confirm(msg)){status.textContent='已取消；原账本保持不变。';return}
 if(previous)await D.put('meta',{key:'v74:ledger:backup:'+Date.now(),savedAt:new Date().toISOString(),ledger:previous});
 const next=C.create(C.SNAPSHOT,previous);await D.put('ledger',next);const check=await D.get('ledger','main');if(check?.holdings?.length!==7)throw Error('写入后校验未通过');status.textContent='已导入并读取校验7只持仓快照，旧账本已先备份到本机meta库。当前价格及盈亏必须重新联网更新；历史交易记录不可凭截图补造。';
 if($('v72LedgerRefresh'))$('v72LedgerRefresh').click();if($('v7CheckExit')){$('v7HoldRisk').textContent='持仓已更新，请点击“逐只检查必须退出/卖出警戒”，且先确认行情时间。'}
 }catch(e){status.textContent='导入失败：'+e.message+'。请核对账本是否已写入，勿重复点击。'}finally{button.disabled=false}}
function mountImport(){if($('v74Import'))return;const panel=$('v72Portfolio');if(!panel)return;const el=document.createElement('div');el.className='card';el.innerHTML='<h3>持仓快照更新（7只，已排除瑞芯微）</h3><p class="hint">读取你最新上传的券商持仓截图：剩余7只持仓含700份创业板ETF；瑞芯微100股已于198元成交，单独记账请先核对是否已经存在成交记录。股数和成本是截图快照，未包含逐笔成交或确定截图交易日。<b>不会擅自覆盖现有账本。</b></p><button type="button" id="v74Import" class="primary">核对并导入截图持仓</button><p id="v74LedgerStatus" class="status" aria-live="polite"></p>';
 panel.insertAdjacentElement('afterbegin',el);$('v74Import').onclick=importSnapshot;showStatus();}
function tencentKline(code,market,timeout=10500){return new Promise((resolve,reject)=>{const sym=window.QuantProvider.tencentSymbol(code,market),v='qd_kline_'+Math.floor(Math.random()*1e9)+'_'+Date.now(),script=document.createElement('script');const finish=()=>{clearTimeout(timer);script.remove();try{delete window[v]}catch(_){}};let timer=setTimeout(()=>{finish();reject(Error('腾讯K线接口超时（10秒）；网络或跨域脚本被拦截'))},timeout);script.onerror=()=>{finish();reject(Error('腾讯K线脚本请求失败：可能被网络/CSP拦截'))};script.onload=()=>{let payload=window[v];finish();try{const rows=C.parseKlinePayload(payload,sym,market,code);if(rows.length<60)throw Error('K线条数不足60');resolve(rows)}catch(e){reject(e)}};script.src='https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?_var='+v+'&param='+encodeURIComponent(sym+',day,,,600,qfq');document.head.appendChild(script)})}
async function updateOne(key,log){const [market,code]=key.split(':'),lines=[],emit=x=>{lines.push(x);log.textContent=lines.join('\n')};
 emit(`联网研究 ${key}：开始获取报价和历史K线（不等待全市场建库）`);
 const parallel=await Promise.allSettled([P.quote(code,market),P.bars(code,market,600)]);
 if(parallel[0].status==='fulfilled'){
  const quote=parallel[0].value;if(quote?.price>0&&quote.code===code&&quote.market===market){await D.put('stocks',quote);emit('报价：成功；来源 '+(quote.source||'未说明')+'；行情时间 '+(quote.quoteTime||'未知'))}else emit('报价：返回数据代码或价格不符，拒绝写入');
 }else emit('报价：失败 '+(parallel[0].reason?.message||parallel[0].reason));
 let klineOK=false;
 if(parallel[1].status==='fulfilled'){const arr=parallel[1].value;if(Array.isArray(arr)&&arr.length>=60){await D.putMany('bars',arr);klineOK=true;emit('东方财富历史K线：成功 '+arr.length+' 根；最新 '+arr.at(-1).date)}else emit('东方财富K线：数据不足')}else emit('东方财富K线：'+(parallel[1].reason?.message||parallel[1].reason));
 if(!klineOK){try{emit('尝试独立腾讯历史K线备用接口…');const bars=await tencentKline(code,market);await D.putMany('bars',bars);klineOK=true;emit('腾讯K线补数成功：'+bars.length+' 根，最新 '+bars.at(-1).date)}catch(e){emit('腾讯K线备用失败：'+e.message)}}
 let quote=await D.get('stocks',key),bars=await D.withPrefix('bars',key+':');emit(`本地核对：有效报价 ${Number(quote?.price)>0?'1':'0'}，历史K线 ${bars.length} 根。`);
 if(!quote?.price||bars.length<253)emit('暂不生成积极买入信号：模型需可靠报价与至少253根日K。');
 // Per-stock A-share filings are optional and may take many seconds. Keep quote/K-line path fast.
 emit('财报/公告：仍按原数据中心单独补齐；本次不冒充已更新三大财报。');return{lines,quote,bars};}
async function redrawStudy(key,report){const [market,code]=key.split(':'),target=$('v73ResearchResult');try{
 const [quote,bars,financial,notices]=await Promise.all([D.get('stocks',key),D.withPrefix('bars',key+':'),D.withPrefix('finance',key+':'),D.withPrefix('notices',key+':')]);
 const result=window.QuantDecision.evaluate({quote,bars,financial,notices,now:new Date()});
 target.innerHTML='';const pre=document.createElement('details');pre.open=true;pre.innerHTML='<summary>本次联网记录（展开查看）</summary><pre style="white-space:pre-wrap;font-size:12px"></pre>';pre.querySelector('pre').textContent=report;target.appendChild(pre);
 const card=document.createElement('div');card.className='v73-verdict'+((!result.quoteOK||!result.barsOK)?' v73-unknown':'');const b=document.createElement('b');b.textContent=result.action||'数据不足';const reason=document.createElement('p');reason.textContent=result.reason||'暂无可靠依据';card.append(b,reason);target.append(card);
 const facts=document.createElement('div');facts.className='v73-facts';const data=[['报价',quote?.price||'缺失'],['报价时点',quote?.quoteTime||'未知'],['日K',bars.length+'根'],['最新K线日期',bars.at(-1)?.date||'未知'],['财报记录',financial.length],['公告记录',notices.length],['动量12-1',result.technical?.momentum12mSkip1m==null?'数据不足':result.technical.momentum12mSkip1m+'%'],['数据可信',result.quoteOK&&result.barsOK?'基础验证通过':'不满足积极建议']];for(const [label,value] of data){const r=document.createElement('div'),a=document.createElement('small'),z=document.createElement('strong');a.textContent=label;z.textContent=String(value);r.append(a,z);facts.append(r)}target.append(facts);if(financial.length===0){const warn=document.createElement('div');warn.className='status';warn.textContent='重要：已取得技术行情，不代表基本面合格。当前没有已核验财报，不能据此给出完整买入建议；请先补充三大财报。';target.append(warn);}
 const para=document.createElement('p');para.className='v73-muted';para.textContent='策略：'+(result.version||'未知')+'；风险与缺失：'+(result.issues||[]).concat(result.risks||[]).join('；')+'。该结果并非实时可成交指令。';target.append(para);
 }catch(e){target.textContent='已联网，但量化计算未完成：'+e.message+'\n'+report;}}
async function liveStudy(){const title=$('v73Subtitle')?.textContent||'',key=(title.match(/(A|HK):\d{5,6}/)||[])[0];const button=$('v73LiveFetch');if(!key){$('v73ResearchResult').textContent='无法确定研究股票代码，未发起请求';return}
 button.disabled=true;const target=$('v73ResearchResult');target.innerHTML='<div id="v74NetStatus" class="status" style="white-space:pre-wrap">准备访问数据源…</div>';const log=$('v74NetStatus');try{const result=await updateOne(key,log);await redrawStudy(key,result.lines.join('\n'));}catch(e){log.textContent+='\n任务发生错误：'+e.message}finally{button.disabled=false}}
function patchResearch(){const button=$('v73LiveFetch');if(!button||button.dataset.v74==='1')return;button.dataset.v74='1';button.textContent='联网补报价和日K，原地重新分析';
 // Capture blocks the older onclick handler which only navigated to another page.
 button.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();liveStudy()},true);
 // Research is cache-first for speed, but when no bars are saved perform online
 // fetch automatically; no speculative research prices appear while loading.
 $('v73Rows')?.addEventListener('click',e=>{const b=e.target.closest('button[data-research]');if(!b)return;const key=b.dataset.research;setTimeout(async()=>{try{const [market,code]=key.split(':'),bars=await D.withPrefix('bars',key+':'),q=await D.get('stocks',key);if($('v73Overlay')?.hidden!==false)return;const displayed=($('v73Subtitle')?.textContent||'');if(!displayed.includes(key))return;if(!q?.price||bars.length<253){await liveStudy()}}catch(_){}},250)},true);
}
function boot(){let n=0;const timer=setInterval(()=>{n++;if(isReady()){clearInterval(timer);mountImport();patchResearch()}else if(n>=100)clearInterval(timer)},150)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
