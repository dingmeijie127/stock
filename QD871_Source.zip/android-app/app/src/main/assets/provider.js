(function(root,factory){let v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantProvider=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
let seq=0;const CONST_UT='fa5fd1943c7b386f172d6893dbfba10';
const qp=(url,params={})=>url+'?'+new URLSearchParams(params).toString();
function jsonp(url,params={},cbField='cb',timeout=9000){
  // In the Android app, Java's same-origin allowlisted HTTPS proxy avoids CORS/JSONP restrictions.
  if(location.hostname==='appassets.androidplatform.net'){
    const tag='qd_android_reply',target=qp(url,{...params,[cbField]:tag}),proxy='/proxy?target='+encodeURIComponent(target);
    // Android proxy fetch MUST have its own hard timeout. Without it, a stalled native
    // request can leave sync stuck on the same page indefinitely.
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
    return fetch(proxy,{cache:'no-store',signal:controller.signal}).then(async res=>{
      const raw=(await res.text()).trim();if(!res.ok)throw Error('安卓网络代理 HTTP '+res.status+': '+raw.slice(0,120));
      let body=raw;if(body.startsWith(tag+'('))body=body.slice(tag.length+1).replace(/\);?$/,'');
      let data=JSON.parse(body);if(!data||data.rc===102||data.success===false)throw Error('行情/财报上游错误或限流');return data;
    }).catch(e=>{if(e.name==='AbortError')throw Error('安卓代理请求超过'+Math.ceil(timeout/1000)+'秒已超时，允许跳页/重试');throw e}).finally(()=>clearTimeout(timer));
  }
  return new Promise((resolve,reject)=>{let cb='qd_v3_cb_'+Date.now()+'_'+(++seq),script=document.createElement('script'),timer;const finalize=()=>{clearTimeout(timer);delete window[cb];script.remove()};window[cb]=(data)=>{finalize();if(!data||data.rc===102||data.success===false)reject(Error('上游返回错误/拒绝请求'));else resolve(data)};script.onerror=()=>{finalize();reject(Error('数据接口无法访问、CSP或JSONP不受支持'))};timer=setTimeout(()=>{finalize();reject(Error('请求超时；网络/限流/接口可能不可用'))},timeout);script.src=qp(url,{...params,[cbField]:cb});document.head.appendChild(script)})}
const fmtVal=v=>v==null||v==='-'||v===''||!Number.isFinite(Number(v))?null:Number(v);
const ts=v=>{if(!v)return null;let s=String(v);if(/^\d{10}$/.test(s))return new Date(Number(s)*1000).toISOString();if(/^\d{13}$/.test(s))return new Date(Number(s)).toISOString();if(/^\d{12}$/.test(s))return `${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}T${s.slice(8,10)}:${s.slice(10,12)}:00+08:00`;if(/^\d{14}$/.test(s))return `${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}T${s.slice(8,10)}:${s.slice(10,12)}:${s.slice(12,14)}+08:00`;return null};
function secid(code,market='A'){code=String(code);if(market==='HK')return '116.'+code.padStart(5,'0');return (code.startsWith('6')||code.startsWith('5')||code.startsWith('9')?'1.':'0.')+code.padStart(6,'0')}
function normalizeQuote(d,market='A'){let code=String(d.f12??d.f57??'').trim(),m=market==='HK'?'HK':'A';return{key:m+':'+code,code,market:m,name:d.f14??d.f58??code,price:fmtVal(d.f2??d.f43),pct:fmtVal(d.f3??d.f170),open:fmtVal(d.f17??d.f46),high:fmtVal(d.f15??d.f44),low:fmtVal(d.f16??d.f45),prev:fmtVal(d.f18??d.f60),volume:fmtVal(d.f5??d.f47),amount:fmtVal(d.f6??d.f48),turnover:fmtVal(d.f8??d.f168),pe:fmtVal(d.f9??d.f162),pb:fmtVal(d.f23??d.f167),cap:fmtVal(d.f20??d.f116),sector:String(d.f100||''),quoteTime:ts(d.f86)||null,fetchedAt:new Date().toISOString(),source:'东方财富公开行情（未经交易所直连核验）'};}
// Independent Tencent quote backup. It is NOT an all-market page source.
// Scripts use a fixed vendor URL and hardcoded symbol format; no HTML evaluation.
function tencentSymbol(code,market='A'){
 code=String(code).trim();
 if(market==='HK'){if(!/^\d{5}$/.test(code))throw Error('港股代码不合法');return 'hk'+code;}
 if(!/^\d{6}$/.test(code))throw Error('A股代码不合法');
 return (/^[659]/.test(code)?'sh':/^[48]/.test(code)?'bj':'sz')+code;
}
function parseTencent(raw,symbol,market='A'){
 const t=String(raw||'').split('~');
 if(t.length<35||String(t[2]||'')!==symbol.slice(2))throw Error('腾讯报价字段/股票代码校验失败');
 const price=fmtVal(t[3]),prev=fmtVal(t[4]);if(price===null||price<=0||prev===null||prev<=0)throw Error('腾讯报价缺少有效价格');
 const code=symbol.slice(2);
 const when=ts(t[30]); // For HK this provider has shown a different timestamp format; fail closed.
 return {key:market+':'+code,code,market,name:t[1]||code,price,prev,open:fmtVal(t[5]),high:fmtVal(t[33]),low:fmtVal(t[34]),
  pct:fmtVal(t[32]),volume:fmtVal(t[6]),amount:fmtVal(t[37])===null?null:fmtVal(t[37])*10000,turnover:fmtVal(t[38]),
  pe:fmtVal(t[39]),quoteTime:when,fetchedAt:new Date().toISOString(),source:'腾讯行情独立备用（非交易所直连）'};
}
async function tencentQuotes(items,market='A',timeout=8500){
 if(!Array.isArray(items)||!items.length)return [];
 const symbols=[...new Set(items.map(x=>tencentSymbol(x,market)))].slice(0,50);
 if(typeof document==='undefined'||!document.createElement)throw Error('当前环境不能载入腾讯行情备用脚本');
 return new Promise((resolve,reject)=>{
  const script=document.createElement('script');script.charset='gbk';
  const before=new Map(symbols.map(x=>[x,window['v_'+x]]));
  const cleanup=()=>{clearTimeout(timer);script.remove()};
  const timer=setTimeout(()=>{cleanup();reject(Error('腾讯备用行情请求超时'))},timeout);
  script.onerror=()=>{cleanup();reject(Error('腾讯备用行情不可达'))};
  script.onload=()=>{let got=[];
   for(const sym of symbols){const raw=window['v_'+sym];if(raw===before.get(sym))continue;
    try{got.push(parseTencent(raw,sym,market))}catch(e){} }
   cleanup();got.length?resolve(got):reject(Error('腾讯备用源未返回可核验的个股报价'));
  };
  script.src='https://qt.gtimg.cn/q='+symbols.join(',');document.head.appendChild(script);
 });
}
// Independent Sina batch quote fallback (known symbols only, not a stock directory).
function parseSinaQuote(raw,symbol){
 const t=String(raw||'').split(',');if(t.length<32)throw Error('新浪返回字段不足');
 const code=symbol.slice(2),price=fmtVal(t[3]),prev=fmtVal(t[2]),date=String(t[30]||'').trim(),time=String(t[31]||'').trim();
 const qtime=/^\d{4}-\d{2}-\d{2}$/.test(date)&&/^\d{2}:\d{2}:\d{2}$/.test(time)?date+'T'+time+'+08:00':null;
 if(!price||price<=0||!prev||prev<=0||!qtime||!Number.isFinite(Date.parse(qtime)))throw Error('新浪价格或报价时间不合法');
 return{key:'A:'+code,market:'A',code,name:t[0]||code,price,prev,open:fmtVal(t[1]),high:fmtVal(t[4]),low:fmtVal(t[5]),
  pct:(price-prev)/prev*100,volume:fmtVal(t[8]),amount:fmtVal(t[9]),quoteTime:qtime,fetchedAt:new Date().toISOString(),source:'新浪独立备用报价（非交易所直连）'};
}
async function sinaQuotes(items,market='A',timeout=7000){
 if(market!=='A')throw Error('新浪备用源当前仅支持A股');
 const symbols=[...new Set(items.map(x=>tencentSymbol(x,'A')))].slice(0,35);
 if(!symbols.length)return [];
 return new Promise((resolve,reject)=>{
  let script=document.createElement('script');script.charset='gb2312';
  const before=new Map(symbols.map(sym=>[sym,window['hq_str_'+sym]]));
  const done=()=>{clearTimeout(timer);script.remove()};
  let timer=setTimeout(()=>{done();reject(Error('新浪接口超时'))},timeout);
  script.onerror=()=>{done();reject(Error('新浪报价源不可访问'))};
  script.onload=()=>{let rows=[];for(const sym of symbols){let raw=window['hq_str_'+sym];if(raw===before.get(sym))continue;try{rows.push(parseSinaQuote(raw,sym))}catch(_){}}done();rows.length?resolve(rows):reject(Error('新浪未返回有效的报价与时间'))};
  script.src='https://hq.sinajs.cn/rn='+Date.now()+'&list='+symbols.join(',');document.head.appendChild(script);
 });
}
const FIELDS='f2,f3,f5,f6,f8,f9,f12,f13,f14,f15,f16,f17,f18,f20,f23,f86,f100';
const marketHealth=new Map();
async function marketRequest(path,params){
 // A burst of failures should not tie up the entire user workflow for minutes.
 const scope=path==='/api/qt/clist/get'?String(params?.fs||'market'):'single';
 const h=marketHealth.get(scope)||{failures:0,until:0};
 if(h.until>Date.now())throw Error('主/备行情连续故障，短时熔断；剩余页跳过并稍后补抓');
 let first;try{first=await jsonp('https://push2.eastmoney.com'+path,params,'cb',5500);if(!first?.data)throw Error('主行情源响应为空');first._qdSource='东方财富push2';marketHealth.set(scope,{failures:0,until:0});return first;}catch(err){try{let alt=await jsonp('https://push2delay.eastmoney.com'+path,params,'cb',5500);if(!alt?.data)throw Error('备用行情源响应为空');alt._qdSource='东方财富备用延迟行情';marketHealth.set(scope,{failures:0,until:0});return alt;}catch(e){h.failures++;if(h.failures>=3)h.until=Date.now()+25000;marketHealth.set(scope,h);throw Error('主源和备用源均失败：'+err.message+'；备用：'+e.message)}}}
function listParams(fs,page,size){return{pn:page,pz:size,po:1,np:1,ut:CONST_UT,fltt:2,invt:2,fid:'f6',fs,fields:FIELDS}}
async function stockPages(market='A',page=1,size=200){let fs=market==='HK'?'m:128':'m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048,m:0+t:81+s:262144';let r=await marketRequest('/api/qt/clist/get',listParams(fs,page,size));if(!r.data)throw Error('全市场行情响应缺少data');let diff=r.data.diff||[],rows=Array.isArray(diff)?diff:Object.values(diff);return{total:r.data.total||null,rows:rows.map(x=>normalizeQuote(x,market)).filter(x=>/^\d{5,6}$/.test(x.code)),rawCount:rows.length,source:r._qdSource,page};}
// fltt=2 returns decimal prices; never divide f43/f170 again.
async function eastmoneyQuote(code,market='A'){let r=await marketRequest('/api/qt/stock/get',{secid:secid(code,market),fields:'f43,f44,f45,f46,f47,f48,f57,f58,f60,f86,f162,f167,f168,f169,f170,f116',fltt:2,ut:CONST_UT});if(!r.data)throw Error('报价为空或代码不支持');let q=normalizeQuote(r.data,market);q.source=r._qdSource;return q}
async function quote(code,market='A'){
 let primaryError;try{return await eastmoneyQuote(code,market)}catch(e){primaryError=e;}
 try{const backup=await tencentQuotes([code],market);return backup[0]}
 catch(e){throw Error('东财主/备报价失败：'+primaryError.message+'；腾讯独立备用失败：'+e.message)}
}
function qualityModule(){const q=typeof QuantKlineQuality!=='undefined'?QuantKlineQuality:(typeof require==='function'?require('./kline-quality.js'):null);if(!q)throw Error('K线质量验证模块缺失');return q;}
async function fetchTencentHistory(code,market,limit){
 if(market!=='A')throw Error('腾讯独立历史日K备用暂时仅支持A股');
 const symbol=tencentSymbol(code,market),url=qp('https://web.ifzq.gtimg.cn/appstock/app/fqkline/get',{_var:'kline_dayqfq',param:`${symbol},day,,,${Math.min(640,limit)},qfq`});
 // Proxy is mandatory for reliable WebView reads: ordinary WebView CORS may reject this endpoint.
 const native=typeof location!=='undefined'&&location.hostname==='appassets.androidplatform.net';
 const target=native?'/proxy?target='+encodeURIComponent(url):url;
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12500);
 try{const res=await fetch(target,{cache:'no-store',signal:controller.signal});const text=await res.text();if(!res.ok)throw Error('腾讯历史源 HTTP '+res.status);
  return qualityModule().tencent(text,market,code);
 }finally{clearTimeout(timer)}
}
async function bars(code,market='A',limit=320){
 const q=qualityModule(),need=Math.max(80,Math.min(650,Number(limit)||320));let firstError;
 try{
  const r=await jsonp('https://push2his.eastmoney.com/api/qt/stock/kline/get',{secid:secid(code,market),fields1:'f1,f2,f3,f4,f5,f6',fields2:'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61',klt:101,fqt:1,end:'20500101',lmt:need,ut:CONST_UT},'cb',12500);
  const rows=q.eastmoney(r?.data?.klines,market,code);
  // A young IPO may legitimately have fewer than requested; require 80 to use in screen.
  q.validate(rows,{market,code,min:80});return rows;
 }catch(e){firstError=e;}
 if(market==='A')try{const rows=await fetchTencentHistory(code,market,need);q.validate(rows,{market,code,min:80});return rows;}
 catch(e){throw Error('历史K线双源失败；东财：'+firstError.message+'；腾讯：'+e.message);}
 throw Error('港股历史K线主源失败、尚无经过验证的独立历史备用：'+firstError.message);
}
async function sectors(kind='industry'){let fs=kind==='concept'?'m:90+t:3+f:!50':'m:90+t:2+f:!50',r=await jsonp('https://push2.eastmoney.com/api/qt/clist/get',{...listParams(fs,1,200),fid:'f3',fields:'f12,f14,f2,f3,f62,f104,f105,f128'});if(!r.data)throw Error('板块行情为空');return (Array.isArray(r.data.diff)?r.data.diff:Object.values(r.data.diff||{})).map(d=>({key:kind+':'+d.f12,kind,code:String(d.f12||''),name:String(d.f14||''),pct:fmtVal(d.f3),price:fmtVal(d.f2),flow:fmtVal(d.f62),up:fmtVal(d.f104),down:fmtVal(d.f105),leader:String(d.f128||''),fetchedAt:new Date().toISOString()}));}
const finColumnMap={revenue:'TOTAL_OPERATE_INCOME',profit:'PARENT_NETPROFIT'};
function cleanReport(raw,type='summary'){let code=String(raw.SECURITY_CODE||raw.CODE||'').trim();let date=String(raw.REPORTDATE||raw.REPORT_DATE||raw.QDATE||'').slice(0,10);let rev=fmtVal(raw.TOTAL_OPERATE_INCOME??raw.TOTALOPERATEREVE),profit=fmtVal(raw.PARENT_NETPROFIT??raw.PARENTNETPROFIT),cash=fmtVal(raw.NETCASH_OPERATE),debt=fmtVal(raw.DEBT_ASSET_RATIO);
return {key:`A:${code}:${date}:${type}`,market:'A',code,reportDate:date,type,name:raw.SECURITY_NAME_ABBR||raw.SECURITY_NAME||code,noticeDate:String(raw.NOTICE_DATE||raw.EITIME||raw.UPDATE_DATE||'').slice(0,19)||null,revenue:rev,profit,ocf:cash,ocfRatio:cash!=null&&profit!=null&&profit>0?cash/profit:null,revenueYoY:fmtVal(raw.YSTZ??raw.TOTALOPERATEREVETZ),profitYoY:fmtVal(raw.SJLTZ??raw.PARENTNETPROFITTZ),grossMargin:fmtVal(raw.XSMLL),roe:fmtVal(raw.WEIGHTAVG_ROE??raw.ROEJQ),debtRatio:debt,assets:fmtVal(raw.TOTAL_ASSETS),liabilities:fmtVal(raw.TOTAL_LIABILITIES),eps:fmtVal(raw.BASIC_EPS),currency:raw.CURRENCY||'CNY',rawFields:{...raw},source:'东方财富数据中心',fetchedAt:new Date().toISOString()};}
const types={summary:'RPT_LICO_FN_CPD',income:'RPT_DMSK_FN_INCOME',balance:'RPT_DMSK_FN_BALANCE',cashflow:'RPT_DMSK_FN_CASHFLOW'};
async function financialPage(reportDate,kind='summary',page=1,pageSize=100,code=null){let reportName=types[kind];if(!reportName)throw Error('未知财务类型');let df=kind==='summary'?'REPORTDATE':'REPORT_DATE',sortCol='NOTICE_DATE,SECURITY_CODE',filter=code?`(SECURITY_CODE="${code}")`:`(${df}='${reportDate}')`;let params={sortColumns:sortCol,sortTypes:'-1,1',pageSize,pageNumber:page,reportName,columns:'ALL',filter,source:'WEB',client:'WEB'};let r=await jsonp('https://datacenter-web.eastmoney.com/api/data/v1/get',params,'callback',25000);let v=r.result;if(!v)throw Error('财报接口返回数据为空/查询字段可能已经调整');let rows=(v.data||[]).map(x=>cleanReport(x,kind)).filter(x=>x.code&&x.reportDate);return {rows,pages:Number(v.pages)||Math.ceil((Number(v.count)||rows.length)/pageSize),total:v.count??null,page,rawCount:v.data?.length||0};}
async function announcements(code){const params={sr:-1,page_size:30,page_index:1,ann_type:'A',client_source:'web',stock_list:code};let r=await jsonp('https://np-anotice-stock.eastmoney.com/api/security/ann',params,'cb',25000);let list=r.data?.list;if(!Array.isArray(list))throw Error('公告接口响应格式不兼容当前客户端');return list.map(x=>{let id=String(x.art_code||''),dt=String(x.notice_date||'').slice(0,19);return{key:`A:${code}:${id}`,code,market:'A',title:String(x.title||''),date:dt,tag:(x.columns||[]).map(y=>y.column_name).join('、'),url:`https://data.eastmoney.com/notices/detail/${code}/${encodeURIComponent(id)}.html`,source:'东方财富公告索引（请查阅正式公告正文）',fetchedAt:new Date().toISOString()}}).filter(x=>x.title&&x.date)}
async function globalNews(){let r=await jsonp('https://np-weblist.eastmoney.com/comm/web/getFastNewsList',{client:'web',biz:'web_724',fastColumn:102,sortEnd:'',pageSize:60,req_trace:Date.now()},'callback',24000),raw=r.data?.fastNewsList;if(!Array.isArray(raw))throw Error('财经快讯源未返回可识别的新闻列表');return raw.map((x,i)=>({key:'global:'+String(x.code||x.id||x.showTime||'')+':'+i,title:String(x.title||x.summary||'').replace(/<[^>]*>/g,''),summary:String(x.summary||'').replace(/<[^>]*>/g,'').slice(0,300),date:String(x.showTime||x.pubTime||''),source:'东方财富7x24快讯',fetchedAt:new Date().toISOString()})).filter(x=>x.title);}
return {jsonp,secid,normalizeQuote,fetchTencentHistory,stockPages,quote,eastmoneyQuote,tencentQuotes,sinaQuotes,parseSinaQuote,parseTencent,tencentSymbol,bars,sectors,financialPage,announcements,globalNews,cleanReport,ts};
});
