/* V8.0: one format contract for daily OHLCV, regardless of vendor. No invented bars. */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantKlineQuality=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const number=v=>v===undefined||v===null||v===''?null:Number(v);
function strictDate(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T12:00:00Z');return !Number.isNaN(+d)&&d.toISOString().slice(0,10)===s;}
function normalized({market,code,date,open,high,low,close,volume,amount=null,source}){
 const r={market,code,date,open:number(open),high:number(high),low:number(low),close:number(close),volume:number(volume),amount:number(amount),source};
 r.key=market+':'+code+':'+date;return r;
}
function validate(rows,{market,code,min=80,asOf=new Date(),allowShort=false}={}){
 if(!['A','HK'].includes(market)||!/^\d{6}$/.test(code)&&!(market==='HK'&&/^\d{5}$/.test(code)))throw Error('KLINE_SYMBOL_INVALID');
 if(!Array.isArray(rows)||rows.length===0)throw Error('KLINE_EMPTY');
 let last='',seen=new Set();for(const r of rows){
  if(!r||r.market!==market||r.code!==code||r.key!==market+':'+code+':'+r.date)throw Error('KLINE_SYMBOL_MISMATCH');
  if(!strictDate(r.date)||r.date<=last||seen.has(r.date))throw Error('KLINE_DATE_DUPLICATE_OR_UNSORTED');
  if(Date.parse(r.date+'T00:00:00Z')>asOf.getTime()+36*3600000)throw Error('KLINE_FUTURE_DATE');
  for(const k of ['open','close','high','low','volume'])if(!Number.isFinite(r[k]))throw Error('KLINE_BAD_'+k.toUpperCase());
  if(r.low<=0||r.high<r.low||r.open<r.low-0.0005||r.open>r.high+0.0005||r.close<r.low-0.0005||r.close>r.high+0.0005||r.volume<0)throw Error('KLINE_OHLC_INCONSISTENT');
  seen.add(r.date);last=r.date;
 }
 if(rows.length<min&&!allowShort)throw Error(`KLINE_SHORT_${rows.length}_NEED_${min}`);
 return {count:rows.length,first:rows[0].date,last,source:rows[0].source||'未知',short:rows.length<min};
}
function eastmoney(raw,market,code,source='东方财富前复权日K'){
 if(!Array.isArray(raw)||!raw.length)throw Error('EASTMONEY_EMPTY_KLINES');
 const rows=raw.map(s=>{const a=String(s).split(',');return normalized({market,code,date:a[0],open:a[1],close:a[2],high:a[3],low:a[4],volume:a[5],amount:a[6],source});});
 validate(rows,{market,code,min:1});return rows;
}
function tencent(body,market,code,source='腾讯独立历史日K（复权规则需核验）'){
 if(market!=='A')throw Error('TENCENT_MARKET_UNSUPPORTED');
 let text=typeof body==='string'?body.trim():null,parsed;
 if(text!==null){const first=text.indexOf('{'),last=text.lastIndexOf('}');if(first<0||last<=first||(/^[\s\S]*?[=(]/.test(text)&&text.slice(0,first).length>120))throw Error('TENCENT_FORMAT_UNRECOGNIZED');
  parsed=JSON.parse(text.slice(first,last+1));}
 else parsed=body;
 const symbol=(/^[659]/.test(code)?'sh':/^[48]/.test(code)?'bj':'sz')+code;
 const entry=parsed?.data?.[symbol];if(!entry||typeof entry!=='object')throw Error('TENCENT_SYMBOL_MISMATCH');
 const input=(Array.isArray(entry.qfqday)&&entry.qfqday.length?entry.qfqday:entry.day);
 if(!Array.isArray(input)||!input.length)throw Error('TENCENT_EMPTY_KLINES');
 const rows=input.map(a=>{
  if(!Array.isArray(a)||a.length<6)throw Error('TENCENT_BAD_KLINE_ROW');
  return normalized({market,code,date:a[0],open:a[1],close:a[2],high:a[3],low:a[4],volume:a[5],source});
 });
 validate(rows,{market,code,min:1});return rows;
}
function classifyError(err){const s=String(err?.message||err||'未知错误');
 if(/429|限流|频繁|rc.?102|request.?limit/i.test(s))return 'RATE_LIMIT_OR_UPSTREAM';
 if(/timeout|超时|abort|network|网络|Failed to fetch|502|503|Cannot connect/i.test(s))return 'NETWORK_OR_PROXY';
 if(/KLINE_SHORT|不足.*根|少于.*根/.test(s))return 'SHORT_HISTORY';
 if(/KLINE_|格式|响应|json|JSON|schema|payload/i.test(s))return 'SCHEMA_OR_DATA_INVALID';
 if(/IndexedDB|事务|QuotaExceeded|数据库|storage/i.test(s))return 'STORAGE';
 return 'OTHER';
}
function readiness(rows,{market='A',code,min=220,now=new Date(),maxAgeDays=12}={}){
 try{const v=validate(rows,{market,code,min});const age=(now.getTime()-Date.parse(v.last+'T15:00:00+08:00'))/86400000;
  if(age< -1||age>maxAgeDays)return {ok:false,reason:'STALE_HISTORY',count:v.count,last:v.last,age};
  return{ok:true,reason:'OK',count:v.count,last:v.last,source:v.source};
 }catch(e){return{ok:false,reason:classifyError(e)==='SHORT_HISTORY'?'SHORT_HISTORY':'INVALID_HISTORY',details:e.message,count:rows?.length||0};}
}
return{validate,eastmoney,tencent,readiness,classifyError,strictDate};});
