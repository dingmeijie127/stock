/* V7 workflow: EVERY discovered symbol is assigned a research status before shortlist.
 * Decision records are never modified by this application after first creation.
 * Cannot claim full market coverage when source symbol list / finances missing.
 */
(function(){'use strict';
const D=QuantDB,P=QuantProvider,Q=QuantDecision,R=QuantResearch,X=QuantRisk,Paper=QuantPaper,Audit=QuantV75;
const $=id=>document.getElementById(id),html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const num=n=>Number.isFinite(+n)?Number(n).toFixed(2):'未知';
let scanning=false,abort=false,latestGood=[],stats=null,initializing=false;
function setStatus(s){
 const target=$('v7Status');if(target)target.textContent=s;
 if(initializing){const log=$('v72InitLog');if(log){log.textContent=new Date().toLocaleTimeString('zh-CN')+' '+s+'\n'+(log.textContent||'').slice(0,4500);}const label=$('v72InitSummary');if(label)label.textContent=s;}
}
function getUniverseRows(catalog,quotes){const m=new Map();for(const q of catalog||[])if(q?.market&&q?.code)m.set(q.market+':'+q.code,{...q});for(const q of quotes||[])if(q?.market&&q?.code){const key=q.market+':'+q.code;m.set(key,{...(m.get(key)||{}),...q});}return [...m.values()].filter(x=>['A','HK'].includes(x.market));}
function groupByMarket(rows){return ['A','HK'].map(m=>[m,rows.filter(x=>x.market===m)]);}
async function dataAudit(){
 const uni=await D.all('universe'),quotes=await D.all('stocks'),finAll=await D.all('finance'),rows=getUniverseRows(uni,quotes),names=new Set(rows.map(x=>x.market+':'+x.code));
 let output='<b>本地数据覆盖（不是交易所真实全量）：</b>';
 for(const [m,list] of groupByMarket(rows)){let quoteCount=list.filter(x=>+x.price>0&&Number.isFinite(Date.parse(x.quoteTime||''))).length;
  const finCount=finAll.filter(x=>x.market===m&&x.type==='summary').length;
  output+=`<p>${m==='A'?'A股':'港股'}：已知代码 <b>${list.length}</b>，存储过报价 <b>${quoteCount}</b>，摘要报表记录 <b>${finCount}</b>；无行情/财报的证券仍计入待补数</p>`;
 }
 output+=`<small>合计去重代码 ${names.size}。A/H目录缺失部分无法由程序推测；请先建库。行情历史、财报四类、公告还须分别核验。</small>`;$('v7Coverage').innerHTML=output;
}
const batch=async(a,n,fn)=>{for(let i=0;i<a.length&&!abort;i+=n){await Promise.all(a.slice(i,i+n).map(fn));if(i%120===0)await new Promise(r=>setTimeout(r,0));}};
function timeDate(){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
async function inspectCode(){const raw=$('v7FindCode').value.trim(),market=raw.length===5?'HK':'A';if(!/^\d{5,6}$/.test(raw))throw Error('请输入A股6位代码或港股5位代码');const code=raw;const key=market+':'+code;const q=await D.get('stocks',key),u=await D.get('universe',key),bars=await D.withPrefix('bars',key+':'),fin=await D.withPrefix('finance',key+':'),notices=await D.withPrefix('notices',key+':'),screen=await D.get('screening_items',key);$('v7LookupResult').textContent=`${market}:${code} 名称 ${q?.name||u?.name||'未找到'}\n股票目录 ${u?'已有':'缺失'}；报价 ${q?.price>0?'已有 '+q.price+' 时间'+(q.quoteTime||'未知'):'缺失'}\n历史K线 ${bars.length}条（最新 ${bars.at(-1)?.date||'无'}）；财报 ${fin.length}条：${[...new Set(fin.map(x=>x.type))].join('/')}；公告 ${notices.length}条\n最新筛选状态 ${screen?.status||'尚未计算'}，原因 ${screen?.reasons?.join('；')||'无记录'}。`; }
window.QuantDeskRefreshAHCoverage=dataAudit;
async function exportScreening(){const rows=await D.all('screening_items');$('v7LookupResult').textContent=`已记录 ${rows.length}只股票；下方JSON可供导出审计（数据可能很多）。`;const json=JSON.stringify({exportedAt:new Date().toISOString(),model:R.VERSION,universe:await D.get('screenings','latest'),stocks:rows});$('v7ScreenExport').value=json;$('v7ScreenExport').select();}
async function fullScreen({offline=false}={}){
 if(scanning)return;scanning=true;abort=false;let start=Date.now();$('v7Stop').disabled=false;latestGood=[];
 try{
  const uni=await D.all('universe'),quotes=await D.all('stocks'),all=getUniverseRows(uni,quotes),saved=new Map(quotes.map(x=>[x.market+':'+x.code,x]));
  if(!all.length){setStatus('股票池为空：先在数据存储页运行A/H股票目录初始化；没有真实目录就不假装扫过5000只。');return;}
  const counts={},qualified=[],results=[];let n=0;setStatus(`第一层：开始逐一筛选当前本地A/H证券目录及行情共 ${all.length} 只，每只有结果，无论通过与否。`);
  await batch(all,20,async x=>{
   const quote=saved.get(x.market+':'+x.code);const fin=await D.withPrefix('finance',x.market+':'+x.code+':');
   const result=R.screen({...x,...(quote||{})},fin,new Date());results.push({...result,name:x.name||quote?.name||x.code,sector:x.sector||quote?.sector,quote:quote||null,market:x.market,code:x.code});
   counts[result.status]=(counts[result.status]||0)+1;if(result.status==='qualified')qualified.push(results.at(-1));n++;
   if(n%100===0||n===all.length)setStatus(`完整逐只初筛 ${n}/${all.length}：合格 ${qualified.length}，缺财报 ${counts.missing_finance||0}，缺行情 ${counts.missing_quote||0}，明确未通过 ${counts.rejected||0}，金融专用待建模 ${counts.special_sector||0}；耗时${((Date.now()-start)/1000).toFixed(1)}秒`);
  });
  const done=!abort;await D.put('screenings',{key:'latest',at:new Date().toISOString(),universeCount:all.length,counts,complete:done,byMarket:Object.fromEntries(groupByMarket(all).map(([m,rows])=>[m,rows.length]))});
  for(let i=0;i<results.length;i+=100)await D.putMany('screening_items',results.slice(i,i+100).map(r=>({key:r.market+':'+r.code,market:r.market,code:r.code,name:r.name,status:r.status,reasons:r.reasons,at:new Date().toISOString()})));
  stats={total:all.length,counts,complete:done};
  if(abort){setStatus(`人工停止：已初筛${n}/${all.length}。未完成不能称为全量筛选；已保存结果供复查。`);return;}
  // Baseline is the ENTIRE known universe; quality candidates may be limited only by an explicit user choice.
  // Do not quietly discard qualified firms because they are not among the top ROE values.
  qualified.sort((a,b)=>(b.fundamentals?.roe||0)-(a.fundamentals?.roe||0));
  const limit=Number($('v7Depth').value)||5000,deep=qualified.slice(0,limit),deepIds=deep.map(x=>x.market+':'+x.code);
  let checked=0,picks=[],failed=0,deepOutcomes=[];
  setStatus(`已逐只完成 ${all.length} 家基本面筛选，其中合格 ${qualified.length} 家；将深验 ${deep.length} 家。其余 ${qualified.length-deep.length} 家列为“未深验”，不会当作淘汰。`);
  // Keep a complete visible roster even while the individual K-line downloads are running.
  const current=Audit.audits(results,deepIds,[]);await D.put('meta',{key:'v75:deepStatus',updatedAt:new Date().toISOString(),selected:deepIds,checked:0});
  for(let i=0;i<current.length;i+=100)await D.putMany('screening_items',current.slice(i,i+100).map(r=>({...r,at:new Date().toISOString()})));
  window.QuantV75UI?.render?.();
  await batch(deep,3,async x=>{
   let bars=[],plan=null,fetchError='';
   try{
    bars=await D.withPrefix('bars',x.market+':'+x.code+':');
    if(!offline&&(bars.length<253||Date.now()-Date.parse(bars.at(-1)?.date||'')>7*86400000)){
     try{const downloaded=await P.bars(x.code,x.market,650);if(downloaded.length)await D.putMany('bars',downloaded);bars=await D.withPrefix('bars',x.market+':'+x.code+':');}catch(e){fetchError=String(e?.message||e);failed++;}
    }
    if(bars.length>=253)plan=R.plan({market:x.market,code:x.code,lotSize:x.quote?.lotSize},bars,{equity:Number($('v7Equity').value)||100000,cash:Number($('v7Equity').value)||100000,riskFraction:0.005,maxStockFraction:0.10},x.quote?.lotSize);
    if(plan?.eligible)picks.push({...x,plan,bars});
   }catch(e){fetchError=String(e?.message||e);failed++;}
   const decision=Audit.reasonForPlan(plan,bars,fetchError),row={key:x.market+':'+x.code,market:x.market,code:x.code,name:x.name,status:x.status,reasons:x.reasons||[],screenReasons:x.reasons||[],deepStatus:decision.status,deepReason:decision.reason,barCount:bars.length,lastBar:bars.at(-1)?.date||null,financeComplete:!!x.fundamentals?.complete,plan:plan?.eligible?plan:null,at:new Date().toISOString()};
   deepOutcomes.push(row);await D.put('screening_items',row);
   checked++;
   if(checked%10===0||checked===deep.length){setStatus(`全池 ${all.length} 家初筛完成；合格 ${qualified.length} 家；技术深验 ${checked}/${deep.length}，买点观察 ${picks.length}，K线请求失败 ${failed}。全部名单和逐只原因可在下方查看。`);await D.put('meta',{key:'v75:deepStatus',updatedAt:new Date().toISOString(),selected:deepIds,checked,qualified:qualified.length});window.QuantV75UI?.render?.();}
  });
  latestGood=picks.sort((a,b)=>(b.fundamentals?.roe||0)-(a.fundamentals?.roe||0));
  const classifications=Audit.tally(Audit.audits(results,deepIds,deepOutcomes));
  $('v7Results').innerHTML=`<p><b>股票池 ${all.length} 家；基本面合格 ${qualified.length} 家；技术深验 ${checked} 家；符合全部买点条件 ${picks.length} 家。</b></p><p class="hint">未深验 ${qualified.length-checked} 家；趋势未通过 ${classifications.trend_fail||0} 家；K线不足 ${classifications.insufficient_bars||0} 家；K线失败 ${classifications.data_error||0} 家；港股每手缺失 ${classifications.missing_lot||0} 家。零买点不等于零优质企业。</p>`+
    (latestGood.slice(0,20).map(x=>`<div class="result"><b>${html(x.name)} ${html(x.code)} [${x.market}]</b><p>计划观察区间：${num(x.plan.planLow)}～${num(x.plan.planHigh)}；参考 ${x.plan.qty} 股；风险失效观察位 ${num(x.plan.invalidation)}；<small>最近日K：${html(x.plan.barDate)}</small></p></div>`).join('')||'<p>本轮没有满足严格买点规则的证券；查看下方“基本面合格”和“趋势未通过”列表，不要误以为全市场没有好公司。</p>');
  await D.put('meta',{key:'v75:final',at:new Date().toISOString(),qualified:qualified.length,selected:deep.length,checked,picks:picks.length,classifications});
  window.QuantV75UI?.render?.();
  await D.put('meta',{key:'v7:lastFullScreen',when:new Date().toISOString(),total:all.length,qualified:qualified.length,analyzed:checked,picks:picks.length,counts,complete:true});
  setStatus(`研究计算结束。全库初筛 ${all.length}只；技术深验${checked}只；观察${picks.length}只；总耗时${((Date.now()-start)/1000).toFixed(1)}秒。数据完整度请查看上方覆盖；“已扫完”不等于“已拿到完整财报”。`);
 }finally{scanning=false;$('v7Stop').disabled=true;}
}
async function ahInitialize(){
 if(scanning)throw Error('已有筛选任务运行');scanning=true;initializing=true;abort=false;let t=Date.now(),failures=[];
 try{
  const mk=QuantBootstrap.create({db:D,provider:P,fastSync:QuantFastSync,financeSync:QuantFinanceSync,universeSync:QuantUniverse,stop:()=>abort,onEvent:e=>{if(e.stage==='market-pages')setStatus(`A股分页：已写入${e.stored||0}条，成功页${e.committedPages||0}，状态${e.status||''}`);if(e.stage==='finance-pages')setStatus(`四类财报：${e.kind||''} 第${e.page||'?'}页，状态${e.status||''}，已写入${e.saved||0}`);if(e.stage==='quotes')setStatus(`报价补数：成功${e.saved||0}只，失败批次${e.batchFailures||0}`);if(e.stage==='bars')setStatus(`A股K线：成功${e.done||0}，跳过已有${e.skipped||0}，失败${e.failed||0} / ${e.total||'?'}；写入后才计数`);}});
  setStatus('初始化阶段1：A股股票目录与全市场快照，失败页不会清空已经保存的数据。');
  try{const catalog=await mk.directory();if(!catalog.ok)failures.push(`A股目录尚不完整：仅${catalog.count||0}只`);
   const quoteResult=await mk.quotes({limit:6000});if(!quoteResult.ok)failures.push(`有效报价覆盖不足：${quoteResult.freshQuotes||0}/${quoteResult.directory||0}`);
  }catch(e){failures.push('A股目录/快照 '+e.message);}
  if(abort)return;
  setStatus('初始化阶段2：港股全市场快照、公司代码和现价；具体覆盖率以本地统计为准。');
  try{const h=await QuantFastSync.create({provider:P,db:D,market:'HK',size:200,concurrency:2,stop:()=>abort,progress:p=>{if(p.phase==='saved')setStatus(`港股快照成功页${p.committedPages||'?'}，目前已入库${p.stored||0}条`);}}).run();if(!h.complete)failures.push('港股部分页面未完成');}catch(e){failures.push('港股目录/行情 '+e.message);}
  if(abort)return;
  const periods=Number($('v7Quarters').value)||8;
  setStatus('初始化阶段3：A股四类财报逐季度采集，每页入库与检查点原子提交；港股三表尚无已验收授权数据源。');
  try{const financeResult=await mk.finance({quarters:periods});if(!financeResult.complete)failures.push('A股四类财报存在未成功页面');}catch(e){failures.push('A股财报 '+e.message);}
  if(abort)return;
  if($('v7History').checked){
   const barsNumber=Number($('v7Bars').value)||650;
   setStatus('初始化阶段4：为A股全部已知股票保存历史K线，支持中断续传。');
   try{await mk.bars({limit:barsNumber,maxSymbols:20000,intervalMs:120,concurrency:Number($('v76Concurrency')?.value)||3});}catch(e){failures.push('A股全池历史 '+e.message);}
   if(abort)return;
   const hk=(await D.all('stocks')).filter(x=>x.market==='HK'&&x.code&&/^\d{5}$/.test(x.code));
   let done=0,skip=0,fail=0;
   for(const x of hk){if(abort)break;
    const key='bootBar:HK:'+x.code,check=await D.get('meta',key);
    if(check?.done&&check.count>=253){skip++;continue;}
    try{let bs=await P.bars(x.code,'HK',barsNumber);if(bs.length<80)throw Error('有效日K不足80根');await D.commitPage('bars',bs,{key,done:true,count:bs.length,lastDate:bs.at(-1).date,updatedAt:new Date().toISOString()});done++;}
    catch(e){fail++;if(fail===1)failures.push('部分港股历史K线失败，已保存成功项');}
    if((done+skip+fail)%15===0)setStatus(`港股历史K线：新入库${done}只，已有跳过${skip}只，失败${fail}只 / 已知池${hk.length}只；可以续传。`);
    await new Promise(r=>setTimeout(r,120));
   }
  }
  await D.put('meta',{key:'v7:ahInit',when:new Date().toISOString(),finished:!abort&&failures.length===0,partial:failures.length>0,errors:failures,marketCount:(await D.all('stocks')).length});
  setStatus(`本轮A/H初始化${abort?'暂停':failures.length?'部分完成（需要补抓）':'流程结束'}，耗时${((Date.now()-t)/1000).toFixed(1)}秒；${failures.length?'缺口：'+failures.join('；'):'请继续核对各类别数据库覆盖，不等于所有公司财报完整'}。港股完整三大报表待接入已授权源，不能标完成。`);
  await dataAudit();
 }finally{scanning=false;initializing=false;const btn=$('v7AHInit');if(btn)btn.disabled=false;}
}
async function realRisk(){const x=await D.get('ledger','main'),holdings=x?.holdings?.filter(h=>h.shares>0)||[],trades=x?.trades||[];let results=[];
 for(const h of holdings){let quote=await D.get('stocks',(h.market==='HK'?'HK':'A')+':'+h.code),bars=await D.withPrefix('bars',(h.market==='HK'?'HK':'A')+':'+h.code+':'),finance=await D.withPrefix('finance',(h.market==='HK'?'HK':'A')+':'+h.code+':'),notices=await D.withPrefix('notices',(h.market==='HK'?'HK':'A')+':'+h.code+':');
  const decision=Q.evaluate({quote,bars,financial:finance,notices,holding:h,now:new Date()});const risk=X.evaluate({...h,trades:trades.filter(t=>t.code===h.code&&(t.market||'A')===(h.market||'A'))},decision);results.push({h,risk,decision});}
 $('v7HoldRisk').innerHTML=results.length?results.map(x=>`<div class="result"><b>${html(x.h.name||x.h.code)}（${x.h.code}）</b>：<b class="${x.risk.level==='exit'?'risk':'watch'}">${html(x.risk.label)}</b><p>${html(x.risk.reason)}。可卖参考 ${x.risk.sellable} 股；风险价位 ${num(x.risk.stop)}；数据截至 ${html(x.decision.quoteTime||'未知')}。</p></div>`).join(''):'暂无真实持仓。';
 return results;}
async function journal(){let x=await D.get('paper','rules')||Paper.account('rules',100000),ml=await D.get('paper','ml')||Paper.account('ml',100000),sig=await D.all('signals');
 const perf=Paper.metrics(x);$('v7PaperStats').innerHTML=`<p>规则账户：现金 ${num(x.cash)}元，模拟成交${x.fills.length}笔，信号${sig.filter(s=>s.strategy==='rules').length}条，已记每日净值${x.nav.length}天。</p><p>收益 ${perf.totalReturn===null?'缺少逐日有效行情':num(perf.totalReturn)+'%'}；最大回撤 ${perf.maxDrawdown===null?'未知':num(perf.maxDrawdown)+'%'}；已平仓${perf.closedTrades}笔；胜率${perf.winRate===null?'样本不足/未公布':num(perf.winRate)+'%'}。</p><p>机器学习账户：<b>未训练 / 禁止模拟推荐</b>。数据完整并完成时间滚动验证后才能启用。</p><p class="hint">历史模拟胜率不以当日推荐涨跌代替；需要完整已平仓匹配交易，当前不展示虚构胜率。账本仅在手机本地，卸载前导出备份。</p>`;
 const events=await D.all('paper_events'),settled=new Map(events.map(e=>[e.signal,e.status]));$('v7SignalHistory').textContent=sig.slice(-12).reverse().map(x=>`${x.date} ${x.market}:${x.code} ${x.side} ${x.qty}股 ${settled.get(x.key)||x.status} 限价${num(x.limit)} 生成${x.generatedAt} / 数据${x.dataCutoff}`).join('\n')||'暂无冻结推荐。';
}
async function dailySignal(){const today=timeDate(),now=new Date();if(!latestGood.length)throw Error('请先执行全市场筛选，取得符合条件且有完整K线的股票');
 let book=await D.get('paper','rules')||{key:'rules',...Paper.account('rules',Number($('v7Equity').value)||100000)};let added=0;
 for(const x of latestGood.filter(x=>x.market==='A').slice(0,5)){const p=x.plan;
  if(!p.qty||!p.barDate)continue;
  const quoteTime=Date.parse(x.quote?.quoteTime||''),lastClose=Date.parse(p.barDate+'T15:00:00+08:00');
  // Never issue a new 'current' buy on stale / future bars.
  if(!Number.isFinite(quoteTime)||Math.abs(now-quoteTime)>96*3600000||!Number.isFinite(lastClose)||lastClose>now.getTime()||now-lastClose>7*86400000)continue;
  const dataCutoff=new Date(lastClose).toISOString(),row={key:`rules:${today}:${x.market}:${x.code}:BUY`,strategy:'rules',version:R.VERSION,date:today,generatedAt:now.toISOString(),dataCutoff,market:x.market,code:x.code,name:x.name,side:'BUY',qty:p.qty,lotSize:p.lot,limit:p.planHigh,reason:'财务四类核验+动量趋势+ATR风险参考；需下个可交易日开盘价格满足限价',barDate:p.barDate};
  if(await D.get('signals',row.key))continue;const result=Paper.propose([],row);
  if(result.added){await D.put('signals',result.signals[0]);added++;}
 }
 await D.put('paper',book);
 await journal();$('v7PaperStatus').textContent=`本日 ${today} 新冻结 ${added} 条条件委托。不会用今天已经知道的收盘价假装今天成交。需未来交易日真实OHLCV，满足限价和现金条件才模拟成交。`;
}
async function settle(){const orders=(await D.all('signals')).filter(x=>x.strategy==='rules'&&x.status==='pending');let book=await D.get('paper','rules')||{key:'rules',...Paper.account('rules')},done=0,blocked=0;
 for(const order of orders){if(await D.get('paper_events','execution:'+order.key))continue;let bars=await D.withPrefix('bars',order.market+':'+order.code+':'),next=bars.filter(x=>Paper.tradeDayAfter(order,x)).sort((a,b)=>a.date.localeCompare(b.date))[0];if(!next)continue;
  const outcome=Paper.execute(book,order,next,{lotSize:order.lotSize});if(outcome.order.status==='filled'){book={...outcome.book,key:'rules'};done++;}
  else if(outcome.order.status==='blocked')blocked++;
  if(outcome.order.status!=='pending'){// Old recommendation untouched: append an execution event separately.
   const key='execution:'+order.key;if(!(await D.get('paper_events',key)))await D.put('paper_events',{key,signal:order.key,at:new Date().toISOString(),status:outcome.order.status,reason:outcome.reason,fill:outcome.fill||null});
   // Current order status is derived from events, not rewritten.
  }
 }
 await D.put('paper',book);const latestBars={};const active=book.positions.filter(x=>x.shares>0);if(active.length){const dates=[];for(const h of active){const bs=await D.withPrefix('bars',h.market+':'+h.code+':');const last=bs.at(-1);if(last){latestBars[h.market+':'+h.code]=last;dates.push(last.date);}}if(dates.length===active.length&&dates.every(x=>x===dates[0])){const snap=Paper.mark(book,dates[0],latestBars);if(snap.completed)book={...snap.book,key:'rules'};await D.put('paper',book);}}
 await journal();$('v7PaperStatus').textContent=`新模拟成交${done}笔，因交易单位/现金等阻塞${blocked}笔；未出现下一交易日可核验开盘K线的推荐继续待核验。信号原文保留不改。`;
}
function backup(){Promise.all([D.all('signals'),D.all('paper'),D.all('paper_events'),D.get('ledger','main')]).then(([signals,paper,events,ledger])=>{
 $('v7Export').value=JSON.stringify({version:'QD7',exportedAt:new Date().toISOString(),signals,paper,events,realLedger:ledger},null,2);$('v7Export').select();
 });}
async function appInit(){
 await D.open();
 const page=document.querySelector('#page-picks .card');if(page){page.querySelector('h2').textContent='③ 全市场逐股基本面筛选 + 条件买点';page.querySelectorAll('p.hint')[0].textContent='先遍历数据库内的所有A/H股代码，逐只给出基本面筛选状态；合格后才下载K线择时。缺财报并非失败股，不伪称全市场数据齐全。';}
 const fields=`<div class="card"><h2>全市场基本面筛选 · V7</h2><div class="row"><button class="primary" id="v7Scan">遍历所有已建库A/H股票</button><button id="v7Offline">用本地资料重新筛选</button><button id="v7Stop" disabled>中止（保存状态）</button></div><div class="two"><label>合格股的技术深验上限<select id="v7Depth"><option value="60">60只</option><option value="180">180只（只深验部分）</option><option value="500">500只</option><option value="5000" selected>全部基本面合格公司（较慢）</option></select></label><label>规则策略模拟本金<input id="v7Equity" type="number" value="100000" min="1000"></label></div><div id="v7Status" class="status">尚未全池筛选。先在数据页建库并检查A/H覆盖率。</div><div id="v7Results"></div><details><summary>核对某只股票为什么有/没有数据，或导出全部筛选明细</summary><div class="row"><input id="v7FindCode" placeholder="A股6位 / 港股5位"><button id="v7Find">查看本地完整性</button><button id="v7ExportScreen">导出全池筛选台账</button></div><div id="v7LookupResult" class="status"></div><textarea id="v7ScreenExport" placeholder="JSON审计数据，仅在点击导出时产生"></textarea></details></div>`;
 document.querySelector('#page-picks').insertAdjacentHTML('afterbegin',fields);
 document.querySelector('#page-positions .card').insertAdjacentHTML('beforeend','<div class="card"><h2>真实持仓 · 退出规则与可卖核验</h2><button id="v7CheckExit" class="primary">逐只检查必须退出/卖出警戒</button><div id="v7HoldRisk" class="hint">暂无本轮风险核查。必须先核验行情与K线；软件不自动卖单。</div></div>');
 document.querySelector('#page-data .card').insertAdjacentHTML('afterbegin','<div class="card"><h2>V7 · A/H 首次建库和覆盖检查</h2><p class="hint">首次下载可很久，中断后保留数据。A股财报4类支持逐季抓取；港股完整三报表暂缺授权源，不会伪造。</p><div class="two"><label>季度数<select id="v7Quarters"><option value="4">4季度</option><option value="8" selected>8季度</option><option value="20">20季度</option></select></label><label>每只历史K线<select id="v7Bars"><option value="650">650根（约2.5年）</option><option value="2500">2500根（约10年，需要较大存储）</option></select></label></div><label><input type="checkbox" id="v7History" style="width:auto"> 首次补全已知股票的历史K线（时间和存储开销很大）</label><button class="primary" id="v7AHInit">启动 / 继续 A/H 全市场初次建库</button><details open><summary><b>A/H数据缺口核对</b></summary><div id="v7Coverage" class="hint">读取中……</div><button id="v7RefreshCoverage">刷新A/H覆盖</button></details></div>');
 const newSection=document.createElement('section');newSection.className='view';newSection.id='page-sim';newSection.innerHTML='<div class="card"><h2>⑤ 双模拟账户 · 每日不改写推荐</h2><p class="hint">账户A：基本面/动量/趋势/风险规则；账户B：机器学习（未训练，禁用推荐）。每天生成带时间戳计划，次一交易日有真实完整日K后再模拟委托；不假定收盘价成交。</p><div class="row"><button id="v7Daily" class="primary">冻结今日候选推荐</button><button id="v7Settle">以未来K线结算模拟委托</button><button id="v7Backup">导出模拟＋真实账本</button></div><div id="v7PaperStatus" class="status">策略成绩必须由以后真实行情逐日检验。</div><div id="v7PaperStats" class="card"></div><h3>最近冻结的交易计划</h3><div id="v7SignalHistory" class="status"></div><details><summary>复制审计/备份JSON</summary><textarea id="v7Export" placeholder="点击导出后复制到安全位置"></textarea></details></div>';
 document.querySelector('footer').before(newSection);
 const nav=document.querySelector('nav');const button=document.createElement('button');button.dataset.page='sim';button.innerHTML='▥<div>模拟验证</div>';nav.append(button);button.onclick=()=>{document.querySelectorAll('.view').forEach(el=>el.classList.toggle('active',el.id==='page-sim'));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b===button));};
 const click=(id,fn)=>{$(id).onclick=async()=>{try{if(id==='v7AHInit'){const b=$(id);b.disabled=true;setStatus('已接收建库操作，正在初始化数据库…');}await fn();}catch(e){const error='错误：'+(e?.message||String(e));setStatus(error);if($('v7PaperStatus'))$('v7PaperStatus').textContent=error;if(id==='v7AHInit'){const el=$('v72InitLog');if(el)el.textContent=error+'\n'+el.textContent;}}finally{if(id==='v7AHInit')$(id).disabled=false;}};};
 click('v7RefreshCoverage',dataAudit);click('v7AHInit',ahInitialize);click('v7Find',inspectCode);click('v7ExportScreen',exportScreening);click('v7Scan',()=>fullScreen());click('v7Offline',()=>fullScreen({offline:true}));click('v7CheckExit',realRisk);click('v7Daily',dailySignal);click('v7Settle',settle);click('v7Backup',backup);
 $('v7Stop').onclick=()=>{abort=true;setStatus('正在终止当前批次，已完成的股票筛选状态会保存。');};
 // Do not let the old top-N-before-fundamental paths silently run.
 click('scanPicks',()=>fullScreen());click('scanLocal',()=>fullScreen({offline:true}));
 click('oneClick',async()=>{
   setStatus('只用已入库数据进行风险分析和候选研究；全市场更新请到数据中心操作。');
   await realRisk();await fullScreen({offline:true});
   if(latestGood.length)await dailySignal();await dataAudit();
 });
 await dataAudit();await journal();}
 // Earlier app.js registers its initializer first; this one runs after it on the same event.
 document.addEventListener('DOMContentLoaded',()=>{setTimeout(()=>appInit().catch(e=>console.error('V7 init',e)),250)});
})();
