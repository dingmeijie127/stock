/* Pure, deterministic brokerage ledger arithmetic. Only user-confirmed fills are input. */
(function(root,factory){let result=factory();if(typeof module==='object'&&module.exports)module.exports=result;root.QuantLedger=result;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const round=n=>Math.round((Number(n)+Number.EPSILON)*1e8)/1e8;
function applyFill(ledger,input){
 const market=input.market==='HK'?'HK':'A';
 const code=String(input.code||'').trim();
 const name=String(input.name||'').trim();
 const side=input.side;
 const shares=Number(input.shares),price=Number(input.price),fee=Number(input.fee??0);
 const time=String(input.time||'');
 const date=String(input.date||'');
 if(!new RegExp(market==='HK'?'^\\d{5}$':'^\\d{6}$').test(code))throw Error('证券代码与市场不匹配');
 if(!['buy','sell'].includes(side))throw Error('交易方向无效');
 if(!Number.isSafeInteger(shares)||shares<=0)throw Error('成交股数必须为正整数');
 if(market==='A'&&side==='buy'&&shares%100!==0)throw Error('A股普通股票买入一般需整百股');
 if(market==='HK'&&side==='buy'&&(!Number.isSafeInteger(Number(input.lotSize))||Number(input.lotSize)<1||shares%Number(input.lotSize)!==0))throw Error('港股需提供该证券真实每手股数，并按整数手买入');
 if(!Number.isFinite(price)||price<=0||!Number.isFinite(fee)||fee<0)throw Error('价格、费用必须是合法数字');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(date+'T00:00:00Z')))throw Error('成交日期错误');
 if(time&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('成交时间格式应为HH:mm');
 let holdings=(ledger.holdings||[]).map(h=>({...h,shares:Number(h.shares),cost:Number(h.cost)}));const trades=(ledger.trades||[]).map(t=>({...t}));
 let holding=holdings.find(h=>h.code===code&&(h.market||'A')===market);let oldShares=Number(holding?.shares)||0,oldCost=Number(holding?.cost)||0;
 if(side==='sell'&&(!holding||oldShares<shares))throw Error('不能卖出超过现有持仓的股数');
 if(side==='sell'&&market==='A'){const acquiredToday=trades.filter(t=>t.code===code&&(t.market||'A')===market&&t.date===date&&t.side==='买入').reduce((sum,t)=>sum+Number(t.shares||0),0);if(shares>oldShares-acquiredToday)throw Error('A股T+1：本交易日新买入的部分不可卖出');}
 if(side==='buy'&&!holding&&!name)throw Error('新股票必须填写股票名称');
 let realized=0,deltaCash;const currency=market==='HK'?'HKD':'CNY';
 if(side==='buy'){
  deltaCash=-round(shares*price+fee);
  if(!holding){holding={code,name,market,shares:0,cost:0,sector:'未分类'};holdings.push(holding)}
  // All recorded transaction fees are included in the buy cost.
  holding.cost=round((oldShares*oldCost+shares*price+fee)/(oldShares+shares));holding.currency=currency; if(market==='HK')holding.lotSize=Number(input.lotSize)||holding.lotSize||null;
  holding.shares=oldShares+shares;
 }else{
  realized=round((price-oldCost)*shares-fee);
  deltaCash=round(shares*price-fee);
  holding.shares=oldShares-shares;
 }
 const dateTime=date+(time?' '+time:'');
 const entry={currency,id:'fill-'+String(input.id||Date.now()+'-'+Math.random().toString(36).slice(2,8)),date,time,dateTime,market,code,name:holding.name,side:side==='buy'?'买入':'卖出',shares,price,fee,realized,previousShares:oldShares,newShares:holding.shares,previousCost:oldCost,newCost:holding.cost,cashChange:deltaCash};
 trades.push(entry);
 const oldCash={CNY:Number(ledger.cashByCurrency?.CNY??ledger.cashApprox??0),HKD:Number(ledger.cashByCurrency?.HKD??0)};oldCash[currency]=round(oldCash[currency]+deltaCash);
 const realizedByCurrency={CNY:Number(ledger.realizedByCurrency?.CNY??ledger.realized??0),HKD:Number(ledger.realizedByCurrency?.HKD??0)};realizedByCurrency[currency]=round(realizedByCurrency[currency]+realized);
 return {holdings,trades,cashByCurrency:oldCash,realizedByCurrency, cashApprox:oldCash.CNY,realized:realizedByCurrency.CNY,entry};
}
return{applyFill};
});
