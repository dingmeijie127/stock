/* QuantDesk V6.6: a single verifiable path for the three core functions.
 * Data -> identical decision-core evaluate() -> holdings / universe shortlist / quick action.
 * No fake realtime quote, probability, trade instruction or seeded user portfolio.
 */
(function(){'use strict';
const D=QuantDB,P=QuantProvider,Q=QuantDecision,F=QuantFastSync,L=QuantLedger,FS=QuantFinanceSync,U=QuantUniverse,B=QuantBootstrap;
const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(x,n=2)=>x===null||x===undefined||!Number.isFinite(+x)?'—':Number(x).toLocaleString('zh-CN',{minimumFractionDigits:n,maximumFractionDigits:n});
const nowIso=()=>new Date().toISOString(),sleep=t=>new Promise(r=>setTimeout(r,t));
const ledger={cashApprox:0,holdings:[],trades:[],realized:0,cashByCurrency:{CNY:0,HKD:0},realizedByCurrency:{CNY:0,HKD:0}};
let ready=false,running=false,cancelled=false,currentStarted=0,clock=null,latestDecisions=[],lastCandidates=[],autoSaved=false;
const say=(id,message,append=true)=>{const el=$(id);if(!el)return;el.textContent=append?(message+'\n'+el.textContent).slice(0,2700):message;};
const notice=x=>{const e=$('toast');e.textContent=x;e.style.display='block';setTimeout(()=>e.style.display='none',3000)};
function enableActions(state){for(const id of ['oneClick','syncMarket','syncFinance','retryMarket','syncHoldings','analyzeHoldings','analyzeStock','scanPicks','scanLocal','probeData','rebuildUniverse','fillQuotes','bootstrapInit','bootstrapIncrement','tsBatch'])if($(id))$(id).disabled=state;}
function progress(p,label){$('runBar').style.width=Math.min(100,p)+'%';$('runStatus').textContent=label+'\n'+$('runStatus').textContent.slice(0,2000);}
function times(ms){return ms>=1000?(ms/1000).toFixed(1)+'秒':ms+'毫秒';}
function bootstrapEngine(){return B.create({db:D,provider:P,fastSync:F,financeSync:FS,universeSync:U,stop:()=>cancelled,onEvent:e=>{
  const title={directory:'股票目录',directory_feed:'备用目录','market-pages':'全市场行情分页',quotes:'行情补数','finance-pages':'财报分页',finance:'财报',bars:'历史K线',initialization:'首次建库',market:'日常行情'}[e.stage]||e.stage;
  const detail=e.stage==='bars'?`已成功${e.done||0}只/跳过已有${e.skipped||0}只/失败${e.failed||0}只/目标${e.total||'未知'}`:
   e.stage==='finance-pages'?`${e.kind||''} ${e.date||''} 第${e.page||'?'}页，存储${e.saved||e.localStored||0}`:
   e.stage==='market-pages'?`已验收${e.committedPages||0}/${e.pages||'?'}页，本轮入库${e.stored||0}`:
   e.stage==='quotes'?`请求${e.requested||'?'}只，成功${e.saved||0}只，失败${e.batchFailures||0}批`:
   e.count!=null?` ${e.count}只`:e.error||'';
  if(['page','running','saved','failed','end','coverage_checked','partial','market-fetch','sina-page','source'].includes(e.status)||['initialization','directory'].includes(e.stage)){
   say('bootstrapState',`${title} ${e.status||''} ${detail}`);}
 }});}
async function showBootstrapStatus(){const c=await B.coverage(D),last=await D.get('meta','bootstrap:last'),info=await D.get('meta','bootstrap:v1');
 const status=`A股目录 ${c.directory}只 · 近期可核验报价 ${c.freshQuotes}只 / 目录覆盖 ${(c.coverage*100).toFixed(1)}% · 历史报价记录${c.storedQuotes}只`;
 $('bootstrapState').textContent=status+'\n'+(last?.complete?'上次首次建库：选定任务已通过各自覆盖检查':'首次建库尚未完全验收，可点击继续。')+(info?.stage?'\n上次阶段 '+info.stage+' '+info.status:'')+(last?.failed?.length?'\n错误：'+last.failed.slice(0,2).join('；'):'');}
async function fullTushare(){await oneLock('本机Tushare批量盘后数据采集',async()=>{
 if(!QuantTushare.available())throw Error('本测试APK未内置原生HTTPS POST桥；请使用上方免费首建，或用标准Android工程构建。');
 const token=$('tsToken').value.trim();if(token.length<16)throw Error('请填入自己有效的Tushare授权Token');
 const days=Number($('tsDays').value),quarters=Number($('tsQuarters').value);
 $('tsToken').value='';// never retain the token in the DOM
 const client=QuantTushare.create({db:D,token,stop:()=>cancelled,progress:p=>{
  $('tsStatus').textContent=`${p.type} ${p.state} ${p.date||p.period||''} ${p.count||0}条 ${p.message||''} ${p.done||''}/${p.total||''}`;
 }});
 const r=await client.full({days,quarters});
 $('tsStatus').textContent=r.done?'授权批量采集已完成选定任务（并非盘中实时报价）':`批量采集部分完成；错误 ${r.errors.slice(0,3).join('；')}，可再次启动断点续抓。`;
 if(r.done)progress(100,'Tushare盘后股票池、逐日未复权日线、最新估值、三大报表采集任务完成。');
 else progress(82,'仍有授权/源端/披露缺口，已入库数据保留。');
 await renderCounts();await showBootstrapStatus();});}
async function fullBootstrap(){await oneLock('首次建库：不需Python；逐页真实入库、可续传',async()=>{
 const quarters=Number($('initQuarters')?.value)||8,history=!!$('initHistory')?.checked,requireFinance=!!$('initFinance')?.checked;
 progress(2,'开始首次建库（行情、财报、可选全池K线），断网不清库');
 const engine=bootstrapEngine();let r=await engine.full({quarters,history,requireFinance});
 if(r.complete)progress(100,`首次建库所选范围完成；${r.directory}个代码、近期可核验报价${r.freshQuotes}只、财报分页已核验。`);
 else progress(89,`首次建库未完成：目录${r.directory}只、近期报价${r.freshQuotes}只、覆盖${(r.coverage*100).toFixed(1)}%；失败阶段${r.failed.join('；')||'有未验收项目'}。已保存可续传。`);
 await showBootstrapStatus();await renderCounts();});}
async function incrementalBootstrap(){await oneLock('日常增量：不是重新抓取全部历史',async()=>{
 progress(3,'检测交易日变化与近2季度披露增量');const r=await bootstrapEngine().incremental();
 if(r.complete)progress(100,'增量请求结束。请核对行情覆盖率以及财报分页状态；不代表所有报价均为交易所实时价。');
 else progress(87,'增量任务仍有缺口：'+r.failures.join('；'));
 await showBootstrapStatus();await renderCounts();});}

function audit(text){say('algoAudit',text)}
function emptyIfBad(q){return !q||q.price==null||!Number.isFinite(Number(q.price))||Number(q.price)<=0;}
async function oneLock(title,fn){if(running)throw Error('已有任务在执行，请先停止或等本轮结束');running=true;cancelled=false;currentStarted=Date.now();enableActions(true);$('runStatus').textContent=title;clock=setInterval(()=>{$('runClock').textContent='本轮已经运行 '+times(Date.now()-currentStarted)+' · '+Q.analysisVersion+' · 真实联网用时单独计入'},500);try{return await fn()}catch(e){$('runStatus').textContent='本轮中断，未达到100%：'+e.message+'\n'+$('runStatus').textContent.slice(0,1000);throw e}finally{clearInterval(clock);clock=null;enableActions(false);running=false;$('runClock').textContent='本轮耗时 '+times(Date.now()-currentStarted)+'；未核验的信号不能作为即时交易指令';}}
function eventHandler(fn){return async()=>{try{await fn()}catch(e){say('runStatus','错误：'+(e.message||e));notice('操作未完成：'+(e.message||e))}}}
const exchange=x=>x==='HK'?'港股':'A股';
const holdingMarket=h=>h.market==='HK'?'HK':'A';
async function dbBars(market,code){return D.withPrefix('bars',market+':'+code+':')}
async function dbReports(market,code){return D.withPrefix('finance',market+':'+code+':')}
async function dbNotices(market,code){return D.withPrefix('notices',market+':'+code+':')}
function isRecent(iso,maxHours){const ms=Date.parse(iso||'');return Number.isFinite(ms)&&Date.now()-ms>=0&&Date.now()-ms<maxHours*3600000}
async function quoteFromInternet(code,market){const old=await D.get('stocks',market+':'+code),quote=await P.quote(code,market);if(emptyIfBad(quote))throw Error('行情缺少有效价格');
  // Guard the known single-symbol vs snapshot scale divergence.
  if(!emptyIfBad(old)&&isRecent(old.fetchedAt,12)&&Number.isFinite(Number(old.price))&&Math.abs(quote.price-old.price)/old.price>.35){throw Error('个股报价与同日市场快照相差超过35%，可能是字段单位或数据错误，已拒绝覆盖');}
  await D.put('stocks',quote);return quote;
}
async function refreshStock(code,market,{quote=true,bars=true,finance=true,notices=true,force=false,report=()=>{}}={}){
 const output={market,code,failures:[]};const t0=Date.now();
 let saved=await D.get('stocks',market+':'+code);
 if(quote){try{saved=await quoteFromInternet(code,market);report('报价')}catch(e){output.failures.push('报价：'+e.message)}}
 output.quote=saved;
 let h=await dbBars(market,code),end=h.at(-1),barsRecent=h.length>=180&&end&&((Date.now()-Date.parse(end.date+'T16:00:00+08:00'))/86400000<4);
 if(bars&&(!barsRecent||force))try{const rows=await P.bars(code,market,650);if(rows.length<80)throw Error('有效日K过少');const meta={key:'bootBar:'+market+':'+code,done:true,count:rows.length,requestedLimit:650,latest:rows.at(-1).date,source:rows[0].source,updatedAt:nowIso()};
  if(typeof D.replaceSeries==='function')await D.replaceSeries('bars',market+':'+code+':',rows,meta);
  else await D.commitPage('bars',rows,meta);
  h=await dbBars(market,code);report('历史K线'+rows.length+'根')}catch(e){output.failures.push('K线：'+e.message);await D.put('meta',{key:'historyError:'+market+':'+code,market,code,status:'failed',details:e.message,reason:typeof QuantKlineQuality!=='undefined'?QuantKlineQuality.classifyError(e):'FETCH_ERROR',updatedAt:nowIso()});}
 output.bars=h;
 let f=await dbReports(market,code);
 // No adequate provider for HK corporate-financial history; never fabricate.
 if(market==='A'&&finance){
  let latest=f.filter(r=>r.type==='summary').sort((a,b)=>b.reportDate.localeCompare(a.reportDate))[0]?.reportDate;
  const types=new Set(f.filter(r=>r.reportDate===latest).map(r=>r.type));
  const expected=FS.TYPES.filter(kind=>force||!latest||!types.has(kind));
  // Existing full-market IndexedDB statements are reused: do NOT re-download every company.
  for(const kind of expected){if(cancelled)break;try{
   const t=await P.financialPage(null,kind,1,16,code);
   if(!t.rows.length)throw Error('未返回可核对的'+FS.TYPES_ZH[kind]);
   await D.putMany('finance',t.rows);report(FS.TYPES_ZH[kind]+' '+t.rows.length+'期');
  }catch(e){output.failures.push(FS.TYPES_ZH[kind]+'：'+e.message)} }
  if(expected.length){f=await dbReports(market,code);await D.put('meta',{key:'financeFetch:'+code,when:nowIso(),count:f.length,types:[...new Set(f.map(r=>r.type))]});}
 }
 output.finance=f;
 let n=await dbNotices(market,code);
 if(market==='A'&&notices&&(!isRecent((await D.get('meta','noticeFetch:'+code))?.when,24)||force))try{const a=await P.announcements(code);if(a.length)await D.putMany('notices',a);await D.put('meta',{key:'noticeFetch:'+code,when:nowIso(),count:a.length});n=await dbNotices(market,code);report('公告'+a.length+'项')}catch(e){output.failures.push('公告：'+e.message)}
 output.notices=n;
 output.elapsedMs=Date.now()-t0;return output;
}
function runDecision(x,holding=null){const start=performance.now();const result=Q.evaluate({quote:x.quote,bars:x.bars,financial:x.finance,notices:x.notices,holding,marketContext:x.marketContext||null,now:new Date()});result.computeMs=performance.now()-start;result.fetchMs=x.elapsedMs||0;result.name=x.quote?.name||holding?.name||x.code;result.code=x.code;result.market=x.market;result.fetchErrors=x.failures;return result;}
function decisionHTML(r){let x=r,desc=x.signals?.slice(0,3).join('；')||'信号不足';let risk=x.risks?.slice(0,3).join('；')||'仍存在市场和流动性风险';let issues=x.issues?.join('；')||'主要数据时间条件通过';return `<div class="result"><h3>${esc(x.name)} <span class="tag">${esc(exchange(x.market))} ${esc(x.code)}</span></h3><p class="${esc(x.severity)}"><b>${esc(x.action)}</b></p><p>${esc(x.reason)}</p><p class="hint">价格 ${fmt(x.price)} ${x.market==='HK'?'港元':'元'}；模型：12-1动量 ${fmt(x.technical?.momentum12mSkip1m,2)}%；200日均线 ${fmt(x.technical?.ma200,2)}；6-1动量 ${fmt(x.technical?.momentum6mSkip1m,2)}%；MA60 ${fmt(x.technical?.ma60,2)}；仓位参考上限 ${fmt(x.suggestedMaxPct,1)}%（非指令，无胜率评分）；行情 ${esc(x.quoteTime||'未知')}；K线截至 ${esc(x.lastBarDate||'未知')}</p><p class="hint">算法：${esc(x.version)} · 纯计算 ${times(Math.ceil(x.computeMs||x.analysisMs||0))} · 数据获取 ${times(x.fetchMs||0)}</p><details><summary>为什么这么判断 / 风险在哪</summary><p><b>依据：</b>${esc(desc)}</p><p><b>风险：</b>${esc(risk)}</p><p><b>数据问题：</b>${esc(issues)}</p><p>观察位：突破 ${fmt(x.indicators?.breakout)} / 参考支撑 ${fmt(x.indicators?.support)} / 风险观察 ${fmt(x.indicators?.risk)}，不是委托价。</p><p>模型由公开的动量/趋势研究启发；不主张缠论信号或已经过机构认证。</p><p class="hint">接口错误：${esc(x.fetchErrors?.join('；')||'无')}；披露 ${esc(x.financeDate||'未知')}；同季度四类报表 ${x.completeStatements?'齐备':'不完整'} (${esc((x.reportTypes||[]).join('/'))})；经营现金/归母净利 ${fmt(x.cashCoverage,2)}；资产负债率 ${fmt(x.debtRatio)}%，公告核验 ${x.verifiedAnnouncements?'有本地记录':'不充分'}。</p></details></div>`;}
async function renderCounts(){const s=await D.count('stocks'),u=await D.count('universe'),b=await D.count('bars'),raw=await D.count('daily_raw'),fac=await D.count('factors'),f=await D.count('finance'),n=await D.count('notices'),sects=await D.count('sectors'),news=await D.count('news');const a=await D.get('meta','fastMarket:A'),hk=await D.get('meta','fastMarket:HK');const k=(x,label,note)=>`<div class="mini"><small>${esc(label)}</small><b>${esc(x)}</b><small>${esc(note)}</small></div>`;
 const recentStocks=(await D.all('stocks')).filter(x=>x.price>0&&Date.now()-Date.parse(x.fetchedAt||'')<72*3600000&&Date.now()-Date.parse(x.quoteTime||'')<96*3600000).length;
 const fc=await financeCoverage(4);
 let reportCards='';for(const t of FS.TYPES){let done=0,totalRows=0,error='';for(const dt of FS.quarterDates(4)){
  const x=await D.get('meta',`financeFull:v2:${t}:${dt}`);if(x?.done){done++;totalRows+=x.saved||0;}else if(x?.lastError)error=x.lastError;
 }reportCards+=k(done+'/4',FS.TYPES_ZH[t],`${totalRows}条通过页级检查的记录；${error?'失败：'+error.slice(0,18):'完整性按季度统计'}`);}
 $('coverage').innerHTML=reportCards+k(u,'独立股票目录','股票代码，不是最新报价')+k(`${fc.ok}/${fc.total}`,'四类财报×近4季','仅已完成源端分页+落盘任务')+k(s,'历史报价记录','A/H合计，可能过期')+k(recentStocks,'近期有效报价','报价值与时间通过基础筛选')+k(b,'复权历史K线','用于当前技术指标')+k(raw,'授权盘后未复权日线','独立保存，不与复权K线混用')+k(fac,'盘后估值因子','完整原始字段可查')+k(f,'财报记录','A股披露')+k(n,'公告索引','标题与日期')+k(sects,'行业/概念快照','外部网络数据')+k(news,'财经快讯','仅辅助信息')+k(a?.finished?'完成':a?'部分':'尚无','全A股快照',a?`已覆盖${(a.completedPages||[]).length}页 / 最近${a.updatedAt?.slice(0,16)}`:'需联网')+k(hk?.finished?'完成':hk?'部分':'尚无','港股快照',hk?`已覆盖${(hk.completedPages||[]).length}页 / 最近${hk.updatedAt?.slice(0,16)}`:'需联网');}
async function rebuildUniverse(){say('universeState','下载独立的全A股目录中...',false);const t0=Date.now();
 const x=await U.syncDirectory({db:D,stop:()=>cancelled,onEvent:e=>{if(e.phase==='saved'||e.phase==='error')say('universeState',e.phase==='saved'?`目录入库${e.count}/${e.total}`:`${e.source}不可用：${e.error}`)}});
 say('universeState',`独立目录${x.count}条已入库，来源${x.source}，用时${times(Date.now()-t0)}。注意：不是${x.count}个实时有效报价。`);await renderCounts();return x;
}
async function fillUniverseQuotes(limit=350){let s=await U.fillQuotes({db:D,provider:P,limit,stop:()=>cancelled,onEvent:e=>{if(e.done) say('universeState',`腾讯批量更新 ${e.done}/${e.requested}：真实有效入库${e.saved}只 / 批次失败${e.batchFailures}`)}});
 say('universeState',`本次尝试${s.requested}只，已保存${s.saved}只；失败批次${s.batchFailures}；目录总数${s.catalogSize}。部分源无响应不等于已补全。`);await renderCounts();return s;}
async function syncMarket(market,{retryOnly=false}={}){
 if(cancelled)return {complete:false,stopped:true};
 say('dataLog',`开始${exchange(market)}${retryOnly?'失败页补抓':'全市场快照'}，每页200只，最多2并发；失败自动降到100/50条子页，无法补齐则跳过，不阻塞分析`);
 const task=F.create({provider:P,db:D,market,size:200,concurrency:2,stop:()=>cancelled,progress:u=>{
  if(u.phase==='saved'||u.phase==='failed'||u.phase==='end')say('dataLog',`${exchange(market)} ${u.phase} 第${u.page||'—'}页 / 已验收${u.committedPages||0}/${u.pages||'?'}页 / 本轮新入库${u.stored||0}条 / 失败${u.failed||0}页 / ${u.source||'自动选源'} / ${times(u.ms)}`);
 }});
 const out=await task.run({retryOnly});
 say('dataLog',`${exchange(market)}${out.complete?'所有源端页面验收':'部分覆盖但仍可分析'}：总股票数 ${out.total||'未知'} / 本轮成功存储${out.stored}只 / 已验收${out.committedPages||0}/${out.pages||'?'}页 / 失败${out.failed.length}页 / 未尝试${out.pendingPages?.length||0}页 / ${times(out.ms)}`);
 if(market==='A'&&!out.complete&&!cancelled){
   const have=await D.count('universe');if(have<1200){try{await rebuildUniverse()}catch(e){say('dataLog','独立股票目录仍不可用：'+e.message)}}
   if(await D.count('universe')>=1200){try{const x=await fillUniverseQuotes(350);say('dataLog',`独立目录批量补价：${x.saved}/${x.requested}只成功，非全市场报价完成`)}catch(e){say('dataLog','独立批量报价失败：'+e.message)}}
 }
 if(!out.complete&&!cancelled){const repaired=await patchKnownQuotes(market);say('dataLog',`${exchange(market)}：腾讯独立备用源为本地已知代码更新${repaired.saved}只，失败批次${repaired.failed}；未知遗漏股票仍未覆盖。`);}
 await renderCounts();return out;
}
// Tencent batch source can repair known symbols when Eastmoney paging fails.
// Never mark an Eastmoney page complete based on this independent partial repair.
async function patchKnownQuotes(market,cap=150){
 const prev=(await D.all('stocks')).filter(x=>x.market===market&&/^\d{5,6}$/.test(x.code||''))
  .sort((a,b)=>Date.parse(a.fetchedAt||'')-Date.parse(b.fetchedAt||''));
 let saved=0,failed=0;const selected=prev.slice(0,cap);
 for(let i=0;i<selected.length&&!cancelled;i+=35){
  try{const rows=await P.tencentQuotes(selected.slice(i,i+35).map(x=>x.code),market);
   const old=new Map(selected.map(x=>[x.code,x]));
   const valid=rows.filter(x=>x.price>0&&x.quoteTime&&Number.isFinite(Date.parse(x.quoteTime)))
    .filter(x=>{let p=Number(old.get(x.code)?.price);return !Number.isFinite(p)||p<=0||Math.abs(x.price-p)/p<.35;});
   if(valid.length){await D.putMany('stocks',valid);saved+=valid.length;}
  }catch(e){failed++;say('dataLog',`腾讯备用批次失败：${e.message}`)}
  await sleep(100);
 }
 return {saved,failed};
}
async function updatePublicContext(){
  // External sector snapshot / news are supplementary context, not automatically a verified trading edge.
  let completed=[];
  await Promise.all([['industry',()=>P.sectors('industry')],['concept',()=>P.sectors('concept')],['news',()=>P.globalNews()]].map(async([k,get])=>{
   try{let rows=await get();if(rows.length){await D.putMany(k==='news'?'news':'sectors',rows);completed.push(k+':'+rows.length);}}catch(e){say('dataLog',k+'附加数据源不可用：'+e.message)}}));
  say('dataLog','额外在线数据：'+(completed.join('、')||'均失败；本轮未假设已核验板块/消息')+'。宏观快讯不作为具体个股直接买入信号。');
  return completed;
}
async function syncCompleteFinance({refresh=false,forceAll=false}={}){
 const quarters=forceAll?4:(Number($('financeRange')?.value)||4);
 const choice=forceAll?'all':($('financeType')?.value||'all');
 const types=choice==='all'?FS.TYPES:[choice];
 say('dataLog',`开始逐季同步：${types.map(x=>FS.TYPES_ZH[x]).join('、')}；${quarters}个季度。源接口每页50条，写入并校验后才算成功，断开后可续传。`);
 let lastPrinted=0;
 const sync=FS.create({provider:P,db:D,stop:()=>cancelled,progress:p=>{
  if(p.phase==='page'){
   $('financeState').textContent=`${FS.TYPES_ZH[p.kind]} ${p.date} 第${p.page}/${p.sourcePages}页 · 该季落盘${p.localStored}条 / 源端${p.sourceTotal??'未知'}条 · 总任务完成${p.completed}/${p.tasks} · 累计写入${p.saved}条 · 用时${times(p.elapsedMs)}`;
   if(p.pages-lastPrinted>=5){say('dataLog',$('financeState').textContent);lastPrinted=p.pages;}
  }else if(p.phase==='skip'||p.phase==='quarter'||p.phase==='failed'||p.phase==='end'){
   const detail=p.error||`已完成季度任务 ${p.completed}/${p.tasks}，本轮存储${p.saved}条`;
   say('dataLog',`${p.kind||'全财报'} ${p.date||''} ${p.phase}：${detail}`);
  }
 }});
 const res=await sync.run({types,quarters,refresh});
 $('financeState').textContent=`${res.complete?'接口分页已完成':'尚未完成｜不可声称财报齐全'}：${res.completed}/${res.tasks}季度×报表任务，本轮${res.pages}页写入${res.saved}条，失败${res.failed.length}项，用时${times(Date.now()-Date.parse(res.startedAt))}。${res.failed[0]||''}`;
 await D.put('meta',{key:'financeLastRun',...res,reportedAt:nowIso()});await renderCounts();return res;
}
async function financeCoverage(quarters=4){
 const keys=FS.TYPES.flatMap(kind=>FS.quarterDates(quarters).map(date=>`financeFull:v2:${kind}:${date}`));
 let ok=0,problems=[];
 for(const key of keys){let meta=await D.get('meta',key);if(meta?.done&&meta?.saved>0)ok++;else problems.push(key.replace('financeFull:v2:',''));}
 return {ok,total:keys.length,complete:ok===keys.length,problems};
}
async function probeDataSources(){
 const samples=[['A股行情',()=>P.stockPages('A',1,20)],['港股行情',()=>P.stockPages('HK',1,20)]];
 const quarter=FS.quarterDates(2)[1];
 for(const type of FS.TYPES)samples.push([FS.TYPES_ZH[type]+' '+quarter,()=>P.financialPage(quarter,type,1,20)]);
 let results=[],good=0;
 for(const [label,run] of samples){if(cancelled)break;const started=Date.now();try{
  const p=await run(),items=p.rows||[],raw=p.rawCount;
  if(!items.length||items.length!==raw)throw Error('源端返回空数据或字段丢失');
  // This is a source probe: save real returned rows, but do not mark whole period complete.
  await D.putMany(label.includes('行情')?'stocks':'finance',items);
  results.push(`${label}：成功读取并入库 ${items.length} 条 · 源端总量${p.total??'未知'} · ${times(Date.now()-started)}`);good++;
 }catch(e){results.push(`${label}：失败 · ${e.message} · ${times(Date.now()-started)}`);}
 $('probeStatus').textContent=results.join('\n');}
 const success=good===samples.length;await D.put('meta',{key:'sourceProbe',when:nowIso(),success,results});
 await renderCounts();if(success)progress(100,'抽样接口体检全部成功；不等于全市场完整。');else $('runStatus').textContent='接口抽样有失败，不可把数据库宣称为完整。';
 return {success,results};
}
async function renderHoldings(){const fresh=await D.get('ledger','main');if(fresh)Object.assign(ledger,fresh);let rows=[],total=0,totalHKD=0,known=0;for(const h of ledger.holdings.filter(h=>h.shares>0)){const q=await D.get('stocks',holdingMarket(h)+':'+h.code),p=q?.price;if(p>0){known++;if(h.market==='HK')totalHKD+=p*h.shares;else total+=p*h.shares;}rows.push(`<div class="result"><b>${esc(h.name||h.code)} ${esc(h.code)}</b> · ${fmt(h.shares,0)}股 · 成本${fmt(h.cost,3)} · 行情${fmt(p)} <small>${esc(q?.quoteTime||'报价时间未知')}</small></div>`)}
 $('holdings').innerHTML=rows.length?rows.join(''):'尚无持仓。请导入V5 JSON账本，或先录入实际成交。';
 $('holdingMetrics').innerHTML=`<div class="mini"><small>持仓数量</small><b>${ledger.holdings.filter(h=>h.shares>0).length}</b></div><div class="mini"><small>行情覆盖</small><b>${known}/${ledger.holdings.filter(h=>h.shares>0).length}</b></div><div class="mini"><small>A股已知市值(人民币)</small><b>${fmt(total,0)}</b></div><div class="mini"><small>人民币现金</small><b>${fmt(ledger.cashByCurrency?.CNY??ledger.cashApprox,0)}</b></div><div class="mini"><small>港股已知市值(HKD)</small><b>${fmt(totalHKD,0)}</b></div><div class="mini"><small>港币现金(HKD)</small><b>${fmt(ledger.cashByCurrency?.HKD??0,0)}</b></div>`;
}
async function inspectHoldings(){const hs=ledger.holdings.filter(h=>h.shares>0);latestDecisions=[];
 if(!hs.length){$('holdStatus').textContent='未导入持仓。请先完成V5账本迁移，不能替你虚构持仓。';return []}
 for(let i=0;i<hs.length&&!cancelled;i+=2){await Promise.all(hs.slice(i,i+2).map(async h=>{
  const m=holdingMarket(h);const result=await refreshStock(h.code,m,{report:s=>say('holdStatus',h.code+'已获取'+s)});const d=runDecision(result,h);latestDecisions.push(d);say('holdStatus',`${d.name}: ${d.action}｜12-1动量${fmt(d.technical?.momentum12mSkip1m,2)}%｜计算${times(Math.ceil(d.computeMs))}｜网络${times(d.fetchMs)}`);
 }));await renderHoldings();await sleep(25)}
 $('holdings').innerHTML=latestDecisions.map(decisionHTML).join('')||$('holdings').innerHTML;
 await renderHoldingsMetricsWithRisk();return latestDecisions;
}
async function renderHoldingsMetricsWithRisk(){let p=latestDecisions.filter(x=>x.severity==='risk').length,missing=latestDecisions.filter(x=>!x.ready).length;
 $('holdingMetrics').innerHTML+=`<div class="mini"><small>风险观察</small><b>${p}</b></div><div class="mini"><small>数据不足</small><b>${missing}</b></div>`;
}
function firstPassUniverse(stocks){const now=Date.now();let valid=stocks.filter(x=>x?.code&&x.price>0&&Number.isFinite(+x.amount)&&Date.parse(x.fetchedAt)>now-72*3600000&&(!x.quoteTime||Date.parse(x.quoteTime)>now-96*3600000)).filter(x=>!/(退|ST|\*ST)/i.test(x.name||''));
 const rank=x=>{let a=x.amount||0,p=x.pct||0,cap=x.cap||0,pe=x.pe||0;return Math.log10(Math.max(1,a))*6+(cap>2000000000?4:0)-(Math.abs(p)>15?5:0)};
 return valid.map(x=>({...x,rankScore:rank(x)})).sort((a,b)=>b.rankScore-a.rankScore);
}
function diversePool(rows,limit){
 // Multi-gate shortlist avoids selecting exclusively by turnover/size. Every route
 // consumes the SAME whole-market snapshot, and none is a backtested alpha claim.
 const groups=[
  rows, // composite quality/liquidity
  rows.filter(x=>x.pct>=1&&x.pct<=7).sort((a,b)=>(b.pct||0)-(a.pct||0)), // momentum (avoid chase)
  rows.filter(x=>x.pe>0&&x.pe<35&&x.pb>0&&x.pb<3).sort((a,b)=>(a.pe||100)-(b.pe||100)), // value
  rows.filter(x=>x.turnover>2&&x.turnover<28).sort((a,b)=>(b.turnover||0)-(a.turnover||0)) // participation
 ];
 const curs=[0,0,0,0],selected=[],used=new Set();
 while(selected.length<limit){let gained=false;
  for(let i=0;i<groups.length&&selected.length<limit;i++){
   const g=groups[i];while(curs[i]<g.length&&used.has(g[curs[i]].code))curs[i]++;
   if(curs[i]<g.length){let x=g[curs[i]++];selected.push(x);used.add(x.code);gained=true;}
  }
  if(!gained)break;
 }
 return selected;
}
async function scanCandidates({local=false,maxA=null,maxHK=null}={}){
 const fc=await financeCoverage(4),aa=await D.get('meta','fastMarket:A'),hh=await D.get('meta','fastMarket:HK');
 const today=F.tradingDate(new Date());
 const marketScopeOK=!!(aa?.finished&&hh?.finished&&aa?.sessionDay===today&&hh?.sessionDay===today);
 const verified=fc.complete&&marketScopeOK;
 if(!verified)say('pickLog',`部分市场分析模式：四类报表季度任务${fc.ok}/${fc.total}，A行情页${(aa?.completedPages||[]).length}/${aa?.total?Math.ceil(aa.total/200):'?'}，H行情页${(hh?.completedPages||[]).length}/${hh?.total?Math.ceil(hh.total/200):'?'}。失败页不阻塞已入库股票的研究。`);
 const depth=Number($('scanDepth')?.value)||60;maxA=maxA??Math.ceil(depth*.84);maxHK=maxHK??Math.max(1,depth-maxA);
 const t0=Date.now(),all=await D.all('stocks');
 const a=firstPassUniverse(all.filter(x=>x.market==='A')),hk=firstPassUniverse(all.filter(x=>x.market==='HK'));
 const pool=[...diversePool(a,maxA),...diversePool(hk,maxHK)],sectors=await D.all('sectors'),sectorMap=new Map(sectors.filter(x=>x.kind==='industry').map(x=>[x.name,x.pct]));
 say('pickLog',`本地近期已核验报价池：A股${a.length}只/H股${hk.length}只；初筛选${pool.length}只。先核验K线，再仅为技术候选补财报与公告（不需要对5000只全部下载多年K线）。`);
 if(!pool.length){$('picks').textContent='暂无近期可用的股票快照，无法构建候选。可先只更新持仓或补抓失败页。';lastCandidates=[];return []}
 let stage1=[],n=0,fail=0;
 for(let i=0;i<pool.length&&!cancelled;i+=3){await Promise.all(pool.slice(i,i+3).map(async st=>{
  try{
   const r=local?{market:st.market,code:st.code,quote:st,bars:await dbBars(st.market,st.code),finance:await dbReports(st.market,st.code),notices:await dbNotices(st.market,st.code),elapsedMs:0,failures:[]}:
     await refreshStock(st.code,st.market,{quote:false,finance:false,notices:false});
   if(st.market==='A'&&sectorMap.has(st.sector))r.marketContext={sectorPct:sectorMap.get(st.sector)};
   const d=runDecision(r);stage1.push(d);if(d.fetchErrors.length)fail++;
  }catch(e){fail++;say('pickLog',`${st.code}基础分析失败：${e.message}`)}n++;
 }));
  if(i%15===0||i+3>=pool.length)say('pickLog',`K线初选${n}/${pool.length}只；网络错误${fail}只；耗时${times(Date.now()-t0)}。剩余仍可继续，不等待全部财报。`);
  await sleep(30);
 }
 // Exclude stale/invalid quotes from enrichment. A-shares have an on-demand 4-statement path.
 stage1.sort((a,b)=>Number(b.ready)-Number(a.ready)||(Number(b.rankKey??-1e9)-Number(a.rankKey??-1e9)));
 const cap=local?0:Math.min(24,Math.max(8,Math.ceil(stage1.length*.2)));
 const deep=stage1.filter(x=>x.market==='A'&&x.quoteOK&&x.barsOK&&x.technical?.long).slice(0,cap),updated=new Map();
 for(let i=0;i<deep.length&&!cancelled;i+=2){await Promise.all(deep.slice(i,i+2).map(async d=>{
  try{const r=await refreshStock(d.code,d.market,{quote:false,bars:false,finance:true,notices:true});updated.set(d.market+':'+d.code,runDecision(r));}
  catch(e){say('pickLog',`${d.code}财报/公告补齐失败：${e.message}`)}
 }));
  if(i%6===0||i+2>=deep.length)say('pickLog',`财务与公告深验${Math.min(i+2,deep.length)}/${deep.length}只，前期已完成K线${n}只；总耗时${times(Date.now()-t0)}`);
 }
 let results=stage1.map(d=>updated.get(d.market+':'+d.code)||d);
 // Conditional candidates are per-stock; partial market coverage means NO global ranking claim.
 if(!marketScopeOK)for(const d of results){if(d.action.startsWith('研究候选')){d.action='局部池研究候选｜需人工复核';d.reason+='；A/H市场仍有失败页，本股已独立核验，但不能视作全市场最优或即时下单指令';d.severity='watch';d.partialUniverse=true;}}
 results.sort((u,v)=>Number(v.ready)-Number(u.ready)||Number(v.action.includes('研究候选'))-Number(u.action.includes('研究候选'))||(Number(v.rankKey??-1e9)-Number(u.rankKey??-1e9)));
 const eligible=results.filter(x=>x.action.startsWith('研究候选')||x.partialUniverse),observed=results.filter(x=>x.ready);
 lastCandidates=results;
 $('picks').innerHTML=`<p><b>本次K线分析 ${n}只；财报和公告深验 ${updated.size}只</b> · 已覆盖的近期快照 A${a.length}/H${hk.length}只 · 条件观察${eligible.length}只。</p><p class="hint">${verified?'已选数据范围成功下载':'部分覆盖！有失败页或财报未齐；此排名仅限已获取股票，不代表全市场最优。'} 第一阶段本地快照筛选，第二阶段K线核验，第三阶段仅对入围技术强势的少量股票深验财报公告。未分析的股票不是无潜力。</p>`+(eligible.length?eligible.slice(0,18).map(decisionHTML).join(''):'<p>目前没有同时达到数据质量、形态和公告门槛的候选，不强行推荐。</p>')+`<details><summary>查看其余已分析${Math.max(0,results.length-eligible.length)}只</summary>${results.filter(x=>!eligible.includes(x)).slice(0,20).map(decisionHTML).join('')}</details>`;
 await D.put('meta',{key:'lastScan',when:nowIso(),pool:{a:a.length,hk:hk.length},selected:pool.length,analyzed:n,deep:updated.size,eligible:eligible.length,partial:cancelled||!marketScopeOK});
 audit(`算法 ${Q.analysisVersion} · 已入库报价A${a.length}/HK${hk.length} · K线分析${n}只 · 财务深验${updated.size}只 · 条件观察${eligible.length}只 · ${verified?'所选范围完整':'市场/报表部分覆盖'} · 本阶段用时${times(Date.now()-t0)}`);
 return results;
}
function summarizeActions(holdings=[],picks=[]){let risk=holdings.filter(x=>x.severity==='risk'),unknown=holdings.filter(x=>!x.ready),w=holdings.filter(x=>x.ready&&x.severity!=='risk'),b=picks.filter(x=>x.action.startsWith('研究候选')||x.partialUniverse);
 const bhtml=x=>x.map(y=>`<div class="result"><b>${esc(y.name)} ${esc(y.code)}</b> · ${esc(y.action)}<p class="hint">参考价 ${fmt(y.price)}；${esc(y.quoteTime||'时间未知')}；12-1动量 ${fmt(y.technical?.momentum12mSkip1m,2)}%（非收益预测）。${esc(y.reason)}</p></div>`).join('');
 $('actions').innerHTML=`<p class="risk"><b>卖出风险警戒 ${risk.length}只</b>（需确认可卖股数、成交价格、T+1和券商账本）</p>${bhtml(risk)||'<p class="hint">暂无通过风险门槛的强烈预警，不能理解为安全。</p>'}<p class="buy"><b>候选条件观察 ${b.length}只</b>（部分市场覆盖时非全市场排名）</p>${bhtml(b)||'<p class="hint">暂无同时满足时间/技术/财务/公告门槛的候选，不凭空给出“现在买”。</p>'}<p><b>继续观察持仓 ${w.length}只 · 数据不足需核验 ${unknown.length}只</b></p><p class="hint">买卖清单是软件研究结论，不是实盘下单建议；市场闭市时应理解为下一交易时段观察计划。未完成全市场抓取时扫描范围有限。</p>`;
}
async function runAll(){await oneLock('持仓优先 → 行情尽力更新 → 已获取股票继续量化',async()=>{
 $('actions').textContent='正在更新持仓并获取行情；有失败页也不会阻断后续分析。';$('runBar').style.width='2%';
 progress(5,'阶段1/4：持仓优先联网并运行统一策略');let holdings=[];
 try{holdings=await inspectHoldings()}catch(e){say('runStatus','部分持仓更新失败：'+e.message)}summarizeActions(holdings,[]);
 if(cancelled)return;
 progress(25,'阶段2/4：A股只做当日行情和季度披露增量；不重复初建全量历史');
 let ar={complete:false,failed:[],total:0};try{
   const inc=await bootstrapEngine().incremental();ar.complete=inc.complete;
   if(inc.failures?.length)say('dataLog','A股增量仍有缺口：'+inc.failures.join('；'));
 }catch(e){say('dataLog','A股增量不可用，继续使用已存储且有效的股票：'+e.message)}
 if(cancelled)return;
 progress(50,'阶段3/4：港股仅在当日数据未通过验收时更新');
 let hr={complete:false,failed:[],total:0};try{
   const cache=await D.get('meta','fastMarket:HK');
   if(cache?.finished&&cache.sessionDay===F.tradingDate(new Date()))hr={complete:true,cached:true};
   else hr=await syncMarket('HK');
 }catch(e){say('dataLog','港股行情不可用，仍继续已存储股票研究：'+e.message)}
 if(cancelled)return;
 const fc=await financeCoverage(4);
 say('dataLog',`财报完整季度任务 ${fc.ok}/${fc.total}；“一键”不再强制等待下载几千页。需要时可在数据页单独后台/分次续传全量财报；入围股票单独补财报。`);
 progress(73,'阶段4/4：已入库股票初筛、K线验证、少量财报深验');
 // Market context is optional, not a blocking prerequisite.
 updatePublicContext().catch(e=>say('dataLog','辅助板块数据失败：'+e.message));
 let picks=[];try{picks=await scanCandidates()}catch(e){say('pickLog','候选扫描发生错误：'+e.message)}
 if(cancelled){summarizeActions(holdings,picks);$('runStatus').textContent='本轮人工停止；已生成的内容属于部分扫描。';return}
 summarizeActions(holdings,picks);
 const partial=!(ar.complete&&hr.complete&&fc.complete);
 progress(100,`本轮计算流程已结束${partial?'（数据部分覆盖，不是全市场100%）':''}：A股${ar.complete?'全页通过':'有缺页'}；港股${hr.complete?'全页通过':'有缺页'}；财报季度${fc.ok}/${fc.total}；候选技术分析${picks.length}只，需人工复核。用时${times(Date.now()-currentStarted)}。`);
 const summary={key:'lastDecision',when:nowIso(),version:Q.analysisVersion,partial,holdings:holdings.map(x=>({code:x.code,name:x.name,market:x.market,action:x.action,momentum:x.technical?.momentum12mSkip1m??null,quoteTime:x.quoteTime})),picks:picks.filter(x=>x.action.startsWith('研究候选')||x.partialUniverse).map(x=>({code:x.code,name:x.name,market:x.market,action:x.action,momentum:x.technical?.momentum12mSkip1m??null,quoteTime:x.quoteTime})),market:{A:ar.complete,HK:hr.complete}};await D.put('meta',summary);
})}
async function showLastRun(){let p=await D.get('meta','lastDecision');if(!p){$('actions').textContent='尚无成功完成的一键研究记录。';return}const list=(xs)=>xs?.map(x=>`<p><b>${esc(x.name||x.code)}</b>：${esc(x.action)} · 行情${esc(x.quoteTime||'未知')}</p>`).join('')||'<p>暂无</p>';
 $('actions').innerHTML=`<p class="missing"><b>历史记录：${esc(p.when)}</b>，不是现在行情</p><h3>持仓</h3>${list(p.holdings)}<h3>候选</h3>${list(p.picks)}`;}
async function saveLedger(){await D.put('ledger',{key:'main',...ledger})}
function exportBackup(){let x={kind:'quantdesk-v6.4-ledger-only',exportedAt:nowIso(),...ledger};$('ledgerBackup').value=JSON.stringify(x,null,2);$('ledgerBackup').focus();$('ledgerBackup').select();notice('账本JSON已填入文本框，请复制到安全位置备份')}
async function restoreBackup(){const file=$('ledgerFile').files?.[0],raw=$('ledgerBackup').value.trim()||(file?await file.text():'');if(!raw)throw Error('先选JSON文件或粘贴备份');let x;try{x=JSON.parse(raw)}catch(e){throw Error('JSON格式不正确')}
 if(!Array.isArray(x.holdings)||!Array.isArray(x.trades)||!Number.isFinite(Number(x.cashApprox))||!Number.isFinite(Number(x.realized)))throw Error('缺少账本的必要字段');
 if(x.holdings.some(h=>!/^\d{5,6}$/.test(String(h.code||''))||!Number.isFinite(+h.shares)||+h.shares<0||!Number.isFinite(+h.cost)||+h.cost<0))throw Error('持仓代码或成本不合法');
 if(!window.confirm(`将覆盖当前持仓和成交记录：${x.holdings.length}只持仓、${x.trades.length}笔交易，确认导入？导入前请备份旧账本。`))return;
 Object.assign(ledger,{cashApprox:Number(x.cashApprox),realized:Number(x.realized),holdings:x.holdings,trades:x.trades,cashByCurrency:x.cashByCurrency||{CNY:Number(x.cashApprox),HKD:0},realizedByCurrency:x.realizedByCurrency||{CNY:Number(x.realized),HKD:0}});await saveLedger();await renderHoldings();notice('账本导入成功，请与券商账户再次核对');}
async function recordFill(){
 const market=$('tradeMarket')?.value||'A',code=$('tradeCode').value.trim();
 const current=await D.get('ledger','main');
 let name=$('tradeName').value.trim();
 if(!name){const record=await D.get('stocks',market+':'+code)||await D.get('universe',market+':'+code);name=record?.name||current?.holdings?.find(x=>x.code===code&&(x.market||'A')===market)?.name||'';if(name)$('tradeName').value=name;}
 const input={market,lotSize:Number($('tradeLot')?.value)||null,code,name,side:$('tradeSide').value,shares:Number($('tradeShares').value),price:Number($('tradePrice').value),fee:Number($('tradeFee').value),date:$('tradeDate').value,time:$('tradeTime').value};
 if(!$('tradeShares').value.trim()||!$('tradePrice').value.trim()||!new RegExp(market==='HK'?'^\\d{5}$':'^\\d{6}$').test(code))throw Error('成交代码、股数、价格必填，A股6位/港股5位');
 if(!input.date)throw Error('请确认真实成交日期');
 // First validate against the database, not the stale in-memory pre-import ledger.
 L.applyFill(current||{holdings:[],trades:[],cashApprox:0,realized:0},input);
 if(!window.confirm(`仅记录真实已成交订单：${name||code} (${code})，${input.side==='sell'?'卖出':'买入'} ${input.shares}股，成交价${market==='HK'?'HK$':'¥'}${fmt(input.price)}。确认？`))return;
 const saved=await D.mutateLedger(old=>L.applyFill(old,input));Object.assign(ledger,saved);
 await renderHoldings();document.dispatchEvent(new Event('quantdesk:ledgerChanged'));notice('成交已写入本地账本，并重新读取核验');
}
async function analyzeOne(){await oneLock('联网分析指定股票',async()=>{const code=$('stockCode').value.trim(),m=/^\d{5}$/.test(code)?'HK':'A';if(!/^\d{5,6}$/.test(code))throw Error('A股请输入6位代码，港股请输入5位代码');$('stockResult').textContent='联网核对报价、历史K线和财务信息中……';const x=await refreshStock(code,m,{force:true,report:v=>say('runStatus',code+' '+v)}),d=runDecision(x);$('stockResult').innerHTML=decisionHTML(d);audit(`指定股票${m}:${code}已调用 ${d.version}，算法耗时${times(Math.ceil(d.computeMs))}，联网+存储耗时${times(d.fetchMs)}。`);progress(100,'股票分析完成。');});}
async function checkStockBacktest(){const code=$('stockCode').value.trim(),market=/^\d{5}$/.test(code)?'HK':'A';
 if(!/^\d{5,6}$/.test(code)){say('backtestResult','请先输入有效的6位A股或5位港股代码');return}
 const bars=await dbBars(market,code);try{const r=Q.backtest(bars,{market,stockCode:code});say('backtestResult',`策略：${r.strategy}\n测试：${r.firstDate}至${r.lastDate}，${r.holdoutBars}根K线\n扣成本模拟 ${fmt(r.returnPct)}% · 同期买入持有 ${fmt(r.buyHoldPct)}% · 超额 ${fmt(r.excessPct)}% · 最大回撤 ${fmt(r.maxDrawdownPct)}% · 已平仓交易 ${r.trades} 笔\n胜率：${r.winRate===null?'交易少于30笔，不公布':fmt(r.winRate)+'%'}\n边界：${r.mode}\n${r.assumptions}\n未获机构认证：${r.whyNotVerified}`)}catch(e){say('backtestResult','无法完成回测：'+e.message+'。这不是策略验证通过。')}}
function selectPage(page){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('active',e.id==='page-'+page));document.querySelectorAll('nav button').forEach(e=>e.classList.toggle('active',e.dataset.page===page))}
async function init(){try{await D.open();ready=true;let x=await D.get('ledger','main');if(x)Object.assign(ledger,{cashApprox:+x.cashApprox||0,realized:+x.realized||0,holdings:x.holdings||[],trades:x.trades||[],cashByCurrency:x.cashByCurrency||{CNY:+x.cashApprox||0,HKD:0},realizedByCurrency:x.realizedByCurrency||{CNY:+x.realized||0,HKD:0}});
 await renderHoldings();await renderCounts();await showBootstrapStatus();const probed=await D.get('meta','sourceProbe');if(probed)$('probeStatus').textContent='上次接口体检 '+probed.when+'（不是本次实时结果）\n'+probed.results.join('\n');$('runStatus').textContent='数据库已就绪。已加载唯一算法 '+Q.analysisVersion+'。支持行情失败跳过继续研究，进度100%只指本轮计算结束，不表示数据全量。';let sc=await D.get('meta','lastScan');if(sc)$('pickLog').textContent=`历史扫描 ${sc.when} / 在线快照池A${sc.pool.a}/HK${sc.pool.hk}/深度核验${sc.analyzed}只，非当前推荐。`;
 }catch(e){$('runStatus').textContent='本地数据库打开失败：'+e.message+'。请检查Android WebView存储权限或更新系统组件。';return}
 document.querySelectorAll('nav button').forEach(el=>el.onclick=()=>selectPage(el.dataset.page));
 $('oneClick').onclick=eventHandler(runAll);$('stockBacktest').onclick=eventHandler(checkStockBacktest);
 $('bootstrapInit').onclick=eventHandler(fullBootstrap);
 $('bootstrapIncrement').onclick=eventHandler(incrementalBootstrap);
 $('tsBatch').disabled=!QuantTushare.available();$('tsStatus').textContent=QuantTushare.available()?'原生联网桥可用；需要你自己的合法授权。':'本测试 APK 不含原生联网桥，此按钮不可用；上方免费初始化可用。';
 $('tsBatch').onclick=eventHandler(fullTushare);
 $('cancelRun').onclick=()=>{cancelled=true;say('runStatus','已请求终止；正在执行的网络请求完成后停止。已保存数据不会被删除。')};
 $('showLastRun').onclick=eventHandler(showLastRun);
 $('rebuildUniverse').onclick=eventHandler(()=>oneLock('独立股票目录重建',rebuildUniverse));
 $('fillQuotes').onclick=eventHandler(()=>oneLock('腾讯/新浪批量补充A股有效报价',()=>fillUniverseQuotes(Number($('quoteBatchSize')?.value)||350)));
 $('syncMarket').onclick=eventHandler(()=>oneLock('A/H全市场快照同步',async()=>{const a=await syncMarket('A');const h=cancelled?{complete:false}:await syncMarket('HK');progress(100,`本次行情下载已结束，A股${a.complete?'全页':'部分覆盖'}，港股${h.complete?'全页':'部分覆盖'}；失败页可补抓，仍可继续持仓和选股分析。`);}));
 $('retryMarket').onclick=eventHandler(()=>oneLock('仅补抓A/H失败页面',async()=>{await syncMarket('A',{retryOnly:true});if(!cancelled)await syncMarket('HK',{retryOnly:true});$('runStatus').textContent='失败页补抓请求结束，请核对数据覆盖卡片后再判断是否全量完成。'}));
 $('syncFinance').onclick=eventHandler(()=>oneLock('逐季度全市场四类报表同步',async()=>{const f=await syncCompleteFinance();if(f.complete)progress(100,'已完成选定季度和报表类型的全部源端分页下载与落盘。');else $('runStatus').textContent='财报同步尚未完成；请检查失败页或继续断点续传。';}));
 $('syncHoldings').onclick=eventHandler(()=>oneLock('只更新持仓数据',async()=>{const h=await inspectHoldings();summarizeActions(h,lastCandidates);progress(100,'持仓联网和量化分析结束。')}));
 $('analyzeHoldings').onclick=eventHandler(()=>oneLock('持仓同算法分析',async()=>{const h=await inspectHoldings();summarizeActions(h,lastCandidates);progress(100,'持仓量化分析结束。')}));
 $('checkData').onclick=eventHandler(renderCounts);
 $('probeData').onclick=eventHandler(()=>oneLock('检测真实外部接口并保存样本行',probeDataSources));
 $('analyzeStock').onclick=eventHandler(analyzeOne);
 $('scanPicks').onclick=eventHandler(()=>oneLock('候选深度扫描',async()=>{const x=await scanCandidates();summarizeActions(latestDecisions,x);progress(100,'本次候选研究流程完成，K线分析'+x.length+'只。缺页不妨碍已核验股票的研究。')}));
 $('scanLocal').onclick=eventHandler(()=>oneLock('只用已下载数据重新打分',async()=>{const x=await scanCandidates({local:true});summarizeActions(latestDecisions,x);progress(100,'已对缓存重新计算，但数据时间未变。')}));
 $('exportBackup').onclick=exportBackup;$('exportBackup2').onclick=exportBackup;
 $('restoreBackup').onclick=eventHandler(restoreBackup);$('saveTrade').onclick=eventHandler(recordFill);
}
document.addEventListener('DOMContentLoaded',init);
})();
