/* V7.1 professional mobile navigation. Existing data, signals and ledger are never
   reset by this UI layer. Displays only real locally persisted observations. */
(function(root,factory){
 const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;
 root.QuantUI=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(root){
 'use strict';
 const ROUTES=['home','market','picks','positions','sim','data','stock'];
 const TITLES={home:['工作台','你的今日研究与风险清单'],market:['我的自选','A股 · 港股 · 独立研究'],picks:['智能选股','全市场基本面 → 趋势与买点'],positions:['我的持仓','真实交易账本和风险管理'],sim:['模拟验证','规则策略与机器学习对照'],data:['数据中心','建立 / 更新数据库 · 自动续传 · 覆盖率核验'],stock:['股票详情','历史K线与可信数据来源']};
 const LABELS={home:'首页',market:'行情',picks:'选股',positions:'持仓',sim:'模拟'};
 const ICONS={home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-6h6v6"/>',market:'<path d="M4 18V9m5 9V5m5 13v-7m5 7V3"/>',picks:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5m-11-8 2 2 4-5"/>',positions:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m-13 7h18"/>',sim:'<path d="M4 18h16M5 15l4-4 3 2 6-7 2 2"/><circle cx="18" cy="6" r="2"/>',data:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v7c0 2 4 3 9 3s9-1 9-3V5M3 12v7c0 2 4 3 9 3s9-1 9-3v-7"/>',search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M4.8 4.8l2.1 2.1m10.2 10.2 2.1 2.1M19.2 4.8l-2.1 2.1M6.9 17.1l-2.1 2.1"/>',arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',shield:'<path d="M12 2 4 5v6c0 5 3.2 8.7 8 11 4.8-2.3 8-6 8-11V5z"/><path d="M12 7v5m0 4h.01"/>',star:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2-5.5-3-5.5 3 1-6.2L3 9.6l6.2-.9z"/>'};
 const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[name]||ICONS.home}</svg>`;
 const byId=id=>document.getElementById(id),safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const amount=n=>Number.isFinite(Number(n))?Number(n).toLocaleString('zh-CN',{maximumFractionDigits:2}):'—';
 let route='home',market='A',watch=new Set(),filterText='',maxRows=60,quotes=[],universe=[],ready=false;
 const store={load:()=>{try{let v=JSON.parse(localStorage.getItem('qd71.watchlist')||'[]');watch=new Set(Array.isArray(v)?v:[])}catch(e){watch=new Set()}},save:()=>{try{localStorage.setItem('qd71.watchlist',JSON.stringify([...watch]))}catch(e){}}};
 function create(tag,cls,html){const node=document.createElement(tag);if(cls)node.className=cls;if(html!==undefined)node.innerHTML=html;return node;}
 function activateTab(group,pane){for(const b of group.querySelectorAll(':scope > .subtabs button'))b.classList.toggle('active',b.dataset.sub===pane);
  for(const el of group.querySelectorAll(':scope > .subpane'))el.classList.toggle('active',el.dataset.sub===pane);
 }
 function tabs(section,descs,initial){const menu=create('div','subtabs');menu.setAttribute('role','tablist');
  const old=[...section.children];for(const item of descs){const el=create('section','subpane');el.dataset.sub=item.id;for(const node of (item.nodes||[])){if(node)el.append(node)}section.append(el);const button=create('button','',item.label);button.type='button';button.dataset.sub=item.id;button.setAttribute('role','tab');button.onclick=()=>activateTab(section,item.id);menu.append(button)}const heading=section.querySelector(':scope > .screen-head');section.insertBefore(menu,heading?heading.nextSibling:section.firstChild);activateTab(section,initial||descs[0].id);
  return name=>activateTab(section,name);
 }
 const banner=(title,desc)=>create('div','screen-head',`<h1>${safe(title)}</h1><p>${safe(desc)}</p>`);
 function buildHeader(){const h=document.querySelector('body > header');h.className='app-topbar';h.innerHTML=`<div class="top-left"><div class="brandmark">Q</div><div><strong id="appTitle">远见 QuantDesk</strong><small id="appSubtitle">V7.1 · 专业多页面版</small></div></div><div class="top-icons"><button type="button" class="icon-button" id="toData" aria-label="打开数据中心" title="数据中心">${icon('data')}</button><button type="button" class="icon-button" id="themeToggle" aria-label="切换日间夜间模式" title="切换主题">${icon('gear')}</button></div>`;
  byId('toData').onclick=()=>navigate('data');byId('themeToggle').onclick=()=>{document.body.classList.toggle('light-ui');try{localStorage.setItem('qd71.theme',document.body.classList.contains('light-ui')?'light':'dark')}catch(e){}};
  try{if(localStorage.getItem('qd71.theme')!=='dark')document.body.classList.add('light-ui')}catch(e){}
 }
 function buildNav(){const nav=document.querySelector('body > nav');nav.className='app-tabbar';nav.innerHTML=Object.keys(LABELS).map(n=>`<button type="button" data-page="${n}" aria-label="${LABELS[n]}">${icon(n)}<span>${LABELS[n]}</span></button>`).join('');for(const b of nav.querySelectorAll('button'))b.onclick=()=>navigate(b.dataset.page)}
 function moveMain(){const main=document.querySelector('main.wrapper'),hero=main.querySelector(':scope > .hero'),actions=main.querySelector(':scope > .card');
  const home=create('section','view');home.id='page-home';home.append(banner('今日工作台','行情更新、买卖警戒和候选研究一目了然'));
  home.insertAdjacentHTML('beforeend',`<div class="dashboard-metrics"><div class="metric"><b id="homeUni">—</b><small>已建库代码</small></div><div class="metric"><b id="homeQuotes">—</b><small>本地报价记录</small></div><div class="metric"><b id="homeHolding">—</b><small>真实持仓只数</small></div></div><div class="notice-bar">行情与推荐以实际数据时间为准；本软件不直连券商下单，不能保证交易收益。</div><div class="section-title">快捷入口</div><div class="quick-grid" id="shortcuts"></div>`);
  home.append(hero);home.append(actions);hero.querySelector('h1').textContent='一键检查持仓与候选';hero.querySelector('p').textContent='优先识别真实持仓风险，再按已建库范围研究股票；行情缺失会如实标注。';
  const researchBtn=byId('oneClick');if(researchBtn)researchBtn.textContent='分析已有数据（不启动建库）';
  const runLog=byId('runStatus');if(runLog){const details=create('details','',`<summary>查看本轮下载与计算详情</summary>`);runLog.parentNode.insertBefore(details,runLog);details.append(runLog)}
  home.insertAdjacentHTML('beforeend',`<div class="section-title">数据与任务状态 <button id="homeDataMore">进入数据中心 →</button></div><div class="card"><div id="homeAudit" class="small-label">正在读取本地数据库…</div></div>`);
  main.insertBefore(home,byId('page-data'));
  const q=byId('shortcuts');for(const [name,label,ic] of [['market','A/H行情','market'],['picks','全市场选股','picks'],['positions','持仓预警','shield'],['sim','模拟成绩','sim'],['data','数据中心','data']]){
   const b=create('button','quick-tile',icon(ic)+`<span>${label}</span>`);b.type='button';b.onclick=()=>navigate(name);q.append(b)
  }byId('homeDataMore').onclick=()=>navigate('data');
  return main;
 }
 function buildMarket(main){const el=create('section','view');el.id='page-market';el.append(banner('市场行情','A股 · 港股 · 自选股（显示实际已保存行情）'));
  el.insertAdjacentHTML('beforeend',`<div class="market-summary"><div class="metric"><b id="marketCount">—</b><small>已保存有效报价</small></div><div class="metric"><b id="marketLast">—</b><small>最近报价日期</small></div></div><div class="searchbox"><input id="marketSearch" type="search" placeholder="输入股票代码或名称搜索本地数据" autocomplete="off" aria-label="搜索股票"><button id="marketUpdate" class="primary" type="button">更新行情</button></div><div class="market-filter" id="marketFilters"><button data-filter="A" class="active">A股</button><button data-filter="HK">港股</button><button data-filter="watch">自选</button></div><div class="card" style="padding:0;overflow:hidden"><div class="quote-table-head"><span>名称 / 代码</span><span style="text-align:right">最新价</span><span style="text-align:right">涨跌幅</span></div><div id="marketRows" aria-live="polite"><div class="empty-state">请先到数据中心建立股票池与行情数据库</div></div></div><button id="marketMore" class="more-link">显示更多已入库股票</button><p class="hint" id="marketDisclaimer">本地缓存不是交易所授权实时行情；点击任意股票查看本地K线和数据来源。</p>`);
  main.insertBefore(el,byId('page-data'));
  byId('marketSearch').addEventListener('input',e=>{filterText=e.target.value.trim();maxRows=60;drawMarket()});
  for(const b of byId('marketFilters').querySelectorAll('button'))b.onclick=()=>{market=b.dataset.filter;maxRows=60;for(const n of b.parentNode.querySelectorAll('button'))n.classList.toggle('active',n===b);drawMarket()};
  byId('marketUpdate').onclick=()=>navigate('data');byId('marketMore').onclick=()=>{maxRows+=80;drawMarket()};
 }
 function buildPositions(){const el=byId('page-positions');el.insertBefore(banner('真实持仓','价格、持仓风险、真实成交分别管理'),el.firstChild);
  const cards=[...el.querySelectorAll(':scope > .card')];const set=tabs(el,[{id:'holdings',label:'持仓与风控',nodes:[cards[0]]},{id:'lookup',label:'个股分析',nodes:[cards[1]]},{id:'trades',label:'真实成交记录',nodes:[cards[2]]}],'holdings');
  return set;
 }
 function buildPicks(){const el=byId('page-picks');el.insertBefore(banner('智能选股','先筛公司质量，再找合适的交易区间'),el.firstChild);
  const cards=[...el.querySelectorAll(':scope > .card')];return tabs(el,[{id:'screen',label:'全市场初筛',nodes:[cards[0]]},{id:'candidate',label:'候选与观察',nodes:[cards[1]]}],'screen');
 }
 function buildSim(){const el=byId('page-sim');if(!el)return;el.insertBefore(banner('策略模拟盘','每天留痕推荐 · 次日模拟成交 · 统计长期结果'),el.firstChild)}
 function buildData(){const el=byId('page-data');el.insertBefore(banner('数据中心','A/H股票池、行情和财务报表分别统计'),el.firstChild);
  const rootCard=el.querySelector(':scope > .card');if(!rootCard)return;
  const v7=byId('v7AHInit')?.closest('.card'),bootstrap=byId('bootstrapInit')?.closest('.card');
  const adv=create('details','data-advanced');adv.innerHTML='<summary>更多数据工具：补行情 / 财报 / 接口检测 / 账本备份</summary>';
  // Keep front-and-center initialization cards; collapse verbose legacy controls.
  if(bootstrap){let child=bootstrap.nextSibling;while(child){const next=child.nextSibling;adv.append(child);child=next}}
  rootCard.append(adv);
  if(v7)rootCard.insertBefore(v7,rootCard.children[2]||null);
  if(bootstrap){const details=create('details','data-advanced');details.innerHTML='<summary>旧版增量建库与授权接口（高级）</summary>';details.append(bootstrap);rootCard.insertBefore(details,adv)}
  const dataLog=byId('dataLog');if(dataLog){const panel=create('details','data-advanced','<summary>下载运行日志</summary>');dataLog.parentNode.insertBefore(panel,dataLog);panel.append(dataLog)}
 }
 function buildStock(main){const section=create('section','view');section.id='page-stock';section.innerHTML=`<button class="back-button" id="stockBack">← 返回行情</button><div class="screen-head"><h1 id="detailName">股票详情</h1><p id="detailCode">本地数据核验</p></div><div class="card"><div id="detailPrice" class="detail-price">—</div><div class="small-label" id="detailTime">尚无有效报价</div><div class="chart-box" id="detailChart"><span class="small-label">历史行情尚未下载</span></div><p id="detailChartNote" class="hint"></p><div class="info-list" id="detailFacts"></div></div><div class="row"><button class="primary" id="detailAnalyze">联网分析该股票</button><button id="detailWatch">☆ 加入自选</button></div><p class="hint">此页面的走势来自本机已经保存的日K，不是实时分时图。</p>`;
  main.insertBefore(section,byId('page-data'));byId('stockBack').onclick=()=>navigate('market');
  byId('detailAnalyze').onclick=()=>{const [m,c]=section.dataset.symbol?.split(':')||[];if(!c)return;byId('stockCode').value=c;window.QuantUI.holdingsSub('lookup');navigate('positions');byId('analyzeStock').click()};
  byId('detailWatch').onclick=()=>{let key=section.dataset.symbol;if(!key)return;if(watch.has(key))watch.delete(key);else watch.add(key);store.save();byId('detailWatch').textContent=watch.has(key)?'★ 已加入自选':'☆ 加入自选';drawMarket()};
 }
 function updateTitle(name){const [title,desc]=TITLES[name]||TITLES.home;byId('appTitle').textContent=title;byId('appSubtitle').textContent=desc}
 function show(name){if(!ROUTES.includes(name))name='home';route=name;for(const el of document.querySelectorAll('main > .view'))el.classList.toggle('active',el.id==='page-'+name);const primary=name==='stock'?'market':name==='data'?'home':name;
  for(const b of document.querySelectorAll('nav.app-tabbar button'))b.classList.toggle('active',b.dataset.page===primary);
  updateTitle(name);window.scrollTo({top:0,behavior:'instant'});
  if(name==='market')loadMarket();if(name==='home')refreshHome();if(name==='sim')refreshSim();
 }
 function navigate(name){if(!ROUTES.includes(name))name='home';if(location.hash!=='#/ui/'+name)location.hash='/ui/'+name;else show(name)}
 function refreshHome(){if(!root.QuantDB)return;const D=root.QuantDB;
  Promise.all([D.count('universe'),D.count('stocks'),D.get('ledger','main'),D.get('screenings','latest')]).then(([n,q,led,screen])=>{
   byId('homeUni').textContent=n.toLocaleString('zh-CN');byId('homeQuotes').textContent=q.toLocaleString('zh-CN');byId('homeHolding').textContent=(led?.holdings||[]).filter(x=>Number(x.shares)>0).length.toString();
   byId('homeAudit').textContent=`本地股票目录 ${n} 条，行情记录 ${q} 条；${screen?'上次初筛 '+(screen.universeCount||0)+' 只，'+(screen.complete?'本轮初筛已结束':'未完成'):'尚未执行全市场初筛'}。注意：股票记录数量不等于完整实时行情覆盖。`;
  }).catch(e=>{byId('homeAudit').textContent='无法读取本地数据库：'+e.message})}
 function loadMarket(){const D=root.QuantDB;if(!D)return;byId('marketRows').innerHTML='<div class="empty-state">正在读取本地行情…</div>';
  return Promise.all([D.all('stocks'),D.all('universe')]).then(([q,u])=>{quotes=q||[];universe=u||[];drawMarket()}).catch(e=>{byId('marketRows').textContent='本地行情读取失败：'+e.message})}
 function dateOnly(v){return String(v||'').slice(0,10)||'未知'}
 function drawMarket(){const list=quotes.filter(q=>q&&['A','HK'].includes(q.market)&&Number(q.price)>0);
  const lookup=filterText.toLowerCase();let filtered=list.filter(q=>(market==='watch'?watch.has(q.market+':'+q.code):q.market===market)&&(!lookup||String(q.name||'').toLowerCase().includes(lookup)||String(q.code||'').includes(lookup)));
  filtered.sort((a,b)=>(Number(b.amount)||0)-(Number(a.amount)||0));
  byId('marketCount').textContent=filtered.length.toLocaleString('zh-CN');const dates=filtered.map(x=>x.quoteTime).filter(Boolean).sort();byId('marketLast').textContent=dates.length?dateOnly(dates[dates.length-1]):'未知';
  const host=byId('marketRows');host.replaceChildren();if(!filtered.length){host.innerHTML=`<div class="empty-state">${lookup?'本地无匹配股票':'当前没有符合条件的有效报价'}。<br>可到数据中心建立或补充行情，不会生成假股票。</div>`;}
  for(const q of filtered.slice(0,maxRows)){const change=Number(q.pct),valid=Number.isFinite(change)&&q.pct!==null&&q.pct!==undefined;const row=create('button','quote-row');row.type='button';row.innerHTML=`<span><strong>${safe(q.name||q.code)}</strong><small>${q.market==='HK'?'HK':'A'} ${safe(q.code)} ${watch.has(q.market+':'+q.code)?'★':''}</small></span><span class="value">${amount(q.price)}</span><span class="chg ${valid?(change>0?'rise':change<0?'fall':''):''}">${valid?(change>0?'+':'')+change.toFixed(2)+'%':'—'}</span>`;row.onclick=()=>openStock(q.market,q.code);host.append(row)}
  byId('marketMore').hidden=filtered.length<=maxRows;byId('marketDisclaimer').textContent=`当前显示 ${Math.min(maxRows,filtered.length)}/${filtered.length} 条已保存的${market==='A'?'A股':market==='HK'?'港股':'自选'}报价；上游数据可能延迟，须核对报价时间及来源。`;
 }
 function sparkSvg(series){const vals=series.map(x=>Number(x.close)).filter(x=>Number.isFinite(x)&&x>0);if(vals.length<2)return '<span class="small-label">有效历史K线不足，无法绘制走势</span>';
  const width=320,height=150,pad=14,min=Math.min(...vals),max=Math.max(...vals),range=max-min||1;
  const points=vals.map((v,i)=>`${(pad+i*(width-2*pad)/Math.max(1,vals.length-1)).toFixed(1)},${(height-pad-(v-min)/range*(height-2*pad)).toFixed(1)}`).join(' ');
  const linecolor=vals.at(-1)>=vals[0]?'#ec686f':'#25b99f';return `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="本地日K收盘趋势"><path d="M${pad} ${height-pad}H${width-pad}" stroke="#617589" opacity=".35"/><polyline points="${points}" fill="none" stroke="${linecolor}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
 }
 async function openStock(m,code){const key=m+':'+code;const D=root.QuantDB;const q=await D.get('stocks',key),un=await D.get('universe',key),bars=await D.withPrefix('bars',key+':');
  const section=byId('page-stock');section.dataset.symbol=key;byId('detailName').textContent=q?.name||un?.name||code;byId('detailCode').textContent=`${m==='A'?'A股':'港股'} · ${code} · 仅显示真实入库数据`;
  byId('detailPrice').textContent=Number(q?.price)>0?amount(q.price)+' '+(m==='HK'?'HKD':'CNY'):'无有效行情';byId('detailTime').textContent='报价时间：'+(q?.quoteTime||'未知')+' · 来源：'+(q?.source||'未记录');
  const sorted=bars.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date)));byId('detailChart').innerHTML=sparkSvg(sorted.slice(-140));byId('detailChartNote').textContent=`日K记录 ${sorted.length} 条；最近日期 ${sorted.at(-1)?.date||'未知'}。历史复权方式以每条数据的实际来源为准。`;
  byId('detailFacts').innerHTML=`<div><small>最新收盘/报价</small><b>${amount(q?.price)}</b></div><div><small>涨跌幅（上游）</small><b>${q?.pct!=null?Number(q.pct).toFixed(2)+'%':'—'}</b></div><div><small>成交额</small><b>${amount(q?.amount)}</b></div><div><small>行业</small><b>${safe(q?.sector||un?.sector||'暂无')}</b></div>`;
  byId('detailWatch').textContent=watch.has(key)?'★ 已加入自选':'☆ 加入自选';navigate('stock');
 }
 async function refreshSim(){try{const a=await root.QuantDB.count('signals');if(a===0)byId('v7PaperStatus').textContent='尚无每日冻结推荐。先在选股页完成候选初筛与技术核验；没有有效信号不强行模拟成交。'}catch(e){}}
 function init(){if(ready)return;ready=true;store.load();buildHeader();buildNav();const main=moveMain();buildMarket(main);const holdingsSub=buildPositions();buildPicks();buildSim();buildData();buildStock(main);
  api.holdingsSub=holdingsSub;
  const current=(location.hash.match(/^#\/ui\/(\w+)/)||[])[1];show(current||'home');
  window.addEventListener('hashchange',()=>{const v=(location.hash.match(/^#\/ui\/(\w+)/)||[])[1];show(v||'home')});
  refreshHome();
 }
 // Existing V7 dynamically creates V7 modules after DB.open. Do not move nodes before that.
 function wait(){let n=0;const t=setInterval(()=>{n++;if(byId('v7Scan')&&byId('v7PaperStats')){clearInterval(t);init()}else if(n>=65){clearInterval(t);if(byId('page-picks')&&byId('page-positions'))init()}},150)}
 if(typeof document!=='undefined'){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wait);else wait()}
 const api={navigate,show,refreshHome,drawMarket,openStock,holdingsSub:()=>{},init};return api;
});
