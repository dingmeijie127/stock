/* User-visible full A/HK imports from a self-hosted backend, with durable per-symbol checkpoints. */
(function(root){'use strict';
if(!root.document||!root.QuantV85)return;
const Q=root.QuantV85,D=root.QuantDB,$=id=>document.getElementById(id);
const stamp=()=>new Date().toISOString();let abort=false,busy=false;
const info=s=>{if($('v85Status'))$('v85Status').textContent=String(s).slice(0,2500)};
async function importMarket(market,limit=0,withBars=true,withFinance=true){
 await D.open();const universe=await Q.backendUniverse(market);
 // Backend local cached directory is observed, not exchange-authoritative.
 const allowed=universe.filter(x=>x&&x.market===market&&(market==='A'?/^\d{6}$/:/^\d{5}$/).test(x.code)&&x.name);
 await D.putMany('universe',allowed.map(x=>({...x,key:market+':'+x.code,catalogFetchedAt:x.catalogFetchedAt||stamp()})));
 const quotes=allowed.filter(x=>Number.isFinite(Number(x.price))&&Number(x.price)>0);
 if(quotes.length)await D.putMany('stocks',quotes.map(x=>({...x,key:market+':'+x.code,fetchedAt:stamp()})));
 const targets=limit>0?allowed.slice(0,limit):allowed;
 let kOk=0,fOk=0,err=0,short=0,skipped=0;
 info(`${market}目录实际入库${allowed.length}；有效报价${quotes.length}；开始请求${targets.length}只股票`);
 for(let i=0;i<targets.length&&!abort;i++){
  const x=targets[i],code=x.code,prefix=market+':'+code;
  if(withBars){
   try{
    const rows=await Q.backendBars(code,market,650,1);
    const meta={key:'bootBar:'+prefix,done:true,count:rows.length,latest:rows.at(-1).date,
                source:rows[0].source,adjustment:rows[0].adjustment,updatedAt:stamp()};
    if(rows.length<220)short++;
    await D.replaceSeries('bars',prefix+':',rows,meta);kOk++;
   }catch(e){err++;await D.put('meta',{key:'v85:gap:bars:'+prefix,error:String(e.message||e),checkedAt:stamp()});}
  }
  if(withFinance){
   try{
    const rows=await Q.backendFinance(code,market);
    await D.putMany('finance',rows);
    fOk++;
    const types=[...new Set(rows.map(r=>r.type))];
    await D.put('meta',{key:'v85:finance:'+prefix,types,count:rows.length,updatedAt:stamp(),complete:rows.some(r=>['income','balance','cashflow'].every(t=>rows.some(z=>z.reportDate===r.reportDate&&z.type===t)))});
   }catch(e){err++;await D.put('meta',{key:'v85:gap:finance:'+prefix,error:String(e.message||e),checkedAt:stamp()});}
  }
  if((i+1)%5===0||i===targets.length-1||abort)info(`${market}进度${i+1}/${targets.length}；成功K线${kOk}（不足220根${short}）；成功财报${fOk}；请求失败${err}；暂停可保留已存数据`);
 }
 return {market,directory:allowed.length,targets:targets.length,barsSaved:kOk,financeSaved:fOk,shortBars:short,errors:err,stopped:abort};
}
async function run(){
 if(busy)return;busy=true;abort=false;const btn=$('v85Run');if(btn)btn.disabled=true;
 try{
  const markets=$('v85Market').value==='ALL'?['A','HK']:[$('v85Market').value];
  const cap=Math.max(0,Math.floor(Number($('v85Limit').value)||0));
  const results=[];
  for(const m of markets){if(abort)break;results.push(await importMarket(m,cap,$('v85Bars').checked,$('v85Finance').checked));}
  info('本轮请求结束（不是全市场认证）：\n'+JSON.stringify(results,null,2)+'\n查看 SQLite/本地覆盖审计核对缺失量。');
 }catch(e){info('任务未完成：'+e.message)}finally{busy=false;if(btn)btn.disabled=false;}
}
async function setup(){
 if(!$('v85Root'))return;
 $('v85Endpoint').value=Q.configured();
 $('v85Save').onclick=()=>{try{Q.configure($('v85Endpoint').value);info('已保存采集服务地址。未配置时继续采用旧版直接获取方式。')}catch(e){info(e.message)}};
 $('v85Check').onclick=async()=>{try{const [h,c]=await Promise.all([Q.request('/v1/health'),Q.request('/v1/coverage')]);
  info('采集服务 '+h.version+' 可用；注意“接口可用”不是“数据已经齐全”。\n'+JSON.stringify(c,null,2));}catch(e){info('联网体检失败：'+e.message)}};
 $('v85Run').onclick=run;$('v85Stop').onclick=()=>{abort=true;info('已请求暂停：当前请求结束后停止，已存数据不清除。')};
 $('v85SeriesFetch').onclick=async()=>{
  try{
   const m=$('v85SeriesMarket').value,c=$('v85SeriesCode').value.trim(),iv=$('v85SeriesInterval').value,
         n=Math.max(1,Math.min(200000,Math.floor(Number($('v85SeriesLimit').value)||650)));
   if(!(m==='A'?/^\d{6}$/:/^\d{5}$/).test(c))throw Error('股票代码格式不正确');
   const payload=await Q.request(`/v1/series/${m}/${c}?interval=${iv}&limit=${n}`,{timeout:90000});
   if(!Array.isArray(payload.rows)||!payload.rows.length)throw Error('返回数据为空');
   info(`已从 ${payload.source} 读取并在服务端缓存 ${payload.rows.length} 根${iv} K线：`+
     `${payload.rows[0].moment} ～ ${payload.rows.at(-1).moment}。`+
     `\n复权：${payload.adjustment}。这只表明当前来源返回的有效条数，不代表全历史无缺。`+
     (payload.errors?.length?'\n其他来源失败：'+payload.errors.join('; '):''));
  }catch(e){info('多周期K线请求失败：'+e.message)}
 };

}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup);else setup();
root.QuantV85Import={importMarket,run};
})(typeof globalThis!=='undefined'?globalThis:this);
