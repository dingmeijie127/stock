/* V8.0 short-horizon research radar. Never auto-executes. Fail closed on data/finance/risk gaps. */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantShortRadar=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const mean=a=>a.reduce((s,v)=>s+v,0)/a.length;
function build({quote,bars,finance=[],marketRisk='unknown',sectorHeat=null,portfolioStress=null,budget=2000,now=new Date()}={}){
 const market=quote?.market||'A',code=quote?.code||'',name=quote?.name||code,reasons=[];
 const bj=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now);
 const get=k=>bj.find(x=>x.type===k)?.value||'';
 const day=get('year')+'-'+get('month')+'-'+get('day'),time=get('hour')+':'+get('minute');
 const forming=bars?.length&&bars.at(-1).date===day&&time<'15:10';
 if(forming){bars=bars.slice(0,-1);reasons.push('已排除当日未收盘日K；今天的盘中行情不得冒充收盘确认');}
 const mk=(state,why,extras={})=>({market,code,name,state,reasons:[...reasons,why],dataEnd:bars?.at(-1)?.date||null,...extras});
 if(market!=='A'||!/^\d{6}$/.test(code))return mk('BLOCKED','仅支持A股短线研究');
 const Q=typeof QuantKlineQuality!=='undefined'?QuantKlineQuality:((typeof require==='function')?require('./kline-quality.js'):null);
 if(!Q)return mk('BLOCKED','K线校验模块不存在');
 const quality=Q.readiness(bars,{market,code,min:220,now,maxAgeDays:12});if(!quality.ok)return mk('DATA_MISSING','日K不可用：'+quality.reason,{quality});
 if(!(Number(quote.price)>0)||!Number.isFinite(Date.parse(quote.quoteTime||'')))return mk('DATA_MISSING','有效带时间戳的行情缺失',{quality});
 const quoteAge=now.getTime()-Date.parse(quote.quoteTime);if(quoteAge>5*86400000||quoteAge< -3600000)return mk('DATA_MISSING','报价过期或时间异常',{quality});
 const selected=(finance||[]).filter(f=>f.market==='A'&&f.code===code&&f.type==='summary'&&f.reportDate&&f.noticeDate&&Date.parse(f.noticeDate)<=+now).sort((a,b)=>b.reportDate.localeCompare(a.reportDate))[0];
 if(!selected||+now-Date.parse(selected.reportDate)>500*86400000)return mk('DATA_MISSING','缺少在当前时间前已披露的近期财务摘要',{quality});
 if(!Number.isFinite(selected.profit)||!Number.isFinite(selected.revenue))return mk('DATA_MISSING','基本面必要字段缺失',{quality});
 if(selected.profit<=0||selected.revenue<=0||Number.isFinite(selected.profitYoY)&&selected.profitYoY<0)return mk('FUNDAMENTAL_FAIL','利润非正或利润同比下降',{quality});
 const latestCash=(finance||[]).filter(f=>f.market==='A'&&f.code===code&&f.type==='cashflow'&&f.noticeDate&&Date.parse(f.noticeDate)<=+now&&Math.abs(Date.parse(f.reportDate)-Date.parse(selected.reportDate))<=35*86400000).sort((a,b)=>b.reportDate.localeCompare(a.reportDate))[0];
 if(!latestCash||!Number.isFinite(latestCash.ocf))return mk('DATA_MISSING','缺少可核验的同期经营现金流',{quality});
 if(latestCash.ocf<=0)return mk('FUNDAMENTAL_FAIL','同期经营现金流为负',{quality});
 if(!Number.isFinite(Number(quote.amount))||quote.amount<1e8)return mk('LIQUIDITY_FAIL','成交额不满足1亿元研究门槛',{quality});
 const close=bars.map(b=>b.close),last=bars.at(-1),ma20=mean(close.slice(-20)),ma60=mean(close.slice(-60)),high20=Math.max(...bars.slice(-21,-1).map(x=>x.high));
 const avgVol=mean(bars.slice(-21,-1).map(x=>x.volume));const volRatio=avgVol>0?last.volume/avgVol:0;
 const ret5=(last.close/bars.at(-6).close-1)*100;
 const heatConfirmed=!!(sectorHeat&&sectorHeat.sample>=5&&sectorHeat.positiveRatio>=.6&&sectorHeat.avgPct>=.8&&ret5>=2);
 const trend=last.close>ma20&&ma20>ma60;const breakout=last.close>high20*1.003&&volRatio>=1.2;
 const pullback=trend&&last.low<=ma20*1.015&&last.close>=ma20&&last.close>last.open&&volRatio>=.7;
 const low10=Math.min(...bars.slice(-10).map(x=>x.low));
 const invalid=+(Math.min(low10,ma20*.985)).toFixed(2);const riskShare=Math.max(0,last.close-invalid);
 const maxLot=100;const planLoss=Math.ceil(riskShare*maxLot);
 let state=breakout&&trend?'WATCH_BREAKOUT':pullback?'WATCH_PULLBACK':'WAIT_TREND';
 if(marketRisk!=='bull'&&marketRisk!=='sideways')reasons.push('大盘风险环境未确认，不能发实盘买入信号');
 if(portfolioStress===null||!Number.isFinite(Number(portfolioStress)))reasons.push('账户现有持仓风险未知');
 else if(portfolioStress+planLoss>budget)reasons.push(`账户压力损失约${portfolioStress}元，新增一手理论风险${planLoss}元，超过${budget}元限额`);
 if(!heatConfirmed)reasons.push('板块单日热度和个股5日强度未同时确认（热度不等于可持续）');
 if(!breakout&&!pullback)reasons.push('尚无符合规则的突破/回踩确认');
 if(state==='WAIT_TREND'||reasons.length)state='WATCH_ONLY';
 return {market,code,name,state,reasons,dataEnd:last.date,quality,fundamental:{period:selected.reportDate,profit:selected.profit,cashflow:latestCash.ocf},
  technical:{close:last.close,ma20:+ma20.toFixed(2),ma60:+ma60.toFixed(2),high20:+high20.toFixed(2),volRatio:+volRatio.toFixed(2),return5d:+ret5.toFixed(2),sectorHeat:heatConfirmed?'单日强度初筛合格':'未确认',breakout,pullback},
  plan:{observationPrice:last.close,invalidation:invalid,riskPer100:planLoss,orderAllowed:false},
  note:'信号仅供次日观察；尚未通过样本外回测，不直接建议委托。A股T+1、跌停、跳空可能使实际亏损超过模拟风险。'};
}
return{build};});
