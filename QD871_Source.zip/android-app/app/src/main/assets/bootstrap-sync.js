/* QuantDesk V6.6: built-in staged initial database builder (no Python on phone).
 * All steps are optional/independent, atomic checkpoints, never invent completeness.
 * Store provider provenance and vendor quote timestamps. This is NOT a real-time exchange feed.
 */
(function(root,factory){const lib=factory();if(typeof module==='object'&&module.exports)module.exports=lib;root.QuantBootstrap=lib;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const K='bootstrap:v1', qKey=x=>`bootBar:A:${x}`;
const clean=(e)=>String(e?.message||e).slice(0,180);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const asDay=x=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(x);
function checkQuote(x){return x&&x.market==='A'&&/^\d{6}$/.test(x.code||'')&&Number.isFinite(Number(x.price))&&x.price>0&&x.quoteTime&&Number.isFinite(Date.parse(x.quoteTime))&&x.fetchedAt&&Number.isFinite(Date.parse(x.fetchedAt));}
async function coverage(db,now=new Date()){
 const universe=(await db.all('universe')).filter(x=>x.market==='A'&&/^\d{6}$/.test(x.code||'')),codes=new Set(universe.map(x=>x.code));
 const quoted=(await db.all('stocks')).filter(checkQuote),unique=new Map(quoted.map(q=>[q.code,q]));
 let fresh=0;const t=now.getTime();for(const [code,q] of unique){if(codes.has(code)&&t-Date.parse(q.quoteTime)<96*3600000&&t-Date.parse(q.fetchedAt)<72*3600000&&Date.parse(q.quoteTime)<=t+60000)fresh++;}
 return {directory:codes.size,storedQuotes:unique.size,freshQuotes:fresh,coverage:codes.size?fresh/codes.size:0};
}
function create({db,provider,fastSync,financeSync,universeSync,stop=()=>false,onEvent=()=>{},now=()=>new Date(),wait=sleep,minDirectory=3000}={}){
 if(!db?.get||!db?.put||!db?.putMany||!db?.all||!provider?.bars||!provider?.stockPages)throw Error('初始化器缺少必要依赖');
 const signal=(stage,data={})=>onEvent({stage,...data});
 const checkpoint=async(stage,status,extra={})=>{const m={key:K,stage,status,updatedAt:now().toISOString(),...extra};await db.put('meta',m);signal(stage,{status,...extra});};
 const interrupted=()=>{if(stop())throw Error('用户已暂停；成功入库的数据及检查点保留');};
 async function seedDirectoryFromPrices(){
  const s=(await db.all('stocks')).filter(x=>x.market==='A'&&/^\d{6}$/.test(x.code||'')&&x.name),dedup=new Map(s.map(x=>[x.code,x]));
  if(dedup.size<minDirectory)return 0;
  const at=now().toISOString(),arr=[...dedup.values()].map(x=>({key:'A:'+x.code,market:'A',code:x.code,name:x.name,source:'全市场行情快照内证券目录',catalogFetchedAt:at}));
  for(let i=0;i<arr.length;i+=300){interrupted();await db.putMany('universe',arr.slice(i,i+300));}
  await db.put('meta',{key:'universe:A',source:'全市场行情快照',count:arr.length,stored:arr.length,updatedAt:at,complete:true});
  return arr.length;
 }
 async function directory({force=false,concurrency=3}={}){
  let count=(await coverage(db,now())).directory;
  if(count>=minDirectory&&!force){signal('directory',{status:'cached',count});return{count,already:true};}
  let failures=[],marketResult=null;
  try{
   signal('directory',{status:'market-fetch'});
   marketResult=await fastSync.create({provider,db,market:'A',size:200,concurrency:Math.max(1,Math.min(4,Number(concurrency)||3)),stop,progress:p=>{
    if(['saved','failed','end'].includes(p.phase))signal('market-pages',{...p,status:p.phase});}
   }).run();
  }catch(e){failures.push('全市场快照：'+clean(e));}
  interrupted();
  let seeded=await seedDirectoryFromPrices();count=(await coverage(db,now())).directory;
  if(count<minDirectory){try{
   const r=await universeSync.syncDirectory({db,stop,onEvent:e=>signal('directory-feed',{...e,status:e.phase})});count=r.count;
  }catch(e){failures.push('独立代码目录：'+clean(e));}}
  const ok=count>=minDirectory;await checkpoint('directory',ok?'coverage_checked':'partial',{count,seeded,marketComplete:!!marketResult?.complete,failures});
  return{count,ok,seeded,marketResult,failures};
 }
 async function quotes({limit=6000}={}){
  interrupted();const before=await coverage(db,now());if(!before.directory)throw Error('股票目录为空，先建立股票目录');
  const result=await universeSync.fillQuotes({db,provider,limit,stop,onEvent:e=>{
   if(e.done||e.batchFailures)signal('quotes',{status:'running',...e});}});
  const after=await coverage(db,now());const ok=after.coverage>=.80&&after.directory>=minDirectory;
  await checkpoint('quotes',ok?'coverage_checked':'partial',{...after,attempted:result.requested,batchFailures:result.batchFailures||0});return{...result,...after,ok};
 }
 async function finance({quarters=4,refresh=false,concurrency=2}={}){
  interrupted();const r=await financeSync.create({provider,db,stop,progress:p=>{
   if(['page','skip','quarter','failed','end'].includes(p.phase))signal('finance-pages',{...p,status:p.phase});}
  }).run({types:financeSync.TYPES,quarters,refresh,concurrency});
  await checkpoint('finance',r.complete?'pages_checked':'partial',{quarters,tasks:r.tasks,completed:r.completed,saved:r.saved,failed:r.failed.slice(0,10)});return r;
 }
 async function bars({limit=320,maxSymbols=6000,intervalMs=100,concurrency=3}={}){
  interrupted();const all=(await db.all('universe')).filter(x=>x.market==='A'&&/^\d{6}$/.test(x.code||'')).slice(0,maxSymbols);
  const parallel=Math.max(1,Math.min(6,Math.floor(Number(concurrency)||3)));
  let done=0,failed=0,skipped=0,attempted=0,errors=[],cursor=0,streak=0,circuitOpen=false;
  const start=Date.now();let writeChain=Promise.resolve();
  const serialize=fn=>{const next=writeChain.then(fn);writeChain=next.catch(()=>{});return next;};
  const storeStatus=()=>serialize(async()=>{await db.put('meta',{key:'bootstrap:historyCount',done,failed,skipped,attempted,total:all.length,concurrency:parallel,elapsedMs:Date.now()-start,pending:all.length-attempted,updatedAt:now().toISOString(),errors:errors.slice(-8)});signal('bars',{status:'running',done,failed,skipped,total:all.length,attempted,concurrency:parallel,pending:all.length-attempted,errors:errors.slice(-2)});});
  async function worker(){while(cursor<all.length&&!stop()&&!circuitOpen){
   const x=all[cursor++];let wasError=false;
   try{
    const prev=await db.get('meta',qKey(x.code));
    // A previous 80-bar fetch is NOT proof that the requested 320/650 bars exist.
    const oldLatest=Date.parse(String(prev?.latest||'')+'T15:00:00+08:00');
    const daysOld=(now().getTime()-oldLatest)/86400000;
    if(prev?.done&&prev.count>=Math.min(limit,320)&&prev.requestedLimit>=limit&&daysOld<=12&&daysOld>=-1){skipped++;continue;}
    const rows=await provider.bars(x.code,'A',limit);
    if(!Array.isArray(rows)||rows.length<80||!rows.every(z=>z.code===x.code&&z.market==='A'&&z.date&&z.close>0))throw Error('有效K线小于80根或字段错误');
    const meta={key:qKey(x.code),done:true,count:rows.length,requestedLimit:limit,shortHistory:rows.length<Math.min(limit,320),updatedAt:now().toISOString(),latest:rows.at(-1)?.date,source:rows[0]?.source||'未知'};
    // One stock's K-lines and completion marker commit atomically.
    if(typeof db.replaceSeries==='function')await db.replaceSeries('bars','A:'+x.code+':',rows,meta);
    else if(typeof db.commitPage==='function')await db.commitPage('bars',rows,meta);
    else{await db.putMany('bars',rows);await db.put('meta',meta);}
    done++;streak=0;
   }catch(e){failed++;wasError=true;const msg=clean(e);const category=typeof QuantKlineQuality!=='undefined'?QuantKlineQuality.classifyError(e):'UNKNOWN';
    // Newly listed stocks with short history are not evidence of a global outage.
    streak=['NETWORK_OR_PROXY','RATE_LIMIT_OR_UPSTREAM'].includes(category)?streak+1:0;
    if(errors.length<30)errors.push(x.code+':'+msg);
    try{await db.put('meta',{key:'historyError:A:'+x.code,code:x.code,market:'A',status:'failed',reason:category,details:msg.slice(0,240),updatedAt:now().toISOString()});}catch(_ignored){}
    if(streak>=12)circuitOpen=true;}
   finally{attempted++;if(attempted%10===0||attempted===all.length||circuitOpen)await storeStatus();}
   // Respect provider constraints: bounded concurrency and exponential backoff.
   if(intervalMs)await wait(Math.min(6000,intervalMs*(wasError?Math.min(16,2**Math.min(streak,4)):1)));
  }}
  await Promise.all(Array.from({length:Math.min(parallel,all.length)},()=>worker()));
  await storeStatus();
  if(circuitOpen)errors.push('历史K线源连续失败，已停止新请求，剩余股票下次续传');
  const progress={done,failed,skipped,total:all.length,attempted,pending:all.length-attempted,concurrency:parallel,circuitOpen,errors};
  const ok=all.length>=minDirectory&&done+skipped>=Math.ceil(all.length*.95)&&!circuitOpen&&!stop();
  await checkpoint('bars',ok?'coverage_checked':'partial',{...progress,errors:errors.slice(0,8)});
  return{...progress,ok};
 }
 async function full({quarters=4,history=false,requireFinance=true}={}){
  let result={startedAt:now().toISOString(),options:{quarters,history,requireFinance},steps:{},failed:[]};
  await checkpoint('initialization','running',{startedAt:result.startedAt});
  const attempt=async(name,job)=>{try{const r=await job();result.steps[name]=r;return r;}catch(e){result.failed.push(name+': '+clean(e));signal(name,{status:'failed',error:clean(e)});return null;}};
  await attempt('directory',()=>directory());
  if(!stop()&&(await coverage(db,now())).directory>=minDirectory)await attempt('quotes',()=>quotes());
  if(!stop()&&requireFinance)await attempt('finance',()=>finance({quarters}));
  if(!stop()&&history&&(await coverage(db,now())).directory>=minDirectory)await attempt('bars',()=>bars());
  const c=await coverage(db,now());const directoryOK=c.directory>=minDirectory,quotesOK=c.coverage>=.8;
  const financeOK=!requireFinance||!!result.steps.finance?.complete;
  const historyOK=!history||!!result.steps.bars?.ok;
  const success=!stop()&&directoryOK&&quotesOK&&financeOK&&historyOK&&result.failed.length===0;
  result={...result,...c,complete:success,finishedAt:now().toISOString(),dataModes:{finance:requireFinance,history}};
  await db.put('meta',{key:'bootstrap:last',...result});
  await checkpoint('initialization',success?'coverage_checked':'partial',{directory:c.directory,freshQuotes:c.freshQuotes,coverage:c.coverage,financeOK,historyOK,failed:result.failed});
  return result;
 }
 async function incremental({financeEveryDays=7}={}){
  const old=await db.get('meta','bootstrap:incremental'),day=asDay(now());const ret={day,startedAt:now().toISOString(),steps:{},failures:[]};
  const run=async(stage,fn)=>{try{ret.steps[stage]=await fn();}catch(e){ret.failures.push(stage+':'+clean(e));signal(stage,{status:'failed',error:clean(e)});}};
  // Don't skip updating on a new trading date just because the initial DB exists.
  if((await coverage(db,now())).directory<minDirectory)await run('directory',()=>directory());
  if(old?.day!==day)await run('market',()=>fastSync.create({provider,db,market:'A',size:200,concurrency:3,stop,progress:p=>{if(p.phase==='saved'||p.phase==='failed')signal('market-pages',{status:p.phase,...p});}}).run());
  if(!stop())await run('quotes',()=>quotes());
  const lastFinance=Date.parse(old?.financeAt||'');const financeDue=!Number.isFinite(lastFinance)||now().getTime()-lastFinance>=financeEveryDays*86400000;
  if(!stop()&&financeDue)await run('finance',()=>finance({quarters:2,refresh:true}));
  ret.finishedAt=now().toISOString();ret.complete=ret.failures.length===0&&!stop();
  await db.put('meta',{key:'bootstrap:incremental',day:ret.complete?day:(old?.day||''),financeAt:ret.steps.finance?.complete?ret.finishedAt:old?.financeAt||null,runAt:ret.finishedAt,result:ret});
  return ret;
 }
 return{directory,quotes,finance,bars,full,incremental,coverage:()=>coverage(db,now)};
}
return{create,coverage,checkQuote,asDay};
});
