/* V8.2 unified reconciliation: physical IndexedDB counts != native queue progress != validated market coverage. */
(function(root,factory){const x=factory();if(typeof module==='object'&&module.exports)module.exports=x;root.QuantDataHealth=x;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const valid=(x)=>x&&['A','HK'].includes(x.market)&&new RegExp(x.market==='A'?'^[0-9]{6}$':'^[0-9]{5}$').test(x.code||'')&&!!String(x.name||'').trim()&&String(x.name).trim()!==String(x.code);
function summarize(directory,quotes,counts={},native={}){
 const indexed={A:new Set(),HK:new Set()},fromQuotes={A:new Set(),HK:new Set()},onlyQuote={A:new Set(),HK:new Set()};
 for(const x of directory||[])if(valid(x))indexed[x.market].add(x.code);
 for(const x of quotes||[])if(valid(x)){fromQuotes[x.market].add(x.code);if(!indexed[x.market].has(x.code))onlyQuote[x.market].add(x.code);}
 const count=(key)=>Math.max(0,Number(counts[key]||0));
 const invalidDirectory=(directory||[]).filter(x=>!valid(x)).length,invalidQuotes=(quotes||[]).filter(x=>!valid(x)).length;
 const byKind=native.byKind||{};
 const total=Number(native.total||0),waiting=Number(native.pending||0),ready=Number(native.ready||0),failed=Number(native.failed||0);
 const importFailed=Number(native.import_failed||0);
 let phase='未建立下载任务';
 if(native.startError)phase='后台启动失败';
 else if(failed>0||importFailed>0)phase='部分数据请求或入库校验失败';
 else if(ready>0)phase='已下载，等待导入分析库';
 else if(native.serviceActive)phase='后台服务运行中（实际进度见任务状态）';
 else if(waiting>0||Number(native.running||0)>0)phase='任务已排队，服务目前未运行';
 else if(total>0)phase='任务结束或暂停（需核验数据覆盖）';
 return{
  counts:{catalog:count('universe'),stocks:count('stocks'),bars:count('bars'),finance:count('finance')},
  markets:{A:{directory:indexed.A.size,knownQuotes:fromQuotes.A.size,quoteOnly:onlyQuote.A.size},HK:{directory:indexed.HK.size,knownQuotes:fromQuotes.HK.size,quoteOnly:onlyQuote.HK.size}},
  discrepancies:{catalogAndQuote:count('universe')!==directory?.length||count('stocks')!==quotes?.length,quoteOnly:onlyQuote.A.size+onlyQuote.HK.size,invalidDirectory,invalidQuotes},
  queue:{total,waiting,ready,failed,importFailed,running:Number(native.running||0),imported:Number(native.imported||0),byKind,serviceActive:!!native.serviceActive,startError:String(native.startError||''),errors:native.errors||[]},
  phase,verifiedFullMarket:false,
  warning:'K线条数是日期记录数量，不是拥有合格K线的股票数。目录条数也不等于官方全市场覆盖率。'
 };
}
async function inspect(db,rawStatus){
 const [uni,stocks,catalogCount,stocksCount,barsCount,financeCount]=await Promise.all([
  db.all('universe'),db.all('stocks'),db.count('universe'),db.count('stocks'),db.count('bars'),db.count('finance')]);
 return summarize(uni,stocks,{universe:catalogCount,stocks:stocksCount,bars:barsCount,finance:financeCount},rawStatus||{});
}
async function recoverDirectory(db,{now=()=>new Date()}={}){
 const [uni,stocks]=await Promise.all([db.all('universe'),db.all('stocks')]);
 const known=new Set(uni.filter(valid).map(x=>x.market+':'+x.code));
 const recovered=new Map();for(const q of stocks){if(!valid(q))continue;const key=q.market+':'+q.code;
  if(!known.has(key))recovered.set(key,{key,market:q.market,code:q.code,name:q.name,source:'由本机已有行情索引恢复（非官方全市场目录）',catalogFetchedAt:q.fetchedAt||now().toISOString(),recovered:true});}
 const rows=[...recovered.values()],meta={key:'v82:directoryRecovery',added:rows.length,at:now().toISOString(),complete:false,source:'local_quotes_only'};
 // Do not mark completeness and never wipe existing verified rows.
 if(typeof db.commitBundle==='function')await db.commitBundle([['universe',rows]],meta);
 else {if(rows.length)await db.putMany('universe',rows);await db.put('meta',meta);}
 return{added:rows.length,totalAfter:known.size+rows.length};
}
return{valid,summarize,inspect,recoverDirectory};
});
