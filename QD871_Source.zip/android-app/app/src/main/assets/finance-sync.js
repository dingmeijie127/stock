/* QuantDesk V6.3: four statement types, quarter-by-quarter, page-by-page,
 * single transactional page + checkpoint commit, real progress and restart.
 * Provider pagination completion is NOT proof every listed company has filed.
 */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantFinanceSync=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const TYPES=['summary','balance','income','cashflow'];
const TYPES_ZH={summary:'财务摘要',balance:'资产负债表',income:'利润表',cashflow:'现金流量表'};
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const iso=()=>new Date().toISOString();
function quarterDates(count=4,now=new Date()){
 const p=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit'}).formatToParts(new Date(now)).map(x=>[x.type,x.value]));
 const year=Number(p.year),month=Number(p.month);
 let q=Math.floor((month-1)/3); // last quarter ended BEFORE start of current quarter
 let y=year;if(q===0){q=4;y--;}
 let out=[];for(let i=0;i<count;i++){out.push(`${y}-${String(q*3).padStart(2,'0')}-${q===1||q===4?'31':'30'}`);q--;if(q===0){q=4;y--;}}
 return out;
}
function create({provider,db,progress=()=>{},stop=()=>false,wait=pause,pageSize=50,maxPages=400}={}){
 if(!provider?.financialPage||!db?.get||!db?.putMany)throw Error('财报同步缺少数据源或数据库');
 async function run({types=TYPES,quarters=4,now=new Date(),refresh=false,concurrency=1}={}){
  if(!Array.isArray(types)||!types.length||types.some(t=>!TYPES.includes(t)))throw Error('无效财报类型');
  if(!Number.isInteger(quarters)||quarters<1||quarters>32)throw Error('季度数量必须为1到32');
  const dates=quarterDates(quarters,now),tasks=types.flatMap(kind=>dates.map(date=>({kind,date,key:`financeFull:v2:${kind}:${date}`})));
  let consecutiveFailures=0,circuitOpen=false;const parallel=Math.max(1,Math.min(3,Math.floor(Number(concurrency)||1)));const started=Date.now(),stat={tasks:tasks.length,completed:0,skipped:0,pages:0,saved:0,failed:[],stopped:false,complete:false,startedAt:iso(),finishedAt:null};
  const emit=(phase,extra={})=>progress({phase,...stat,elapsedMs:Date.now()-started,...extra});emit('start');
  async function processTask(task){
   if(stop()){stat.stopped=true;return;}
   const old=await db.get('meta',task.key);
   if(old?.done&&!refresh){stat.completed++;stat.skipped++;emit('skip',{...task,sourceTotal:old.sourceTotal,localStored:old.saved});return;}
   let page=refresh?1:Math.max(1,Number(old?.nextPage)||1),saved=refresh?0:Number(old?.saved)||0,sourceTotal=refresh?null:(old?.sourceTotal??null),sourcePages=null;
   let taskOK=false,failed=false;
   for(;page<=maxPages;page++){
    if(stop()){stat.stopped=true;break;}
    try{
     const r=await provider.financialPage(task.date,task.kind,page,pageSize);
     if(!r||!Array.isArray(r.rows)||!Number.isInteger(Number(r.pages))||Number(r.pages)<1)throw Error('源端财报分页/总页数缺失，禁止标记完成');
     if(!Number.isInteger(Number(r.rawCount))||Number(r.rawCount)!==r.rows.length)throw Error('源端记录有缺失或格式不匹配，当前页未确认');
     if(r.rows.some(x=>x.type!==task.kind||x.reportDate!==task.date||!x.code||!x.key))throw Error('报表类型或季度数据不匹配，拒绝提交');
     if(r.rows.length===0)throw Error('源端返回空财报页，无法证明已覆盖');
     if(sourcePages!==null&&Number(r.pages)!==sourcePages)throw Error('抓取期间源端总页数变化，未通过一致性检查');
     if(sourceTotal!==null&&r.total!=null&&Number(r.total)!==sourceTotal)throw Error('抓取期间源端记录总量变化，请重做该季度');
     sourcePages=Number(r.pages);sourceTotal=Number.isFinite(Number(r.total))?Number(r.total):null;
     if(page>sourcePages)throw Error('分页检查点已超过源端总页数，请重新同步');
     if(page<sourcePages&&r.rawCount!==pageSize)throw Error('未到末页却返回不足整页，拒绝标记完成');
     const nextSaved=saved+r.rows.length,done=page>=sourcePages;
     if(done&&sourceTotal!==null&&nextSaved!==sourceTotal)throw Error(`末页数量不一致：当前可入库${nextSaved}条，源端${sourceTotal}条`);
     const metadata={key:task.key,kind:task.kind,date:task.date,done,nextPage:page+1,lastPage:page,
       saved:nextSaved,sourceTotal,sourcePages,updatedAt:iso(),lastError:null,source:'东方财富公开数据中心（仅查询到的已披露记录）'};
     if(typeof db.commitPage==='function')await db.commitPage('finance',r.rows,metadata);
     else {await db.putMany('finance',r.rows);await db.put('meta',metadata);}
     saved=nextSaved;stat.saved+=r.rows.length;stat.pages++;emit('page',{...task,page,sourcePages,sourceTotal,localStored:saved});
     if(done){taskOK=true;break;}
     await wait(170);
    }catch(e){
     const message=String(e?.message||e);stat.failed.push(`${TYPES_ZH[task.kind]} ${task.date} 第${page}页：${message}`);
     await db.put('meta',{key:task.key,kind:task.kind,date:task.date,done:false,nextPage:page,saved,sourceTotal,sourcePages,updatedAt:iso(),lastError:message});
     emit('failed',{...task,page,error:message});failed=true;break;
    }
   }
   if(taskOK){consecutiveFailures=0;stat.completed++;emit('quarter',{...task,sourcePages,sourceTotal,localStored:saved});}
   if(!taskOK&&!stat.stopped&&!failed){stat.failed.push(`${TYPES_ZH[task.kind]} ${task.date} 超出${maxPages}页上限`);emit('failed',{...task,error:'分页保护上限'});}
   // Failures should not freeze other quarters, but avoid hammering a broken provider.
   if(failed||!taskOK){consecutiveFailures++;emit('continue',{...task,consecutiveFailures});
    if(consecutiveFailures>=3){circuitOpen=true;emit('halt',{error:'连续3个季度任务失败，停止本轮以防限流；其他功能可继续使用'});}
    return;
   }
  }
  // Separate quarters/types can download simultaneously; each task still commits its own pages sequentially.
  let taskCursor=0;
  async function worker(){while(taskCursor<tasks.length&&!stop()&&!circuitOpen){await processTask(tasks[taskCursor++]);}}
  await Promise.all(Array.from({length:Math.min(parallel,tasks.length)},()=>worker()));
  stat.complete=stat.completed===stat.tasks&&!stat.failed.length&&!stat.stopped;
  stat.finishedAt=iso();emit('end');return stat;
 }
 return {run};
}
return {create,quarterDates,TYPES,TYPES_ZH};
});
