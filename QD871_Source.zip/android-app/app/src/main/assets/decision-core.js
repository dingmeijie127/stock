/* Single source of truth for current technical signal and the historical simulation.
 * Publicly researched factor families != independent verification of this implementation.
 */
(function(root,factory){const x=factory(root.QuantEvidence||(typeof require==='function'?require('./evidence-core.js'):null));if(typeof module==='object'&&module.exports)module.exports=x;root.QuantDecision=x;})(typeof globalThis!=='undefined'?globalThis:this,function(E){
'use strict';if(!E)throw Error('evidence-core.js required');return{evaluate:E.evaluate,backtest:E.backtest,technical:E.technical,analysisVersion:'QDE-6.8-transparent',isSession:E.inSession};});
