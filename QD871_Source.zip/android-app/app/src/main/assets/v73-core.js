/* V7.3 screenshot transcription and analytics helpers. No screenshots are live quotes. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.QuantV73=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
// User screenshot lists. heldWatch means broker "持仓股" WATCHLIST category only,
// not a verified filled trade or position in this application's private ledger.
const raw=[
 ['A','002156','通富微电',1],['A','002466','天齐锂业',1],['A','002475','立讯精密',1],['A','159915','创业板ETF',1],['A','600036','招商银行',1],['A','600900','长江电力',1],['A','603501','豪威集团',1],['A','603893','瑞芯微',1],
 ['A','002409','雅克科技'],['A','002173','创新医疗'],['A','000021','深科技'],['A','000725','京东方A'],
 ['A','688836','宇树科技-W'],['A','002185','华天科技'],['A','603248','锡华科技'],['A','688825','长鑫科技'],['A','600176','中国巨石'],['A','600206','有研新材'],['A','002971','和远气体'],['A','603986','兆易创新'],
 ['A','300124','汇川技术'],['A','688676','金盘科技'],['A','002028','思源电气'],['A','002270','华明装备'],['A','301308','江波龙'],['A','002343','慈文传媒'],['HK','01810','小米集团-W'],['HK','81810','小米集团-R'],['A','688322','奥比中光-W'],
 ['A','603728','鸣志电器'],['A','688617','惠泰医疗'],['HK','01801','信达生物'],['A','301489','思泉新材'],['A','001339','智微智能'],['A','300503','昊志机电'],['A','002001','新和成'],['A','600298','安琪酵母']
];
const DEFAULT=Object.freeze(raw.map(([market,code,name,heldWatch])=>Object.freeze({market,code,name,heldWatch:!!heldWatch,key:market+':'+code,needsListingVerification:/^(688836|688825)$/.test(code),specialCurrencyCounter:code==='81810'})));
function merge(existing,items=DEFAULT){const by=new Map();for(const x of [...(existing||[]),...items]){if(!x||!['A','HK'].includes(x.market)||!/^(\d{5}|\d{6})$/.test(String(x.code)))continue;const key=x.market+':'+x.code;by.set(key,{...x,...(by.get(key)||{})});}return [...by.values()];}
function profile(book){if(!book)return {available:false,why:'账户未创建'};const nav=(book.nav||[]).filter(x=>Number.isFinite(x.equity)&&x.equity>0).slice().sort((a,b)=>a.date.localeCompare(b.date));const seed=Number(book.seed)||0;let peak=seed,maxdd=0;for(const x of nav){peak=Math.max(peak,x.equity);maxdd=Math.min(maxdd,x.equity/peak-1)}const closed=(book.fills||[]).filter(x=>x.side==='SELL'&&Number.isFinite(x.realized));const winners=closed.filter(x=>x.realized>0).length;return {available:true,seed,navDays:nav.length,currentEquity:nav.length?nav.at(-1).equity:null,returnPct:nav.length?100*(nav.at(-1).equity/seed-1):null,maxDrawdownPct:nav.length?100*maxdd:null,closedTrades:closed.length,winners,winRate:closed.length>=30?100*winners/closed.length:null,winRateDisplay:closed.length>=30?null:'不足30笔已平仓模拟交易，不公布胜率',lastDate:nav.at(-1)?.date||null};}
function dailySummary(signals,day,events){const seen=new Map((events||[]).map(e=>[e.signal,e]));return(signals||[]).filter(s=>s.strategy==='rules'&&s.date===day&&['BUY','SELL'].includes(s.side)).map(s=>({key:s.key,code:s.code,market:s.market,side:s.side,qty:s.qty,limit:s.limit,reason:s.reason,date:s.date,generatedAt:s.generatedAt,execution:seen.get(s.key)?.status||'pending'}));}
return {DEFAULT,merge,profile,dailySummary};
});
