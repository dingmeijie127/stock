/* V8.5 optional HTTPS collector bridge. Never fabricate an API response or silently mix adjustment modes.
 * Source JS is recoverable from user-provided APK; backend provider is optional, not secretly hardcoded.
 */
(function(root,factory){const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;root.QuantV85=api;})(typeof globalThis!=='undefined'?globalThis:this,function(root){
'use strict';
const STORAGE='quantdesk:v85:backend';
const validUrl=u=>{try{const p=new URL(u);return (p.protocol==='https:'||(p.protocol==='http:'&&['localhost','127.0.0.1'].includes(p.hostname)))&&!p.username&&!p.password&&!p.search&&!p.hash&&p.pathname.replace(/\/$/,'')==='';}catch(_){return false}};
const configured=()=>{try{return root.localStorage?.getItem(STORAGE)||''}catch(_){return ''}};
const configure=u=>{const v=String(u||'').trim().replace(/\/$/,'');if(v&&!validUrl(v))throw Error('采集服务必须为 HTTPS 地址（本机调试允许 localhost HTTP），不可包含用户名、口令或路径');
 if(!root.localStorage)throw Error('无法保存地址');if(v)root.localStorage.setItem(STORAGE,v);else root.localStorage.removeItem(STORAGE);return v;};
async function request(path,{timeout=18000}={}){
 const base=configured();if(!base||!validUrl(base))throw Error('尚未配置经 HTTPS 访问的 V8.5 采集服务');
 if(!/^\/v1\/[A-Za-z0-9/_?=&.%\-]+$/.test(path)||path.includes('..'))throw Error('禁止访问未授权路径');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
 try{const res=await fetch(base+path,{cache:'no-store',signal:controller.signal,credentials:'omit'}),body=await res.json();
  if(!res.ok)throw Error('采集服务 HTTP '+res.status+' '+String(body?.detail||'').slice(0,180));
  if(!body||typeof body!=='object')throw Error('数据结构无效');return body;
 }catch(e){if(e.name==='AbortError')throw Error('采集服务超过'+timeout+'毫秒未响应');throw e;}finally{clearTimeout(timer)}
}
const codeOk=(code,market)=>(market==='HK'?/^\d{5}$/:/^\d{6}$/).test(String(code));
function barsNormalized(payload,code,market,min=1){
 if(!payload||!Array.isArray(payload.rows)||!payload.rows.length)throw Error('采集服务未返回K线');
 if(!['none','qfq','hfq'].includes(payload.adjustment))throw Error('K线复权方式缺失或非法');
 let rows=payload.rows.map(x=>({...x,source:'V8.5 '+(x.source||payload.source)+' ['+payload.adjustment+']'}));
 if(rows.some(x=>x.adjustment!==payload.adjustment))throw Error('发现混用复权方式');
 const validator=root.QuantKlineQuality;if(validator)validator.validate(rows,{market,code,min});
 return rows;
}
async function backendBars(code,market='A',limit=650,min=80){
 if(!codeOk(code,market))throw Error('股票代码格式错误');
 const payload=await request(`/v1/bars/${market}/${code}?limit=${Math.max(1,Math.min(200000,Number(limit)||650))}`,{timeout:30000});
 return barsNormalized(payload,code,market,Math.min(min,Math.max(1,Number(limit)||650)));
}
async function backendFinance(code,market='A',kind=null){
 if(!codeOk(code,market))throw Error('股票代码格式错误');
 const payload=await request(`/v1/finance/${market}/${code}`+(kind?'?kind='+encodeURIComponent(kind):''),{timeout:40000});
 if(!Array.isArray(payload.rows)||!payload.rows.length)throw Error('该股票目前没有已获得的财务数据');
 return payload.rows.map(r=>({...r,source:'V8.5 '+r.source}));
}
async function backendUniverse(market){
 if(!['A','HK'].includes(market))throw Error('市场不支持');
 const p=await request(`/v1/universe/${market}`,{timeout:90000});
 if(!Array.isArray(p.rows)||p.rows.length<1)throw Error('该市场没有有效目录');
 return p.rows;
}
function installProvider(p=root.QuantProvider){
 if(!p||p._v85Installed)return p;
 const legacyBars=p.bars.bind(p),legacyFinance=p.financialPage.bind(p);
 p.bars=async function(code,market='A',limit=650){
  if(!configured())return legacyBars(code,market,limit);
  let originalError;
  try{return await backendBars(code,market,limit)}catch(e){originalError=e}
  try{return await legacyBars(code,market,limit)}
  catch(e){throw Error('V8.5采集服务和旧直连历史K线均失败：'+originalError.message+'；'+e.message)}
 };
 // One-symbol quarterly financial lookups are routed through multi-source finance,
 // while all-stock-quarter paging remains under legacy EastMoney for compatibility.
 p.financialPage=async function(period,kind='summary',page=1,pageSize=100,code=null){
  if(!configured()||!code)return legacyFinance(period,kind,page,pageSize,code);
  try{
   const rows=await backendFinance(code,'A',kind);
   const filtered=rows.filter(x=>!period||x.reportDate===period).slice((page-1)*pageSize,page*pageSize);
   return {rows:filtered,pages:Math.max(1,Math.ceil(rows.length/pageSize)),total:rows.length,page,rawCount:filtered.length,source:'V8.5 multi-source'};
  }catch(e){return legacyFinance(period,kind,page,pageSize,code)}
 };
 p.financialSymbol=(code,market='A',kind=null)=>backendFinance(code,market,kind);
 p._v85Installed=true;return p;
}
installProvider();
return{STORAGE,configure,configured,validUrl,request,barsNormalized,backendBars,backendFinance,backendUniverse,installProvider};
});
