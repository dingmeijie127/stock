/* V7.2: pure data validation. Never manufacture a brokerage position. */
(function(root,factory){const out=factory();if(typeof module==='object'&&module.exports)module.exports=out;root.QuantV72Core=out;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function normalizeLedger(input){
 const x=input?.realLedger||input?.ledger||input?.data?.ledger||input;
 if(!x||!Array.isArray(x.holdings)||!Array.isArray(x.trades))throw Error('不是支持的真实持仓备份（缺少 holdings / trades）');
 const holdings=x.holdings.map((h,i)=>{const market=h.market==='HK'?'HK':'A',code=String(h.code||'').trim();
  const shares=Number(h.shares),cost=Number(h.cost);if(!new RegExp(market==='HK'?'^\\d{5}$':'^\\d{6}$').test(code)||!Number.isSafeInteger(shares)||shares<0||!Number.isFinite(cost)||cost<0)throw Error('第'+(i+1)+'条持仓证券或数量/成本不合法');
  return {...h,market,code,shares,cost,name:String(h.name||code)};});
 const cashApprox=Number(x.cashApprox??x.cashByCurrency?.CNY??0),realized=Number(x.realized??x.realizedByCurrency?.CNY??0);
 if(!Number.isFinite(cashApprox)||!Number.isFinite(realized))throw Error('现金或盈亏不合法');
 return {key:'main',holdings,trades:x.trades,cashApprox,realized,cashByCurrency:x.cashByCurrency||{CNY:cashApprox,HKD:0},realizedByCurrency:x.realizedByCurrency||{CNY:realized,HKD:0}};
}
function validateOrder(x,available,existing){
 const market=x.market==='HK'?'HK':'A',code=String(x.code||'').trim(),qty=Number(x.qty),limit=Number(x.limit),lot=market==='A'?100:Number(x.lotSize);
 if(!new RegExp(market==='HK'?'^\\d{5}$':'^\\d{6}$').test(code))throw Error('股票代码格式有误');
 if(!['BUY','SELL'].includes(x.side))throw Error('买卖方向有误');
 if(!Number.isSafeInteger(lot)||lot<1||!Number.isSafeInteger(qty)||qty<1||qty%lot!==0)throw Error('委托股数不符合交易单位');
 if(!Number.isFinite(limit)||limit<=0)throw Error('限价必须大于0');
 if(x.side==='SELL'&&qty>available)throw Error('模拟可用持仓不足，不能提交卖单');
 if(existing)throw Error('同一天同一股票相同方向已提交委托；请查看历史订单');
 return {market,code,qty,limit,lotSize:lot};
}
return {normalizeLedger,validateOrder};
});
