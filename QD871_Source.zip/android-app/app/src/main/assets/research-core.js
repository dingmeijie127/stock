/* QuantDesk 7.0: point-in-time fundamental gate and non-repainting technical plan.
   Deterministic rules, unverified research model, NOT a trained return predictor. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.QuantResearch=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const VERSION='QD7.0-screen-v1';
const num=x=>x===null||x===undefined||x===''?null:Number.isFinite(+x)?+x:null;
const pct=(x)=>x===null?null:Math.round(x*100)/100;
const validDate=x=>typeof x==='string'&&Number.isFinite(Date.parse(x));
function financialAt(rows,asOf){
 const cap=new Date(asOf).getTime();
 const ok=(rows||[]).filter(x=>x?.reportDate&&validDate(x.noticeDate)&&Date.parse(x.noticeDate)<=cap && Date.parse(x.reportDate+'T00:00:00Z')<=cap).sort((a,b)=>b.reportDate.localeCompare(a.reportDate));
 const anchor=ok.find(x=>x.type==='summary'||x.type==='income');if(!anchor)return {ready:false,reason:'缺少在筛选时点已披露的利润/摘要报表',reports:0};
 const relevant=ok.filter(x=>x.reportDate===anchor.reportDate),byType=Object.fromEntries(relevant.map(x=>[x.type,x]));
 const summary=byType.summary||byType.income,profit=num(summary?.profit),revenue=num(summary?.revenue);
 const ocf=num(byType.cashflow?.ocf??byType.summary?.ocf),roe=num(byType.summary?.roe),profitYoY=num(summary?.profitYoY),revenueYoY=num(summary?.revenueYoY);
 const debt=num(byType.balance?.debtRatio??summary?.debtRatio);
 const cash=profit!==null&&profit>0&&ocf!==null?ocf/profit:null;
 const complete=['summary','income','balance','cashflow'].every(t=>!!byType[t]);
 return {ready:complete,complete,reportDate:anchor.reportDate,noticeDate:anchor.noticeDate,profit,revenue,ocf,roe,profitYoY,revenueYoY,debt,cashCoverage:cash,reports:relevant.length,missing:['summary','income','balance','cashflow'].filter(t=>!byType[t]),reason:complete?'':'同季度四类财报不完整'};
}
function screen(stock,reports,asOf=new Date()){
 const market=stock?.market==='HK'?'HK':'A',code=String(stock?.code||'');
 const f=financialAt(reports,asOf);const reasons=[];
 if(!/^(\d{6}|\d{5})$/.test(code))return {market,code,status:'invalid',reasons:['无效股票代码'],fundamentals:f};
 // No delisted / suspended stock can silently pass the active universe gate.
 if(stock?.delisted||stock?.active===false||/\*?ST|退市/.test(stock?.name||''))return {market,code,status:'excluded',reasons:['退市或特别风险警示'],fundamentals:f};
 if(!f.ready)return {market,code,status:'missing_finance',reasons:[f.reason,...(f.missing||[])],fundamentals:f};
 const financialSector=/(银行|保险|证券|券商|金融)/.test(stock?.sector||'');
 // Financial firms use specialized regulations/ratios: do not misuse debt ratio.
 if(financialSector)return {market,code,status:'special_sector',reasons:['金融行业需要专用资本充足率/偿付指标，普通公司规则不适用'],fundamentals:f};
 if(f.profit===null||f.profit<=0)reasons.push('最近披露盈利不为正');
 if(f.ocf===null||f.ocf<=0)reasons.push('经营现金流不为正');
 if(f.roe===null||f.roe<8)reasons.push('ROE未达到示例门槛8%或缺失');
 if(f.debt===null||f.debt>75)reasons.push('资产负债率高于75%或缺失');
 if(f.profitYoY===null||f.profitYoY < -10)reasons.push('利润同比变化低于-10%或缺失');
 if(reasons.length)return {market,code,status:'rejected',reasons,fundamentals:f};
 const quoteTime=Date.parse(stock?.quoteTime||''),checkTime=new Date(asOf).getTime();
 const quoteOK=num(stock?.price)>0&&Number.isFinite(quoteTime)&&quoteTime<=checkTime+60000&&checkTime-quoteTime<96*3600000;
 if(!quoteOK)return {market,code,status:'missing_quote',reasons:['财务通过，但近期有效报价缺失或时间异常'],fundamentals:f};
 const amount=num(stock.amount);if(amount===null||amount<(market==='HK'?1000000:20000000))return {market,code,status:'low_liquidity',reasons:['成交额不足或币种单位不可核验'],fundamentals:f};
 return {market,code,status:'qualified',reasons:['最近披露财报满足质量与现金流条件','行情时间及流动性通过'],fundamentals:f};
}
function plan(stock,bars,account={equity:100000,cash:100000,riskFraction:0.005,maxStockFraction:0.1},marketLot=null){
 const list=(bars||[]).filter(b=>b?.date&&+b.close>0&&+b.high>=+b.low).slice().sort((a,b)=>a.date.localeCompare(b.date));
 if(list.length<253)return {eligible:false,reason:'日K少于253根，无法确认动量和长期趋势'};
 const last=list.at(-1),cl=+last.close,avg=n=>list.slice(-n).reduce((s,x)=>s+ +x.close,0)/n;
 const ma60=avg(60),ma200=avg(200),m12=list.at(-22).close/list.at(-253).close-1,m6=list.at(-22).close/list.at(-127).close-1;
 const trend=cl>ma60&&cl>ma200&&m12>0&&m6>0;
 let tr=0;for(let i=list.length-20;i<list.length;i++){const b=list[i],prev=list[i-1].close;tr+=Math.max(b.high-b.low,Math.abs(b.high-prev),Math.abs(b.low-prev));}
 const atr=tr/20,priorHigh=Math.max(...list.slice(-21,-1).map(x=>+x.high));
 // Close-of-day plan: conditional next-session range only. Not an order or guaranteed fill.
 const zoneLow=Math.max(ma60,priorHigh*.97),zoneHigh=priorHigh*1.015;
 const distance=Math.max(2.5*atr,.08*cl),riskBudget=+account.equity*+account.riskFraction;
 const unit=stock.market==='HK'?Number(marketLot||stock.lotSize||0):100;
 if(!Number.isSafeInteger(unit)||unit<1)return {eligible:false,reason:'港股每手交易单位未知，禁止生成股数'};
 const maxByRisk=Math.floor(riskBudget/distance),maxByCash=Math.floor(Math.min(+account.cash,+account.equity*+account.maxStockFraction)/Math.max(cl,zoneLow));
 const qty=Math.floor(Math.min(maxByRisk,maxByCash)/unit)*unit;
 return {eligible:trend&&qty>0,trend,reason:!trend?'动量和长期趋势没有同时通过':qty<=0?'风险预算或现金不足一手':'需下一交易时段确认突破/回踩，不能把预测价当成交价',barDate:last.date,planLow:pct(zoneLow),planHigh:pct(Math.max(zoneLow,zoneHigh)),invalidation:pct(cl-distance),riskDistance:pct(distance),atr20:pct(atr),ma60:pct(ma60),ma200:pct(ma200),momentum12:pct(m12*100),momentum6:pct(m6*100),qty,lot:unit,model:VERSION};
}
return {VERSION,financialAt,screen,plan};
});
