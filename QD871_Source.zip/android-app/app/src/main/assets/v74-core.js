/* QD7.4: user supplied brokerage screenshot; figures are an unverified snapshot,
   NOT trade fills or live quote observations. Never silently replace existing ledger. */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantV74=v})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const SNAPSHOT=[
 ['002156','通富微电',100,52.461],['002466','天齐锂业',100,47.401],
 ['002475','立讯精密',100,63.542],['159915','创业板ETF易方达',700,3.897],
 ['600036','招商银行',100,37.747],['600900','长江电力',100,26.770],
 ['603501','豪威集团',100,100.041]
].map(([code,name,shares,cost])=>Object.freeze({market:'A',code,name,shares,cost,currency:'CNY',source:'user-broker-screenshot',snapshotOnly:true}));
// Historic snapshot cash/assets were recorded BEFORE a confirmed 100-share sale of 瑞芯微 at ¥198.
// Do not import stale broker balances or invent the post-sale cash balance.
const CASH=null,ASSETS=null,MARKET_VALUE=null;
function validate(positions){if(!Array.isArray(positions)||positions.length!==7)throw Error('截图持仓数量与预期不符');const keys=new Set();for(const h of positions){if(!/^\d{6}$/.test(h.code)||!Number.isSafeInteger(h.shares)||h.shares<1||!Number.isFinite(h.cost)||h.cost<=0)throw Error('持仓字段异常');if(keys.has(h.code))throw Error('持仓重复');keys.add(h.code)}return true;}
function plan(snapshot,old){validate(snapshot);const existing=(old?.holdings||[]).filter(h=>Number(h.shares)>0);const changed=existing.filter(x=>!snapshot.some(h=>h.code===x.code&&h.shares===x.shares&&Math.abs(h.cost-x.cost)<.00001));return{hasExisting:existing.length>0,existingCount:existing.length,changedCount:changed.length,willReplace:existing.length>0,snapshot: snapshot.map(h=>({...h}))};}
function create(snapshot,old){const p=plan(snapshot,old);const remainingCash=Number(old?.cashByCurrency?.CNY??old?.cashApprox??0);const ledger={key:'main',holdings:p.snapshot.map(h=>({...h})),trades:[],cashApprox:remainingCash,realized:Number(old?.realized??0),cashByCurrency:{CNY:remainingCash,HKD:Number(old?.cashByCurrency?.HKD??0)},realizedByCurrency:old?.realizedByCurrency||{CNY:Number(old?.realized??0),HKD:0},snapshotMeta:{source:'broker screenshots provided by user',asOf:'unknown (screenshot contains time but not date)',importedAt:new Date().toISOString(),historicalTradesUnavailable:true,brokerReportedAssets:ASSETS,brokerReportedMarketValue:MARKET_VALUE,holdingsAsOf:'2026-10-23 user confirmed 瑞芯微 100 shares sold at ¥198; remaining 7 positions still from earlier screenshot',cashNotVerified:true}};return ledger;}
function parseKlinePayload(payload,symbol,market,code){const node=payload?.data?.[symbol];const raw=node?.qfqday||node?.day||node?.hfqday||[];if(!Array.isArray(raw)||!raw.length)throw Error('腾讯没有提供该代码的前复权日K');let out=raw.map(a=>({key:`${market}:${code}:${a[0]}`,market,code,date:String(a[0]),open:Number(a[1]),close:Number(a[2]),high:Number(a[3]),low:Number(a[4]),volume:Number(a[5]),source:'腾讯公开日K · 复权规则以返回值为准'})).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.date)&&[x.open,x.high,x.low,x.close].every(v=>Number.isFinite(v)&&v>0)&&x.high>=x.low&&x.close<=x.high*1.01&&x.close>=x.low*.99);
 out.sort((a,b)=>a.date.localeCompare(b.date));return out;}
return{SNAPSHOT,CASH,ASSETS,MARKET_VALUE,validate,plan,create,parseKlinePayload};
});
