/* V6.4: a failed quote page cannot block the rest of the universe or holdings.
 * Retry Eastmoney main/delay in provider; halve oversized pages; keep per-day
 * verified-page checkpoints. A partial download is NEVER described as complete.
 */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantFastSync=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const tradingDate=now=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
function create({provider,db,market='A',size=200,concurrency=2,progress=()=>{},stop=()=>false,maxPages=160,wait=pause,now=()=>new Date()}={}){
 if(!provider?.stockPages||!db?.get||!db?.putMany)throw Error('市场同步缺少数据源或数据库');
 const key='fastMarket:'+market;
 async function run({retryOnly=false}={}){
  const start=Date.now(),today=tradingDate(now()),old=await db.get('meta',key)||{};
  const sameDay=old.sessionDay===today&&Number(old.size)===size;
  if(retryOnly&&!sameDay)return{market,complete:false,partial:true,stored:0,done:0,failed:[],errors:['今天尚无可续抓的页；先更新一次行情'],pages:0,total:0,ms:0};
  const good=new Set(sameDay?old.completedPages||[]:[]),failed=new Set(sameDay?old.failedPages||[]:[]);
  let total=sameDay?Number(old.total)||0:0,done=0,stored=0,partialSaved=0,errors=[],pages=0,sourceCounts={},failedThisRun=0,consecutiveFailures=0,sourceOutage=false;
  const emit=(phase,extra={})=>progress({phase,market,total,pages,done,stored,partialSaved,committedPages:good.size,failed:failed.size,ms:Date.now()-start,...extra});
  const checkpoint=finished=>({key,total,size,sessionDay:today,completedPages:[...good].sort((a,b)=>a-b),failedPages:[...failed].sort((a,b)=>a-b),pendingPages:total?Array.from({length:Math.ceil(total/size)},(_,i)=>i+1).filter(p=>!good.has(p)&&!failed.has(p)):[],updatedAt:new Date().toISOString(),finished,sourceCounts:{...sourceCounts}});
  let commitChain=Promise.resolve();
  const serialize=fn=>{const next=commitChain.then(fn);commitChain=next.catch(()=>{});return next};
  async function savePage(page,rows,source){
   await serialize(async()=>{
    const wasGood=good.has(page),wasFailed=failed.has(page);
    good.add(page);failed.delete(page);
    try{const state=checkpoint(false);
     if(typeof db.commitPage==='function')await db.commitPage('stocks',rows,state);
     else{await db.putMany('stocks',rows);await db.put('meta',state);}
     done++;consecutiveFailures=0;stored+=rows.length;sourceCounts[source]=(sourceCounts[source]||0)+1;
    }catch(e){if(!wasGood)good.delete(page);if(wasFailed)failed.add(page);throw e;}
   });
   emit('saved',{page,source});
  }
  async function markFailed(page,err){failedThisRun++;consecutiveFailures++;if(consecutiveFailures>=4)sourceOutage=true;await serialize(async()=>{failed.add(page);good.delete(page);await db.put('meta',checkpoint(false));});errors.push(`第${page}页：${err}`);emit('failed',{page,error:err});}
  async function fetchBlock(subPage,subSize,expected){
   const d=await provider.stockPages(market,subPage,subSize);
   if(!d||!Array.isArray(d.rows)||!Number.isInteger(Number(d.rawCount))||!Number.isInteger(Number(d.total))||Number(d.total)<=0)throw Error('响应的分页字段缺失');
   if(d.rows.length!==Number(d.rawCount)||Number(d.rawCount)!==expected)throw Error(`页大小不符，期望${expected}条实际${d.rows.length}条`);
   if(!d.rows.every(x=>x.market===market&&/^\d{5,6}$/.test(x.code||'')&&x.key===market+':'+x.code))throw Error('股票代码或市场字段无法核对');
   if(total&&Number(d.total)!==total)throw Error(`源端股票总量改变 ${total} → ${d.total}`);
   return d;
  }
  async function fetchPage(page){
   if(stop())return false;
   if(sourceOutage)return false; // Remaining pages are unattempted; NEVER report them as failed/successful.

   let err,lastValid=null;
   // Whole pages first. If providers time out/rate-limit, request 2x100 then 4x50.
   for(const slice of [size,Math.max(1,Math.floor(size/2)),Math.max(1,Math.floor(size/4))]){
    if(size%slice)continue;
    let rows=[],sources=new Set();const blocks=size/slice;
    try{
     for(let b=0;b<blocks;b++){
      if(stop())throw Error('用户停止');
      const subPage=(page-1)*blocks+b+1;
      const expected=Math.min(slice,Math.max(0,total?total-(subPage-1)*slice:page===1?slice:Number.MAX_SAFE_INTEGER));
      if(expected===0)continue;
      let data;
      try{data=await fetchBlock(subPage,slice,expected)}catch(e){if(page===1&&b===0&&total===0){
       // First response establishes market count, so check the first page separately.
       data=await provider.stockPages(market,subPage,slice);
       if(!data?.total||data.rows?.length!==data.rawCount||!data.rows?.length)throw e;
      }else throw e;}
      if(!total)total=Number(data.total);
      if(!Number.isInteger(total)||total<=0)throw Error('市场股票总数无效');
      const actualExpected=Math.min(slice,Math.max(0,total-(subPage-1)*slice));
      if(data.rows.length!==actualExpected)throw Error(`第${subPage}子页期望${actualExpected}只，得到${data.rows.length}只`);
      rows.push(...data.rows);sources.add(data.source||'未知');
     }
     if(rows.length!==Math.min(size,Math.max(0,total-(page-1)*size)))throw Error('组合子页后仍缺少股票');
     if(new Set(rows.map(x=>x.key)).size!==rows.length)throw Error('不同子页出现重复股票，拒绝假定市场完整');
     await savePage(page,rows,[...sources].join('+')+(slice<size?'（分段'+slice+'）':''));return true;
    }catch(e){err=e;
     if(/主源和备用源均失败|熔断|主\/备行情连续故障/.test(String(e.message))){sourceOutage=true;break;}
     if(rows.length>(lastValid?.length||0))lastValid=rows;
     if(stop())break;
     await wait(200);
    }
   }
   if(lastValid?.length){
    // Salvage verified subsets for per-stock analysis; do not mark page successful.
    try{await db.putMany('stocks',lastValid);partialSaved+=lastValid.length;emit('partial',{page,count:lastValid.length});}
    catch(e){err=new Error(String(err?.message||err)+'；部分数据存储失败 '+e.message);}
   }
   await markFailed(page,String(err?.message||err||'未知网络错误'));return false;
  }
  emit('start');
  // Always validate today's first page unless only retrying reported failures.
  if(!retryOnly){
   const first=await fetchPage(1);
   if(!first&&!total){emit('end',{error:'无法取得当日总页数，仅能使用已入库历史股票池'});
    return{market,complete:false,partial:true,stored,partialSaved,done,failed:[...failed],errors,pages:0,total,ms:Date.now()-start,coverage:0};}
  }
  pages=Math.ceil(total/size);
  if(pages>maxPages){const msg=`源端${pages}页超过保护上限${maxPages}`;errors.push(msg);emit('end',{error:msg});return{market,complete:false,partial:true,stored,partialSaved,done,failed:[...failed],errors,pages,total,ms:Date.now()-start};}
  const todo=(retryOnly?[...failed]:Array.from({length:pages},(_,i)=>i+1)).filter(p=>p>=1&&p<=pages&&!good.has(p));
  let cursor=0;
  async function worker(){while(cursor<todo.length&&!stop()&&!sourceOutage){const page=todo[cursor++];await fetchPage(page);await wait(75);}}
  await Promise.all(Array.from({length:Math.min(Math.max(1,concurrency),todo.length)},()=>worker()));
  const complete=!stop()&&failed.size===0&&good.size===pages&&total>0;const pendingPages=Array.from({length:pages},(_,i)=>i+1).filter(p=>!good.has(p)&&!failed.has(p));
  await serialize(()=>db.put('meta',checkpoint(complete)));
  const result={market,complete,partial:!complete,stored,partialSaved,done,failed:[...failed].sort((a,b)=>a-b),errors,pages,total,coverage:pages?good.size/pages:0,committedPages:good.size,sourceCounts,pendingPages,sourceOutage,ms:Date.now()-start,stopped:!!stop()};
  emit('end',result);return result;
 }
 return {run};
}
return {create,tradingDate};
});
