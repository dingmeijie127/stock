/* V7.7 native background responses -> existing IndexedDB; ack only AFTER commit.
 * Deliberately rejects malformed/mismatched pages, never uses unverified data to buy.
 */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantBackgroundImport=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
function parsePage(task,provider,now=new Date()){
 if(!task||!['catalog','bars','finance'].includes(task.kind))throw Error('未知下载任务');
 const data=JSON.parse(task.payload),market=task.market,src='原生后台·东方财富公开接口',fetchedAt=now.toISOString();
 if(task.kind==='catalog'){
  const diff=data?.data?.diff;if(!diff)throw Error('目录分页没有有效数据');
  const originals=Array.isArray(diff)?diff:Object.values(diff),rows=originals.map(x=>provider.normalizeQuote(x,market));
  const size=market==='HK'?5:6;
  if(!rows.length||rows.some(x=>x.market!==market||!new RegExp('^\\d{'+size+'}$').test(x.code||'')||!x.name||x.name===x.code)||new Set(rows.map(x=>x.key)).size!==rows.length)throw Error('股票目录代码/名称/去重校验失败');
  // A suspended security can legitimately have no positive quote today. Do NOT
  // invalidate the entire catalog page or remove it from the directory.
  const quotes=rows.filter(x=>Number(x.price)>0).map(x=>({...x,source:src,fetchedAt}));
  const directory=rows.map(x=>({key:market+':'+x.code,market,code:x.code,name:x.name,source:src,catalogFetchedAt:fetchedAt}));
  return{stores:[['universe',directory],['stocks',quotes]],count:rows.length};
 }
 if(task.kind==='bars'){
  const Q=typeof QuantKlineQuality!=='undefined'?QuantKlineQuality:(typeof require==='function'?require('./kline-quality.js'):null);
  if(!Q)throw Error('原生K线缺少统一校验模块');
  const code=task.code,rows=Array.isArray(data?.data?.klines)?Q.eastmoney(data.data.klines,market,code,src):Q.tencent(data,market,code,'原生后台·腾讯独立历史日K');
  Q.validate(rows,{market,code,min:1,asOf:now});
  return{stores:[['bars',rows]],count:rows.length,seriesKey:market+':'+code+':',source:rows[0].source,last:rows.at(-1).date};
 }
 const original=data?.result?.data;if(!Array.isArray(original))throw Error('财报格式无效');
 const kind=task.subtype,rows=original.map(r=>provider.cleanReport(r,kind));
 if(rows.some(x=>x.reportDate!==task.period||x.type!==kind||!x.code))throw Error('财报季度/类型不一致');
 // Empty quarterly page can legitimately mean no disclosed records; do not infer completeness.
 return{stores:[['finance',rows]],count:rows.length};
}
async function importBatch(bridge,db,provider,{max=6,onProgress=()=>{}}={}){
 if(!bridge||typeof bridge.pull!=='function')throw Error('当前APK未接入原生后台模块');
 const tasks=JSON.parse(bridge.pull(max));let saved=0,acks=[],errors=[];
 for(const task of tasks){try{
   const result=parsePage(task,provider);
   if(task.kind==='bars'&&result.seriesKey&&typeof db.replaceSeries==='function'){
     await db.replaceSeries('bars',result.seriesKey,result.stores[0][1],{key:'bootBar:'+task.market+':'+task.code,done:true,count:result.count,requestedLimit:null,eligible220:result.count>=220,eligible500:result.count>=500,latest:result.last,source:result.source,updatedAt:new Date().toISOString()});
   }else if(typeof db.commitBundle==='function'){
      await db.commitBundle(result.stores,{key:'bgImport:'+task.id,done:true,kind:task.kind,count:result.count,at:new Date().toISOString()});
   }else{for(const [store,rows] of result.stores){if(rows.length)await db.putMany(store,rows);}}
   // K-line replacement already wrote completion metadata; catalog and finance
   // are atomically audited via commitBundle in production.
   if(task.kind==='bars'||typeof db.commitBundle!=='function')await db.put('meta',{key:'bgImport:'+task.id,done:true,kind:task.kind,count:result.count,at:new Date().toISOString()});
   acks.push(task.id);saved+=result.count;
  }catch(e){
   const reason=String(e.message||e);
   errors.push({id:task.id,error:reason});
   // Permanent import failures must never monopolize the oldest ready page.
   // The native store keeps the page for forensic inspection and future refetch.
   if(typeof bridge.reject==='function')bridge.reject(task.id,reason.slice(0,850));
  }}
 if(acks.length)bridge.ack(JSON.stringify(acks));onProgress({pages:acks.length,records:saved,errors});
 return{pages:acks.length,records:saved,errors,available:tasks.length};
}
return{parsePage,importBatch};
});
