/* QuantDesk native Android batch APIs: translates the collector's Tushare data schema
 * into app IndexedDB without running Python. Requires Android Studio native bridge
 * and the user's own authorized token. No token is persisted or shipped in APK.
 * Daily is UNADJUSTED; store separately from Eastmoney front-adjusted technical bars.
 */
(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantTushare=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const pending=new Map();let seq=0;
const asDate=v=>String(v||'').replace(/^(\d{4})(\d{2})(\d{2})$/,'$1-$2-$3');
const num=x=>{const n=Number(x);return x===null||x===undefined||x===''||!Number.isFinite(n)?null:n};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function available(){return typeof window!=='undefined'&&typeof window.QuantDeskNative?.request==='function'}
function _receive(id,payload){const p=pending.get(id);if(!p)return;pending.delete(id);clearTimeout(p.timer);try{p.resolve(JSON.parse(payload))}catch(e){p.reject(Error('授权数据返回非JSON格式'))}}
function nativeRequest(api_name,params,token,timeout=50000){
 if(!available())return Promise.reject(Error('当前精简APK不含原生Tushare HTTPS桥；请使用完整Android Studio工程编译的正式包'));
 if(!/^[a-z0-9_]+$/.test(api_name)||typeof token!=='string'||token.length<16)return Promise.reject(Error('请输入自己的Tushare有效Token'));
 const id='ts'+(++seq);return new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{pending.delete(id);reject(Error('Tushare原生请求超时'))},timeout);pending.set(id,{resolve,reject,timer});
  try{window.QuantDeskNative.request(id,JSON.stringify({api_name,params,token}))}catch(e){clearTimeout(timer);pending.delete(id);reject(e)}
 });
}
function rowsFrom(reply){if(!reply||reply.code!==0)throw Error('Tushare权限/网络错误：'+String(reply?.msg||reply?.code||'未知').slice(0,170));
 const d=reply.data||{};if(!Array.isArray(d.fields)||!Array.isArray(d.items))throw Error('Tushare返回字段结构不完整');
 if(d.items.length>20000)throw Error('单次响应过大，需要分页采集');
 return d.items.map(cells=>{if(!Array.isArray(cells)||cells.length!==d.fields.length)throw Error('字段数不一致');return Object.fromEntries(d.fields.map((f,i)=>[f,cells[i]]))});}
const code=x=>{const s=String(x||'').toUpperCase();return /^\d{6}\.(SH|SZ|BJ)$/.test(s)?s.slice(0,6):null};
async function saveChunks(db,store,records,meta,n=350){for(let i=0;i<records.length;i+=n)await db.putMany(store,records.slice(i,i+n));if(meta)await db.put('meta',meta);return records.length;}
function create({db,token,request=nativeRequest,stop=()=>false,progress=()=>{},wait=sleep,now=()=>new Date()}={}){
 if(!db?.get||!db?.putMany||!db?.put||!db?.all)throw Error('Tushare采集器需要本地数据库');
 const call=async(api,params)=>rowsFrom(await request(api,params,token));
 const ensure=()=>{if(stop())throw Error('已停止，完成页面仍保存在本地')};
 const stamp=()=>now().toISOString();
 async function instruments(){ensure();progress({type:'instruments',state:'fetch'});const raw=await call('stock_basic',{list_status:'L'}),m=new Map();
  for(const x of raw){const c=code(x.ts_code);if(c&&x.name)m.set(c,{key:'A:'+c,market:'A',code:c,name:String(x.name),exchange:x.exchange||'',board:x.market||'',listingDate:x.list_date||'',source:'Tushare stock_basic（授权）',catalogFetchedAt:stamp()});}
  if(m.size<3000)throw Error('授权股票目录仅有'+m.size+'只，不认定为全市场');
  await saveChunks(db,'universe',[...m.values()],{key:'ts:instruments',count:m.size,updatedAt:stamp(),source:'tushare',checked:true});
  progress({type:'instruments',state:'saved',count:m.size});return m.size;
 }
 async function calendar(days=120){ensure();const end=now(),start=new Date(end.getTime()-(Math.ceil(days*1.7)+35)*86400000),fmt=d=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(d).replace(/-/g,'');
  const rows=await call('trade_cal',{exchange:'SSE',start_date:fmt(start),end_date:fmt(end),is_open:'1'});
  const dates=[...new Set(rows.filter(x=>String(x.is_open)==='1'&&/^\d{8}$/.test(x.cal_date||'')).map(x=>x.cal_date))].sort().reverse().slice(0,days);
  if(!dates.length)throw Error('交易日历没有返回有效交易日');return dates.reverse();
 }
 async function daily(date){ensure();if(!/^\d{8}$/.test(date))throw Error('日期必须为YYYYMMDD');const key='ts:daily:'+date,old=await db.get('meta',key);if(old?.checked)return{skipped:true,count:old.count};
  const raw=await call('daily',{trade_date:date}),items=[];
  for(const x of raw){const c=code(x.ts_code),price=num(x.close);if(!c||x.trade_date!==date||!(price>0))continue;
   items.push({key:'A:'+c+':'+asDate(date),market:'A',code:c,date:asDate(date),open:num(x.open),high:num(x.high),low:num(x.low),close:price,prevClose:num(x.pre_close),pct:num(x.pct_chg),volume:num(x.vol),amount:num(x.amount),source:'Tushare daily（未复权盘后）',fetchedAt:stamp(),rawFields:x});}
  if(items.length<100)throw Error(date+'盘后日线只有'+items.length+'只（休市/限流/未更新），不记为成功');
  await saveChunks(db,'daily_raw',items,{key,count:items.length,updatedAt:stamp(),checked:true,source:'tushare',date});
  progress({type:'daily',state:'saved',date,count:items.length});return{date,count:items.length};
 }
 async function factor(date){ensure();const key='ts:factor:'+date,old=await db.get('meta',key);if(old?.checked)return{skipped:true,count:old.count};
  const raw=await call('daily_basic',{trade_date:date}),items=[];
  for(const x of raw){const c=code(x.ts_code);if(!c||x.trade_date!==date)continue;
   items.push({key:'A:'+c+':'+asDate(date),market:'A',code:c,date:asDate(date),turnover:num(x.turnover_rate),pe:num(x.pe),pb:num(x.pb),totalMv:num(x.total_mv),circMv:num(x.circ_mv),source:'Tushare daily_basic（盘后）',fetchedAt:stamp(),rawFields:x});}
  if(items.length<100)throw Error('盘后估值数据只有'+items.length+'只');await saveChunks(db,'factors',items,{key,count:items.length,checked:true,updatedAt:stamp()});
  progress({type:'factors',state:'saved',date,count:items.length});return{date,count:items.length};
 }
 async function statement(kind,period){ensure();const choices={balance:'balancesheet_vip',income:'income_vip',cashflow:'cashflow_vip'};
  if(!choices[kind]||!/^\d{8}$/.test(period))throw Error('报表类型/季度无效');const key='ts:statement:'+kind+':'+period,old=await db.get('meta',key);if(old?.checked)return{skipped:true,count:old.count};
  const raw=await call(choices[kind],{period});const items=[];
  for(const x of raw){const c=code(x.ts_code),ann=asDate(x.f_ann_date||x.ann_date||'');if(!c||x.end_date!==period||!/^\d{4}-\d\d-\d\d$/.test(ann))continue;
   const dd=asDate(period),rt=String(x.report_type||''),rev=num(x.total_revenue||x.revenue),profit=num(x.n_income_attr_p||x.n_income),cash=num(x.n_cashflow_act),assets=num(x.total_assets),debt=num(x.total_liab);
   items.push({key:`A:${c}:${dd}:${kind}:${ann}:${rt}`,market:'A',code:c,type:kind,reportDate:dd,noticeDate:ann,reportType:rt,name:x.name||c,revenue:rev,profit,cash:cash,assets,liabilities:debt,debtRatio:assets>0&&debt!=null?debt/assets*100:null,rawFields:x,source:'Tushare '+choices[kind]+'（授权）',fetchedAt:stamp()});}
  if(items.length===0)throw Error(kind+' '+period+'没有可核验披露记录（可能未披露/无权限）');
  // Tushare endpoints may cap returned rows. Never certify a quarter at a plausible cap.
  const checked=items.length<5000;
  await saveChunks(db,'finance',items,{key,count:items.length,checked,updatedAt:stamp(),note:checked?'已保存返回记录，不保证所有企业同日披露':'达到单次5000行上限，可能需授权分页核对'});
  progress({type:kind,state:checked?'saved':'partial',period,count:items.length});return{kind,period,count:items.length,checked};
 }
 async function full({days=120,quarters=4,withFactors=true}={}){
  if(!/^[0-9A-Za-z]{16,90}$/.test(token||''))throw Error('没有有效的个人Tushare令牌');
  const report={startedAt:stamp(),steps:[],errors:[]};const tryStep=async(name,fn)=>{try{const x=await fn();report.steps.push({name,...x});}catch(e){report.errors.push(name+': '+e.message);progress({type:name,state:'failed',message:e.message});}};
  await tryStep('股票目录',async()=>({count:await instruments()}));if(stop())return report;
  let dates=[];try{dates=await calendar(days)}catch(e){report.errors.push('交易日历：'+e.message)}
  for(let i=0;i<dates.length&&!stop();i++){await tryStep('盘后日线 '+dates[i],()=>daily(dates[i]));if((i+1)%10===0)progress({type:'daily-progress',state:'running',done:i+1,total:dates.length});await wait(150);}
  if(withFactors&&dates.length&&!stop())await tryStep('最近交易日估值',()=>factor(dates.at(-1)));
  // Most recent completed quarter ends. A report for that quarter may still be undisclosed.
  const today=now();const periods=[];let y=today.getFullYear(),q=Math.ceil((today.getMonth()+1)/3);
  for(let i=0;i<quarters;i++){q--;if(q<=0){q=4;y--;}const mm=q*3,dd=[31,30,30,31][q-1];periods.push(String(y)+String(mm).padStart(2,'0')+String(dd).padStart(2,'0'));}
  for(const p of periods){for(const k of ['balance','income','cashflow']){if(stop())break;await tryStep(k+' '+p,()=>statement(k,p));await wait(250);}}
  const done=!stop()&&report.errors.length===0;
  await db.put('meta',{key:'tushare:last',...report,done,finishedAt:stamp(),days,quarters});return{...report,done};
 }
 return{instruments,calendar,daily,factor,statement,full};
}
return{available,_receive,nativeRequest,rowsFrom,create};
});
