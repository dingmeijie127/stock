/* V8.2 One coherent data-quality view: native queue, actual IndexedDB, market coverage.
   An accepted start request never implies a running service or complete data. */
(function(){'use strict';
const $=id=>document.getElementById(id);let draining=false,busy=false,lastAction='',lastImportError='';
const clean=x=>String(x??'').slice(0,200);
function bridgeStatus(){try{return window.QuantDeskBackground?JSON.parse(QuantDeskBackground.status()):null;}catch(e){return{startError:'原生后台状态获取失败：'+clean(e.message)}}}
async function refresh(){if(busy||!$('qd82Health'))return;busy=true;try{
 const native=bridgeStatus(),db=window.QuantDB;
 if(!db||!window.QuantDataHealth)throw Error('数据库健康检查模块没有装载');
 await db.open();const r=await QuantDataHealth.inspect(db,native||{}),m=r.markets,q=r.queue;
 const warning=r.discrepancies.quoteOnly?`\n发现 ${r.discrepancies.quoteOnly} 只证券只存在于报价表、缺少目录关联；可以点“修复目录关联”。`:'';
 const errs=(q.errors||[]).slice(0,3).map(e=>`\n  · ${clean(e.kind)} ${clean(e.market||'')}:${clean(e.code||'')} 页${e.page||'?'}：${clean(e.error)}`).join('');
 $('qd82Health').textContent=`实际分析库（重新读取）：目录 ${r.counts.catalog} 条；报价 ${r.counts.stocks} 条；财报 ${r.counts.finance} 条；日K ${r.counts.bars} 根。\nA股：目录 ${m.A.directory} 只 / 已有报价记录 ${m.A.knownQuotes} 只；港股：目录 ${m.HK.directory} 只 / 已有报价记录 ${m.HK.knownQuotes} 只。\n${r.warning}${warning}\n\n原生下载队列：总任务 ${q.total}、等待 ${q.waiting}、正在请求 ${q.running}、待导入 ${q.ready}、已确认导入 ${q.imported}、失败 ${q.failed}。\n后台服务：${q.serviceActive?'运行中':'未确认正在运行'}；当前阶段：${r.phase}。${q.startError?'\n启动错误：'+clean(q.startError):''}${errs}${lastImportError?'\n导入错误：'+lastImportError:''}${lastAction?'\n最近操作：'+lastAction:''}`;
 const a=$('qd77BgStatus');if(a)a.textContent=`${r.phase}；等待${q.waiting} / 待导入${q.ready} / 失败${q.failed}。详情见“统一数据健康诊断”。`;
 }catch(e){$('qd82Health').textContent='诊断未完成：'+clean(e.message);}
 finally{busy=false;}}
async function importReady(){if(draining||!window.QuantDeskBackground||!window.QuantDB||!window.QuantBackgroundImport)return;draining=true;let pages=0,records=0;lastImportError='';
 try{await QuantDB.open();for(let i=0;i<12;i++){
  const batch=await QuantBackgroundImport.importBatch(QuantDeskBackground,QuantDB,QuantProvider,{max:6});pages+=batch.pages;records+=batch.records;
  if(batch.errors.length){lastImportError=batch.errors.slice(0,3).map(x=>clean(x.id)+': '+clean(x.error)).join('；');break;}
  if(!batch.pages)break;
 }
 if(pages){lastAction=`本轮 ${pages} 页、${records} 条已通过数据库提交，原生任务已确认；它们未必满足策略数据门槛。`;
   if(typeof window.QuantDeskRefreshAHCoverage==='function')await window.QuantDeskRefreshAHCoverage();
   document.dispatchEvent(new Event('quantdesk:dataImported'));
 }
 }catch(e){lastImportError=clean(e.message);}finally{draining=false;await refresh();}}
async function seedLocalBars(){const bridge=window.QuantDeskBackground;if(!bridge)return 0;await QuantDB.open();
 const [universe,stocks]=await Promise.all([QuantDB.all('universe'),QuantDB.all('stocks')]);
 const map=new Map();for(const x of [...universe,...stocks])if(window.QuantDataHealth?.valid(x))map.set(x.market+':'+x.code,{market:x.market,code:x.code});
 const symbols=[...map.values()];let n=0;
 for(let i=0;i<symbols.length;i+=100)n+=bridge.seedSymbols(JSON.stringify(symbols.slice(i,i+100)));
 return n;
}
async function startNative(source){const bridge=window.QuantDeskBackground;
 if(!bridge){lastAction='当前APK没有原生后台能力';await refresh();return;}
 const fromV7=source==='v7AHInit',bars=source==='qd77BgStart'?true:fromV7?!!$('v7History')?.checked:!!$('initHistory')?.checked,
 finance=source==='qd77BgStart'?true:fromV7?true:!!$('initFinance')?.checked;
 const quarters=Math.max(1,Math.min(20,Number(fromV7||source==='qd77BgStart'?$('v7Quarters')?.value:$('initQuarters')?.value)||4));
 const limit=Math.max(320,Math.min(2500,Number(fromV7||source==='qd77BgStart'?$('v7Bars')?.value:$('initBars')?.value)||650));
 const concurrency=Math.max(1,Math.min(4,Number($('v76Concurrency')?.value)||3));
 let seeded=0;if(bars)seeded=await seedLocalBars();
 const reply=bridge.start(JSON.stringify({bars,finance,quarters,limit,concurrency}));
 lastAction=`启动请求返回 ${reply}；已知证券尝试排入 ${seeded} 个历史任务。${reply==='start_requested'?'请查看服务状态与目录任务，不代表下载成功。':'请求未确认，请检查参数或状态。'}`;
 if($('bootstrapState'))$('bootstrapState').textContent=lastAction;
 if($('v72InitLog'))$('v72InitLog').textContent=lastAction;
 await refresh();
}
function init(){if(!$('v76SyncControls')||$('qd77BgPanel'))return false;
 const panel=document.createElement('div');panel.id='qd77BgPanel';panel.className='card';
 panel.innerHTML='<h3>V8.2 · 原生下载和统一数据诊断</h3><p class="hint">数据流：目录下载 → 生成K线/财报任务 → 原生SQLite暂存 → 导入IndexedDB → 策略质量验收。每一步独立统计；下载页数不等于合格股票数。第一次请允许通知，再查看是否真正运行。</p><div class="row"><button class="primary" id="qd77BgStart">开始/继续后台建库</button><button id="qd77BgPause">暂停下载（保留结果）</button><button id="qd77BgImport">导入已下载数据</button></div><div class="row"><button id="qd82Refresh">刷新统一诊断</button><button id="qd82Repair">修复目录关联（不联网）</button></div><p id="qd77BgStatus" class="status">检查中…</p><details open><summary><b>统一数据健康诊断（实时读取）</b></summary><p id="qd82Health" class="status" aria-live="polite">正在读取实际库与下载队列…</p></details><p class="hint">诊断仅保证统计自洽。A/H官方全量覆盖、财务披露完整性和K线交易日连续性需要另外验收；这次不再把任务排队说成建库成功。</p>';
 $('v76SyncControls').appendChild(panel);
 $('qd77BgStart').onclick=()=>startNative('qd77BgStart').catch(e=>{lastAction='启动请求异常：'+clean(e.message);refresh();});
 $('qd77BgImport').onclick=importReady;
 $('qd77BgPause').onclick=()=>{try{QuantDeskBackground?.pause();lastAction='已提交暂停请求；数据未清除';}catch(e){lastAction='暂停异常：'+clean(e.message)}refresh();};
 $('qd82Refresh').onclick=async()=>{await refresh();if(window.QuantDeskRefreshAHCoverage)await QuantDeskRefreshAHCoverage();};
 $('qd82Repair').onclick=async()=>{if(!window.QuantDB||!window.QuantDataHealth)return;
  const r=await QuantDataHealth.recoverDirectory(QuantDB);lastAction=`从已有行情恢复 ${r.added} 条缺失的目录索引。未宣称达到全市场覆盖。`;
  if(window.QuantDeskRefreshAHCoverage)await QuantDeskRefreshAHCoverage();await refresh();};
 // Capture and unify only the two legacy first-build buttons; other specialized actions remain functional.
 if(window.QuantDeskBackground)for(const id of ['v7AHInit','bootstrapInit']){
  const button=$(id);if(button)button.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();
   startNative(id).catch(err=>{lastAction='建库请求异常：'+clean(err.message);refresh();});},true);
 }
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)importReady()});
 // While the app is visible, continuously reconcile native SQLite responses with IndexedDB.
 setInterval(()=>{if(document.hidden)return;const n=bridgeStatus();if(n?.ready>0)importReady();else refresh();},8500);
 importReady().then(refresh);return true;
}
let attempts=0;const t=setInterval(()=>{if(init()||++attempts>=120)clearInterval(t);},180);
})();
