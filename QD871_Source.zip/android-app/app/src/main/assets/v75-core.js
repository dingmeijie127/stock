/* V7.5 screening audit: no candidate is silently dropped; pure, testable, no market calls. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.QuantV75=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const L={qualified:'基本面合格',missing_finance:'财报缺失',missing_quote:'行情不合格',rejected:'财务条件未通过',special_sector:'金融专用模型未就绪',low_liquidity:'流动性不足',excluded:'风险排除',invalid:'证券代码异常',pending:'尚未深度分析',eligible:'买点观察',trend_fail:'趋势／动量未通过',insufficient_bars:'历史K线不足',missing_lot:'港股每手股数缺失',data_error:'行情补数失败',risk_or_cash:'仓位／交易条件限制',unverified:'待核验'};
function reasonForPlan(plan,bars,error){
 if(error&&(!bars||bars.length<253))return {status:'data_error',reason:'K线请求失败：'+String(error).slice(0,140)};
 if(!Array.isArray(bars)||bars.length<253)return {status:'insufficient_bars',reason:'实际只有'+(bars?.length||0)+'根日K；至少需要253根'};
 if(plan?.eligible)return{status:'eligible',reason:plan.reason||'满足技术观察条件'};
 const reason=String(plan?.reason||'数据或仓位条件不满足');
 if(/每手|lotSize|交易单位/.test(reason))return{status:'missing_lot',reason};
 if(/动量|趋势|长期/.test(reason))return{status:'trend_fail',reason};
 return{status:'risk_or_cash',reason};
}
function tally(items){const counts={};for(const item of items||[])counts[item.deepStatus||item.status]=(counts[item.deepStatus||item.status]||0)+1;return counts}
function audits(full,deepIds,outcomes){const selected=new Set(deepIds),out=new Map((outcomes||[]).map(x=>[x.market+':'+x.code,x]));return(full||[]).map(x=>{
 const k=x.market+':'+x.code;const res=out.get(k);return {key:k,market:x.market,code:x.code,name:x.name||x.code,status:x.status,reasons:x.reasons||[],screenReasons:x.reasons||[],deepStatus:res?.deepStatus|| (x.status==='qualified'?(selected.has(k)?'unverified':'pending'):null),deepReason:res?.deepReason|| (x.status==='qualified'?'尚未技术核验':(x.reasons||[]).join('；')),lastBar:res?.lastBar||null,barCount:res?.barCount||0,financeComplete:!!x.fundamentals?.complete,plan:res?.plan||null};
})}
return{L,reasonForPlan,tally,audits};
});
