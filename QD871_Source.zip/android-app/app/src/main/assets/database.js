(function(root,factory){let v=factory();if(typeof module==='object'&&module.exports)module.exports=v;root.QuantDB=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const STORES={stocks:{keyPath:'key'},universe:{keyPath:'key'},bars:{keyPath:'key'},daily_raw:{keyPath:'key'},factors:{keyPath:'key'},finance:{keyPath:'key'},sectors:{keyPath:'key'},notices:{keyPath:'key'},news:{keyPath:'key'},ledger:{keyPath:'key'},meta:{keyPath:'key'},screenings:{keyPath:'key'},screening_items:{keyPath:'key'},signals:{keyPath:'key'},paper:{keyPath:'key'},paper_events:{keyPath:'key'}};
let db,opening=null;
function open(){
 if(db)return Promise.resolve(db);
 if(opening)return opening;
 opening=new Promise((resolve,reject)=>{
  if(!globalThis.indexedDB)return reject(Error('当前环境不支持IndexedDB'));
  let r=indexedDB.open('quantdesk_native_local_v3',4);
  r.onupgradeneeded=()=>{let d=r.result;for(let [name,opt] of Object.entries(STORES))if(!d.objectStoreNames.contains(name))d.createObjectStore(name,opt)};
  r.onsuccess=()=>{db=r.result;db.onversionchange=()=>{db.close();db=null;opening=null;};resolve(db)};
  r.onerror=()=>reject(r.error);r.onblocked=()=>reject(Error('数据库升级被其他页面阻塞'));
 }).catch(e=>{opening=null;throw e});
 return opening;
}
function ensure(){if(!db)throw Error('本地数据库尚未打开')}
function putMany(store,items){ensure();return new Promise((resolve,reject)=>{if(!items.length)return resolve(0);let t=db.transaction(store,'readwrite'),s=t.objectStore(store);for(let x of items)s.put(x);t.oncomplete=()=>resolve(items.length);t.onerror=()=>reject(t.error||Error('数据库保存失败'));t.onabort=()=>reject(t.error||Error('数据库写入中断'))})}
// Save statement page and progress marker in ONE IndexedDB transaction.
function commitPage(store,items,meta){ensure();return new Promise((resolve,reject)=>{
 let t=db.transaction([store,'meta'],'readwrite'),s=t.objectStore(store);
 for(const x of items)s.put(x);
 t.objectStore('meta').put(meta);
 t.oncomplete=()=>resolve(items.length);
 t.onerror=()=>reject(t.error||Error('财报页数据库事务失败'));
 t.onabort=()=>reject(t.error||Error('财报页写入回滚'));
})}
// Replace an entire symbol's adjusted daily series atomically. Never mix two
// providers' adjustment baselines when the fallback source changes.
function replaceSeries(store,prefix,items,meta){ensure();return new Promise((resolve,reject)=>{
 if(store!=='bars'||!prefix||!Array.isArray(items)||!items.length)return reject(Error('非法K线覆盖任务'));
 if(items.some(x=>!String(x.key||'').startsWith(prefix)))return reject(Error('K线标识与股票代码不一致'));
 const tx=db.transaction(['bars','meta'],'readwrite'),bars=tx.objectStore('bars');
 const cursor=bars.openCursor(IDBKeyRange.bound(prefix,prefix+'\uffff'));
 cursor.onsuccess=()=>{const c=cursor.result;if(c)c.delete(),c.continue();else {for(const x of items)bars.put(x);tx.objectStore('meta').put(meta);}};
 tx.oncomplete=()=>resolve(items.length);tx.onerror=()=>reject(tx.error||Error('历史K线事务失败'));tx.onabort=()=>reject(tx.error||Error('历史K线事务回滚'));
 });}
// Commit multiple related stores and an audit checkpoint in a single IDB transaction.
function commitBundle(collection,meta){ensure();return new Promise((resolve,reject)=>{
 if(!Array.isArray(collection)||!meta?.key)return reject(Error('非法分组事务'));
 const names=[...new Set([...collection.map(x=>x[0]),'meta'])],tx=db.transaction(names,'readwrite');
 for(const [store,rows] of collection)for(const x of rows)tx.objectStore(store).put(x);
 tx.objectStore('meta').put(meta);
 tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||Error('分组入库失败'));tx.onabort=()=>reject(tx.error||Error('分组事务回滚'));
 });}
function put(store,item){return putMany(store,[item])}
// Read-validate-write one ledger as a single IndexedDB transaction. The update
// callback MUST be synchronous; never await inside an IDB transaction.
function mutateLedger(change){ensure();return new Promise((resolve,reject)=>{
 let tx=db.transaction('ledger','readwrite'),store=tx.objectStore('ledger'),out=null;
 const request=store.get('main');request.onsuccess=()=>{try{
  const old=request.result||{key:'main',holdings:[],trades:[],cashApprox:0,realized:0};
  const next=change(old);if(!next||!Array.isArray(next.holdings)||!Array.isArray(next.trades))throw Error('账本变更无效');
  out={...next,key:'main'};store.put(out);
 }catch(e){out=null;tx.abort();reject(e);}};
 tx.oncomplete=()=>resolve(out);tx.onerror=()=>reject(tx.error||Error('账本保存失败'));tx.onabort=()=>reject(tx.error||Error('账本事务被撤销'));
 });}

function get(store,key){ensure();return new Promise((resolve,reject)=>{let r=db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>resolve(r.result??null);r.onerror=()=>reject(r.error)})}
function all(store){ensure();return new Promise((resolve,reject)=>{let r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function withPrefix(store,prefix){ensure();return new Promise((resolve,reject)=>{let arr=[],r=db.transaction(store).objectStore(store).openCursor(IDBKeyRange.bound(prefix,prefix+'\uffff'));r.onsuccess=()=>{let c=r.result;if(c){arr.push(c.value);c.continue()}else resolve(arr)};r.onerror=()=>reject(r.error)})}
function count(store){ensure();return new Promise((resolve,reject)=>{let r=db.transaction(store).objectStore(store).count();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function removeAll(){ensure();return new Promise((resolve,reject)=>{let tx=db.transaction(Object.keys(STORES),'readwrite');for(let store of Object.keys(STORES))tx.objectStore(store).clear();tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
return {open,putMany,commitPage,replaceSeries,commitBundle,put,get,all,withPrefix,count,removeAll,mutateLedger};
});
