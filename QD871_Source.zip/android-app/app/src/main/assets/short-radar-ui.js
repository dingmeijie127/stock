/* V8.0 local short radar and prioritized historical data repair; no broker integration. */
(function(){'use strict';
 const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let busy=false,lastMissing=[],lastSummary=null;
 async function pricesAndRisks(){const stocks=await QuantDB.all('stocks'),map=new Map(stocks.map(s=>[s.market+':'+s.code,s]));
  const ledger=await QuantDB.get('ledger','main');let risk=0,known=true;
  for(const h of ledger?.holdings||[]){if(Number(h.shares)<=0)continue;const q=map.get((h.market||'A')+':'+h.code);
   if((h.market||'A')!=='A'||!q?.price||!Number.isFinite(+q.price)||Date.now()-Date.parse(q.quoteTime||'')>5*86400000){known=false;break;}
   risk+=Number(h.shares)*Number(q.price)*.08;
  }
  return{map,risk:known?Math.round(risk):null,holdings:(ledger?.holdings||[]).length};
 }
 function eligible(q,now){return q?.market==='A'&&/^\d{6}$/.test(q.code||'')&&!/^(ST|\*ST|退市)/i.test(q.name||'')&&Number(q.price)>0&&Number(q.amount)>=1e8&&q.quoteTime&&Date.parse(q.quoteTime)<now.getTime()+3600000&&now.getTime()-Date.parse(q.quoteTime)<5*86400000;}
 const say=s=>{if($('qd80Status'))$('qd80Status').textContent=s};
 async function scan(){if(busy)return;busy=true;try{
  say('读取本地全市场快照和逐股K线…');const {map,risk}=await pricesAndRisks();const now=new Date();
  const sect=new Map();for(const q of map.values())if(eligible(q,now)&&q.sector&&Number.isFinite(+q.pct)){
    const x=sect.get(q.sector)||{sample:0,sum:0,positive:0};x.sample++;x.sum+=Number(q.pct);if(Number(q.pct)>0)x.positive++;sect.set(q.sector,x);
  }
  const n=Number($('qd80Depth')?.value||60);
  // Amount and recent price strength are research prioritization, not proof of heat.
  const pool=[...map.values()].filter(q=>eligible(q,now)).sort((a,b)=>Number(b.amount||0)-Number(a.amount||0)).slice(0,n);
  const records=[],missing=[];let i=0;for(const q of pool){
   const b=await QuantDB.withPrefix('bars','A:'+q.code+':'),finance=await QuantDB.withPrefix('finance','A:'+q.code+':');
   const sh=sect.get(q.sector),heat=sh?{sample:sh.sample,avgPct:sh.sum/sh.sample,positiveRatio:sh.positive/sh.sample}:null;
   const item=QuantShortRadar.build({quote:q,bars:b,finance,marketRisk:'unknown',sectorHeat:heat,portfolioStress:risk,budget:2000,now});
   records.push(item);if(item.state==='DATA_MISSING'&&item.reasons.some(x=>x.includes('日K')))missing.push(q);
   if(++i%12===0)say(`正在核验第${i}/${pool.length}只；K线问题${missing.length}只…`);
  }
  lastMissing=missing;lastSummary={pool:pool.length,missing:missing.length,risk};
  const pass=records.filter(r=>r.state==='WATCH_ONLY'&&r.technical),fFail=records.filter(r=>r.state==='FUNDAMENTAL_FAIL'),data=records.filter(r=>r.state==='DATA_MISSING');
  $('qd80Summary').textContent=`实际核查 ${records.length} 只（从有效报价池按流动性排序，不是全市场完成率）。K线缺失或不可用 ${missing.length}；其他数据缺失 ${data.length-missing.length}；财务过滤未过 ${fFail.length}；具备技术研究条件 ${pass.length}。账户8%情景损失 ${risk===null?'无法核实':risk+'元'}；不得用此估计保证亏损上限。`;
  $('qd80Results').innerHTML=records.slice().sort((a,b)=>Number(!!b.technical)-Number(!!a.technical)).slice(0,35).map(r=>{
   const stat=r.technical?`${r.technical.breakout?'收盘突破待确认':r.technical.pullback?'回踩研究':'趋势暂未确认'}；MA20 ${r.technical.ma20}；近5日 ${r.technical.return5d}%；量比 ${r.technical.volRatio}；热度 ${r.technical.sectorHeat}`:r.reasons.join('；');
   return `<div class="result"><b>${esc(r.name)} ${esc(r.code)}</b> <span class="tag">${esc(r.state)}</span><p>${esc(stat)}</p><p class="hint">最新历史K ${esc(r.dataEnd||'未知')}；${r.plan?'每100股理论失效价损失约'+r.plan.riskPer100+'元；禁止自动下单':'未满足数据条件，不产生买入信号'}</p></div>`;
  }).join('')||'<p class="hint">没有可核验股票。请先建立行情目录，再尝试修复历史K线。</p>';
  say(`核验结束。${records.length}只样本中${pass.length}只具备技术观察条件。市场状态尚未完整核实，全部仅供观察，不是实盘买入建议。`);
 }catch(e){say('雷达核验失败：'+e.message);}finally{busy=false;}}
 async function repair(){if(busy)return;busy=true;let done=0,failed=0;try{
  if(!lastMissing.length){say('先点击“核查本地数据与雷达”，找出确切缺口。');return;}
  const target=lastMissing.slice(0,12);say(`仅对优先队列中${target.length}只补齐历史K线，不盲目请求全市场。`);
  for(const q of target){try{
    const rows=await QuantProvider.bars(q.code,'A',320);
    QuantKlineQuality.validate(rows,{market:'A',code:q.code,min:80});
    const meta={key:'bootBar:A:'+q.code,done:true,count:rows.length,requestedLimit:320,latest:rows.at(-1).date,source:rows[0].source,updatedAt:new Date().toISOString()};
    if(typeof QuantDB.replaceSeries!=='function')throw Error('当前数据库版本不支持原子化整组K线替换');
    await QuantDB.replaceSeries('bars','A:'+q.code+':',rows,meta);
    await QuantDB.put('meta',{key:'historyError:A:'+q.code,code:q.code,market:'A',status:'repaired',updatedAt:new Date().toISOString(),source:rows[0].source});
    done++;
   }catch(e){failed++;await QuantDB.put('meta',{key:'historyError:A:'+q.code,code:q.code,market:'A',status:'failed',reason:QuantKlineQuality.classifyError(e),details:String(e.message).slice(0,240),updatedAt:new Date().toISOString()});}
   say(`K线修复进度${done+failed}/${target.length}，成功${done}，失败${failed}。可在诊断中查看原因。`);
  }
  say(`补数结束：本轮成功${done}，失败${failed}；失败项已记录。再次点击“核查本地数据与雷达”验证，未核验前不生成交易信号。`);
 }catch(e){say('修复中断：'+e.message);}finally{busy=false;}}
 async function errors(){try{
  const m=(await QuantDB.all('meta')).filter(x=>String(x.key||'').startsWith('historyError:A:')&&x.status==='failed').sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));
  $('qd80Errors').textContent=m.length?m.slice(0,16).map(x=>`${x.code}: ${x.reason||'UNKNOWN'} · ${x.details||''} (${x.updatedAt||''})`).join('\n'):'尚未发现持久化的A股历史K线失败记录。旧版失败可能未记下原因，不表示覆盖完整。';
 }catch(e){$('qd80Errors').textContent='读取失败记录异常：'+e.message;}}
 function mount(){const place=$('page-picks');if(!place||$('qd80RadarPanel'))return false;
  const el=document.createElement('div');el.className='card';el.id='qd80RadarPanel';el.innerHTML=`<h2>短线机会雷达 · 数据优先 / 纪律优先</h2><p class="hint">仅研究3～10个交易日的观察条件；完整财务摘要、同季经营现金流、至少220根近期有效日K和行情时间必须齐备。大盘与持仓整体风险未知时，不产生实盘买入指令。</p><div class="two"><label>核查股票数<select id="qd80Depth"><option value="30">30只 · 快速诊断</option><option value="60" selected>60只 · 标准诊断</option><option value="120">120只 · 深入诊断</option></select></label><div class="row"><button id="qd80Scan" class="primary">核查本地数据与雷达</button><button id="qd80Repair">补救缺失K线（最多12只）</button></div></div><div id="qd80Summary" class="status">尚未运行。先诊断覆盖率，不用残缺数据凑买点。</div><p id="qd80Status" class="hint">等待读取。</p><div id="qd80Results"></div><details><summary>逐股历史K线失败原因</summary><button id="qd80ErrorReload">读取失败日志</button><div class="status" id="qd80Errors">尚未查询。</div></details>`;
  place.insertBefore(el,place.firstChild);
  $('qd80Scan').addEventListener('click',scan);$('qd80Repair').addEventListener('click',repair);$('qd80ErrorReload').addEventListener('click',errors);return true;
 }
 let count=0;const t=setInterval(()=>{if(mount()||++count>120)clearInterval(t);},150);
})();
