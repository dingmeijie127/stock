/* V7.6 UI. No fake quotes, no automatic real brokerage orders. */
(function(){'use strict';const D=window.QuantDB,C=window.QuantV76,$=id=>document.getElementById(id);
let index=new Map(),lastMode='A',busy=false;
const codeValid=(m,c)=>new RegExp(m==='HK'?'^\\d{5}$':'^\\d{6}$').test(c);
const safe=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const localDate=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
async function rebuildIndex(){await D.open();const [universe,stocks,ledger]=await Promise.all([D.all('universe'),D.all('stocks'),D.get('ledger','main')]);index=C.directoryIndex({universe,stocks,holdings:ledger?.holdings||[],seed:window.QuantV74?.SNAPSHOT||[]});return index.size;}
function sellOptions(){const ledgerPromise=D.get('ledger','main');ledgerPromise.then(x=>{const sel=$('v76SellHolding');if(!sel)return;const m=$('tradeMarket').value,old=sel.value;const items=(x?.holdings||[]).filter(h=>(h.market||'A')===m&&Number(h.shares)>0);sel.innerHTML='<option value="">选择已有持仓…</option>'+items.map(h=>`<option value="${safe(h.code)}">${safe(h.name||h.code)} ${safe(h.code)} · ${Number(h.shares)}股</option>`).join('');if(items.some(h=>h.code===old))sel.value=old;}).catch(()=>{});}
async function codeChanged(){const code=String($('tradeCode')?.value||'').trim(),market=$('tradeMarket')?.value||'A';const hint=$('v76NameHint');if(!hint)return;if(!codeValid(market,code)){hint.textContent='输入'+(market==='HK'?'5位港股':'6位A股')+'代码，自动匹配本地股票名称';return;}if(!index.size)await rebuildIndex();const hit=index.get(market+':'+code);if(hit){$('tradeName').value=hit.name;hint.textContent='已从本地名称索引匹配：'+hit.name+'（'+hit.source+'）。如券商显示不同，请以成交单核对。';}else{hint.textContent='本地股票目录无此代码，请先同步股票目录或手工核对名称；不会伪造证券名称。';}}
async function updateSellable(){const out=$('v76Sellable');if(!out)return;const market=$('tradeMarket').value,code=$('tradeCode').value.trim(),date=$('tradeDate').value;
 const l=await D.get('ledger','main'),h=(l?.holdings||[]).find(x=>x.code===code&&(x.market||'A')===market),n=C.sellable(l,market,code,date);out.textContent=h?`${h.name||code}：账本持有 ${Number(h.shares)} 股；${date||'该交易日'}估算可卖 ${n} 股。${market==='A'?'当日买入部分按T+1扣除。':''}这是账本校验，不代表券商当前实际可卖数量。`:'当前本地账本没有该证券持仓；请先导入持仓或核对市场与代码。';}
function setupLedger(){const node=$('tradeCode');if(!node||$('v76NameHint'))return;
 const name=$('tradeName');const hint=document.createElement('div');hint.id='v76NameHint';hint.className='hint';hint.setAttribute('aria-live','polite');hint.textContent='代码与股票名称自动匹配（本地哈希索引）；支持A股和港股';name.insertAdjacentElement('afterend',hint);
 const pick=document.createElement('div');pick.innerHTML='<label>从真实持仓中选择（卖出时推荐使用）<select id="v76SellHolding"><option value="">选择已有持仓…</option></select></label><div id="v76Sellable" class="status">选择持仓后显示可卖股数及T+1约束。</div>';
 const card=node.closest('.card');card.querySelector('#saveTrade')?.insertAdjacentElement('beforebegin',pick);
 $('v76SellHolding').onchange=()=>{const c=$('v76SellHolding').value;if(c){node.value=c;codeChanged();updateSellable();}};
 node.addEventListener('input',()=>{codeChanged();updateSellable()});$('tradeMarket').addEventListener('change',()=>{sellOptions();codeChanged();updateSellable()});$('tradeSide').addEventListener('change',updateSellable);$('tradeShares').addEventListener('input',updateSellable);$('tradeDate').addEventListener('change',updateSellable);
 if(!$('tradeDate').value)$('tradeDate').value=localDate();
 const refresh=()=>{rebuildIndex().then(()=>{sellOptions();codeChanged();updateSellable()})};document.addEventListener('quantdesk:ledgerChanged',refresh);$('saveTrade').addEventListener('click',()=>setTimeout(refresh,500));refresh();
}
function uiConcurr(){const div=document.createElement('div');div.className='card';div.id='v76SyncControls';div.innerHTML='<h3>V7.6 建库性能与后台说明</h3><div class="two"><label>历史K线请求并发<select id="v76Concurrency"><option value="1">1路 · 最稳</option><option value="2">2路 · 保守</option><option value="3" selected>3路 · 推荐</option><option value="4">4路 · 较快</option><option value="6">6路 · 可能触发限流</option></select></label><div><p class="hint">不是CPU多线程满载：请求是网络I/O，更多并发可能导致超时/限流。每只K线落盘后可续传。</p></div></div><p id="v76BackgroundNote" class="status">此测试APK仍由WebView执行采集：离开页面或锁屏后可能暂停。真正后台持久任务需要标准Android原生前台服务＋通知/WorkManager，并重新编译，不能以本APK保证。</p><button id="v76VerifyStore">核查K线下载检查点</button><p id="v76Stats" class="hint">尚未读取。</p>';
 const btn=$('v7AHInit');btn?.parentNode.insertBefore(div,btn);
 $('v76VerifyStore').onclick=async()=>{const st=await D.get('meta','bootstrap:historyCount');$('v76Stats').textContent=st?`本轮成功${st.done}只，复用${st.skipped}只，失败${st.failed}只，待尝试${st.pending}只；并发${st.concurrency||1}，最近更新${st.updatedAt}`:'尚无历史K线全量任务检查点';};
 document.addEventListener('visibilitychange',()=>{if(window.QuantDeskBackground)$('v76BackgroundNote').textContent='Android原生后台下载已接入：任务在通知栏持续运行；返回App后需导入到量化分析数据库。';else if(document.hidden)$('v76BackgroundNote').textContent='应用切到后台：精简WebView可能暂停；请前台下载或改用标准原生构建。';else $('v76BackgroundNote').textContent='已回到前台。仅WebView测试版不保证后台下载。';});
}
async function computeRegime(){if(busy)return;busy=true;const host=$('v76RegimeResult');host.textContent='读取本地 A/H 股票池及历史日K，计算样本市场趋势…';try{
 const catalog=(await D.all('universe')).filter(x=>x.market===lastMode),pool=[...new Map(catalog.map(x=>[x.code,x])).values()].sort((a,b)=>a.code.localeCompare(b.code));
 const sampled=pool.length>320?Array.from({length:320},(_,i)=>pool[Math.floor(i*(pool.length-1)/319)]):pool;
 let bs=[],checked=0;for(const u of sampled){const bars=await D.withPrefix('bars',lastMode+':'+u.code+':');if(bars.length>=210)bs.push(bars);checked++;if(checked%45===0)host.textContent=`已经检查 ${checked}/${sampled.length}只；可用于长期趋势 ${bs.length}只…`}
 const r=C.sampleRegime({series:bs,market:lastMode,minStocks:100});await D.put('meta',{key:'regime:'+lastMode,at:new Date().toISOString(),...r});drawRegime(r);}
 catch(e){host.textContent='市场状态计算失败：'+e.message}finally{busy=false}}
function drawRegime(r){const host=$('v76RegimeResult');const a=r.metrics||{},percent=v=>Number.isFinite(Number(v))?(Number(v)*100).toFixed(1)+'%':'—';
 host.innerHTML=`<b>${r.market==='HK'?'港股':'A股'} · ${safe(r.label)}</b>（样本计算日期 ${safe(r.asOf||'未知')}）<p>${safe(r.reason||'')}</p><p>抽样股票 ${a.sampleCount||0}只；120日最大回撤 ${percent(a.dd120)}；年化波动 ${percent(a.vol20)}；站上60日均线比例 ${a.breadth==null?'缺少足够样本':percent(a.breadth)}。</p><p>市场标签仅用于调整选股风险阈值的研究，当前不会擅自更改既有交易规则；数据不足则不分类。</p>`;
}
async function setupRegime(){const card=document.createElement('div');card.className='card';card.id='v76Regime';card.innerHTML='<h2>市场环境 · 牛 / 熊 / 猴</h2><p class="hint">根据本地A/H日K构建等权样本代理，需至少100只证券、210根历史日K；不冒充交易所官方指数，不凭一天大跌定义熊市。</p><div class="row"><button id="v76A" class="primary">计算A股状态</button><button id="v76HK">计算港股状态</button></div><div class="status" id="v76RegimeResult">未计算。数据不足时将如实显示，不能凭空判定牛熊。</div>';
 const home=$('page-home'),data=$('page-data');(home||data)?.insertAdjacentElement('afterbegin',card);
 $('v76A').onclick=()=>{lastMode='A';computeRegime()};$('v76HK').onclick=()=>{lastMode='HK';computeRegime()};
 const past=await D.get('meta','regime:A');if(past)drawRegime(past);
}
function boot(){if(!$('v7AHInit')||!$('tradeCode'))return false;setupLedger();uiConcurr();setupRegime();return true;}
let attempts=0;const t=setInterval(()=>{attempts++;if(boot()||attempts>=90)clearInterval(t)},160);
})();
