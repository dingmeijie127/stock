/* V6.5: symbol *directory* is independent of price *quotes*.
   Never count a directory row as a validated quote. Never invent active listings.
   Remote CSV is a third-party historical snapshot; every quote is revalidated.
 */
(function(root,factory){const x=factory();if(typeof module==='object'&&module.exports)module.exports=x;root.QuantUniverse=x;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const SOURCES=[
 {id:'github-basic',url:'https://raw.githubusercontent.com/whz06/deep-learning2026final-lab/main/train_li/data/basic.csv',format:'csv'},
 {id:'linkdiary',url:'https://assets.linkdiary.cn/shares/zh_a_list.json',format:'json'},
 {id:'sina',url:'https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData',format:'sina'}
];
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function csvFields(row){let fields=[],cur='',q=false;for(let i=0;i<row.length;i++){const c=row[i];if(c==='"'){if(q&&row[i+1]==='"'){cur+='"';i++;}else q=!q;}else if(c===','&&!q){fields.push(cur);cur='';}else cur+=c;}fields.push(cur);return fields;}
function normalize(item){let code=String(item.symbol??item.code??item['股票代码']??item.ts_code??'').split('.')[0].replace(/^(sh|sz|bj)/i,'').trim();
 let name=String(item.name??item['股票简称']??item.stock_name??'').trim();if(!/^\d{6}$/.test(code)||!name||name.length>35)return null;
 let suffix=String(item.ts_code??item.exchange??'').toUpperCase();if(suffix&&/\.HK\b|\.US\b/.test(suffix))return null;
 return{key:'A:'+code,code,market:'A',name,board:String(item.market??item.exchange??'').slice(0,25),source:'公开股票目录（非实时行情）'};}
function parseCsv(text){let lines=String(text||'').replace(/^\uFEFF/,'').split(/\r?\n/),headers=csvFields(lines.shift()||'');if(!headers.includes('symbol')&&!headers.includes('code'))throw Error('目录CSV缺少symbol/code列');let out=[];
 for(const l of lines){if(!l.trim())continue;const cells=csvFields(l),x={};headers.forEach((h,i)=>x[h]=cells[i]||'');const n=normalize(x);if(n)out.push(n);}return out;}
function parseJson(text){let raw=JSON.parse(text),items=Array.isArray(raw)?raw:Array.isArray(raw.data)?raw.data:Array.isArray(raw.stocks)?raw.stocks:Array.isArray(raw.list)?raw.list:[];
 return items.map(x=>typeof x==='string'?normalize({code:x,name:x}):normalize(x)).filter(Boolean);}
function parseSina(text){const rows=[];for(const block of String(text||'').match(/\{[^{}]{20,1200}\}/g)||[]){const code=/\bcode\s*:\s*["']?(\d{6})/.exec(block),name=/\bname\s*:\s*(["'])(.*?)\1/.exec(block);if(code&&name){const x=normalize({code:code[1],name:name[2]});if(x)rows.push(x);}}return rows;}
function validDirectory(rows){const seen=new Set(),unique=[];for(const r of rows){if(r&&!seen.has(r.key)){seen.add(r.key);unique.push(r);}}if(unique.length<1200||unique.length>15000)throw Error(`独立股票目录只有${unique.length}条，拒绝将其误称为全市场`);return unique;}
async function fetchSinaAll(fetchText,url,firstRaw,onEvent){let all=[];for(let page=1;page<=115;page++){const params=new URLSearchParams({page:String(page),num:'80',sort:'symbol',asc:'1',node:'hs_a',_s_r_a:'page'});const raw=page===1?firstRaw:await fetchText(url+'?'+params),rows=parseSina(raw);if(!rows.length){if(page===1)throw Error('新浪返回格式与预期不一致');break;}all.push(...rows);onEvent({phase:'sina-page',page,count:all.length});if(rows.length<80)break;await delay(120);}return all;}
async function download({sources=SOURCES,getText,signal,onEvent=()=>{}}={}){
 const fetchText=getText|| (async(url)=>{const isNative=typeof location!=='undefined'&&location.hostname==='appassets.androidplatform.net';const actual=isNative?'/proxy?target='+encodeURIComponent(url):url;const ctrl=new AbortController(),t=setTimeout(()=>ctrl.abort(),14000);if(signal?.aborted)ctrl.abort();try{const r=await fetch(actual,{cache:'no-store',signal:ctrl.signal});if(!r.ok)throw Error('HTTP '+r.status);const body=await r.text();if(body.length>5*1024*1024)throw Error('目录文件超过大小限制');return body;}finally{clearTimeout(t);}});
 let errors=[];
 for(const s of sources){if(signal?.aborted)break;try{onEvent({phase:'source',source:s.id});const firstUrl=s.format==='sina'?s.url+'?'+new URLSearchParams({page:'1',num:'80',sort:'symbol',asc:'1',node:'hs_a',_s_r_a:'page'}):s.url;const raw=await fetchText(firstUrl),arr=validDirectory(s.format==='csv'?parseCsv(raw):s.format==='sina'?await fetchSinaAll(fetchText,s.url,raw,onEvent):parseJson(raw));onEvent({phase:'downloaded',source:s.id,count:arr.length});return{rows:arr,source:s.id,errors};}catch(e){errors.push(s.id+': '+e.message);onEvent({phase:'error',source:s.id,error:e.message});}}
 throw Error('所有独立目录源均不可用：'+errors.join('；'));
}
async function syncDirectory({db,provider,sources,getText,stop=()=>false,onEvent=()=>{}}={}){
 if(!db?.putMany||!db?.put)throw Error('缺少目录存储接口');
 const result=await download({sources,getText,onEvent});if(stop())throw Error('已停止，目录未入库');
 let saved=0;for(let i=0;i<result.rows.length;i+=350){if(stop())throw Error('已停止，目录只有部分入库');const slice=result.rows.slice(i,i+350).map(x=>({...x,source:result.source,catalogFetchedAt:new Date().toISOString()}));await db.putMany('universe',slice);saved+=slice.length;onEvent({phase:'saved',count:saved,total:result.rows.length});}
 const state={key:'universe:A',source:result.source,count:result.rows.length,stored:saved,verifiedQuotes:0,updatedAt:new Date().toISOString(),complete:true,note:'目录独立于报价，仅代表来源名单，不代表目前仍上市或行情新鲜'};
 await db.put('meta',state);return state;
}
// Batch-fill only symbols present in the independent directory. No made-up price.
async function fillQuotes({db,provider,limit=350,stop=()=>false,onEvent=()=>{},wait=delay,now=()=>Date.now()}={}){
 if(!db?.all||!provider?.tencentQuotes)throw Error('缺少数据库或独立腾讯行情源');
 const all=await db.all('universe'),catalog=all.filter(x=>x.market==='A'),old=new Map((await db.all('stocks')).filter(x=>x.market==='A').map(x=>[x.code,x]));
 let due=catalog.filter(x=>{const p=old.get(x.code);return !p?.price||!p.fetchedAt||Date.parse(p.fetchedAt)<now()-12*3600000;});
 // Fixed ordering ensures a paused job can continue from fresh or skipped codes.
 due.sort((a,b)=>Number(Boolean(old.get(a.code)?.price))-Number(Boolean(old.get(b.code)?.price))||a.code.localeCompare(b.code));
 const chosen=due.slice(0,Math.max(0,Math.min(6000,Math.floor(limit)))),stats={requested:chosen.length,received:0,saved:0,rejected:0,batchFailures:0,provider:'腾讯逐批报价',catalogSize:catalog.length,processed:0,pending:0,circuitOpen:false,errors:[]};
 let failedInARow=0;
 for(let i=0;i<chosen.length&&!stop();i+=35){const batch=chosen.slice(i,i+35);let rows=[];let firstErr=null;
  try{rows=await provider.tencentQuotes(batch.map(x=>x.code),'A')}catch(e){firstErr=e}
  // A separate vendor for known codes can recover Tencent outages or sparse responses.
  if(provider.sinaQuotes&&(firstErr||rows.length<batch.length/2)){
   const received=new Set(rows.map(x=>x.code)),missing=batch.filter(x=>!received.has(x.code));
   if(missing.length)try{const more=await provider.sinaQuotes(missing.map(x=>x.code),'A');rows=[...rows,...more]}catch(e){stats.errors.push('新浪备源第'+(Math.floor(i/35)+1)+'批：'+e.message)}
  }
  if(!rows.length){stats.batchFailures++;failedInARow++;stats.errors.push('第'+(Math.floor(i/35)+1)+'批：'+(firstErr?.message||'所有报价源均未返回有效数据'));}else failedInARow=0;
  const set=new Set(batch.map(x=>x.code));const valid=rows.filter(x=>set.has(x.code)&&x.market==='A'&&Number.isFinite(+x.price)&&x.price>0&&x.quoteTime&&Number.isFinite(Date.parse(x.quoteTime))&&Math.abs(now()-Date.parse(x.quoteTime))<7*86400000);
  const known=valid.filter(x=>{const oldQuote=old.get(x.code);return !oldQuote?.price||!oldQuote.fetchedAt||Date.parse(oldQuote.fetchedAt)<now()-24*3600000||Math.abs(oldQuote.price-x.price)/oldQuote.price<.35;});
  const matched=[...new Map(known.map(x=>[x.key,x])).values()];try{if(matched.length)await db.putMany('stocks',matched)}catch(e){stats.batchFailures++;stats.errors.push('本地写入失败 '+e.message);continue;}
  stats.received+=rows.length;stats.saved+=matched.length;stats.rejected+=batch.length-matched.length;stats.processed+=batch.length;
  onEvent({...stats,phase:'quotes',done:Math.min(i+35,chosen.length)});if(failedInARow>=3){stats.circuitOpen=true;stats.errors.push('连续3批未获取报价，暂停本轮而非盲目请求后续股票');break;}await wait(220);
 }
 stats.pending=chosen.length-stats.processed;
 await db.put('meta',{key:'universeQuote:A',...stats,updatedAt:new Date().toISOString(),complete:stats.pending===0&&stats.batchFailures===0&&stats.rejected===0});
 return stats;
}
return{SOURCES,normalize,parseCsv,parseJson,parseSina,validDirectory,download,syncDirectory,fillQuotes};
});
