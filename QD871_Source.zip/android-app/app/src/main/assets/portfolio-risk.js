/* Pure rules for real, confirmed holdings. Explicit priority, never auto-trades. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.QuantRisk=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';const VERSION='QD7.0-exit-rules-v1';
function evaluate(holding,decision,{today=new Date(),freshHours=96}={}){
 const market=holding?.market==='HK'?'HK':'A',qty=+holding?.shares||0;
 if(qty<=0)return {level:'none',label:'无持仓',sellable:0,reason:'持仓为零'};
 const trades=(holding?.trades||[]).filter(x=>x.side==='买入'||x.side==='buy');
 const tz=market==='HK'?'Asia/Hong_Kong':'Asia/Shanghai',todayString=new Intl.DateTimeFormat('sv-SE',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(today));
 const buyToday=market==='A'?trades.filter(x=>x.date===todayString).reduce((s,x)=>s+(Number(x.shares)||0),0):0;
 const sellable=Math.max(0,qty-buyToday);
 const quoteTime=Date.parse(decision?.quoteTime||''),now=+new Date(today);
 const verified=decision?.quoteOK===true&&decision?.barsOK===true&&Number.isFinite(quoteTime)&&quoteTime<=now+60000&&now-quoteTime<=freshHours*3600000;
 if(!verified)return {level:'unverified',label:'数据待核验｜禁止强制卖出结论',sellable,reason:'持仓报价/K线不新鲜或未通过一致性检查',version:VERSION};
 const price=Number(decision?.price),cost=Number(holding.cost),atr=Number(decision?.technical?.atr20);
 const riskDistance=Number.isFinite(atr)&&atr>0?Math.max(2.5*atr,0.08*cost):0.08*cost;
 const hardStop=cost-riskDistance;
 const hardBreak=Number.isFinite(cost)&&cost>0&&price>0&&price<=hardStop;
 const confirmedBadEvent=!!decision?.eventRisks?.length; // Event title alone needs source verification. Not hard-exit.
 const trendBroken=decision?.technical?.eligible&&decision?.technical?.long===false;
 const financialAlert=decision?.finOK&&decision?.risks?.some(x=>/负债率|经营现金流/.test(x));
 if(hardBreak){return {level:'exit',label:'规则触发退出｜尽快核实卖出条件',sellable,stop:Math.round(hardStop*100)/100,reason:`报价 ${price} 已低于成本风险界限 ${hardStop.toFixed(2)}；先核实停牌、涨跌停和可卖股数。成交不能保证`,version:VERSION};}
 if(confirmedBadEvent||financialAlert)return {level:'urgent',label:'重大事件/财务风险｜优先核查减仓或退出',sellable,stop:Math.round(hardStop*100)/100,reason:'公告标题或财报风险异常，必须核查原文与披露时点，不能只凭关键词自动卖出',version:VERSION};
 if(trendBroken)return {level:'warning',label:'趋势转弱｜核查退出计划',sellable,stop:Math.round(hardStop*100)/100,reason:'趋势与动量过滤失败，参考止损价位来自ATR/成本，不是保证成交价',version:VERSION};
 return {level:'hold',label:'持仓观察｜继续执行风险规则',sellable,stop:Math.round(hardStop*100)/100,reason:'本轮没有触发退出门槛；无风险保证',version:VERSION};
}
return {VERSION,evaluate};
});
