/* Compatibility helpers for older Android System WebView versions.
 * Modern JS syntax still requires reasonably up-to-date Android System WebView. */
(function(){'use strict';
if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{configurable:true,value:function(i){i=Math.trunc(i)||0;return this[i<0?this.length+i:i]}});
if(!String.prototype.at)Object.defineProperty(String.prototype,'at',{configurable:true,value:function(i){i=Math.trunc(i)||0;return this[i<0?this.length+i:i]}});
if(!Object.fromEntries)Object.fromEntries=function(entries){const o={};for(const [k,v] of entries)o[k]=v;return o};
if(!String.prototype.replaceAll)Object.defineProperty(String.prototype,'replaceAll',{configurable:true,value:function(a,b){return String(this).split(a).join(b)}});
})();
