/* QuantDesk V6.8 research engine. Rules are reproducible, not institutionally certified.
   Signal at completed daily close -> next session open. No assumed high win rate.
   Avoid using future financial disclosure, pending candle, missing quote, or stale data.
*/
(function(root,factory){const lib=factory();if(typeof module==='object'&&module.exports)module.exports=lib;root.QuantEvidence=lib;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const VERSION='QDE-6.8-transparent', MS=86400000;
const finite=x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x))?Number(x):null;
const round=(x,n=2)=>Number.isFinite(x)?Number(x.toFixed(n)):null;
const avg=x=>x.reduce((s,v)=>s+v,0)/x.length;
const bj=d=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);
const clock=d=>new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hour12:false}).format(d);
function inSession(now){const dow=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Shanghai',weekday:'short'}).format(now),t=clock(now);return !['Sat','Sun'].includes(dow)&&((t>='09:30'&&t<='11:30')||(t>='13:00'&&t<='15:00'));}
function clean(raw){const map=new Map();for(const x of raw||[]){if(!/^\d{4}-\d\d-\d\d$/.test(String(x?.date||'')))continue;
 const o=finite(x.open),h=finite(x.high),l=finite(x.low),c=finite(x.close),v=finite(x.volume);
 if([o,h,l,c].some(z=>z===null||z<=0)||h<Math.max(o,c,l)||l>Math.min(o,c,h)||v===null||v<0)continue;
 map.set(x.date,{date:x.date,open:o,high:h,low:l,close:c,volume:v});}
 return [...map.values()].sort((a,b)=>a.date.localeCompare(b.date));}
function technical(raw){const a=clean(raw),n=a.length;if(n<253)return{eligible:false,bars:n,reason:'至少需要253根有效且已完成的日K线',long:false,rankKey:null};
 const close=a[n-1].close,ma200=avg(a.slice(-200).map(x=>x.close)),ma60=avg(a.slice(-60).map(x=>x.close));
 const mom12=(a[n-22].close/a[n-253].close-1)*100;
 const mom6=(a[n-22].close/a[n-127].close-1)*100;
 const logret=[];for(let i=n-59;i<n;i++)logret.push(Math.log(a[i].close/a[i-1].close));
 const mean=avg(logret),vol=Math.sqrt(avg(logret.map(x=>(x-mean)**2)))*Math.sqrt(252)*100;
 const d20=a.slice(-20),high20=Math.max(...d20.map(x=>x.high)),pullback=(close/high20-1)*100;
 let tr=0;for(let i=n-20;i<n;i++)tr+=Math.max(a[i].high-a[i].low,Math.abs(a[i].high-a[i-1].close),Math.abs(a[i].low-a[i-1].close));
 const atr20=tr/20,trend=close>ma200&&close>ma60&&ma60>ma200*0.96;
 const momentum=mom12>0&&mom6>0,highVol=vol>85,stressed=pullback < -18;
 const long=trend&&momentum&&!highVol&&!stressed;
 // Ranking is not a win probability; scale-free momentum / realized risk.
 const rankKey=long?round((0.7*mom12+0.3*mom6)/Math.max(15,vol),6):null;
 return{eligible:true,bars:n,lastDate:a[n-1].date,close:round(close,3),ma200:round(ma200,3),ma60:round(ma60,3),momentum12mSkip1m:round(mom12,3),momentum6mSkip1m:round(mom6,3),annualVol60:round(vol,2),drawdown20:round(pullback,2),atr20:round(atr20,3),aboveMA200:close>ma200,positiveMomentum:mom12>0,highVol,long,rankKey,
   gates:{trend,momentum,lowVol:!highVol,limitedPullback:!stressed},explain:long?'中长期趋势和两档动量同时通过，波动风险仍需控制':!trend?'长期趋势未通过':!momentum?'中期动量未同时转强':highVol?'波动率过高':'短期回撤较大'};
}
function reportsAt(financial,now){const cutoff=now.getTime();const list=(financial||[]).filter(x=>x&&x.type&&x.reportDate&&x.noticeDate&&Number.isFinite(Date.parse(x.noticeDate))&&Date.parse(x.noticeDate)<=cutoff);
 const summaries=list.filter(x=>x.type==='summary').sort((a,b)=>b.reportDate.localeCompare(a.reportDate));const summary=summaries[0]||null;
 const matching=list.filter(x=>x.reportDate===summary?.reportDate);const types=new Set(matching.map(x=>x.type));const complete=['summary','balance','income','cashflow'].every(x=>types.has(x));
 const bal=matching.find(x=>x.type==='balance'),cash=matching.find(x=>x.type==='cashflow');
 const debt=finite(bal?.debtRatio)??finite(summary?.debtRatio),profit=finite(summary?.profit),ocf=finite(cash?.ocf);
 const cashCoverage=profit!==null&&profit>0&&ocf!==null?ocf/profit:null;
 const days=summary?(cutoff-Date.parse(summary.reportDate+'T00:00:00+08:00'))/MS:null;
 const current=complete&&days!==null&&days>=0&&days<=550;
 const negative=(debt!==null&&debt>85)||(cashCoverage!==null&&cashCoverage<0);
 return{summary,types:[...types],complete,current,days:days===null?null:Math.round(days),debt,cashCoverage:round(cashCoverage,3),negative};
}
function evaluate({bars=[],quote=null,financial=[],notices=[],holding=null,marketContext=null,now=new Date()}={}){
 const start=Date.now();now=new Date(now);
 const cut=bj(now),all=clean(bars),forming=all.some(x=>x.date===cut)&&clock(now)<'15:10';
 // CRITICAL: discard future rows and unfinished current bar for both live and historical evaluation.
 const a=all.filter(x=>x.date<cut||(x.date===cut&&clock(now)>='15:10'));
 const t=technical(a),fin=reportsAt(financial,now),issues=[],risks=[],signals=[];
 const snap=finite(quote?.price),last=finite(a.at(-1)?.close),qts=Date.parse(quote?.quoteTime||''),age=Number.isFinite(qts)?Math.round((now-qts)/60000):null;
 const mismatch=snap!==null&&last!==null&&(snap>last*1.5||snap<last*.65);
 const quoteOK=snap!==null&&snap>0&&!mismatch&&age!==null&&age>=-5&&age<=(inSession(now)?15:96*60);
 const barAge=t.lastDate?(now-Date.parse(t.lastDate+'T16:00:00+08:00'))/MS:null;
 const barsOK=t.eligible&&barAge!==null&&barAge>=-1&&barAge<=12;
 const amount=finite(quote?.amount),market=quote?.market||'A';
 const liquidityOK=amount!==null&&amount>=(market==='HK'?1000000:20000000); // provider reported trading currency units
 if(forming)issues.push('盘中未完成的日K已排除');if(!t.eligible)issues.push(t.reason);
 if(t.eligible&&!barsOK)issues.push('日K数据过期或日期异常');
 if(!quoteOK)issues.push(mismatch?'报价与日K差异异常，需检查复权/单位':'报价缺少可靠时间或过期');
 if(!liquidityOK)issues.push('成交额不足或单位未核验，不满足本策略流动性门槛');
 if(!fin.current)issues.push('四类同季度财报及披露时点未完全核验');
 if(fin.negative)risks.push('负债率或经营现金流触发风险提醒');
 const safeNotices=(notices||[]).filter(x=>x?.date&&Number.isFinite(Date.parse(x.date))&&Date.parse(x.date)<=now.getTime()&&now-Date.parse(x.date)<90*MS);
 const eventWords=/(退市|立案调查|重大诉讼|处罚决定|停牌|减持计划|破产重整|重大风险提示)/;
 const eventRisks=safeNotices.filter(x=>eventWords.test(x.title||'')).slice(0,3).map(x=>x.title);
 if(eventRisks.length)risks.push('近期公告需要人工核对：'+eventRisks.join('；'));
 if(!safeNotices.length)issues.push('没有核验到近期公告记录，不代表没有公告风险');
 if(t.eligible){signals.push(`12-1动量 ${t.momentum12mSkip1m}% / 6-1动量 ${t.momentum6mSkip1m}%`);signals.push(`MA60 ${t.ma60} / MA200 ${t.ma200}，60日年化波动 ${t.annualVol60}%`);signals.push(`20日高点回撤 ${t.drawdown20}% / ATR20 ${t.atr20}`);}
 const sectorPct=finite(marketContext?.sectorPct),sectorRisk=sectorPct!==null&&sectorPct<=-4;
 if(sectorRisk)risks.push('板块近期显著下跌，待核实数据时点');
 const eligibleData=quoteOK&&barsOK;
 const financeReady=fin.current&&!fin.negative&&safeNotices.length>0&&!eventRisks.length;
 // This is a *research allocation cap*, not an executable order or volatility forecast.
 const riskPerShare=t.eligible?Math.max(t.atr20*2.5,t.close*.08):null;
 const suggestedMaxPct=riskPerShare?round(Math.min(10,.5/(riskPerShare/t.close)),2):null;
 let action,reason,severity='watch';
 if(!eligibleData){action='数据不足｜暂停买卖判断';reason='历史K线/报价时间未达到研究条件';severity='missing';}
 else if(holding&&(!t.long||fin.negative||eventRisks.length||sectorRisk)){
  action='持仓风险警戒｜核查减仓条件';reason='技术条件失效或存在基本面、公告、板块风险；不代表立刻卖单';severity='risk';}
 else if(holding){action='持仓趋势观察｜控制仓位';reason='趋势条件尚在，须核对流动性及实际仓位';}
 else if(t.long&&financeReady&&liquidityOK&&!sectorRisk){action='研究候选｜等待交易确认';reason='动量、趋势、流动性及本次可见风险闸门通过；不是必然上涨信号';}
 else if(t.long){action='技术候选｜风控信息待核验';reason='技术条件满足，但不能跳过财务/公告/流动性与板块风险审查';}
 else{action='暂不列入趋势候选';reason=t.explain;}
 return{version:VERSION,action,severity,reason,ready:eligibleData,quoteOK,barsOK,liquidityOK,finOK:fin.current,completeStatements:fin.complete,reportTypes:fin.types,cashCoverage:fin.cashCoverage,debtRatio:fin.debt,verifiedAnnouncements:safeNotices.length>0,issues,quoteAgeMinutes:age,lastBarDate:t.lastDate||null,forming,score:null,rankKey:t.rankKey,
  technical:t,chan:{strokes:0,centers:0},patterns:[],groups:[],indicators:{breakout:null,support:t.ma60??null,risk:round(t.close-riskPerShare,3)},signals,risks,sectorPct,eventRisks,suggestedMaxPct,
  price:snap,quoteTime:quote?.quoteTime||null,financeDate:fin.summary?.reportDate||null,noticeDate:fin.summary?.noticeDate||null,analysisMs:Math.max(0,Date.now()-start),evaluatedAt:now.toISOString(),
  disclaimer:'公开动量研究启发的自主规则；非机构使用代码。仓位仅示意，不能承诺胜率/盈利；无自动下单。'};
}
function limitThreshold(market,code){if(market!=='A')return null;code=String(code||'');if(/^[48]/.test(code))return .29;if(/^(30|68)/.test(code))return .195;return .095;}
function backtest(raw,{costBuy=0.001,costSell=0.0015,split=0.7,initial=100000,market='A',stockCode='000001'}={}){
 const bars=clean(raw);if(bars.length<500)throw Error('需要至少500根连续有效日K才能做粗略样本外检验');
 if(!Number.isFinite(initial)||initial<=0||costBuy<0||costSell<0||split<.55||split>.8)throw Error('回测参数不合法');
 const at=Math.floor(bars.length*split);if(at<253||bars.length-at<100)throw Error('样本量不够');
 let cash=initial,shares=0,entry=null,buyCost=0,curve=[],trades=[],blocked=0,exposure=0,daysHeld=0;
 // signal based solely on the preceding completed close; executed only at today's open.
 let previous=technical(bars.slice(0,at)).long;
 const band=limitThreshold(market,stockCode);
 for(let i=at;i<bars.length;i++){
  const bar=bars[i],prevClose=bars[i-1].close,open=bar.open;
  const lockedBuy=bar.volume<=0||(band!==null&&open>=prevClose*(1+band));
  const lockedSell=bar.volume<=0||(band!==null&&open<=prevClose*(1-band));
  if(previous&&!shares){
   if(lockedBuy)blocked++;else{
    const unit=market==='A'?100:1,lots=Math.floor(cash/(open*(1+costBuy))/unit);
    if(lots>0){shares=lots*unit;buyCost=shares*open*(1+costBuy);cash-=buyCost;entry={date:bar.date,price:open};daysHeld=0;}
   }
  }else if(!previous&&shares&&daysHeld>=1){
   if(lockedSell)blocked++;else{
    const proceeds=shares*open*(1-costSell);cash+=proceeds;trades.push({entry:entry.date,exit:bar.date,net:round(proceeds-buyCost),entryPrice:entry.price,exitPrice:open});shares=0;entry=null;buyCost=0;
   }
  }
  if(shares){daysHeld++;exposure++;}
  curve.push({date:bar.date,equity:cash+shares*bar.close});
  previous=technical(bars.slice(Math.max(0,i-252),i+1)).long;
 }
 let peak=initial,dd=0;for(const x of curve){peak=Math.max(peak,x.equity);dd=Math.min(dd,x.equity/peak-1);}
 const last=curve.at(-1).equity,wins=trades.filter(t=>t.net>0),losses=trades.filter(t=>t.net<=0);
 const profitable=wins.reduce((s,t)=>s+t.net,0),lost=losses.reduce((s,t)=>s-Math.min(0,t.net),0);
 const buyHoldPct=(bars.at(-1).close/bars[at].open-1)*100;
 return{strategy:'V6.8动量(12-1/6-1)+MA60/MA200+波动闸门',mode:'同一 technical() 技术信号函数：不包含财报、公告、行业风控；单股测试不是全市场验证',firstDate:bars[at].date,lastDate:bars.at(-1).date,
  holdoutBars:bars.length-at,totalBars:bars.length,returnPct:round((last/initial-1)*100),buyHoldPct:round(buyHoldPct),excessPct:round((last/initial-1)*100-buyHoldPct),
  maxDrawdownPct:round(dd*100),trades:trades.length,winRate:trades.length>=30?round(100*wins.length/trades.length):null,
  winCount:wins.length,profitFactor:trades.length>=30&&lost>0?round(profitable/lost,2):null,openPosition:shares>0,blocked,exposurePct:round(exposure/curve.length*100),initial,final:round(last),
  verified:false,whyNotVerified:'仅单股后段留出；不含历史公告与财报、退市股票、全市场组合、完整复权/税费/盘口成交验证。',
  assumptions:'信号仅用前一根收盘日K，在次日开盘尝试；A股按100股整数交易并模拟T+1。买0.10%卖0.15%为假设成本；涨跌停阈值近似且不含ST、停牌复牌特例与盘口深度。'};
}
return{clean,technical,reportsAt,evaluate,backtest,inSession,limitThreshold};
});
