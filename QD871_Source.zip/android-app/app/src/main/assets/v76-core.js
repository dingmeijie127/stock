/* V7.6: deterministic market regime, symbol lookup and ledger utilities.
   Research-only regime: parameter choices NOT empirically validated. */
(function(root,factory){const x=factory();if(typeof module==='object'&&module.exports)module.exports=x;root.QuantV76=x;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const iso=x=>String(x||'').slice(0,10);
function directoryIndex({universe=[],stocks=[],holdings=[],seed=[]}={}){
 const map=new Map();for(const source of [seed,universe,stocks,holdings])for(const x of source||[]){const code=String(x.code||'').trim(),market=x.market==='HK'?'HK':'A';if(!/^(\d{5}|\d{6})$/.test(code)||!(x.name||'').trim())continue;map.set(market+':'+code,{code,market,name:String(x.name).trim(),source:x.source||'本地数据'});}return map;
}
function sma(arr,n,end=arr.length){if(end<n)return null;let sum=0;for(let i=end-n;i<end;i++){const v=Number(arr[i]);if(!Number.isFinite(v)||v<=0)return null;sum+=v;}return sum/n;}
function stdev(a){if(a.length<2)return null;const m=a.reduce((s,v)=>s+v,0)/a.length;return Math.sqrt(a.reduce((s,v)=>s+(v-m)**2,0)/(a.length-1));}
function maxDrawdown(vals){let peak=-Infinity,worst=0;for(const v of vals){if(v>peak)peak=v;if(peak>0)worst=Math.max(worst,1-v/peak);}return worst;}
function regime({indexBars=[],breadthBars=[],asOf,market='A'}={}){
 const date=iso(asOf)||null;
 const series=indexBars.filter(x=>Number(x.close)>0&&(!date||iso(x.date)<=date)).sort((a,b)=>iso(a.date).localeCompare(iso(b.date)));
 if(series.length<210)return{market,state:'insufficient',label:'数据不足',reason:`指数日K${series.length}根，至少210根`,asOf:series.at(-1)?.date||null,metrics:{},verified:false};
 const close=series.map(x=>Number(x.close)),n=close.length,c=close[n-1],ma60=sma(close,60),ma200=sma(close,200),ma200Prev=sma(close,200,n-10),dd120=maxDrawdown(close.slice(-120));
 const lr=close.slice(-21).map((v,i,a)=>i?Math.log(v/a[i-1]):null).filter(x=>x!==null),vol20=stdev(lr)*Math.sqrt(252);
 const breadth=breadthBars.filter(x=>x&&x.length>=60).map(x=>{const d=x.filter(z=>!date||iso(z.date)<=date).slice(-60);if(d.length<60)return null;const m=sma(d.map(z=>Number(z.close)),60);return m>0&&Number(d.at(-1).close)>m?1:0;}).filter(x=>x!==null);
 const b=breadth.length>=100?breadth.reduce((s,v)=>s+v,0)/breadth.length:null;
 const up=c>ma200&&ma60>ma200&&ma200>=ma200Prev&&dd120<.15;
 const down=c<ma200&&ma60<ma200&&ma200<ma200Prev&&dd120>.12;
 // Treat breadth as a guard only if coverage is high enough; never invent it.
 const bull=up&&(b===null||b>=.55),bear=down&&(b===null||b<=.45);
 const state=bull?'bull':bear?'bear':'sideways';const label={bull:'牛市趋势',bear:'熊市趋势',sideways:'震荡／猴市'}[state];
 const metrics={indexClose:c,ma60,ma200,ma200Slope10:(ma200/ma200Prev-1),dd120,vol20,breadth:b,breadthCount:breadth.length};
 return{market,state,label,metrics,asOf:series.at(-1).date,verified:b!==null,reason:b===null?'指数趋势模型已计算；全市场广度不足100只，不代表完整市场确认':'指数趋势与本地市场广度共同判断'};
}
function sellable(ledger,market,code,date){const h=(ledger?.holdings||[]).find(x=>(x.market||'A')===market&&x.code===code);if(!h)return 0;const shares=Number(h.shares)||0;const purchased=(ledger?.trades||[]).filter(t=>(t.market||'A')===market&&t.code===code&&t.side==='买入'&&t.date===date).reduce((s,t)=>s+Number(t.shares||0),0);return Math.max(0,shares-(market==='A'?purchased:0));}
// Synthetic equal-weighted universe index. Survivor/sampling bias is explicitly disclosed by UI.
function sampleRegime({series=[],market='A',minStocks=100,minDays=210}={}){
 const valid=series.map(a=>a.filter(x=>Number(x.close)>0&&/^\d{4}-\d{2}-\d{2}$/.test(iso(x.date))).sort((x,y)=>iso(x.date).localeCompare(iso(y.date))).slice(-310)).filter(x=>x.length>=minDays);
 if(valid.length<minStocks)return{market,state:'insufficient',label:'数据不足',reason:`仅${valid.length}只有足够日K，至少需${minStocks}只`,asOf:null,verified:false,metrics:{sampleCount:valid.length}};
 const retByDay=new Map(),barsByDay=new Map();
 for(const bs of valid){for(let i=1;i<bs.length;i++){const d=iso(bs[i].date),p=Number(bs[i-1].close),c=Number(bs[i].close);if(!p||Math.abs(c/p-1)>.5)continue;const r=retByDay.get(d)||[];r.push(c/p-1);retByDay.set(d,r);} }
 const eligible=[...retByDay].filter(([,r])=>r.length>=minStocks).sort((a,b)=>a[0].localeCompare(b[0])).slice(-310);
 let proxy=100;for(const [date,r] of eligible){proxy*=1+r.reduce((s,v)=>s+v,0)/r.length;barsByDay.set(date,{date,close:proxy});}
 const result=regime({indexBars:[...barsByDay.values()],breadthBars:valid,market});
 return{...result,verified:result.state!=='insufficient'&&valid.length>=minStocks,reason:result.state==='insufficient'?result.reason:`以${valid.length}只本地有历史K线的股票构建等权代理指数；非交易所官方指数，存在样本偏差；${result.reason}`,metrics:{...result.metrics,sampleCount:valid.length}};
}
return{directoryIndex,regime,sampleRegime,sellable,maxDrawdown,sma};});
