/* QuantDesk V6 research-only quantitative library.
 * All patterns and Chan structures use only confirmed bars available at evaluation time.
 * No simulated/upcoming pivots, no predicted win probability, no network dependencies.
 */
(function(root,factory){const value=factory();if(typeof module==='object'&&module.exports)module.exports=value;root.QuantStrategies=value;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const E=typeof QuantEngine!=='undefined'?QuantEngine:require('./engine.js');
const r=(x,n=2)=>Number.isFinite(x)?Number(x.toFixed(n)):null;
const number=x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x))?Number(x):null;
const mean=x=>x.reduce((s,n)=>s+n,0)/x.length;
function cleanBars(raw){
 const byDate=new Map();for(const b of raw||[]){if(!/^\d{4}-\d\d-\d\d$/.test(String(b?.date||'')))continue;
  const o=number(b.open),h=number(b.high),l=number(b.low),c=number(b.close),v=number(b.volume);
  if([o,h,l,c].some(x=>x===null||x<=0)||h<Math.max(o,c,l)||l>Math.min(o,c,h)||v===null||v<0)continue;
  byDate.set(b.date,{date:b.date,open:o,high:h,low:l,close:c,volume:v});
 }return [...byDate.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
// Containment normalization. If consecutive bars contain one another, extend in the
// established direction. Preserve only a completed, dated representation of a bar.
function removeInclusions(raw){const bars=cleanBars(raw),out=[];
 for(const b of bars){if(!out.length){out.push({...b});continue;}
  const last=out[out.length-1],inclusive=(b.high<=last.high&&b.low>=last.low)||(b.high>=last.high&&b.low<=last.low);
  if(!inclusive){out.push({...b});continue;}
  const prior=out[out.length-2],up=prior?(last.high>=prior.high&&last.low>=prior.low):b.close>=last.close;
  const high=up?Math.max(last.high,b.high):Math.min(last.high,b.high),low=up?Math.max(last.low,b.low):Math.min(last.low,b.low);
  out[out.length-1]={...last,high,low,close:b.close,date:b.date,volume:last.volume+b.volume};
 }
 return out;
}
function fractals(bars){const f=[];for(let i=1;i<bars.length-1;i++){
 const p=bars[i-1],b=bars[i],n=bars[i+1];const top=b.high>p.high&&b.high>n.high&&b.low>p.low&&b.low>n.low;
 const bottom=b.low<p.low&&b.low<n.low&&b.high<p.high&&b.high<n.high;
 if(top!==bottom&&(top||bottom))f.push({type:top?'top':'bottom',index:i,date:b.date,price:top?b.high:b.low});
 }return f;}
function chan(raw){const bars=removeInclusions(raw),all=fractals(bars),pivots=[];
 // Alternating confirmed fractals, with four normalized bars minimum separation.
 for(const f of all){const prev=pivots.at(-1);if(!prev){pivots.push(f);continue;}
  if(prev.type===f.type){if((f.type==='top'&&f.price>prev.price)||(f.type==='bottom'&&f.price<prev.price))pivots[pivots.length-1]=f;
  }else if(f.index-prev.index>=4&&((prev.type==='bottom'&&f.price>prev.price)||(prev.type==='top'&&f.price<prev.price)))pivots.push(f);
 }
 const strokes=[];for(let i=1;i<pivots.length;i++){const a=pivots[i-1],b=pivots[i];strokes.push({from:a.date,to:b.date,direction:a.type==='bottom'?'上':'下',high:Math.max(a.price,b.price),low:Math.min(a.price,b.price),start:a.index,end:b.index});}
 const centers=[];for(let i=2;i<strokes.length;i++){
  const part=strokes.slice(i-2,i+1),upper=Math.min(...part.map(x=>x.high)),lower=Math.max(...part.map(x=>x.low));
  if(lower<upper)centers.push({start:part[0].from,end:part[2].to,upper:r(upper),lower:r(lower)});
 }
 const last=strokes.at(-1),center=centers.at(-1),close=bars.at(-1)?.close;
 const location= !center?'未形成已确认中枢':close>center.upper?'价格在最近中枢上方':close<center.lower?'价格在最近中枢下方':'价格位于最近中枢内';
 return {barCount:bars.length,fractals:all.length,strokes:strokes.length,centers:centers.length,lastStroke:last?.direction||'未知',lastCenter:center||null,location,
  // No claim of canonical first/second/third buys without a full segment/divergence engine.
  setup:center&&last?.direction==='上'&&close>center.upper?'中枢上方趋势观察':center&&close<center.lower?'中枢下方回避观察':'未确认缠论买点',
  disclaimer:'客观分型/笔/三笔重叠中枢研究模型；不是完整标准缠论线段、背驰或一二三买卖点。'};
}
function patterns(raw){const a=cleanBars(raw),n=a.length,out=[];if(n<24)return out;const last=a.at(-1),prev=a.at(-2),close=last.close;
 const box=a.slice(-21,-1),hi=Math.max(...box.map(x=>x.high)),lo=Math.min(...box.map(x=>x.low));
 const v20=mean(box.map(x=>x.volume)),volumeRatio=v20>0?last.volume/v20:0;
 if(close>hi*1.003&&volumeRatio>=1.2)out.push({name:'箱体放量突破',direction:1,strength:2,trigger:r(hi),invalid:r(lo),explain:`越过过去20根K线区间高位，成交量为前20日均量${r(volumeRatio)}倍`});
 if(close<lo*.997)out.push({name:'箱体跌破',direction:-1,strength:2,trigger:r(lo),invalid:r(hi),explain:'收盘跌破前20根K线低位'});
 if(last.close>last.open&&prev.close<prev.open&&last.open<=prev.close&&last.close>=prev.open)out.push({name:'看涨吞没',direction:1,strength:1,explain:'最新两根日K形成多头吞没，单独使用误判率高'});
 if(last.close<last.open&&prev.close>prev.open&&last.open>=prev.close&&last.close<=prev.open)out.push({name:'看跌吞没',direction:-1,strength:1,explain:'最新两根日K形成空头吞没'});
 const range=last.high-last.low,body=Math.abs(last.close-last.open),lower=Math.min(last.open,last.close)-last.low;
 if(range>0&&lower/range>.55&&body/range<.3&&last.close>last.low+range*.55)out.push({name:'长下影线',direction:1,strength:1,explain:'单根长下影是观察线索，不是已确认反转'});
 if(n>=65){const hh=Math.max(...a.slice(-61,-1).map(x=>x.high));if(close>hh&&volumeRatio>1.35)out.push({name:'60日高位趋势突破',direction:1,strength:2,trigger:r(hh),invalid:r(hi),explain:'突破60根K线区间高位，且有量能配合'});}
 // Confirmed double bottom: two swing lows formed before the newest bar, spaced >= 5,
 // within 4% and separated by a rebound >= 6%. Confirmation via close above neckline.
 if(n>=45){const starts=Math.max(2,n-65),mins=[];
  for(let i=starts;i<=n-3;i++)if(a[i].low<a[i-1].low&&a[i].low<a[i+1].low)mins.push(i);
  loop:for(let j=mins.length-1;j>=1;j--){for(let k=j-1;k>=0;k--){let i=mins[k],t=mins[j];if(t-i<5||t-i>40)continue;
    let low1=a[i].low,low2=a[t].low;if(Math.abs(low1-low2)/Math.max(low1,low2)>.04)continue;
    let neckline=Math.max(...a.slice(i+1,t).map(x=>x.high));if(neckline/Math.max(low1,low2)<1.06)continue;
    if(close>neckline*1.003&&t<n-3){out.push({name:'双底颈线确认',direction:1,strength:2,trigger:r(neckline),invalid:r(Math.min(low1,low2)),explain:'两个已确认低点和颈线突破，未用未来日K'});break loop;}
  }}
 }
 return out;
}
function analyze(raw,quote=null,financial=[],opts={}){
 const now=opts.now?new Date(opts.now):new Date();let bars=cleanBars(raw);
 // During the Chinese trading session the provider's newest daily bar may still change.
 const bjDate=now.toLocaleDateString('sv-SE',{timeZone:'Asia/Shanghai'}),bjTime=now.toLocaleTimeString('en-GB',{timeZone:'Asia/Shanghai',hour12:false});
 const forming=bars.at(-1)?.date===bjDate&&bjTime<'15:10:00';
 if(forming)bars=bars.slice(0,-1);
 const ind=E.indicators(bars),ch=chan(bars),pat=patterns(bars),reasons=[],risks=[],groups=[],end=bars.at(-1),lastDate=end?.date||null;
 const quoteTs=quote?.quoteTime?Date.parse(quote.quoteTime):NaN;
 const quoteAgeH=Number.isFinite(quoteTs)?(now.getTime()-quoteTs)/3600000:null;
 const barAgeDays=lastDate?(now.getTime()-Date.parse(lastDate+'T16:00:00+08:00'))/86400000:null;
 const stale=forming||!end||bars.length<80||barAgeDays>10||barAgeDays < -2||quoteAgeH===null||quoteAgeH>96||quoteAgeH < -1;
 let score=0;
 if(forming)risks.push('当前交易日的日K可能尚未收盘，已剔除未完成K线，今日买点需要收盘再确认');
 if(bars.length<80)risks.push('历史日K不足80根，无法有效判断多周期趋势');
 if(barAgeDays>10)risks.push(`日K停留在${lastDate}，可能已过期`);
 if(quoteAgeH===null)risks.push('行情缺少可核验的报价时间');else if(quoteAgeH>96||quoteAgeH< -1)risks.push('报价不在最近有效时间范围，必须联网核查');
 if(ind.ma20!==null&&ind.ma60!==null){let points=ind.close>ind.ma20&&ind.ma20>ind.ma60?2:ind.close<ind.ma20&&ind.ma20<ind.ma60?-2:0;
  if(ind.macd?.hist>0&&points>0)points++;if(ind.macd?.hist<0&&points<0)points--;
  groups.push({name:'趋势与动量',value:points,limit:3});score+=points*12;
  reasons.push(points>=2?'中短期均线呈上升结构':points<=-2?'趋势偏弱，应优先控制风险':'均线与动量信号不一致');
 }
 const bp=pat.reduce((s,x)=>s+(x.direction*x.strength),0),patScore=Math.max(-2,Math.min(2,bp));groups.push({name:'K线形态',value:patScore,limit:2});score+=patScore*9;
 if(pat.length)reasons.push(...pat.slice(0,2).map(x=>x.name+'（'+x.explain+'）'));
 const chScore=ch.centers&&ch.lastStroke==='上'&&ch.location.includes('上方')?1:ch.centers&&ch.location.includes('下方')?-1:0;
 groups.push({name:'缠论结构观察',value:chScore,limit:1});score+=chScore*8;
 if(ch.centers)reasons.push(ch.location+'；已确认笔'+ch.strokes+'段');
 const vol=bars.length>=21?mean(bars.slice(-21,-1).map(x=>x.volume)):0;
 const ratio=vol>0?end.volume/vol:null;let volScore=ratio!==null&&ratio>=1.2&&end.close>end.open?1:ratio!==null&&ratio>=1.5&&end.close<end.open?-1:0;
 groups.push({name:'量价行为',value:volScore,limit:1});score+=volScore*8;
 let latest=[...(Array.isArray(financial)?financial:[])].filter(x=>x&&x.type==='summary'&&x.reportDate).sort((a,b)=>b.reportDate.localeCompare(a.reportDate))[0];let fundamental=null;
 if(latest){const pub=latest.noticeDate?Date.parse(latest.noticeDate):NaN,period=Date.parse(latest.reportDate);if(!Number.isFinite(pub)||pub>now.getTime()||now.getTime()-period>540*86400000){risks.push('财报缺少有效披露日或报告期过旧，不纳入正向评分');}
  else {let f=E.scoreFundamentals(Array.isArray(financial)?financial:[],quote);if(f.score!=null){fundamental=f.score;let p=f.score>=70?1:f.score<40?-1:0;groups.push({name:'质量与成长因子',value:p,limit:1});score+=p*12;
  reasons.push('财务质量因子'+r(f.score)+'分（不是收益概率）');}else risks.push('财务字段覆盖不足，不使用财务得分');}}
 else risks.push('尚无可核验财务摘要');
 if(ind.rsi14!==null&&ind.rsi14>78)risks.push('RSI高于78，追高风险较高');
 if((quote?.pct??0)>9)risks.push('单日涨幅过大，追涨可能面临涨跌停无法成交');
 const strong=score>=40&&groups.some(x=>x.name==='趋势与动量'&&x.value>=2)&&groups.some(x=>x.name==='K线形态'&&x.value>0);
 const weak=score<=-25;
 const quality=forming?'盘中日K未收盘，暂不确认买点':stale?'数据不足或过期':financial?.length===0?'技术面数据可用，基本面缺失':'数据具备部分验证条件';
 const signal=stale?'先更新数据':weak?'注意风险':strong?'等待买点确认':'继续观察';
 const high=bars.length>=21?Math.max(...bars.slice(-21,-1).map(x=>x.high)):null;
 const low=bars.length>=21?Math.min(...bars.slice(-21,-1).map(x=>x.low)):null;
 const atr=ind.atr14||null;
 let invalid=end&&atr?Math.max(0,end.close-2*atr):null;
 if(low!==null&&invalid!==null)invalid=Math.min(low,invalid);
 return {signal,score:r(score,0),quality,ready:!stale,groups,reasons:reasons.slice(0,8),risks:risks.slice(0,8),chan:ch,patterns:pat,barCount:bars.length,barInProgress:forming,lastDate,quoteTime:quote?.quoteTime||null,volumeRatio:r(ratio),fundamental,
  levels:{breakout:r(high),support:r(low),risk:r(invalid)},
  explanation:'策略融合得分衡量当前证据，不代表上涨概率。没有经过独立样本外验证的策略不提供预计胜率。'};
}
// Strictly causal, next-session open fills. A-shares only; prices are assumed
// forward-adjusted and all data must be historical as-of. Results remain illustrative.
function backtest(raw,opts={}){
 const a=cleanBars(raw);if(a.length<260)throw Error('至少260根有效日K，才能开展保留样本的策略验证');
 const split=Math.max(200,Math.floor(a.length*.7));let cash=100000,shares=0,entry=0,buyDay=-1,entryDate='',trades=[],curve=[],nextAction=0,ref=a[split].open;
 let skipped=0,orders=0;const commission=x=>Math.max(5,x*.0003),slip=.001;
 for(let i=split;i<a.length;i++){
  const b=a[i],prev=a[i-1],limit=opts.limitPct||.10;const change=prev?b.open/prev.close-1:0;
  const suspended=b.volume<=0,lockedUp=change>=limit-.002&&b.high-b.low<.0001,lockedDown=change<=-limit+.002&&b.high-b.low<.0001;
  if(nextAction===1&&!shares){
   if(suspended||lockedUp){skipped++;}else{const buy=b.open*(1+slip),lots=Math.floor((cash-5)/(buy*1.0003)/100),qty=lots*100;
    if(qty>0){const expense=buy*qty+commission(buy*qty);if(expense<=cash){cash-=expense;shares=qty;entry=expense;buyDay=i;entryDate=b.date;orders++;}}}
  }else if(nextAction===-1&&shares&&i>buyDay){
   if(suspended||lockedDown){skipped++;}else{const sell=b.open*(1-slip),gross=sell*shares,fee=commission(gross)+gross*.0005;
    cash+=gross-fee;trades.push({entry:entryDate,exit:b.date,net:r(gross-fee-entry),days:i-buyDay});shares=0;entry=0;orders++;}
  }
  const mark=cash+shares*b.close;curve.push(mark);
  // Only use history up to and INCLUDING today's close; signals execute next open.
  const his=a.slice(0,i+1),close=his.map(x=>x.close),fast=E.ma(close,20),slow=E.ma(close,60);
  const hi=Math.max(...his.slice(-21,-1).map(x=>x.high));
  nextAction=shares?(fast<slow||his.at(-1).close<slow*.975?-1:0):(fast>slow&&his.at(-1).close>hi*1.003&&his.at(-1).volume>1.2*mean(his.slice(-21,-1).map(x=>x.volume))?1:0);
 }
 let peak=100000,maxdd=0;for(const v of curve){peak=Math.max(peak,v);maxdd=Math.min(maxdd,v/peak-1)}
 const net=curve.at(-1),winCount=trades.filter(t=>t.net>0).length;
 return{firstDate:a[split].date,lastDate:a.at(-1).date,holdoutBars:a.length-split,returnPct:r((net/100000-1)*100),benchmarkPct:r((a.at(-1).close/ref-1)*100),drawdownPct:r(maxdd*100),closedTrades:trades.length,winCount,winRate:trades.length>=30?r(100*winCount/trades.length):null,openPosition:shares>0,blockedFills:skipped,executedOrders:orders,trades,
  assumptions:'前70%只用于预热指标，后30%独立模拟；收盘出信号、下一交易日开盘执行，100股整数交易，T+1；单边滑点0.1%，佣金万三最低5元，卖出额外印花税假设万五；无停牌及一字涨跌停可成交假设。未解决幸存者偏差、历史数据修正和公告时点问题，不可推断真实胜率。'};
}
return{cleanBars,removeInclusions,fractals,patterns,chan,analyze,backtest};
});
