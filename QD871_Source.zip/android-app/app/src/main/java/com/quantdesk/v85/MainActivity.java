package com.quantdesk.v85;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.Context;
import android.Manifest;
import android.content.pm.PackageManager;
import android.view.View;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import java.io.*;
import java.util.Locale;
import org.json.JSONObject;

/** Primary screen: fully native downloader, persistent market database first, analysis second. */
public final class MainActivity extends Activity {
    private static final int EXPORT_SQLITE=203;
    private static final int EXPORT_LOG=204;
    private ProgressBar progressBar;
    private TextView downloadProgress,logView;
    private CheckBox allowMobile;
    private TextView status,details;
    private EditText token,lookup;
    private Spinner searchMarket;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean screenLive;
    private static final int DARK=Color.rgb(19,30,45),BLUE=Color.rgb(24,92,175),MUTED=Color.rgb(75,87,105);
    @Override public void onCreate(Bundle state){super.onCreate(state);build();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},300);
    }
    private GradientDrawable background(int color,int radius){GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(radius);return b;}
    private TextView text(String value,int size,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(DARK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void add(LinearLayout col,View widget,int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(top);col.addView(widget,lp);}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private Button button(String caption,int color){Button b=new Button(this);b.setText(caption);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setBackground(background(color,dp(12)));b.setPadding(dp(12),dp(14),dp(12),dp(14));return b;}
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(244,247,251));
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(dp(20),dp(28),dp(20),dp(40));
        scroll.addView(col);setContentView(scroll);
        add(col,text("QuantDesk · 最近两年选股数据仓库",23,true),1);
        TextView sub=text("先建 SQLite → 全市场股票目录 → 最近两年日K → 后台断点续传 → 完整性日志 → 导出数据库",13,false);
        sub.setTextColor(MUTED);add(col,sub,10);
        TextView warning=text("本阶段优先完成 A 股＋港股最近两年未复权日K数据库，供后续选股/量化使用。免费接口不保证退市股和停牌期间的完整覆盖；失败不会冒充成功。默认仅Wi-Fi。",13,false);
        warning.setBackground(background(Color.rgb(255,246,224),dp(10)));warning.setPadding(dp(12),dp(12),dp(12),dp(12));add(col,warning,14);
        add(col,text("Tushare Token（选填，作为行情备用数据源）",14,true),18);
        token=new EditText(this);token.setHint("粘贴你自己的 Token；仅本次采集在内存使用");
        token.setSingleLine(true);token.setTextSize(14);token.setInputType(129);add(col,token,4);
        add(col,text("历史范围：以当天为终点，向前 2 年（每日收盘数据）",14,true),12);
        allowMobile=new CheckBox(this);allowMobile.setText("允许使用手机移动数据（流量可能较大）");
        allowMobile.setChecked(false);add(col,allowMobile,8);
        Button create=button("① 创建 / 打开本地 SQLite 数据库",BLUE);add(col,create,16);
        create.setOnClickListener(v->{VaultDb db=new VaultDb(this);db.getWritableDatabase();db.close();refresh();toast("本地数据库已建立");});
        Button start=button("② 开始/继续：后台下载最近两年日K",Color.rgb(11,110,80));add(col,start,10);
        start.setOnClickListener(v->{
            try {
                VaultDb db=new VaultDb(this);db.getWritableDatabase();db.log("INFO","用户点击后台采集按钮，正在启动服务");db.close();
                Intent job=new Intent(this,HarvestService.class);job.setAction(HarvestService.START);
                job.putExtra("allow_metered",allowMobile.isChecked());job.putExtra("tushare_token",token.getText().toString().trim());
                if(Build.VERSION.SDK_INT>=26)startForegroundService(job);else startService(job);
                token.setText("");toast("后台采集已启动，查看下方进度与日志");
                refresh();downloadProgress.setText("已点击开始：正在启动后台服务、检查网络并加载股票目录……");
            }catch(Exception e){downloadProgress.setText("无法启动："+e.getMessage());toast("无法启动："+e.getMessage());}
        });
        Button pause=button("③ 暂停采集（记录保存在 SQLite）",Color.rgb(166,93,34));add(col,pause,10);
        pause.setOnClickListener(v->{Intent job=new Intent(this,HarvestService.class);job.setAction(HarvestService.PAUSE);
            try{startService(job);toast("已请求暂停，当前网络请求结束后生效");}catch(Exception e){toast("暂停失败："+e.getMessage());}});
        Button export=button("④ 导出全部数据库 .sqlite3",BLUE);add(col,export,10);
        export.setOnClickListener(v->{if(HarvestService.RUNNING.get()){toast("请先暂停并等待采集服务停止，再导出数据库");return;}
            Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.setType("application/octet-stream");
            save.addCategory(Intent.CATEGORY_OPENABLE);save.putExtra(Intent.EXTRA_TITLE,VaultDb.NAME);startActivityForResult(save,EXPORT_SQLITE);
        });
        Button analysis=button("⑤ 打开原版行情与技术分析界面",DARK);add(col,analysis,10);
        analysis.setOnClickListener(v->startActivity(new Intent(this,AnalysisActivity.class)));
        add(col,text("下载实时进度（切后台后通知栏继续显示）",18,true),22);
        progressBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);progressBar.setProgress(0);add(col,progressBar,8);
        downloadProgress=text("未开始。连接 Wi-Fi 后点击开始下载。",13,true);add(col,downloadProgress,8);
        add(col,text("数据库实时状态",18,true),20);
        status=text("正在读取统计…",14,false);status.setTextIsSelectable(true);
        status.setBackground(background(Color.WHITE,dp(12)));status.setPadding(dp(14),dp(14),dp(14),dp(14));add(col,status,8);
        details=text("提示：已取得数据 ≠ 全市场历史已完整核验。失败、未授权、IPO 前无交易数据必须分别检查。",12,false);
        details.setTextColor(MUTED);add(col,details,10);
        Button reload=button("刷新采集状态",Color.rgb(83,99,115));add(col,reload,12);reload.setOnClickListener(v->refresh());
        add(col,text("下载日志（最近 15 条；每只股票写入 SQLite）",17,true),18);
        logView=text("还没有日志",12,false);logView.setTextIsSelectable(true);
        logView.setBackground(background(Color.WHITE,dp(12)));logView.setPadding(dp(12),dp(12),dp(12),dp(12));
        add(col,logView,8);
        Button exportLog=button("导出下载日志 .txt（可分享/打印）",Color.rgb(83,99,115));
        add(col,exportLog,8);
        exportLog.setOnClickListener(v->{Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            save.setType("text/plain");save.addCategory(Intent.CATEGORY_OPENABLE);
            save.putExtra(Intent.EXTRA_TITLE,"QuantDesk-采集日志.txt");startActivityForResult(save,EXPORT_LOG);
        });
        add(col,text("查询已下载的单只股票",18,true),20);
        searchMarket=new Spinner(this);
        ArrayAdapter<String> option=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,new String[]{"A","HK"});
        option.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        searchMarket.setAdapter(option);add(col,searchMarket,5);
        lookup=new EditText(this);lookup.setSingleLine(true);lookup.setHint("例如 600519 或 00700");
        lookup.setInputType(2);add(col,lookup,5);
        Button inspect=button("查询本地 K 线 / 财报 / 采集状态",BLUE);add(col,inspect,8);
        inspect.setOnClickListener(v->{
            VaultDb db=new VaultDb(this);
            try{
                String market=searchMarket.getSelectedItem().toString();String code=lookup.getText().toString().trim();
                JSONObject j=db.stockStatus(market,code);
                new android.app.AlertDialog.Builder(this).setTitle("本地数据库 · "+market+" "+code)
                        .setMessage(j.toString(2)).setPositiveButton("关闭",(d,w)->{}).show();
            }catch(Exception e){toast("查询失败："+e.getMessage());}finally{db.close();}
        });
        refresh();
    }
    private void refresh(){
        VaultDb db=new VaultDb(this);
        try{
            JSONObject o=db.stats();
            String s="采集服务："+(HarvestService.RUNNING.get()?"运行中":"未运行 / 已停止")+"\n"+
                "A 股："+o.optLong("symbols_A")+" 只   港股："+o.optLong("symbols_HK")+" 只\n"+
                "本地K线总数："+o.optLong("candles")+"（日线 "+o.optLong("candles_day")+"）\n"+
                "财报记录："+o.optLong("financial_statements")+"  扩展指标/事件："+o.optLong("auxiliary_data")+"\n"+
                "已观测任务："+o.optLong("tasks_observed")+"  部分："+o.optLong("tasks_partial")+"\n"+
                "失败："+o.optLong("tasks_failed")+"  未授权："+o.optLong("tasks_permission_required")+"\n"+
                "历史失败日志："+o.optLong("fetch_errors")+"\n"+
                "最近任务："+o.optString("last_run","未开始")+"\n"+
                "A 股目录："+o.optString("catalog_A","待建")+"\n港股目录："+o.optString("catalog_HK","待建")+"\n";
            status.setText(s);
            JSONObject h=db.harvestState();
            int done=h.optInt("processed",0),total=h.optInt("total",0);
            progressBar.setProgress(total>0?HarvestPolicy.percent(done,total):0);
            String headline=h.optString("message",HarvestService.PROGRESS);
            if(HarvestService.RUNNING.get()&&total==0)headline=HarvestService.PROGRESS;
            downloadProgress.setText("任务："+(HarvestService.RUNNING.get()?"运行中":h.optString("status","未开始"))+" · "+done+"/"+total+
                " · "+HarvestPolicy.percent(done,total)+"%\n"+
                "成功 "+h.optInt("succeeded")+" / 失败 "+h.optInt("failed")+
                " / 已续传跳过 "+h.optInt("skipped")+" · 本次获取K线 "+h.optInt("new_bars")+"\n"+
                "时间范围："+h.optString("window_start","—")+" ～ "+h.optString("window_end","—")+"\n"+
                "当前："+headline+"\n"+
                (HarvestService.RUNNING.get()?HarvestService.PROGRESS:""));
            String tail=db.recentLogs(15);logView.setText(tail.isEmpty()?"暂无日志":tail);
        }catch(Exception e){status.setText("数据库检查失败："+e.getMessage());}
        finally{db.close();}
    }
    @Override protected void onResume(){super.onResume();screenLive=true;handler.post(tick);}
    @Override protected void onPause(){screenLive=false;handler.removeCallbacks(tick);super.onPause();}
    private final Runnable tick=new Runnable(){@Override public void run(){if(screenLive){refresh();handler.postDelayed(this,3000);}}};
    private void toast(String str){Toast.makeText(this,str,Toast.LENGTH_LONG).show();}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        if(req==EXPORT_LOG){
            VaultDb vault=new VaultDb(this);
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                if(out==null)throw new IOException("OUTPUT_UNAVAILABLE");
                out.write(("QuantDesk 两年A股/港股日K采集日志\n"+vault.recentLogs(1500)+
                    "\n========== 各数据源详细错误（最近300条） ==========\n"+
                    vault.recentFetchErrors(300)).getBytes("UTF-8"));
                out.flush();toast("日志已导出，可发送给我定位失败原因");
            }catch(Exception e){toast("日志导出失败："+e.getMessage());}finally{vault.close();}
            return;
        }
        if(req!=EXPORT_SQLITE)return;
        if(HarvestService.RUNNING.get()){toast("仍在采集，必须先暂停，不能直接复制写入中的数据库");return;}
        try{
            VaultDb db=new VaultDb(this);SQLiteDatabase sql=db.getWritableDatabase();
            try(Cursor cur=sql.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null)){while(cur.moveToNext()){} }
            db.close();File input=getDatabasePath(VaultDb.NAME);
            Uri output=data.getData();
            try(InputStream in=new FileInputStream(input);OutputStream out=getContentResolver().openOutputStream(output)) {
                if(out==null)throw new IOException("NO_OUTPUT_STREAM");
                byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                out.flush();
            }
            toast("SQLite 已导出到你选择的文件夹");
        }catch(Exception e){toast("数据库导出失败："+e.getMessage());}
    }
}
