package com.quantdesk.v85;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** V8.5 rebuilt native wrapper. Recovered WEB assets, new Java source (not a decompilation). */
public final class AnalysisActivity extends Activity {
    private static final String LOCAL = "appassets.androidplatform.net";
    private static final Set<String> ALLOW = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "push2.eastmoney.com", "push2delay.eastmoney.com", "push2his.eastmoney.com",
        "datacenter-web.eastmoney.com", "np-anotice-stock.eastmoney.com",
        "np-weblist.eastmoney.com", "web.ifzq.gtimg.cn", "hq.sinajs.cn", "qt.gtimg.cn")));
    private WebView web;
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new NativeBridge(),"QuantDeskNative");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl();return !("https".equals(u.getScheme())&&LOCAL.equals(u.getHost()));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl();if(!"https".equals(u.getScheme())||!LOCAL.equals(u.getHost()))return null;
                if("/proxy".equals(u.getPath()))return proxy(u);
                String path=u.getPath();if(path==null||path.contains(".."))return response(400,"bad path");
                String asset=path.equals("/")?"index.html":path.substring(1);
                try{
                    InputStream stream=getAssets().open(asset);
                    String type=asset.endsWith(".js")?"application/javascript":asset.endsWith(".css")?"text/css":
                        asset.endsWith(".html")?"text/html":asset.endsWith(".svg")?"image/svg+xml":
                        asset.endsWith(".json")||asset.endsWith(".webmanifest")?"application/json":"text/plain";
                    return new WebResourceResponse(type,"UTF-8",stream);
                }catch(IOException e){return response(404,"asset not found");}
            }
        });
        web.loadUrl("https://"+LOCAL+"/index.html");
    }
    private WebResourceResponse response(int status,String message){
        return new WebResourceResponse("text/plain","UTF-8",status,status==200?"OK":"Error",
             Collections.singletonMap("Cache-Control","no-store"),new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8)));
    }
    private static String readLimited(InputStream in,int max) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new IOException("upstream too large");out.write(buf,0,n);}
        return out.toString("UTF-8");
    }
    private static URL safeUrl(String value) throws Exception {
        URI u=new URI(value);if(!"https".equalsIgnoreCase(u.getScheme())||u.getUserInfo()!=null||u.getFragment()!=null||
            !ALLOW.contains(u.getHost())||u.getPort()!=-1)throw new SecurityException("host not allowed");
        return u.toURL();
    }
    private WebResourceResponse proxy(Uri uri){
        String target=uri.getQueryParameter("target");if(target==null)return response(400,"missing target");
        try{
            HttpURLConnection connection=(HttpURLConnection)safeUrl(target).openConnection();
            connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(6500);connection.setReadTimeout(12500);
            connection.setRequestProperty("User-Agent","QuantDesk/8.5 Android WebView data client");
            int code=connection.getResponseCode();
            if(code<200||code>=300)return response(502,"upstream HTTP "+code);
            String text;
            try(InputStream in=connection.getInputStream()){text=readLimited(in,4*1024*1024);}
            connection.disconnect();
            return new WebResourceResponse("application/javascript","UTF-8",new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
        }catch(Exception e){return response(502,"native proxy failure: "+e.getClass().getSimpleName());}
    }
    /** Tushare direct POST: token is supplied per-request; never persisted to disk. */
    final class NativeBridge {
        @JavascriptInterface public void request(String id,String payload){
            if(id==null||!id.matches("ts[0-9]{1,9}")||payload==null||payload.length()>12000)return;
            io.execute(()->{
                String result;
                try{
                    JSONObject original=new JSONObject(payload);
                    String method=original.getString("api_name"),token=original.getString("token");
                    if(!method.matches("[a-z0-9_]{1,40}")||!token.matches("[A-Za-z0-9]{16,90}"))throw new SecurityException("invalid request");
                    JSONObject body=new JSONObject();body.put("api_name",method);body.put("token",token);
                    body.put("params",original.optJSONObject("params")!=null?original.optJSONObject("params"):new JSONObject());
                    URL url=new URL("https://api.tushare.pro");
                    HttpURLConnection conn=(HttpURLConnection)url.openConnection();
                    conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(8500);conn.setReadTimeout(25000);
                    conn.setRequestMethod("POST");conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
                    try(OutputStream out=conn.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                    if(conn.getResponseCode()!=200)throw new IOException("upstream HTTP "+conn.getResponseCode());
                    try(InputStream in=conn.getInputStream()){result=readLimited(in,6*1024*1024);}
                    conn.disconnect();
                    // The JS bridge expects serialized JSON; ensure upstream is syntactically JSON.
                    new JSONObject(result);
                }catch(Exception e){result="{\"code\":-1,\"msg\":\""+e.getClass().getSimpleName()+"\"}";}
                final String reply=result;
                runOnUiThread(()->{
                    if(web!=null)web.evaluateJavascript("window.QuantTushare&&QuantTushare._receive("+JSONObject.quote(id)+","+JSONObject.quote(reply)+")",null);
                });
            });
        }
    }
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}io.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
