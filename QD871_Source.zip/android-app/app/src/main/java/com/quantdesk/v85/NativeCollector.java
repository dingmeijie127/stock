package com.quantdesk.v85;

import android.content.Context;
import android.database.Cursor;
import android.os.StatFs;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.*;

/** Standalone Android direct collection engine (no PC, Python or collector API required).
 * Only observed data is persisted. Failed/empty/permission-gated responses are not counted as complete.
 */
public final class NativeCollector {
    public interface Feedback { void onUpdate(String message); boolean isPaused(); }
    public static final String EAST_TOKEN="fa5fd1943c7b386f172d6893dbfba10b";
    private final Context context;
    private final VaultDb vault;
    private final Feedback feedback;
    private final String tushareToken; // in-memory only; never stored in SQLite/logs
    private final int fromYear;
    private final long minInterval;
    private final boolean allowMetered;
    private long lastRequest;
    public NativeCollector(Context context,VaultDb vault,Feedback feedback,String token,int fromYear,long intervalMillis) {
        this(context,vault,feedback,token,fromYear,intervalMillis,false);
    }
    public NativeCollector(Context context,VaultDb vault,Feedback feedback,String token,int fromYear,long intervalMillis,boolean allowMetered) {
        this.context=context;this.vault=vault;this.feedback=feedback;this.allowMetered=allowMetered;
        this.tushareToken=token==null?"":token.trim();
        this.fromYear=Math.max(1990,Math.min(LocalDate.now().getYear(),fromYear));
        this.minInterval=Math.max(500,intervalMillis);
    }
    private void checkpoint() throws InterruptedException {
        if(feedback.isPaused())throw new InterruptedException("USER_PAUSED");
        ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null||cm.getActiveNetwork()==null)
            throw new InterruptedException("NETWORK_UNAVAILABLE:网络未连接，请联网后再次点击开始");
        if(!allowMetered && cm.isActiveNetworkMetered())
            throw new InterruptedException("NEED_WIFI:仅Wi-Fi模式；请连接Wi-Fi或打开允许移动数据");
        long wait=minInterval-(System.currentTimeMillis()-lastRequest);
        if(wait>0)Thread.sleep(wait);
        if(feedback.isPaused())throw new InterruptedException("USER_PAUSED");
        lastRequest=System.currentTimeMillis();
    }
    private String read(InputStream in,int limit) throws IOException {
        try(InputStream input=in; ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192];int n;
            while((n=input.read(buf))>0){if(out.size()+n>limit)throw new IOException("RESPONSE_TOO_LARGE");out.write(buf,0,n);}
            return out.toString("UTF-8");
        }
    }
    private JSONObject get(String url) throws Exception {
        checkpoint();HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(25000);c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent","Mozilla/5.0 QuantDesk Mobile Archive/8.6");
        c.setRequestProperty("Referer","https://quote.eastmoney.com/");
        try {
            int status=c.getResponseCode();if(status!=200)throw new IOException("HTTP_"+status);
            return new JSONObject(read(c.getInputStream(),12_000_000));
        }finally{c.disconnect();}
    }
    private JSONObject postTushare(String api,JSONObject params) throws Exception {
        if(tushareToken.length()<12)throw new SecurityException("TUSHARE_TOKEN_OR_PERMISSION_REQUIRED");
        checkpoint(); HttpURLConnection c=(HttpURLConnection)new URL("https://api.tushare.pro").openConnection();
        c.setRequestMethod("POST");c.setDoOutput(true);c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(12000);c.setReadTimeout(35000);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        JSONObject body=new JSONObject().put("api_name",api).put("token",tushareToken).put("params",params);
        try{
            try(OutputStream stream=c.getOutputStream()){stream.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            if(c.getResponseCode()!=200)throw new IOException("TUSHARE_HTTP_"+c.getResponseCode());
            JSONObject response=new JSONObject(read(c.getInputStream(),16_000_000));
            if(response.optInt("code",-1)!=0)throw new SecurityException("TUSHARE_API_"+response.optInt("code")+":"+response.optString("msg","invalid permission").replace(tushareToken,"[REDACTED]"));
            return response.optJSONObject("data");
        }finally{c.disconnect();}
    }
    private void sendProgress(String status){feedback.onUpdate(status);}
    private JSONObject east(String path,String query) throws Exception {
        JSONObject reply=get("https://"+path+query);
        if(reply.optInt("rc",0)!=0 || reply.optJSONObject("data")==null)
            throw new IOException("EASTMONEY_EMPTY_OR_RC_"+reply.optInt("rc",-1));
        return reply.getJSONObject("data");
    }
    private static String enc(String value){try{return URLEncoder.encode(value,"UTF-8");}catch(Exception e){return value;}}
    private static String compactDate(String iso){return iso.replace("-","");}
    private static String isoDate(String day) {
        if(day.matches("[0-9]{8}"))return day.substring(0,4)+"-"+day.substring(4,6)+"-"+day.substring(6);
        return day.length()>=10?day.substring(0,10):day;
    }
    private int catalogPage(String market,String fs) throws Exception {
        int page=1,total=0,seen=0,previous=0;
        Set<String> encountered=new HashSet<>();
        while(page<=100){
            String params="?pn="+page+"&pz=200&po=1&np=1&fltt=2&invt=2&fid=f6&fs="+enc(fs)+
                    "&fields=f12,f14,f13,f2,f3,f5,f6,f26&ut="+EAST_TOKEN;
            JSONObject data=east("push2.eastmoney.com/api/qt/clist/get",params);
            total=Math.max(total,data.optInt("total",0));
            Object raw=data.opt("diff");
            JSONArray rows;
            if(raw instanceof JSONArray)rows=(JSONArray)raw;
            else if(raw instanceof JSONObject){rows=new JSONArray();JSONObject ob=(JSONObject)raw;
                Iterator<String> keys=ob.keys();while(keys.hasNext())rows.put(ob.optJSONObject(keys.next()));}
            else rows=new JSONArray();
            if(rows.length()==0){if(page==1 && total>0)throw new IOException("EMPTY_LIST_FIRST_PAGE");break;}
            for(int i=0;i<rows.length();i++){
                JSONObject r=rows.optJSONObject(i);if(r==null)continue;
                String code=r.optString("f12","");if(market.equals("HK") && code.matches("[0-9]{1,5}"))code=String.format(Locale.US,"%05d",Integer.parseInt(code));
                String name=r.optString("f14","").trim();
                if(!MarketRules.validCode(market,code)||name.isEmpty())continue;
                vault.saveInstrument(market,code,name,"eastmoney",r.toString());
                encountered.add(code);
            }
            seen+=rows.length();
            if(page%5==0)sendProgress(market+" 目录第 "+page+" 页，保存了 "+encountered.size()+" 只");
            if(total>0 && page*200>=total)break;
            if(seen==previous)throw new IOException("CATALOG_PAGINATION_STALLED");
            previous=seen;page++;
        }
        if(total==0||seen<Math.min(total,100) || seen < Math.ceil(total*0.90))
            throw new IOException("CATALOG_SHORT:"+seen+"/"+total);
        vault.catalogCheck(market,"eastmoney",total,encountered.size(),seen>=total?"observed":"partial");
        return encountered.size();
    }
    public void catalog() throws Exception {
        // Multiple separate source segments are used; each segment has its own advertised count.
        for(String market:new String[]{"A","HK"}){
            sendProgress("建立 "+market+" 股票目录…");
            String[] filters= market.equals("A")?
                new String[]{"m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048"}:
                new String[]{"m:116","m:113,m:114,m:115,m:128"};
            int count=0,success=0;
            for(String fs:filters){try{count+=catalogPage(market,fs);success++;}catch(Exception e){
                sendProgress(market+" 部分目录来源失败: "+e.getMessage());
            }}
            // Merge, never silently replace, the current free listing with authorized
            // Tushare listings (A share L/D/P when permitted, including delisted names).
            if(tushareToken.length()>12){try{count+=catalogTushare(market);success++;}
                catch(Exception e){sendProgress("授权目录补充失败: "+e.getMessage());}}
            int realCount=0;
            try(Cursor cur=vault.getReadableDatabase().rawQuery(
                    "SELECT count(*) FROM instruments WHERE market=?",new String[]{market})){
                if(cur.moveToFirst())realCount=cur.getInt(0);
            }
            if(realCount==0)throw new IOException(market+" 目录为空，不能开始全量采集");
            vault.catalogCheck(market,"merged-eastmoney-tushare",-1,realCount,
                    success>=filters.length?"observed_not_officially_certified":"partial_sources_failed");
            sendProgress(market+" 当前数据库共 "+realCount+" 只（含可能的重复来源；目录还需和交易所官方清单对照）");
        }
    }
    private int catalogTushare(String market) throws Exception {
        String api=market.equals("HK")?"hk_basic":"stock_basic";
        int count=0;
        for(String state:market.equals("HK")?new String[]{"L"}:new String[]{"L","D","P"}){
            JSONObject params=market.equals("HK")?new JSONObject():new JSONObject().put("exchange","").put("list_status",state);
            JSONObject data=postTushare(api,params);
            if(data==null)throw new IOException("EMPTY_TUSHARE_CATALOG");
            JSONArray cols=data.optJSONArray("fields"),rows=data.optJSONArray("items");
            if(cols==null||rows==null)throw new IOException("INVALID_TUSHARE_CATALOG");
            for(int i=0;i<rows.length();i++){
                JSONObject r=rowObject(cols,rows.getJSONArray(i));
                String tc=r.optString("ts_code","");String code=tc.split("\\.")[0];
                if(!MarketRules.validCode(market,code))continue;
                String name=r.optString("name","").trim();if(name.isEmpty())continue;
                vault.saveInstrument(market,code,name,"tushare",r.toString());count++;
            }
        }
        if(count<20)throw new IOException("TUSHARE_CATALOG_SHORT:"+count);
        return count;
    }
    private static JSONObject rowObject(JSONArray fields,JSONArray data) throws Exception {
        JSONObject r=new JSONObject();for(int i=0;i<fields.length();i++)r.put(fields.getString(i),i<data.length()?data.opt(i):JSONObject.NULL);
        return r;
    }
    private int eastCandles(String market,String code,String interval,int klt,int start,int end) throws Exception {
        String url="push2his.eastmoney.com/api/qt/stock/kline/get";
        JSONObject response=east(url,"?secid="+enc(MarketRules.secid(market,code))+"&fields1=f1,f2,f3,f4,f5,f6"+
                "&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61&klt="+klt+
                "&fqt=0&beg="+start+"0101&end="+end+"1231&lmt=100000&ut="+EAST_TOKEN);
        JSONArray klines=response.optJSONArray("klines");if(klines==null)throw new IOException("NO_KLINE_ARRAY");
        // A vendor may silently cap rows. For multi-year windows, an exactly capped
        // response cannot certify full coverage; use an independent provider instead.
        if(klines.length()==460 || klines.length()==500)throw new IOException("SUSPECT_VENDOR_ROW_CAP");
        SQLiteDatabase sql=vault.getWritableDatabase();int saved=0;sql.beginTransaction();
        try {
            for(int i=0;i<klines.length();i++){
                String raw=klines.getString(i);String[] p=raw.split(",");
                if(p.length<6)throw new IOException("INVALID_CANDLE_ROW");
                double o=Double.parseDouble(p[1]),c=Double.parseDouble(p[2]),h=Double.parseDouble(p[3]),l=Double.parseDouble(p[4]),vol=Double.parseDouble(p[5]);
                Double amount=p.length>6 && !p[6].equals("-")?Double.valueOf(p[6]):null;
                vault.saveCandle(market,code,interval,"none",p[0],o,h,l,c,vol,amount,"eastmoney",raw);saved++;
            }
            sql.setTransactionSuccessful();
        }finally{sql.endTransaction();}
        return saved;
    }
    private int yahooCandles(String market,String code,int startYear,int endYear) throws Exception {
        String ticker=MarketRules.yahooTicker(market,code);
        long from=LocalDate.of(startYear,1,1).atStartOfDay(ZoneId.of("Asia/Shanghai")).toEpochSecond();
        long to=LocalDate.of(endYear+1,1,1).atStartOfDay(ZoneId.of("Asia/Shanghai")).toEpochSecond();
        JSONObject top=get("https://query1.finance.yahoo.com/v8/finance/chart/"+enc(ticker)+"?period1="+from+"&period2="+to+"&interval=1d&events=history");
        JSONObject chart=top.getJSONObject("chart");
        JSONArray results=chart.optJSONArray("result");if(results==null||results.length()==0)throw new IOException("YAHOO_NO_DATA");
        JSONObject payload=results.getJSONObject(0);JSONArray ts=payload.optJSONArray("timestamp");
        if(ts==null)throw new IOException("YAHOO_EMPTY_TIMESTAMPS");
        JSONObject quote=payload.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray opens=quote.getJSONArray("open"),highs=quote.getJSONArray("high"),lows=quote.getJSONArray("low"),closes=quote.getJSONArray("close"),vols=quote.getJSONArray("volume");
        int saved=0;SQLiteDatabase db=vault.getWritableDatabase();db.beginTransaction();
        try {
            for(int i=0;i<ts.length();i++){
                if(opens.isNull(i)||highs.isNull(i)||lows.isNull(i)||closes.isNull(i)||vols.isNull(i))continue;
                double o=opens.getDouble(i),h=highs.getDouble(i),l=lows.getDouble(i),c=closes.getDouble(i),v=vols.getDouble(i);
                MarketRules.validateBar(o,h,l,c,v);
                String day=Instant.ofEpochSecond(ts.getLong(i)).atZone(ZoneId.of("Asia/Hong_Kong")).toLocalDate().toString();
                JSONObject raw=new JSONObject().put("date",day).put("o",o).put("h",h).put("l",l).put("c",c).put("volume",v);
                vault.saveCandle(market,code,"day","none",day,o,h,l,c,v,null,"yahoo",raw.toString());saved++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        if(saved==0)throw new IOException("YAHOO_EMPTY_OHLC");
        return saved;
    }
    private int tushareCandles(String market,String code,int start,int end) throws Exception {
        JSONObject params=new JSONObject().put("ts_code",MarketRules.tsCode(market,code))
                .put("start_date",start+"0101").put("end_date",end+"1231");
        JSONObject data=postTushare(market.equals("HK")?"hk_daily":"daily",params);
        if(data==null)throw new IOException("TUSHARE_DAILY_NO_DATA");
        JSONArray fields=data.optJSONArray("fields"),items=data.optJSONArray("items");
        if(fields==null||items==null)throw new IOException("TUSHARE_DAILY_INVALID_SCHEMA");
        if(items.length()>=10000)throw new IOException("TUSHARE_DAILY_TRUNCATED");
        int saved=0;SQLiteDatabase db=vault.getWritableDatabase();db.beginTransaction();
        try {
            for(int i=0;i<items.length();i++){
                JSONObject row=rowObject(fields,items.getJSONArray(i));
                String date=isoDate(row.optString("trade_date",""));
                if(!date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))continue;
                vault.saveCandle(market,code,"day","none",date,row.getDouble("open"),row.getDouble("high"),
                        row.getDouble("low"),row.getDouble("close"),row.getDouble("vol"),
                        row.has("amount")&&!row.isNull("amount")?row.getDouble("amount"):null,"tushare",row.toString());
                saved++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        if(saved==0)throw new IOException("TUSHARE_DAILY_EMPTY");
        return saved;
    }
    private void collectAuxiliary(String market,String code,int calendarYear) throws InterruptedException {
        // Raw fields are deliberately preserved: currency/unit and indicator definitions vary.
        String[] categories=market.equals("A")?
              new String[]{"fina_indicator","dividend","adj_factor","fina_audit","stk_holdernumber"}:
              new String[]{"hk_fina_indicator"};
        if(tushareToken.length()<12)return;
        for(String dataset:categories){
            for(int start=fromYear;start<=calendarYear;start+=4){
                checkpoint();int end=Math.min(calendarYear,start+3);
                String key=MarketRules.rangeTask(market,code,dataset,start,end);
                if(vault.done(key))continue;
                try{
                    JSONObject params=new JSONObject().put("ts_code",MarketRules.tsCode(market,code))
                            .put("start_date",start+"0101").put("end_date",end+"1231");
                    JSONObject data=postTushare(dataset,params);
                    if(data==null)throw new IOException("EXTRA_DATA_EMPTY");
                    JSONArray fields=data.optJSONArray("fields"),items=data.optJSONArray("items");
                    if(fields==null||items==null)throw new IOException("EXTRA_DATA_INVALID_SCHEMA");
                    // API-specific maximums mean reaching a cap cannot prove completeness.
                    if(items.length()>=10000 || (dataset.equals("fina_indicator")&&items.length()>=100)
                           || (dataset.equals("hk_fina_indicator")&&items.length()>=200))
                        throw new IOException("EXTRA_DATA_POSSIBLE_TRUNCATION");
                    int saved=0;SQLiteDatabase db=vault.getWritableDatabase();db.beginTransaction();
                    try{
                        for(int i=0;i<items.length();i++){
                            JSONObject r=rowObject(fields,items.getJSONArray(i));
                            String d=r.optString("trade_date",r.optString("end_date",r.optString("ann_date",r.optString("ex_date",""))));
                            String identity=d+":"+Integer.toHexString(r.toString().hashCode());
                            vault.saveAuxiliary(market,code,dataset,identity,"tushare",r.toString());saved++;
                        }
                        db.setTransactionSuccessful();
                    }finally{db.endTransaction();}
                    vault.recordTask(key,market,code,dataset,saved>0?"observed":"partial",saved,"tushare",saved>0?null:"NO_AVAILABLE_RECORDS");
                }catch(InterruptedException e){throw e;}
                catch(SecurityException e){vault.recordTask(key,market,code,dataset,"permission_required",0,"tushare",e.getMessage());break;}
                catch(Exception e){vault.recordTask(key,market,code,dataset,"failed",0,"tushare",e.getClass().getSimpleName()+":"+e.getMessage());}
            }
        }
    }
    private void financeForPeriod(String market,String code,String kind,int firstYear,int lastYear) throws Exception {
        String endpoint=(market.equals("HK")?"hk_":"")+(kind.equals("balance")?(market.equals("HK")?"balancesheet":"balancesheet"):kind);
        JSONObject params=new JSONObject().put("ts_code",MarketRules.tsCode(market,code))
                .put("start_date",firstYear+"0101").put("end_date",lastYear+"1231");
        JSONObject response=postTushare(endpoint,params);
        if(response==null||response.optJSONArray("fields")==null || response.optJSONArray("items")==null)throw new IOException("FINANCE_BAD_SCHEMA");
        JSONArray fields=response.getJSONArray("fields"),items=response.getJSONArray("items");
        if(items.length()>=10000)throw new IOException("FINANCE_UPSTREAM_MAX_10000_ROWS");
        Map<String,JSONObject> grouped=new LinkedHashMap<>();
        int rows=0;SQLiteDatabase db=vault.getWritableDatabase();db.beginTransaction();
        try {
            for(int i=0;i<items.length();i++){
                JSONObject record=rowObject(fields,items.getJSONArray(i));
                String period=isoDate(record.optString("end_date",""));
                if(!period.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))continue;
                if(market.equals("HK")){
                    JSONObject byPeriod=grouped.get(period);
                    if(byPeriod==null){byPeriod=new JSONObject();grouped.put(period,byPeriod);}
                    String indicator=record.optString("ind_name","");
                    if(!indicator.isEmpty())byPeriod.put(indicator,record.opt("ind_value"));
                }else {
                    vault.saveFinancial(market,code,kind,period,"tushare",record.toString(),
                       "UNKNOWN", "UPSTREAM_ORIGINAL",isoDate(record.optString("ann_date","")));rows++;
                }
            }
            if(market.equals("HK"))for(Map.Entry<String,JSONObject> e:grouped.entrySet()) {
                if(e.getValue().length()==0)continue;
                vault.saveFinancial(market,code,kind,e.getKey(),"tushare",e.getValue().toString(),
                   "UNKNOWN","UPSTREAM_ORIGINAL",null);rows++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        String key=MarketRules.rangeTask(market,code,kind,firstYear,lastYear);
        vault.recordTask(key,market,code,kind,rows>0?"observed":"partial",rows,"tushare",rows>0?null:"EMPTY_FINANCE_PERIOD");
    }
    private void collectSecurity(String market,String code,int calendarYear) throws InterruptedException {
        // Chunked segments: network interruption resumes at last persisted 4-year window.
        for(int start=fromYear;start<=calendarYear;start+=4){
            checkpoint();int end=Math.min(calendarYear,start+3);
            String task=MarketRules.rangeTask(market,code,"day",start,end);
            if(!vault.done(task) || (end==calendarYear && !vault.doneWithin(task,24L*3600*1000))){
                String provider="eastmoney";
                try {
                    int saved=0;
                    for(int retry=0;retry<3;retry++){
                        try{provider="eastmoney";saved=eastCandles(market,code,"day",101,start,end);break;}
                        catch(InterruptedException pause){throw pause;}
                        catch(Exception first){
                            try{provider="tushare";saved=tushareCandles(market,code,start,end);break;}
                            catch(InterruptedException pause){throw pause;}
                            catch(Exception second){
                                try{provider="yahoo";saved=yahooCandles(market,code,start,end);break;}
                                catch(InterruptedException pause){throw pause;}
                                catch(Exception third){
                                    if(retry==2)throw new IOException("ALL_KLINE_SOURCES_FAILED:"+
                                            first.getClass().getSimpleName()+"/"+second.getClass().getSimpleName()+"/"+third.getClass().getSimpleName());
                                    Thread.sleep(2000L*(retry+1));
                                }
                            }
                        }
                    }
                    vault.recordTask(task,market,code,"day",saved>0?"observed":"partial",saved,provider,
                            saved>0?null:"NO_BARS_OR_PRE_LISTING_PERIOD");
                }catch(InterruptedException e){throw e;}catch(Exception e){
                    vault.recordTask(task,market,code,"day","failed",0,provider,e.getClass().getSimpleName()+":"+e.getMessage());
                }
            }
        }
        deriveWeeklyMonthly(market,code);
        collectIntraday(market,code,calendarYear);
        audit(market,code);
        // Each accounting statement is a distinct checkpoint. Report periods differ between markets.
        for(String kind:new String[]{"income","balance","cashflow"}){
            for(int start=fromYear;start<=calendarYear;start+=6){
                checkpoint();int end=Math.min(calendarYear,start+5);
                String key=MarketRules.rangeTask(market,code,kind,start,end);
                if(vault.done(key))continue;
                if(tushareToken.length()<12){
                    vault.recordTask(key,market,code,kind,"permission_required",0,"tushare","TUSHARE_TOKEN_REQUIRED");
                    // Do not flood error table with identical token messages for every period.
                    break;
                }
                try{financeForPeriod(market,code,kind,start,end);}
                catch(InterruptedException e){throw e;}
                catch(SecurityException e){
                    vault.recordTask(key,market,code,kind,"permission_required",0,"tushare",e.getMessage());
                    break;
                }catch(Exception e){vault.recordTask(key,market,code,kind,"failed",0,"tushare",e.getClass().getSimpleName()+":"+e.getMessage());}
            }
        }
        collectAuxiliary(market,code,calendarYear);
        audit(market,code);
    }
    private static final class Agg {
        String timestamp,source,unit;
        double o,h,l,c,volume;Double amount;
        Agg(String timestamp,double o,double h,double l,double c,double volume,Double amount,String source,String unit){
            this.timestamp=timestamp;this.o=o;this.h=h;this.l=l;this.c=c;this.volume=volume;
            this.amount=amount;this.source=source;this.unit=unit;
        }
        void update(String timestamp,double h,double l,double c,double volume,Double amount){
            this.timestamp=timestamp;this.h=Math.max(this.h,h);this.l=Math.min(this.l,l);this.c=c;
            this.volume+=volume;
            if(this.amount==null||amount==null)this.amount=null;else this.amount+=amount;
        }
    }
    private static void accumulate(Map<String,Agg> into,String key,String day,String source,String unit,
          double o,double h,double l,double c,double volume,Double amount) {
        Agg a=into.get(key);
        if(a==null)into.put(key,new Agg(day,o,h,l,c,volume,amount,source,unit));
        else if(a.source.equals(source)&&a.unit.equals(unit))a.update(day,h,l,c,volume,amount);
        else a.source="MIXED_PROVENANCE_NOT_AGGREGATABLE";
    }
    private void deriveWeeklyMonthly(String market,String code) throws InterruptedException {
        checkpoint();
        Map<String,Agg> weeks=new LinkedHashMap<>(),months=new LinkedHashMap<>();
        try(Cursor c=vault.getReadableDatabase().rawQuery(
                "SELECT timestamp,o,h,l,c,volume,amount,source,volume_unit FROM candles WHERE market=? AND code=? AND interval='day' AND adjustment='none' ORDER BY timestamp",
                new String[]{market,code})){
            while(c.moveToNext()){
                String day=c.getString(0),source=c.getString(7),unit=c.getString(8);
                LocalDate d=LocalDate.parse(day);String weekKey=d.get(WeekFields.ISO.weekBasedYear())+"-W"+d.get(WeekFields.ISO.weekOfWeekBasedYear());
                String monthKey=day.substring(0,7);
                Double amount=c.isNull(6)?null:c.getDouble(6);
                accumulate(weeks,weekKey,day,source,unit,c.getDouble(1),c.getDouble(2),
                        c.getDouble(3),c.getDouble(4),c.getDouble(5),amount);
                accumulate(months,monthKey,day,source,unit,c.getDouble(1),c.getDouble(2),
                        c.getDouble(3),c.getDouble(4),c.getDouble(5),amount);
            }
        }
        SQLiteDatabase sql=vault.getWritableDatabase();sql.beginTransaction();
        try{
            for(String interval:new String[]{"week","month"}){
                Map<String,Agg> values=interval.equals("week")?weeks:months;
                for(Map.Entry<String,Agg> entry:values.entrySet()){
                    Agg a=entry.getValue();if(a.source.equals("MIXED_PROVENANCE_NOT_AGGREGATABLE"))continue;
                    JSONObject raw=new JSONObject();
                    raw.put("method","rollup_verified_daily_observations");raw.put("key",entry.getKey());
                    raw.put("upstream",a.source);raw.put("volumeUnit",a.unit);
                    vault.saveCandle(market,code,interval,"none",a.timestamp,a.o,a.h,a.l,a.c,a.volume,a.amount,
                            "derived_daily_"+a.source,raw.toString());
                }
            }
            sql.setTransactionSuccessful();
        }catch(Exception e){throw new IllegalStateException("WEEK_MONTH_ROLLUP_FAILED",e);}
        finally{sql.endTransaction();}
    }
    private void collectIntraday(String market,String code,int calendarYear) throws InterruptedException {
        String end=LocalDate.now(ZoneId.of("Asia/Hong_Kong")).format(DateTimeFormatter.BASIC_ISO_DATE);
        for(int minutes:new int[]{1,5,15,30,60}){
            checkpoint();String interval=minutes+"m";
            String key=market+":"+code+":"+interval+":"+end;
            if(vault.done(key))continue;
            LocalDate startDay=LocalDate.now(ZoneId.of("Asia/Hong_Kong")).minusDays(minutes==1?10:90);
            String begin=startDay.format(DateTimeFormatter.BASIC_ISO_DATE);
            try {
                JSONObject data=east("push2his.eastmoney.com/api/qt/stock/kline/get",
                    "?secid="+enc(MarketRules.secid(market,code))+"&fields1=f1,f2,f3,f4,f5,f6"+
                    "&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61&klt="+minutes+
                    "&fqt=0&beg="+begin+"&end="+end+"&lmt=100000&ut="+EAST_TOKEN);
                JSONArray lines=data.optJSONArray("klines");if(lines==null)throw new IOException("NO_INTRADAY_KLINES");
                int saved=0;SQLiteDatabase sql=vault.getWritableDatabase();sql.beginTransaction();
                try {
                    for(int i=0;i<lines.length();i++){
                        String line=lines.getString(i);String[] p=line.split(",");if(p.length<6)throw new IOException("MALFORMED_MINUTE_CANDLE");
                        double o=Double.parseDouble(p[1]),c=Double.parseDouble(p[2]),h=Double.parseDouble(p[3]),l=Double.parseDouble(p[4]),v=Double.parseDouble(p[5]);
                        Double amt=p.length>6?Double.valueOf(p[6]):null;
                        vault.saveCandle(market,code,interval,"none",p[0],o,h,l,c,v,amt,"eastmoney",line);saved++;
                    }
                    sql.setTransactionSuccessful();
                }finally{sql.endTransaction();}
                vault.recordTask(key,market,code,interval,saved>0?"observed":"partial",saved,"eastmoney",
                    saved>0?null:"MINUTE_HISTORY_UNAVAILABLE");
            }catch(InterruptedException e){throw e;}
            catch(Exception e){vault.recordTask(key,market,code,interval,"failed",0,"eastmoney",e.getClass().getSimpleName()+":"+e.getMessage());}
        }
    }
    private void audit(String market,String code) {
        SQLiteDatabase sql=vault.getWritableDatabase();
        int barCount=0,finKinds=0,aligned=0;
        try(Cursor rows=sql.rawQuery("SELECT count(*) FROM candles WHERE market=? AND code=? AND interval='day'",new String[]{market,code})){
            if(rows.moveToFirst())barCount=rows.getInt(0);
        }
        try(Cursor rows=sql.rawQuery("SELECT count(DISTINCT kind) FROM financial_statements WHERE market=? AND code=?",new String[]{market,code})){
            if(rows.moveToFirst())finKinds=rows.getInt(0);
        }
        try(Cursor rows=sql.rawQuery("SELECT count(*) FROM (SELECT period FROM financial_statements WHERE market=? AND code=? GROUP BY period HAVING count(DISTINCT kind)=3)",new String[]{market,code})) {
            if(rows.moveToFirst())aligned=rows.getInt(0);
        }
        String quality="K线="+barCount+"根；财报表种="+finKinds+"；三表同报告期="+aligned+"；没有官方交易日历/退市全清单，无法认证全量";
        android.content.ContentValues val=new android.content.ContentValues();
        val.put("market",market);val.put("code",code);val.put("checked_at",System.currentTimeMillis());
        if(barCount<100){val.put("category","history_needs_review");val.put("details",quality);
            sql.insertWithOnConflict("data_gaps",null,val,SQLiteDatabase.CONFLICT_REPLACE);}
        else sql.delete("data_gaps","market=? AND code=? AND category='history_needs_review'",new String[]{market,code});
        if(aligned<1){val.put("category","three_statements_missing");val.put("details",quality);
            sql.insertWithOnConflict("data_gaps",null,val,SQLiteDatabase.CONFLICT_REPLACE);}
        else sql.delete("data_gaps","market=? AND code=? AND category='three_statements_missing'",new String[]{market,code});
    }
    /** Phase 1 for stock screening: observed 2-year daily OHLCV only, not synthetic data. */
    private int eastDailyBetween(String market,String code,LocalDate start,LocalDate end) throws Exception {
        String query="?secid="+enc(MarketRules.secid(market,code))+"&fields1=f1,f2,f3,f4,f5,f6"+
            "&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61&klt=101&fqt=0"+
            "&beg="+HarvestPolicy.compact(start)+"&end="+HarvestPolicy.compact(end)+"&lmt=1000&ut="+EAST_TOKEN;
        JSONObject data=east("push2his.eastmoney.com/api/qt/stock/kline/get",query);
        JSONArray bars=data.optJSONArray("klines");
        if(bars==null)throw new IOException("EAST_NO_KLINES");
        if(bars.length()>=1000)throw new IOException("EAST_POSSIBLY_TRUNCATED");
        SQLiteDatabase db=vault.getWritableDatabase();int saved=0;
        db.beginTransaction();
        try{
            for(int i=0;i<bars.length();i++){
                String raw=bars.getString(i);
                DailyBar bar=DailyBar.fromEastmoney(raw,start,end);
                if(bar==null)continue;
                vault.saveCandle(market,code,"day","none",bar.date,bar.open,bar.high,bar.low,
                    bar.close,bar.volume,bar.turnover,"eastmoney",bar.raw);
                saved++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return saved;
    }
    private int yahooDailyBetween(String market,String code,LocalDate start,LocalDate end) throws Exception {
        String ticker=MarketRules.yahooTicker(market,code);
        long from=start.atStartOfDay(HarvestPolicy.MARKET_ZONE).toEpochSecond();
        long until=end.plusDays(1).atStartOfDay(HarvestPolicy.MARKET_ZONE).toEpochSecond();
        JSONObject raw=get("https://query1.finance.yahoo.com/v8/finance/chart/"+enc(ticker)+"?period1="+from+"&period2="+until+"&interval=1d");
        JSONObject chart=raw.optJSONObject("chart");if(chart==null)throw new IOException("YAHOO_NO_CHART");
        JSONArray result=chart.optJSONArray("result");if(result==null||result.length()==0)throw new IOException("YAHOO_NO_RESULT");
        JSONObject series=result.getJSONObject(0);JSONArray stamps=series.optJSONArray("timestamp");
        if(stamps==null)throw new IOException("YAHOO_NO_TIMESTAMPS");
        JSONObject q=series.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray opens=q.getJSONArray("open"),highs=q.getJSONArray("high"),lows=q.getJSONArray("low"),
                  closes=q.getJSONArray("close"),volumes=q.getJSONArray("volume");
        SQLiteDatabase db=vault.getWritableDatabase();int saved=0;
        db.beginTransaction();
        try{
            for(int i=0;i<stamps.length();i++){
                if(opens.isNull(i)||highs.isNull(i)||lows.isNull(i)||closes.isNull(i)||volumes.isNull(i))continue;
                String day=Instant.ofEpochSecond(stamps.getLong(i)).atZone(HarvestPolicy.MARKET_ZONE).toLocalDate().toString();
                if(!HarvestPolicy.inside(day,start,end))continue;
                double o=opens.getDouble(i),h=highs.getDouble(i),l=lows.getDouble(i),
                    c=closes.getDouble(i),v=volumes.getDouble(i);
                MarketRules.validateBar(o,h,l,c,v);
                JSONObject row=new JSONObject().put("date",day).put("open",o).put("high",h)
                    .put("low",l).put("close",c).put("volume",v).put("timestamp",stamps.getLong(i));
                vault.saveCandle(market,code,"day","none",day,o,h,l,c,v,null,"yahoo",row.toString());saved++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return saved;
    }
    private int tushareDailyBetween(String market,String code,LocalDate start,LocalDate end) throws Exception {
        JSONObject params=new JSONObject().put("ts_code",MarketRules.tsCode(market,code))
            .put("start_date",HarvestPolicy.compact(start)).put("end_date",HarvestPolicy.compact(end));
        JSONObject data=postTushare(market.equals("HK")?"hk_daily":"daily",params);
        if(data==null)throw new IOException("TUSHARE_NO_DAILY");
        JSONArray fields=data.optJSONArray("fields"),rows=data.optJSONArray("items");
        if(fields==null||rows==null||rows.length()>=10000)throw new IOException("TUSHARE_BAD_OR_CAPPED_ROWS");
        SQLiteDatabase db=vault.getWritableDatabase();int saved=0;
        db.beginTransaction();
        try {
            for(int i=0;i<rows.length();i++){
                JSONObject row=rowObject(fields,rows.getJSONArray(i));String date=isoDate(row.optString("trade_date",""));
                if(!HarvestPolicy.inside(date,start,end))continue;
                double o=row.getDouble("open"),h=row.getDouble("high"),l=row.getDouble("low"),c=row.getDouble("close"),v=row.getDouble("vol");
                MarketRules.validateBar(o,h,l,c,v);
                vault.saveCandle(market,code,"day","none",date,o,h,l,c,v,
                    row.has("amount")&&!row.isNull("amount")?row.getDouble("amount"):null,"tushare",row.toString());saved++;
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return saved;
    }
    private static final class DownloadResult {
        int saved;String provider="none";String error="";
    }
    private DownloadResult downloadDailySegment(String market,String code,LocalDate a,LocalDate b) throws InterruptedException {
        DownloadResult r=new DownloadResult();StringBuilder errors=new StringBuilder();
        for(int attempt=0;attempt<2;attempt++){
            if(feedback.isPaused())throw new InterruptedException("USER_PAUSED");
            for(String provider:new String[]{"eastmoney","yahoo","tushare"}){
                if(provider.equals("tushare")&&tushareToken.length()<12)continue;
                try{
                    int rows=provider.equals("eastmoney")?eastDailyBetween(market,code,a,b):
                             provider.equals("yahoo")?yahooDailyBetween(market,code,a,b):tushareDailyBetween(market,code,a,b);
                    if(rows>0){r.saved=rows;r.provider=provider;return r;}
                    errors.append(provider).append(":EMPTY;");
                }catch(InterruptedException e){throw e;}
                catch(Exception e){errors.append(provider).append(":").append(e.getClass().getSimpleName())
                                  .append("/").append(e.getMessage()).append(";");}
            }
            if(attempt==0){sendProgress("尝试备用源："+market+" "+code);
                Thread.sleep(1500L);}
        }
        r.error=errors.length()>500?errors.substring(0,500):errors.toString();
        return r;
    }
    private int collectTwoYearDaily(String market,String code,LocalDate start,LocalDate end) throws InterruptedException {
        String wholeKey=HarvestPolicy.key(market,code,start,end);
        if(vault.done(wholeKey))return -1; // resume: never redownload committed security
        int totalRows=0;boolean all=true;String latest="";
        for(LocalDate[] segment:HarvestPolicy.split(start,end)){
            if(feedback.isPaused())throw new InterruptedException("USER_PAUSED");
            String key=wholeKey+":"+HarvestPolicy.compact(segment[0])+"-"+HarvestPolicy.compact(segment[1]);
            if(vault.done(key))continue;
            DownloadResult r=downloadDailySegment(market,code,segment[0],segment[1]);
            totalRows+=r.saved;
            if(r.saved==0){
                all=false;vault.recordTask(key,market,code,"day2y","failed",0,"none",r.error);
                // Previous builds exported only a generic failed-stock count, hiding provider errors.
                vault.log("ERROR",market+":"+code+" "+segment[0]+"~"+segment[1]+" / "+r.error);
            }else{
                latest=r.provider;
                vault.recordTask(key,market,code,"day2y","observed",r.saved,r.provider,null);
            }
        }
        if(all){
            vault.recordTask(wholeKey,market,code,"day2y","observed",totalRows,latest,null);
            vault.markDayGap(market,code,totalRows>0&&totalRows<15?
                    "仅取得少于15根日K，可能是新股、停牌或缺失，需核验上市日期与交易日历":null);
            return totalRows;
        }
        vault.recordTask(wholeKey,market,code,"day2y","partial",totalRows,latest,"SEGMENTS_FAILED_OR_EMPTY");
        vault.markDayGap(market,code,"最近两年有分段为空或数据源失败，请检查fetch_errors并重试；可能属于IPO前/停牌期");
        return -2;
    }
    public void runTwoYearDaily() throws Exception {
        LocalDate end=HarvestPolicy.today(),start=HarvestPolicy.beginning(end);
        // A paused/interrupted run retains exactly the same window for checkpoint integrity.
        JSONObject earlier=vault.harvestState();String prior=earlier.optString("status","");
        if((prior.equals("paused")||prior.equals("interrupted")||prior.equals("running"))&&
           earlier.optString("window_start","").matches("[0-9]{4}-[0-9]{2}-[0-9]{2}") &&
           earlier.optString("window_end","").matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")){
            start=LocalDate.parse(earlier.getString("window_start"));end=LocalDate.parse(earlier.getString("window_end"));
        }
        vault.startRun();vault.initHarvest(start.toString(),end.toString(),0);
        String outcome="interrupted",notice="下载意外中断";
        int complete=0,errors=0,skipped=0,bars=0,processed=0,total=0,consecutiveFails=0,missingMarkets=0;
        try {
            vault.log("INFO","开始创建/继续两年数据库，日期 "+start+" 至 "+end);
            // Fail with the actual connection reason, instead of silently swallowing it
            // during catalog retries and eventually reporting an empty stock catalog.
            ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm==null || cm.getActiveNetwork()==null)
                throw new IOException("NETWORK_UNAVAILABLE: 未联网，请检查手机 Wi-Fi 或移动数据");
            if(!allowMetered && cm.isActiveNetworkMetered())
                throw new IOException("NEED_WIFI: 当前网络被标记为计费网络，请连接 Wi-Fi 或勾选允许移动数据");
            boolean canResume=(prior.equals("paused")||prior.equals("interrupted")||prior.equals("running"))
                && vault.countMarket("A")>0 && vault.countMarket("HK")>0;
            if(canResume){vault.log("INFO","从本地目录和已成功的日线检查点快速续传，不重新下载目录");}
            else{
                sendProgress("正在拉取 A 股、港股证券目录…");
                try{catalog();}catch(InterruptedException e){throw e;}
                catch(Exception e){vault.log("ERROR","目录刷新失败："+e.getMessage()+"；尝试现有数据库目录");}
            }
            total=vault.countInstruments();
            if(total==0)throw new IOException("股票目录为空，下载未开始。检查网络或数据源连接");
            if(vault.countMarket("A")==0 || vault.countMarket("HK")==0){
                missingMarkets=1;
                vault.log("ERROR","市场股票目录不完整：A="+vault.countMarket("A")+
                    " 港股="+vault.countMarket("HK")+"，已获得的市场仍可采集，但不能宣称两个市场都完整");
            }
            vault.initHarvest(start.toString(),end.toString(),total);
            sendProgress("目录 "+total+" 只；开始下载 "+start+" ～ "+end+" 日K");
            SQLiteDatabase db=vault.getReadableDatabase();
            for(String market:new String[]{"A","HK"}) {
                try(Cursor cur=db.rawQuery("SELECT code FROM instruments WHERE market=? ORDER BY code",new String[]{market})){
                    while(cur.moveToNext()) {
                        if(feedback.isPaused())throw new InterruptedException("USER_PAUSED");
                        String code=cur.getString(0),symbol=market+":"+code;
                        int result=collectTwoYearDaily(market,code,start,end);
                        processed++;
                        if(processed%100==0){
                            StatFs space=new StatFs(context.getDatabasePath(VaultDb.NAME).getParent());
                            if(space.getAvailableBytes()<300L*1024*1024)
                                throw new IOException("LOW_STORAGE:手机剩余存储不足300MB，已保存进度，请释放空间后续传");
                        }
                        if(result==-1){skipped++;consecutiveFails=0;}
                        else if(result>=0){complete++;bars+=result;consecutiveFails=0;}
                        else {errors++;consecutiveFails++;}
                        String line="["+processed+"/"+total+"] "+HarvestPolicy.percent(processed,total)+"% "+symbol+
                            " | 成功 "+complete+" 失败 "+errors+" 已跳过 "+skipped+" | K线 "+bars;
                        vault.updateHarvest(total,processed,complete,errors,skipped,bars,symbol,line);
                        vault.log(result==-2?"ERROR":"INFO",line+(result==-2?" · 数据源失败，待补采":""));
                        sendProgress(line);
                        if(consecutiveFails>=25)throw new IOException("25只股票连续采集失败：疑似数据源限流或网络故障，已停止请求以保护设备和接口，请导出日志排查");
                    }
                }
            }
            outcome=(errors==0&&missingMarkets==0)?"completed":"completed_with_gaps";
            notice="日线采集遍历完成：成功="+complete+" 失败="+errors+" 跳过="+skipped+
                "；未能覆盖市场数="+missingMarkets+"；完成指任务遍历，不代表交易所全量验收";
            sendProgress(notice);
        }catch(InterruptedException e){outcome="paused";notice="采集暂停，进度已存数据库；再次点击开始可续传";
            sendProgress(notice);
        }catch(Exception e){notice="采集中断："+e.getClass().getSimpleName()+": "+e.getMessage();
            vault.log("ERROR",notice);sendProgress(notice);throw e;
        }finally {
            vault.finishHarvest(outcome,notice);
            vault.finishRun(outcome,notice);
        }
    }

    public void runAll() throws Exception {
        vault.startRun();String outcome="completed_with_unverified_coverage";
        try {
            // Always reconcile fresh catalogs first; don't confuse historic local cache with actual listing coverage.
            catalog();
            int year=LocalDate.now(ZoneId.of("Asia/Hong_Kong")).getYear();
            SQLiteDatabase db=vault.getReadableDatabase();
            int completed=0;
            for(String market:new String[]{"A","HK"}){
                try(Cursor c=db.rawQuery("SELECT code FROM instruments WHERE market=? ORDER BY code",new String[]{market})){
                    while(c.moveToNext()){
                        checkpoint();String code=c.getString(0);
                        completed++;sendProgress("采集第 "+completed+" 只: "+market+" "+code+" / 历史K线 / 财报");
                        collectSecurity(market,code,year);
                    }
                }
            }
            sendProgress("当前股票采集队列已遍历；请检查失败、权限受限和缺口，不能直接视为全市场完整。");
        }catch(InterruptedException e){outcome="paused";sendProgress("采集已暂停："+e.getMessage());}
        catch(Exception e){outcome="interrupted";sendProgress("采集中断："+e.getMessage());throw e;}
        finally{vault.finishRun(outcome,"检查 fetch_tasks / data_gaps / catalog_checks 评估覆盖率");}
    }
}
