package com.quantdesk.v85;

import java.time.LocalDate;

/** Parsed, validated one-day raw vendor candle. Kept SDK-free for actual JVM tests. */
public final class DailyBar {
    public final String date,raw;
    public final double open,high,low,close,volume;
    public final Double turnover;
    private DailyBar(String date,String raw,double open,double high,double low,double close,double volume,Double turnover) {
        this.date=date;this.raw=raw;this.open=open;this.high=high;this.low=low;
        this.close=close;this.volume=volume;this.turnover=turnover;
    }
    /** Return null outside requested dates; throw on malformed in-range vendor data. */
    public static DailyBar fromEastmoney(String raw,LocalDate from,LocalDate to) {
        String[] p=raw.split(",",-1);
        if(p.length<7)throw new IllegalArgumentException("Expected at least 7 OHLCV columns");
        if(!HarvestPolicy.inside(p[0],from,to))return null;
        double open=Double.parseDouble(p[1]),close=Double.parseDouble(p[2]);
        double high=Double.parseDouble(p[3]),low=Double.parseDouble(p[4]),volume=Double.parseDouble(p[5]);
        MarketRules.validateBar(open,high,low,close,volume);
        Double turnover=p[6].isEmpty()||p[6].equals("-")?null:Double.valueOf(p[6]);
        return new DailyBar(p[0],raw,open,high,low,close,volume,turnover);
    }
}
