package com.quantdesk.v85;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Pure Java, SDK-independent two-year history and resumable task rules. */
public final class HarvestPolicy {
    public static final ZoneId MARKET_ZONE = ZoneId.of("Asia/Hong_Kong");
    private static final DateTimeFormatter BASIC = DateTimeFormatter.BASIC_ISO_DATE;
    private HarvestPolicy() {}
    public static LocalDate today() { return LocalDate.now(MARKET_ZONE); }
    public static LocalDate beginning(LocalDate end) { return end.minusYears(2); }
    public static String key(String market, String code, LocalDate start, LocalDate end) {
        if (!MarketRules.validCode(market, code) || end.isBefore(start)) throw new IllegalArgumentException("Invalid range");
        return market + ":" + code + ":day2y:" + start.format(BASIC) + "-" + end.format(BASIC);
    }
    public static List<LocalDate[]> split(LocalDate start, LocalDate end) {
        if(end.isBefore(start)) throw new IllegalArgumentException("Invalid date range");
        List<LocalDate[]> result=new ArrayList<>();
        for(LocalDate cursor=start;!cursor.isAfter(end);) {
            LocalDate finish=cursor.plusYears(1);
            if(finish.isAfter(end)) finish=end;
            result.add(new LocalDate[]{cursor,finish});
            cursor=finish.plusDays(1);
        }
        return result;
    }
    public static String compact(LocalDate date){return date.format(BASIC);}
    public static boolean inside(String iso,LocalDate start,LocalDate end){
        try {LocalDate day=LocalDate.parse(iso.length()>=10?iso.substring(0,10):iso);
            return !day.isBefore(start)&&!day.isAfter(end);
        } catch(Exception e){return false;}
    }
    public static int percent(int processed,int total){return total<=0?0:Math.max(0,Math.min(100,processed*100/total));}
}
