package com.quantdesk.v85;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.concurrent.atomic.AtomicBoolean;

/** User-started Android foreground ingestion. Pauses cleanly, resume uses SQLite checkpoints. */
public final class HarvestService extends Service {
    public static final String START="com.quantdesk.v85.START_HARVEST";
    public static final String PAUSE="com.quantdesk.v85.PAUSE_HARVEST";
    public static final String CHANNEL="quantdesk_v86_ingestion";
    public static final AtomicBoolean RUNNING=new AtomicBoolean(false);
    private final AtomicBoolean shouldStop=new AtomicBoolean(false);
    private Thread job;
    private PowerManager.WakeLock wake;
    private volatile int total=0,processed=0;
    private static final Pattern PROGRESS_PATTERN=Pattern.compile("\\[(\\d+)/(\\d+)\\]");
    public static volatile String PROGRESS="尚未开始";
    private volatile String progress="准备数据库";
    private long lastNotificationMs=0;
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();
        if(PAUSE.equals(action)){
            if(!RUNNING.get()){PROGRESS="没有正在运行的采集任务";stopSelf();return START_NOT_STICKY;}
            shouldStop.set(true);
            progress="已请求暂停，等待当前请求结束";PROGRESS=progress;
            show(progress);
            return START_NOT_STICKY;
        }
        if(!START.equals(action)||!RUNNING.compareAndSet(false,true))return START_NOT_STICKY;
        shouldStop.set(false);PROGRESS="正在启动两年日K后台采集…";show(PROGRESS);
        try {
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"quantdesk:twoyear-download");wake.acquire(6L*60*60*1000);}
        }catch(Exception ignored){}
        final String token=intent.getStringExtra("tushare_token");
        final boolean allowMetered=intent.getBooleanExtra("allow_metered",false);
        job=new Thread(()->{
            VaultDb vault=new VaultDb(getApplicationContext());
            try{
                NativeCollector collector=new NativeCollector(getApplicationContext(),vault,new NativeCollector.Feedback(){
                    @Override public void onUpdate(String message){ progress=message;PROGRESS=message;
                        Log.i("QuantDeskHarvest",message);
                        Matcher m=PROGRESS_PATTERN.matcher(message);
                        if(m.find()){try{processed=Integer.parseInt(m.group(1));total=Integer.parseInt(m.group(2));}catch(Exception ignored){}}
                        if(System.currentTimeMillis()-lastNotificationMs>2500){lastNotificationMs=System.currentTimeMillis();show(message);} }
                    @Override public boolean isPaused(){return shouldStop.get();}
                },token,HarvestPolicy.today().getYear()-2,850,allowMetered);
                collector.runTwoYearDaily();
            }catch(Exception e){
                progress="采集发生错误: "+e.getClass().getSimpleName()+" / "+e.getMessage();
                PROGRESS=progress;show(progress);
            }finally{
                vault.close();RUNNING.set(false);
                if(wake!=null && wake.isHeld())wake.release();
                stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
            }
        },"market-harvest-worker");
        job.start();return START_NOT_STICKY;
    }
    private void show(String message){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(manager==null)return;
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"QuantDesk 数据采集",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,CHANNEL)
           .setContentTitle("QuantDesk · A 股 / 港股数据库采集")
           .setContentText(message.length()>90?message.substring(0,90):message)
           .setSmallIcon(android.R.drawable.stat_sys_download)
           .setOngoing(true).setOnlyAlertOnce(true)
           .setProgress(Math.max(1,total),Math.max(0,processed),total==0)
           .setContentIntent(pending).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(1024,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(1024,n);
    }
    @Override public void onDestroy(){shouldStop.set(true);
        if(wake!=null && wake.isHeld())wake.release();
        super.onDestroy();}
    @Override public void onTimeout(int startId,int fgsType){
        shouldStop.set(true);PROGRESS="Android 前台服务运行时间限制，进度已写入数据库；请重新打开应用续传";
        stopSelf();
    }
}
