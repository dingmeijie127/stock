package com.quantdesk.v85;

/** Pure-Java market rules; independently runnable with javac (no Android classes). */
public final class MarketRules {
    private MarketRules() {}
    public static boolean validCode(String market, String code) {
        return market != null && code != null && ((market.equals("A") && code.matches("[0-9]{6}")) ||
                (market.equals("HK") && code.matches("[0-9]{5}")));
    }
    public static String secid(String market, String code) {
        if (!validCode(market, code)) throw new IllegalArgumentException("invalid security identifier");
        if (market.equals("HK")) return "116." + code;
        return (code.matches("[569][0-9]{5}") ? "1." : "0.") + code;
    }
    public static String tsCode(String market, String code) {
        if (!validCode(market, code)) throw new IllegalArgumentException("invalid security identifier");
        if (market.equals("HK")) return code + ".HK";
        return code + (code.matches("[569][0-9]{5}") ? ".SH" :
                code.matches("[48][0-9]{5}") ? ".BJ" : ".SZ");
    }
    /** Yahoo Hong Kong symbols normally use four digits for sub-10000 codes,
     * although the internal exchange code is kept at five digits (e.g. 00700 -> 0700.HK).
     * Never rewrite the canonical 5-digit code stored in SQLite.
     */
    public static String yahooTicker(String market, String code) {
        if (!validCode(market, code)) throw new IllegalArgumentException("invalid security identifier");
        if (market.equals("HK")) {
            String yahooCode = code.charAt(0)=='0' ? code.substring(1) : code;
            return yahooCode + ".HK";
        }
        return code + (code.matches("[569][0-9]{5}") ? ".SS" :
                       code.matches("[48][0-9]{5}") ? ".BJ" : ".SZ");
    }
    public static void validateBar(double open, double high, double low, double close, double volume) {
        if (!Double.isFinite(open) || !Double.isFinite(high) || !Double.isFinite(low) ||
                !Double.isFinite(close) || !Double.isFinite(volume) || low <= 0 || volume < 0 ||
                high < low || open < low - .00001 || open > high + .00001 ||
                close < low - .00001 || close > high + .00001) {
            throw new IllegalArgumentException("invalid OHLCV");
        }
    }
    public static String rangeTask(String market, String code, String kind, int startYear, int endYear) {
        if (!validCode(market, code) || startYear > endYear || startYear < 1980 || endYear > 2100)
            throw new IllegalArgumentException("invalid task");
        return market + ":" + code + ":" + kind + ":" + startYear + "-" + endYear;
    }
}
