import com.quantdesk.v85.HarvestPolicy;
import java.time.LocalDate;
import java.util.List;

public final class HarvestPolicyTest {
    private static int checks;
    private static void ok(boolean yes,String note){checks++;if(!yes)throw new AssertionError(note);}
    public static void main(String[] args) {
        LocalDate day=LocalDate.of(2026,10,24);
        LocalDate from=HarvestPolicy.beginning(day);
        ok(from.equals(LocalDate.of(2024,10,24)),"rolling two years");
        List<LocalDate[]> segments=HarvestPolicy.split(from,day);
        ok(segments.size()==2,"two full roughly annual chunks");
        ok(segments.get(0)[0].equals(from),"first day correct");
        ok(segments.get(segments.size()-1)[1].equals(day),"last day correct");
        for(int i=1;i<segments.size();i++)ok(segments.get(i-1)[1].plusDays(1).equals(segments.get(i)[0]),"no gaps");
        ok(HarvestPolicy.percent(50,200)==25,"percentage");
        ok(HarvestPolicy.percent(99,0)==0,"zero total");
        ok(HarvestPolicy.percent(300,200)==100,"percentage clamp");
        ok(HarvestPolicy.inside("2025-10-24",from,day),"included date");
        ok(!HarvestPolicy.inside("2024-10-23",from,day),"outside date");
        ok(HarvestPolicy.key("HK","00700",from,day).contains("HK:00700:day2y:"),"HK key leading zero preserved");
        ok(!HarvestPolicy.key("A","600519",from,day).equals(HarvestPolicy.key("HK","00700",from,day)),"isolated markets");
        LocalDate leap=LocalDate.of(2024,2,29);
        ok(HarvestPolicy.beginning(leap).equals(LocalDate.of(2022,2,28)),"leap date robust");
        ok(HarvestPolicy.split(day,day).size()==1,"single date range");
        System.out.println("PASS HarvestPolicyTest: "+checks+" assertions");
    }
}
