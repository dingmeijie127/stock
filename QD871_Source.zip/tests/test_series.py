import pytest
from unittest.mock import Mock
from quantdesk_v85.series import candle,validate_series,AKShareSeries,EastMoneySeries,get_series
from quantdesk_v85.core import DataError
from quantdesk_v85.store import Store

def test_multifrequency_candles_separate_dates_and_keys():
 x=candle('HK','00700','5m','2024-01-05 09:30:00',300,310,299,305,10,'fixture')
 assert x['key']=='HK:00700:5m:2024-01-05T09:30:00'
 y=candle('HK','00700','week','2024-01-05',300,310,299,305,10,'fixture')
 assert y['key']=='HK:00700:week:2024-01-05'
 with pytest.raises(DataError):candle('HK','00700','1m','2024-01-05 09:35:00',311,310,299,305,10,'fixture')

def test_minute_hk_akshare_sample():
 sdk=Mock();sdk.stock_hk_hist_min_em.return_value=Mock(to_dict=lambda orient:[{
  '时间':'2024-01-05 09:35:00','开盘':300,'最高':301,'最低':299,'收盘':300.5,'成交量':210,'成交额':5000}])
 p=AKShareSeries(sdk)
 rows=p.series('HK','00700','5m')
 assert rows[0]['interval']=='5m' and rows[0]['close']==300.5
 assert sdk.stock_hk_hist_min_em.call_args.kwargs['period']=='5'

def test_weekly_fallback_eastmoney_fixture():
 class FakeSession:
  def get(self,*args,**kwargs):
   return Mock(raise_for_status=lambda:None,json=lambda:{'rc':0,'data':{'klines':['2024-01-05,300,310,320,290,100,10000']}})
 p=EastMoneySeries(FakeSession())
 result=get_series('A','600519','week',providers=[p])
 assert result['rows'][0]['key']=='A:600519:week:2024-01-05'
 assert result['source']=='eastmoney'

def test_series_storage_does_not_splice_adjustment(tmp_path):
 db=Store(tmp_path/'series.sqlite')
 try:
  x=candle('A','600519','5m','2024-01-05 09:30:00',300,310,290,301,100,'a')
  y=candle('A','600519','5m','2024-01-05 09:35:00',320,330,310,321,100,'b',adjustment='qfq')
  db.save_series([x]);db.save_series([y])
  assert db.get_series('A','600519','5m')==[y]
 finally:db.close()
