"""Verify real SQLite DDL from Android source without requiring Android SDK.
These tests do NOT claim network coverage or APK binary compilation.
"""
import pathlib, re, sqlite3, xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
JAVA = ROOT / 'android-app/app/src/main/java/com/quantdesk/v85'
VAULT = (JAVA/'VaultDb.java').read_text(encoding='utf-8')
ENGINE = (JAVA/'NativeCollector.java').read_text(encoding='utf-8')
ACTIVITY = (JAVA/'MainActivity.java').read_text(encoding='utf-8')
SERVICE = (JAVA/'HarvestService.java').read_text(encoding='utf-8')


def db():
    conn = sqlite3.connect(':memory:')
    ddl = re.findall(r'db\.execSQL\("(CREATE (?:TABLE|INDEX)[^"\\]*(?:\\.[^"\\]*)*)"\);', VAULT)
    assert len(ddl) >= 10, f'only {len(ddl)} schema declarations found'
    for query in ddl:
        conn.execute(query)
    return conn


def test_android_db_ddl_valid():
    con = db()
    names = {x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {'instruments','candles','financial_statements','auxiliary_data','fetch_tasks',
            'ingest_runs','catalog_checks','fetch_errors','data_gaps'} <= names


def test_symbol_uniqueness_per_exchange():
    con = db()
    vals=('A','600519','贵州茅台',None,None,'eastmoney',1,'{}')
    con.execute('INSERT INTO instruments VALUES (?,?,?,?,?,?,?,?)',vals)
    try:
        con.execute('INSERT INTO instruments VALUES (?,?,?,?,?,?,?,?)',vals)
    except sqlite3.IntegrityError:pass
    else:raise AssertionError('duplicate instrument accepted')
    con.execute('INSERT INTO instruments VALUES (?,?,?,?,?,?,?,?)',('HK','60051','test',None,None,'src',1,'{}'))


def test_candle_adjustment_not_spliced():
    con = db()
    args=('HK','00700','day','none','2025-09-01',10,11,9,10,100,'SHARES',None,'yahoo',1,'{}')
    con.execute('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',args)
    con.execute('INSERT INTO candles VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',args[:3]+('qfq',)+args[4:])
    assert con.execute('SELECT count(*) FROM candles').fetchone()[0] == 2


def test_financials_keep_source_identity():
    con=db()
    vals=('HK','00700','income','2024-12-31','tushare','UNKNOWN','UPSTREAM_ORIGINAL',None,'{}',1)
    con.execute('INSERT INTO financial_statements VALUES (?,?,?,?,?,?,?,?,?,?)',vals)
    con.execute('INSERT INTO financial_statements VALUES (?,?,?,?,?,?,?,?,?,?)',vals[:4]+('other',)+vals[5:])
    assert con.execute('SELECT count(*) FROM financial_statements').fetchone()[0] == 2


def test_checkpoint_supports_retry_and_resume():
    con=db()
    con.execute('INSERT INTO fetch_tasks VALUES (?,?,?,?,?,?,?,?,?,?)',('A:600519:day:2020-2023','A','600519','day','observed',1,950,'eastmoney',None,1))
    assert con.execute("SELECT count(*) FROM fetch_tasks WHERE status='observed'").fetchone()[0] == 1


def test_error_and_gap_tables():
    con=db()
    con.execute('INSERT INTO fetch_errors(task_key,reason,occurred_at) VALUES (?,?,?)',('HK:00700:income','permission required',1))
    con.execute('INSERT INTO data_gaps VALUES (?,?,?,?,?)',('HK','00700','three_statements_missing','missing cashflow',1))
    assert con.execute('SELECT count(*) FROM data_gaps').fetchone()[0] == 1


def test_android_manifest_foreground_download():
    manifest=ET.parse(ROOT/'android-app/app/src/main/AndroidManifest.xml').getroot()
    names=[el.attrib.get('{http://schemas.android.com/apk/res/android}name') for el in manifest.findall('uses-permission')]
    assert 'android.permission.INTERNET' in names
    assert 'android.permission.FOREGROUND_SERVICE_DATA_SYNC' in names
    app=manifest.find('application')
    assert any('HarvestService' in el.attrib.get('{http://schemas.android.com/apk/res/android}name','') for el in app.findall('service'))


def test_mobile_downloader_has_real_http_and_queue():
    assert 'HttpURLConnection' in ENGINE
    assert 'push2his.eastmoney.com' in ENGINE
    assert 'query1.finance.yahoo.com' in ENGINE
    assert 'api.tushare.pro' in ENGINE
    assert 'collectSecurity(' in ENGINE and 'collectIntraday(' in ENGINE
    assert 'vault.done(' in ENGINE and 'recordTask(' in ENGINE


def test_mobile_ui_shows_database_and_buttons():
    for label in ('创建 / 打开本地 SQLite','后台下载最近两年日K','暂停采集','导出全部数据库','查询本地 K 线'):
        assert label in ACTIVITY
    assert 'Intent.ACTION_CREATE_DOCUMENT' in ACTIVITY
    assert 'stopForeground' in SERVICE


def test_source_does_not_embed_token():
    assert not re.search(r'(?i)(tushareToken\s*=\s*"[A-Za-z0-9]{16,}")',ENGINE)
    assert 'tushare_token' in ACTIVITY
    assert 'token.setText("")' in ACTIVITY
