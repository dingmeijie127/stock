"""Offline contract tests. Database DDL executed in SQLite; no false claim of live provider testing."""
from pathlib import Path
import re
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'android-app/app/src/main/java/com/quantdesk/v85'
APP = (JAVA / 'MainActivity.java').read_text()
ENGINE = (JAVA / 'NativeCollector.java').read_text()
SERVICE = (JAVA / 'HarvestService.java').read_text()
DB = (JAVA / 'VaultDb.java').read_text()


def schema():
    conn = sqlite3.connect(':memory:')
    statements = re.findall(r'db.execSQL\("(CREATE (?:TABLE|INDEX)[^"\\]*)"\);', DB)
    assert len(statements) >= 13
    for sql in statements:
        conn.execute(sql)
    return conn


def test_upgrade_tables_do_not_delete_stock_data():
    db = schema()
    db.execute("INSERT INTO instruments VALUES ('HK','00700','腾讯',NULL,NULL,'src',1,'{}')")
    db.execute("INSERT INTO harvest_state(id,window_start,window_end,status,processed,updated_at) VALUES (1,'2024-10-24','2026-10-24','paused',123,1)")
    assert db.execute('SELECT count(*) FROM instruments').fetchone()[0] == 1
    assert db.execute('SELECT processed FROM harvest_state').fetchone()[0] == 123
    assert 'createHarvestTables(db)' in DB and 'oldVersion<2' in DB
    assert 'DROP TABLE' not in DB


def test_logs_are_persistent_and_ordered():
    db = schema()
    db.execute("INSERT INTO harvest_logs(time_ms,level,message) VALUES (1,'INFO','Downloaded A:600519')")
    db.execute("INSERT INTO harvest_logs(time_ms,level,message) VALUES (2,'ERROR','HK:00700 HTTP_429')")
    values = db.execute('SELECT message FROM harvest_logs ORDER BY id DESC').fetchall()
    assert values == [('HK:00700 HTTP_429',), ('Downloaded A:600519',)]
    assert 'recentLogs(1500)' in APP


def test_button_triggers_real_foreground_worker():
    assert 'startForegroundService(job)' in APP
    assert 'HarvestService.START' in APP
    assert 'new NativeCollector' in SERVICE
    assert 'collector.runTwoYearDaily()' in SERVICE
    assert 'startForeground(1024' in SERVICE
    assert 'setProgress(' in SERVICE
    assert 'runAll()' not in SERVICE


def test_progress_print_export_and_pause_are_wired():
    for term in ('progressBar.setProgress(', 'db.recentLogs(15)', 'EXPORT_LOG',
                 'Intent.ACTION_CREATE_DOCUMENT', 'onActivityResult', 'HarvestService.PAUSE'):
        assert term in APP
    for term in ('vault.updateHarvest(', 'vault.log(', 'vault.finishHarvest(',
                 'vault.done(wholeKey)', 'vault.recordTask(', 'vault.initHarvest('):
        assert term in ENGINE
    assert 'isPaused()' in ENGINE


def test_network_and_period_are_real():
    assert 'eastDailyBetween(' in ENGINE
    assert 'yahooDailyBetween(' in ENGINE
    assert 'tushareDailyBetween(' in ENGINE
    assert 'HarvestPolicy.beginning(end)' in ENGINE
    assert 'HarvestPolicy.split(start,end)' in ENGINE
    assert 'runTwoYearDaily()' in ENGINE
    assert '&& cm.isActiveNetworkMetered()' in ENGINE
    assert 'allow_metered' in APP and 'allowMetered' in ENGINE
    assert 'collectIntraday(market,code' not in ENGINE.split('public void runTwoYearDaily()')[1].split('public void runAll()')[0]
    assert 'financeForPeriod(market,code' not in ENGINE.split('public void runTwoYearDaily()')[1].split('public void runAll()')[0]


def test_security_and_continuity():
    assert 'MarketRules.validateBar(' in ENGINE
    assert 'data_gaps' in DB
    assert 'getDatabasePath' in ENGINE and 'LOW_STORAGE' in ENGINE
    assert 'versionCode 87' in (ROOT/'android-app/app/build.gradle').read_text()
    manifest = ET.parse(ROOT / 'android-app/app/src/main/AndroidManifest.xml').getroot()
    permissions = {x.attrib['{http://schemas.android.com/apk/res/android}name'] for x in manifest.findall('uses-permission')}
    assert 'android.permission.WAKE_LOCK' in permissions
    assert 'android.permission.FOREGROUND_SERVICE_DATA_SYNC' in permissions
