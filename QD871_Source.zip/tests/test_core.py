import json
import sqlite3
from datetime import date
from pathlib import Path
from unittest.mock import Mock
import pytest
from quantdesk_v85.core import (symbol, ts_code, numeric, iso_date, bar, financial, Fallback,DataError,ProviderError)
from quantdesk_v85.providers import EastMoney,AKShare,Tushare,YahooFinance
from quantdesk_v85.store import Store
from quantdesk_v85.config import load_config
from quantdesk_v85.cli import backfill

@pytest.mark.parametrize('market,code,out',[('A','600519','600519.SH'),('A','000001','000001.SZ'),('A','830799','830799.BJ'),('HK','00700','00700.HK')])
def test_exchange_symbols(market,code,out): assert ts_code(market,code)==out
@pytest.mark.parametrize('market,code',[('HK','700'),('A','00700'),('A','abc123'),('HK','700.0'),('US','AAPL')])
def test_invalid_symbols(market,code):
 with pytest.raises(DataError):symbol(market,code)
def test_number_sanitizing():
 assert numeric('NA') is None and numeric('NaN') is None and numeric(float('inf')) is None and numeric('1.25')==1.25
@pytest.mark.parametrize('value',['20240230','2026-13-10','2026/10/24','not a date'])
def test_reject_invalid_dates(value):
 with pytest.raises(DataError):iso_date(value)
def test_bar_validation():
 good=bar('HK','00700','2024-01-04',300,315,299,310,10000,'fixture')
 assert good['key']=='HK:00700:2024-01-04'
 with pytest.raises(DataError):bar('HK','00700','2024-01-04',320,315,299,310,10000,'fixture')
 with pytest.raises(DataError):bar('HK','00700','2024-01-04',300,315,299,310,-1,'fixture')
def test_finance_preserves_raw_and_periods():
 f=financial('HK','00700','balance','20241231','tushare',{'总资产':120000,'应收':None})
 assert f['rawFields']['总资产']==120000 and f['currency']=='HKD'
 assert f['key'].startswith('HK:00700:2024-12-31:balance')

class FakeResponse:
 def __init__(self,j):self.j=j
 def raise_for_status(self):pass
 def json(self):return self.j

def test_eastmoney_realistic_fixture_hk():
 resp={'rc':0,'data':{'klines':['2024-01-04,301,310,315,299,1234,9000','2024-01-05,310,320,325,308,1900,11000']}}
 sess=Mock();sess.get.return_value=FakeResponse(resp)
 rows=EastMoney(session=sess).bars('HK','00700')
 assert len(rows)==2 and rows[1]['close']==320 and rows[1]['adjustment']=='none'
 assert '116.00700'==sess.get.call_args.kwargs['params']['secid']
def test_eastmoney_rejects_missing_data():
 s=Mock();s.get.return_value=FakeResponse({'rc':102})
 with pytest.raises(ProviderError):EastMoney(session=s).bars('A','600519')

def test_tushare_hk_financial_pivots_indicators():
 fake=Mock()
 fake.hk_balancesheet.return_value=Mock(to_dict=lambda orient:[{'end_date':'20241231','ind_name':'总资产','ind_value':123},
                                                                {'end_date':'20241231','ind_name':'总负债','ind_value':45}])
 rows=Tushare(pro=fake).finance('HK','00700','balance')
 assert len(rows)==1 and rows[0]['rawFields']=={'总资产':123,'总负债':45}
 assert fake.hk_balancesheet.call_args.kwargs['ts_code']=='00700.HK'

def test_akshare_kline_mapping_and_sort():
 mock=Mock()
 mock.stock_hk_hist.return_value=Mock(to_dict=lambda orient:[
  {'日期':'2024-01-05','开盘':300,'最高':310,'最低':298,'收盘':305,'成交量':100,'成交额':2000},
  {'日期':'2024-01-04','开盘':301,'最高':304,'最低':299,'收盘':302,'成交量':200,'成交额':3000}])
 res=AKShare(sdk=mock).bars('HK','00700',adjust='qfq')
 assert [r['date'] for r in res]==['2024-01-04','2024-01-05'] and res[0]['adjustment']=='qfq'

def test_fallback_handles_invalid_primary_and_records_source():
 class Broken:
  name='vendor_one'
  def bars(self,*args,**kwargs):return [bar('A','000001','2024-01-05',11,10,9,9,1,'broken')]
 class Good:
  name='vendor_two'
  def bars(self,*args,**kwargs):return [bar('A','000001','2024-01-05',10,11,9,10,1,'good')]
 r=Fallback([Broken(),Good()]).fetch('bars','A','000001')
 assert r.source=='vendor_two' and len(r.errors)==1

def test_finance_aggregates_raw_from_independent_sources():
 class P1:
  name='source1'
  def finance(self,*args,**kwargs):return [financial('HK','00700','income','20241231','source1',{'Revenue':1})]
 class P2:
  name='source2'
  def finance(self,*args,**kwargs):return [financial('HK','00700','cashflow','20241231','source2',{'Operating':3})]
 r=Fallback([P1(),P2()]).fetch('finance','HK','00700')
 assert {x['type'] for x in r.rows}=={'income','cashflow'} and r.source=='source1+source2'

def test_fallback_empty_not_success():
 class Empty:
  name='empty'
  def finance(self,*args,**kwargs):return []
 with pytest.raises(ProviderError):Fallback([Empty()]).fetch('finance','A','600519')

def test_store_transactions_and_local_denominator(tmp_path):
 store=Store(tmp_path/'x.sqlite')
 try:
  store.save('instruments',[{'key':'A:600519','market':'A','code':'600519','name':'贵州茅台','source':'fixture'}])
  r=bar('A','600519','2024-01-05',99,105,98,100,200,'fixture')
  store.save('bars',[r]);assert store.rows('bars','A','600519')[0]['close']==100
  cov=store.coverage()
  assert cov['markets']['A']['localUniverse']==1 and cov['markets']['A']['symbolsWithAnyKline']==1
  assert cov['markets']['A']['universeOfficiallyVerified'] is False
  store.mark('A:600519:bars','failed','rate limit');store.mark('A:600519:bars','complete','ok')
  assert store.status('A:600519:bars')=='complete'
 finally:store.close()

def test_store_no_mixed_adjustment(tmp_path):
 s=Store(tmp_path/'x.sqlite')
 try:
  raw=bar('HK','00700','2024-01-04',300,310,290,300,120,'source1')
  s.save('bars',[raw])
  qfq=bar('HK','00700','2024-01-05',350,360,340,350,120,'source2',adjustment='qfq')
  s.save('bars',[qfq])
  result=s.rows('bars','HK','00700')
  assert len(result)==1 and result[0]['adjustment']=='qfq'
 finally:s.close()

def test_backfill_marks_finance_incomplete_without_stopping(tmp_path,monkeypatch):
 cfg=load_config()
 s=Store(tmp_path/'x.sqlite')
 s.save('instruments',[{'key':'HK:00700','market':'HK','code':'00700','name':'Tencent','source':'fixture'}])
 class FakePipeline:
  def fetch(self,category,market,code,**kwargs):
   rows=[bar('HK','00700','2024-01-04',300,310,290,300,120,'fixture')] if category=='bars' else [financial('HK','00700','income','20241231','fixture',{'Revenue':1})]
   return Mock(rows=rows)
 monkeypatch.setattr('quantdesk_v85.cli.fallback',lambda *args,**kwargs:FakePipeline())
 stats=backfill(cfg,s,('HK',),sleep=lambda x:None)
 assert stats['bars']==1 and stats['finance']==1 and stats['failed']==0
 assert s.status('HK:00700:finance')=='partial' and stats['gaps']
 s.close()

def test_config_source_matrix():
 cfg=load_config()
 assert cfg['markets']==['A','HK']
 assert len(cfg['sources']['bars'])>=3 and len(cfg['sources']['finance'])>=3
 assert 'token' not in str(cfg).lower() or 'TUSHARE_TOKEN' in str(cfg)
