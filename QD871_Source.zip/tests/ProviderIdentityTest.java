import com.quantdesk.v85.MarketRules;
public class ProviderIdentityTest {
    public static void main(String[] args) {
        if (!MarketRules.yahooTicker("HK","00700").equals("0700.HK"))throw new AssertionError("Tencent HK suffix");
        if (!MarketRules.yahooTicker("HK","00005").equals("0005.HK"))throw new AssertionError("HSBC HK suffix");
        if (!MarketRules.yahooTicker("HK","09988").equals("9988.HK"))throw new AssertionError("Alibaba HK suffix");
        if (!MarketRules.yahooTicker("HK","10000").equals("10000.HK"))throw new AssertionError("5-digit HK");
        if (!MarketRules.yahooTicker("A","600519").equals("600519.SS"))throw new AssertionError("SSE suffix");
        if (!MarketRules.yahooTicker("A","000001").equals("000001.SZ"))throw new AssertionError("SZSE suffix");
        System.out.println("PASS: Yahoo Finance symbol contracts (A/HK)");
    }
}
