from tempfile import TemporaryDirectory
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock
from quantdesk_v85 import service
from quantdesk_v85.store import Store
from quantdesk_v85.config import load_config
from quantdesk_v85.core import bar,financial

@pytest.fixture
def app_and_db(tmp_path,monkeypatch):
    s=Store(tmp_path/'data.sqlite')
    monkeypatch.setattr(service,'context',lambda:(load_config(),s))
    yield TestClient(service.app),s
    s.close()

def test_health_and_coverage_on_empty_db(app_and_db):
    client,s=app_and_db
    r=client.get('/v1/health')
    assert r.status_code==200 and r.json()['version']=='8.5.0' and r.json()['dataVerified'] is False
    r=client.get('/v1/coverage')
    assert r.json()['markets']['HK']['localUniverse']==0

def test_bad_stock_symbol_is_422(app_and_db):
    client,s=app_and_db
    assert client.get('/v1/bars/HK/700').status_code==422
    assert client.get('/v1/finance/A/00700').status_code==422

def test_service_ingests_actual_only(app_and_db,monkeypatch):
    client,store=app_and_db
    class Fake:
        def fetch(self,category,market,code=None,**kwargs):
            if category=='universe':return Mock(rows=[{'key':'HK:00700','market':'HK','code':'00700','name':'腾讯控股','source':'test'}],source='test',errors=[])
            if category=='bars':return Mock(rows=[bar('HK','00700','2024-01-04',300,310,290,300,100,'test')],source='test',errors=[])
            if category=='finance':return Mock(rows=[financial('HK','00700','income','20241231','test',{'Revenue':10})],source='test',errors=[])
            raise AssertionError(category)
    monkeypatch.setattr(service,'fallback',lambda *args:Fake())
    assert client.get('/v1/universe/HK?refresh=true').json()['count']==1
    assert client.get('/v1/bars/HK/00700?limit=1&refresh=true').json()['rows'][0]['close']==300
    fin=client.get('/v1/finance/HK/00700?refresh=true').json()
    assert fin['types']==['income'] and fin['threeTypesObserved'] is False
    cover=client.get('/v1/coverage').json()['markets']['HK']
    assert cover['symbolsWithAnyKline']==1 and cover['symbolsWith220Bars']==0
    assert cover['symbolsWithThreeStatementsSamePeriod']==0

def test_service_falls_back_to_explicit_failure(app_and_db,monkeypatch):
    client,s=app_and_db
    class Broken:
        def fetch(self,*args,**kwargs):raise RuntimeError('no vendor connectivity')
    monkeypatch.setattr(service,'fallback',lambda *args:Broken())
    with pytest.raises(RuntimeError,match='no vendor connectivity'):
        client.get('/v1/finance/HK/00700?refresh=true')
