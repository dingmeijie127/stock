import com.quantdesk.v85.DailyBar;
import java.time.LocalDate;
public final class DailyBarTest {
    private static int checks;
    private static void yes(boolean condition){checks++;if(!condition)throw new AssertionError("Test number "+checks+" failed");}
    private static void bad(String raw,LocalDate from,LocalDate to){
        try {DailyBar.fromEastmoney(raw,from,to);throw new AssertionError("Should reject row: "+raw);}
        catch(IllegalArgumentException expected){checks++;}
    }
    public static void main(String[] args) {
        LocalDate a=LocalDate.of(2024,10,24),z=LocalDate.of(2026,10,24);
        DailyBar b=DailyBar.fromEastmoney("2025-11-14,10.00,10.20,10.50,9.80,12300,125000,extra",a,z);
        yes(b!=null);yes(b.date.equals("2025-11-14"));yes(b.open==10.00);
        yes(b.close==10.20);yes(b.high==10.50);yes(b.low==9.80);
        yes(b.volume==12300);yes(b.turnover==125000);
        yes(DailyBar.fromEastmoney("2023-01-01,10,11,12,9,100,1000",a,z)==null);
        yes(DailyBar.fromEastmoney("2024-10-24,10,11,12,9,100,-",a,z).turnover==null);
        bad("2025-01-01,10,11",a,z);
        bad("2025-01-01,10,11,9,8,100,1000",a,z);
        bad("2025-01-01,10,11,12,9,-1,1000",a,z);
        bad("2025-01-01,nan,11,12,9,100,1000",a,z);
        System.out.println("PASS DailyBarTest: "+checks+" assertions");
    }
}
