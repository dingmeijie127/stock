const test=require('node:test'),assert=require('node:assert/strict');
const path=require('node:path');
const root=path.resolve(__dirname,'../web');
global.localStorage={_v:{},getItem(k){return this._v[k]??null},setItem(k,v){this._v[k]=v},removeItem(k){delete this._v[k]}};
global.QuantKlineQuality=require(path.join(root,'kline-quality.js'));
const p=require(path.join(root,'v85-provider.js'));

test('reject unsafe / credential-bearing API URLs',()=>{
 for(const s of ['http://myhost:80','https://user:pass@bad.com','javascript:alert(1)','https://example.com/path','https://example.com?token=a','https://example.com/#token'])
  assert.equal(p.validUrl(s),false,s);
 assert.equal(p.validUrl('https://data.example.com'),true);
 assert.equal(p.validUrl('http://127.0.0.1:8765'),true);
});
test('save + clear URL, no API token persistence',()=>{
 assert.equal(p.configure('https://example.com/'),'https://example.com');
 assert.equal(p.configured(),'https://example.com');
 assert.equal(p.configure(''),'');
});
test('accept source-identified OHLC and reject mixed adjustments',()=>{
 const mk=(d,adjust='none')=>({key:'HK:00700:'+d,market:'HK',code:'00700',date:d,open:100,high:101,low:99,close:100,volume:10,adjustment:adjust,source:'fixture'});
 let rows=p.barsNormalized({rows:[mk('2024-01-04'),mk('2024-01-05')],adjustment:'none',source:'test'},'00700','HK');
 assert.equal(rows.length,2);
 assert.throws(()=>p.barsNormalized({rows:[mk('2024-01-04'),mk('2024-01-05','qfq')],adjustment:'none'},'00700','HK'),/复权/);
 assert.throws(()=>p.barsNormalized({rows:[mk('2024-01-05'),mk('2024-01-04')],adjustment:'none'},'00700','HK'),/KLINE_DATE/);
});
test('service returns errors instead of fabricated success',async()=>{
 p.configure('https://collector.example.com');
 const prev=global.fetch;
 global.fetch=async()=>({ok:false,status:503,json:async()=>({detail:'vendor unavailable'})});
 try {await assert.rejects(p.backendBars('600519','A',200),/HTTP 503/)}finally{global.fetch=prev;p.configure('')}
});
test('existing provider can be patched for fallback without breaking legacy',async()=>{
 let old=0;
 const fake={bars:async()=>{old++;return ['legacy bar']},financialPage:async()=>({rows:['legacy']})};
 p.installProvider(fake);
 assert.equal((await fake.bars('600519','A'))[0],'legacy bar');
 assert.equal(old,1);
 assert.equal(fake._v85Installed,true);
});
test('original V8.4 quality checker accepts honest short history but can refuse readiness',()=>{
 const q=global.QuantKlineQuality;
 const row={key:'A:600519:2024-01-04',market:'A',code:'600519',date:'2024-01-04',open:99,high:101,low:98,close:100,volume:100};
 assert.equal(q.validate([row],{market:'A',code:'600519',min:1}).count,1);
 assert.throws(()=>q.validate([row],{market:'A',code:'600519',min:220}),/KLINE_SHORT/);
});
test('V8.5 coverage includes HK three-statement report completeness',()=>{
 const audit=require(path.join(root,'data-coverage-audit.js'));
 const stocks=[{market:'HK',code:'00700',name:'腾讯控股',key:'HK:00700'}];
 const finance=['income','balance','cashflow'].map(type=>({market:'HK',code:'00700',type,reportDate:'2024-12-31'}));
 const result=audit.audit({universe:stocks,finance,now:new Date('2025-01-01T00:00:00Z')});
 assert.equal(result.markets.HK.financeThreeTypes,1);
 assert.equal(result.markets.HK.financeFourTypes,0);
 assert.equal(result.markets.HK.financeMissing,0);
});
