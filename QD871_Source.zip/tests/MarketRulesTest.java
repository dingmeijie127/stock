import com.quantdesk.v85.MarketRules;
public class MarketRulesTest {
  static int count=0;
  static void eq(Object x,Object y){count++;if(!x.equals(y))throw new AssertionError(x+" != "+y);}
  static void invalid(Runnable task){count++;try{task.run();throw new AssertionError("expected exception");}catch(IllegalArgumentException expected){}}
  public static void main(String[] args){
    eq(MarketRules.validCode("A","600519"),true);
    eq(MarketRules.validCode("A","830799"),true);
    eq(MarketRules.validCode("HK","00700"),true);
    eq(MarketRules.validCode("HK","0700"),false);
    eq(MarketRules.secid("HK","00700"),"116.00700");
    eq(MarketRules.secid("A","600519"),"1.600519");
    eq(MarketRules.secid("A","000001"),"0.000001");
    eq(MarketRules.tsCode("A","830799"),"830799.BJ");
    eq(MarketRules.tsCode("HK","00700"),"00700.HK");
    eq(MarketRules.rangeTask("A","600519","day",1990,1993),"A:600519:day:1990-1993");
    MarketRules.validateBar(10,12,9,11,0);count++;
    invalid(()->MarketRules.validateBar(12,10,9,11,400));
    invalid(()->MarketRules.validateBar(10,12,9,11,-1));
    invalid(()->MarketRules.rangeTask("HK","00700","day",2026,1990));
    invalid(()->MarketRules.secid("HK","700"));
    System.out.println("Native MarketRules tests PASS: "+count);
  }
}
