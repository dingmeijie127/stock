"""Run full-symbol backfill using SQLite checkpoints and modest rate limits."""
import argparse
import json
import logging
import os
import time
from datetime import datetime,timezone
from .config import load_config,fallback
from .store import Store
from .core import DataError,ProviderError

log=logging.getLogger(__name__)

def backfill(cfg, db, markets=('A','HK'), do_bars=True, do_finance=True, limit_symbols=0, sleep=time.sleep, progress=print):
    tally={'symbols':0,'bars':0,'finance':0,'failed':0,'skipped':0,'gaps':[]}
    interval=float(cfg.get('network',{}).get('minimum_interval_seconds',0.35))
    retries=int(cfg.get('network',{}).get('retry_attempts',3))
    for market in markets:
        directory=db.instruments(market)
        if not directory:
            try:
                directory=fallback('universe',cfg).fetch('universe',market).rows
                db.save('instruments',directory)
            except Exception as e:
                tally['failed']+=1;tally['gaps'].append(f'{market}:universe:{str(e)[:150]}');progress(f'{market} 目录失败：{e}');continue
        if limit_symbols:directory=directory[:limit_symbols]
        for item in directory:
            code=item['code'];tally['symbols']+=1
            for category,enabled in (('bars',do_bars),('finance',do_finance)):
                if not enabled:continue
                task=f'{market}:{code}:{category}'
                if db.status(task,max_age_days=7)=='complete':tally['skipped']+=1;continue
                # request bars without an arbitrary 650-bar cap; vendors may truncate histories.
                kwargs=({'start':cfg['history']['start'],'end':cfg['history']['end'],
                         'adjust':cfg['history']['adjustment']} if category=='bars' else
                        {'start':cfg['finance']['start'],'end':cfg['finance']['end']})
                for attempt in range(1,retries+1):
                    try:
                        rows=fallback(category,cfg).fetch(category,market,code,**kwargs).rows
                        if category=='finance':
                            by_period={}
                            for row in rows:by_period.setdefault(row['reportDate'],set()).add(row['type'])
                            complete=any(set(cfg['finance']['required_types']).issubset(types) for types in by_period.values())
                            # Don't mark quarter complete based on noncorresponding periods.
                            db.save('finance',rows)
                            if not complete:
                                db.mark(task,'partial','no period has all three statement types')
                                tally['gaps'].append(f'{task}:THREE_STATEMENT_GAP')
                                tally['finance']+=len(rows)
                                break
                        else:
                            db.save('bars',rows)
                            if len(rows)<cfg['history']['minimum_bars_for_technical_signal']:
                                db.mark(task,'partial',f'only {len(rows)} bars; IPO or source truncation requires review')
                                tally['gaps'].append(f'{task}:SHORT_KLINE_HISTORY:{len(rows)}')
                                tally['bars']+=len(rows)
                                break
                        db.mark(task,'complete',f'{len(rows)} observed rows; refresh due in 7 days, not an official completeness certificate')
                        tally[category]+=len(rows)
                        break
                    except Exception as e:
                        if attempt<retries:
                            sleep(min(30,float(cfg['network'].get('retry_base_delay_seconds',2))*2**(attempt-1)))
                        else:
                            db.mark(task,'failed',e)
                            tally['failed']+=1;tally['gaps'].append(f'{task}:{str(e)[:180]}')
                    finally:sleep(interval)
            if tally['symbols']%20==0:progress(f'{market}: {tally["symbols"]}只，K线{tally["bars"]}根，财报{tally["finance"]}项，失败{tally["failed"]}')
    return tally

def main():
    parser=argparse.ArgumentParser(description='QuantDesk 8.5 A/HK full-history backfill; errors never counted complete')
    parser.add_argument('command',choices=['backfill','coverage','serve','live-check'])
    parser.add_argument('--markets',nargs='+',choices=['A','HK'],default=['A','HK'])
    parser.add_argument('--limit-symbols',type=int,default=0)
    parser.add_argument('--bars-only',action='store_true');parser.add_argument('--finance-only',action='store_true')
    parser.add_argument('--db',default=None);parser.add_argument('--config',default=None)
    args=parser.parse_args()
    cfg=load_config(args.config)
    if args.command=='live-check':
        from .livecheck import run
        r=run(cfg)
        print(json.dumps(r,ensure_ascii=False,indent=2))
        if not r['passed']:raise SystemExit(2)
        return
    if args.command=='serve':
        import uvicorn
        if args.config:os.environ['QD_CONFIG']=args.config
        if args.db:os.environ['QD_DB_PATH']=args.db
        uvicorn.run('quantdesk_v85.service:app',host='127.0.0.1',port=8765)
        return
    db=Store(args.db or cfg['storage']['sqlite_path'])
    try:
        if args.command=='coverage':print(json.dumps(db.coverage(),ensure_ascii=False,indent=2))
        else:
            output=backfill(cfg,db,tuple(args.markets),do_bars=not args.finance_only,do_finance=not args.bars_only,limit_symbols=args.limit_symbols)
            print(json.dumps({'result':output,'coverage':db.coverage()},ensure_ascii=False,indent=2))
            if output['failed']:raise SystemExit(2)
    finally:db.close()

if __name__=='__main__':main()
