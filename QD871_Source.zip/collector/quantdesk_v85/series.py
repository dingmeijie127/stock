"""Optional A/HK daily/weekly/monthly and limited historical minute candles.

Different intervals are stored under different keys; minute vendors typically retain only
recent windows, so an empty period cannot be represented as historical completeness.
"""
from datetime import datetime,date
import re
from .core import symbol, numeric, DataError, ProviderError
from .providers import AKShare, EastMoney

INTERVALS=('day','week','month','1m','5m','15m','30m','60m')

def candle(market,code,interval,moment,op,high,low,close,volume,source,adjustment='none',amount=None):
 symbol(market,code)
 if interval not in INTERVALS:raise DataError('INVALID_INTERVAL')
 raw=str(moment).strip()
 if interval in ('day','week','month'):
  stamp=raw[:10]
  try:date.fromisoformat(stamp)
  except ValueError as e:raise DataError('INVALID_SERIES_DATE') from e
 else:
  stamp=raw[:19].replace(' ','T')
  try:datetime.fromisoformat(stamp)
  except ValueError as e:raise DataError('INVALID_SERIES_TIME') from e
 prices=[numeric(x) for x in (op,high,low,close,volume)]
 o,h,l,c,v=prices
 if any(x is None for x in prices) or l<=0 or v<0 or h<l or not(l-0.00001<=o<=h+0.00001 and l-0.00001<=c<=h+0.00001):
  raise DataError('INVALID_CANDLE_OHLC')
 if stamp[:10]>date.today().isoformat():raise DataError('FUTURE_CANDLE')
 return {'key':f'{market}:{code}:{interval}:{stamp}','market':market,'code':code,'interval':interval,
         'moment':stamp,'open':o,'high':h,'low':l,'close':c,'volume':v,'amount':numeric(amount),
         'source':source,'adjustment':adjustment}

def validate_series(rows,market,code,interval):
 if not rows:raise DataError('EMPTY_CANDLES')
 if any(r['market']!=market or r['code']!=code or r['interval']!=interval for r in rows):raise DataError('SERIES_SYMBOL_MISMATCH')
 stamps=[r['moment'] for r in rows]
 if stamps!=sorted(set(stamps)):raise DataError('SERIES_DATE_DUPLICATE_UNSORTED')
 if len({r['adjustment'] for r in rows})!=1:raise DataError('SERIES_ADJUSTMENT_MIXED')
 return rows

class AKShareSeries:
 name='akshare'
 def __init__(self,sdk=None):self.provider=AKShare(sdk)
 def series(self,market,code,interval,adjust='none'):
  symbol(market,code)
  if interval not in INTERVALS:raise DataError('INVALID_INTERVAL')
  adj={'none':'','qfq':'qfq','hfq':'hfq'}[adjust]
  sdk=self.provider.sdk
  if interval in ('day','week','month'):
   method=sdk.stock_hk_hist if market=='HK' else sdk.stock_zh_a_hist
   frame=method(symbol=code,period={'day':'daily','week':'weekly','month':'monthly'}[interval],
                start_date='19900101',end_date='20500101',adjust=adj)
   records=frame.to_dict(orient='records')
   out=[candle(market,code,interval,r['日期'],r['开盘'],r['最高'],r['最低'],r['收盘'],r['成交量'],self.name,adjust,r.get('成交额')) for r in records]
  else:
   method=sdk.stock_hk_hist_min_em if market=='HK' else sdk.stock_zh_a_hist_min_em
   # Minute history limits are set upstream (e.g., 1-minute often only a few days).
   if interval=='1m' and adjust!='none':raise DataError('ONE_MINUTE_UNADJUSTED_ONLY')
   frame=method(symbol=code,period=interval[:-1],start_date='1979-01-01 09:30:00',
                end_date='2222-01-01 16:30:00',adjust=adj)
   records=frame.to_dict(orient='records')
   out=[candle(market,code,interval,r['时间'],r['开盘'],r['最高'],r['最低'],r['收盘'],r['成交量'],self.name,adjust,r.get('成交额')) for r in records]
  return validate_series(sorted(out,key=lambda r:r['moment']),market,code,interval)

class EastMoneySeries:
 name='eastmoney'
 def __init__(self,session=None):self.provider=EastMoney(session)
 def series(self,market,code,interval,adjust='none'):
  if interval not in ('day','week','month'):raise ProviderError('EASTMONEY_MINUTE_NOT_CONNECTED')
  symbol(market,code)
  secid=('116.' if market=='HK' else '1.' if code[0] in '659' else '0.')+code
  data=self.provider._get('push2his.eastmoney.com','/api/qt/stock/kline/get',{
    'secid':secid,'fields1':'f1,f2,f3,f4,f5,f6',
    'fields2':'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61',
    'klt':{'day':101,'week':102,'month':103}[interval],
    'fqt':{'none':0,'qfq':1,'hfq':2}[adjust],
    'end':'20500101','lmt':100000,'ut':'fa5fd1943c7b386f172d6893dbfba10'})
  raw=data.get('klines')
  if not isinstance(raw,list):raise ProviderError('NO_CANDLES')
  out=[]
  for x in raw:
   v=x.split(',')
   if len(v)<6:raise DataError('INVALID_VENDOR_CANDLE')
   out.append(candle(market,code,interval,v[0],v[1],v[3],v[4],v[2],v[5],self.name,adjust,v[6] if len(v)>6 else None))
  return validate_series(out,market,code,interval)

def get_series(market,code,interval='day',adjust='none',providers=None,limit=0):
 if interval not in INTERVALS:raise DataError('INVALID_INTERVAL')
 if adjust not in ('none','qfq','hfq'):raise DataError('INVALID_ADJUSTMENT')
 sources=providers or [AKShareSeries(),EastMoneySeries()]
 errors=[]
 for provider in sources:
  try:
   rows=provider.series(market,code,interval,adjust)
   if not rows:raise DataError('EMPTY_CANDLES')
   return {'rows':rows[-limit:] if limit else rows,'source':provider.name,'interval':interval,
           'adjustment':adjust,'count':min(limit,len(rows)) if limit else len(rows),'errors':errors,
           'status':'observed','allTradingPeriodsVerified':False}
  except Exception as e:errors.append(f'{provider.name}: {type(e).__name__}: {str(e)[:200]}')
 raise ProviderError('ALL_INTERVAL_SOURCES_FAILED: '+' | '.join(errors))
