"""Validated A/HK market data with explicit lineage, no synthesized prices."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any
import math
import re

SYMBOLS = {'A': re.compile(r'^\d{6}$'), 'HK': re.compile(r'^\d{5}$')}
TYPES = ('income', 'balance', 'cashflow', 'summary')

class DataError(ValueError):
    pass

class ProviderError(RuntimeError):
    pass

def symbol(market: str, code: str) -> str:
    code = str(code).strip()
    if market not in SYMBOLS or not SYMBOLS[market].fullmatch(code):
        raise DataError('INVALID_SYMBOL')
    return code

def ts_code(market: str, code: str) -> str:
    symbol(market, code)
    if market == 'HK': return code + '.HK'
    return code + ('.SH' if code[0] in '659' else '.BJ' if code[0] in '48' else '.SZ')

def numeric(x: Any) -> float | None:
    if x is None or isinstance(x, bool) or (isinstance(x, str) and x.strip() in ('', '-', '--')):
        return None
    try:
        z = float(x)
        return z if math.isfinite(z) else None
    except (ValueError, TypeError): return None

def iso_date(x: Any) -> str:
    x = str(x).strip().split(' ')[0]
    if re.fullmatch(r'\d{8}', x): x = f'{x[:4]}-{x[4:6]}-{x[6:]}'
    try:
        if date.fromisoformat(x).isoformat() != x: raise ValueError()
    except ValueError as exc: raise DataError('INVALID_DATE') from exc
    return x

def bar(market, code, day, op, high, low, close, volume, source, amount=None, adjustment='none'):
    code = symbol(market, code)
    d = iso_date(day)
    o, h, l, c, v = (numeric(z) for z in (op, high, low, close, volume))
    if any(x is None for x in (o, h, l, c, v)) or l <= 0 or v < 0 or h < l or not (l-0.00001 <= o <= h+0.00001 and l-0.00001 <= c <= h+0.00001):
        raise DataError(f'INVALID_OHLC:{market}:{code}:{d}')
    if d > date.today().isoformat(): raise DataError('FUTURE_BAR')
    return {'key': f'{market}:{code}:{d}', 'market': market, 'code': code, 'date': d,
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': v,
            'amount': numeric(amount), 'source': source, 'adjustment': adjustment}

def validate_bars(rows, market, code, limit=None):
    if not rows: raise DataError('EMPTY_BARS')
    dates = [x['date'] for x in rows]
    if dates != sorted(set(dates)): raise DataError('UNSORTED_OR_DUPLICATE_BARS')
    if any(x['market'] != market or x['code'] != code or x['key'] != f'{market}:{code}:{x["date"]}' for x in rows):
        raise DataError('SYMBOL_MISMATCH')
    adjustments = {x['adjustment'] for x in rows}
    if len(adjustments) != 1: raise DataError('MIXED_ADJUSTMENT')
    if limit and len(rows) > limit: rows = rows[-limit:]
    return rows

def financial(market, code, kind, period, source, fields, notice=None, currency=None):
    symbol(market, code)
    if kind not in TYPES: raise DataError('INVALID_FINANCIAL_TYPE')
    p = iso_date(period)
    n = iso_date(notice) if notice else None
    fields = {str(k): sanitize(v) for k, v in fields.items()}
    # Keep raw financial fields: different accounting regimes must not be guessed into the same unit.
    return {'key': f'{market}:{code}:{p}:{kind}:{source}', 'market': market,
            'code': code, 'type': kind, 'reportDate': p, 'noticeDate': n,
            'currency': currency or ('HKD' if market == 'HK' else 'CNY'),
            'rawFields': fields, 'source': source, 'fetchedAt': datetime.now(timezone.utc).isoformat()}

def sanitize(obj):
    if obj is None or isinstance(obj, (str, int, bool)): return obj
    if isinstance(obj, float): return obj if math.isfinite(obj) else None
    if isinstance(obj, (date, datetime)): return obj.isoformat()
    if isinstance(obj, dict): return {str(k): sanitize(v) for k,v in obj.items()}
    if isinstance(obj, (tuple, list)): return [sanitize(v) for v in obj]
    try:
        if hasattr(obj, 'item'): return sanitize(obj.item())
    except Exception: pass
    return str(obj)

@dataclass
class Result:
    rows: list[dict]
    source: str
    errors: list[str]
    status: str = 'observed'  # NEVER certified just because an endpoint succeeded

class Fallback:
    """Try independent providers in priority order. Reject empty/invalid data."""
    def __init__(self, providers): self.providers = providers
    def fetch(self, category, market, code=None, **kwargs):
        errors = []
        merged = []
        used = []
        for p in self.providers:
            method = getattr(p, category, None)
            if not callable(method): continue
            try:
                rows = method(market, code, **kwargs)
                if not rows: raise DataError('EMPTY_RESPONSE')
                if category == 'bars': rows = validate_bars(rows, market, symbol(market, code), kwargs.get('limit'))
                if category == 'finance' and any(r.get('type') not in TYPES or r.get('market') != market or r.get('code') != code for r in rows):
                    raise DataError('INVALID_FINANCIAL_SCHEMA')
                if category != 'finance': return Result(rows=rows, source=p.name, errors=errors)
                merged.extend(rows)
                used.append(p.name)
            except Exception as exc:
                errors.append(f'{p.name}: {type(exc).__name__}: {str(exc)[:180]}')
        if merged:
            # Different data vendors must keep separate provenance; don't overwrite raw statements.
            unique = {r['key']:r for r in merged}
            return Result(rows=list(unique.values()), source='+'.join(used), errors=errors)
        raise ProviderError('ALL_SOURCES_FAILED | ' + ' | '.join(errors))
