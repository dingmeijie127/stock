"""Connectors are lazy: missing optional SDKs do not prevent other sources."""
from __future__ import annotations
from datetime import date, datetime, timezone
import os
import re
from .core import bar, financial, numeric, iso_date, symbol, ts_code, DataError, ProviderError

class EastMoney:
    name='eastmoney'
    def __init__(self, session=None, timeout=12):
        if session is None:
            import requests
            session = requests.Session()
        self.session, self.timeout = session, timeout

    def _get(self, host, path, params):
        r = self.session.get('https://' + host + path, params=params, timeout=self.timeout)
        r.raise_for_status()
        j = r.json()
        if j.get('rc', 0) not in (0, None) or not isinstance(j.get('data'), dict):
            raise ProviderError('UPSTREAM_FAILURE')
        return j['data']

    def bars(self, market, code, start='19900101', end='20500101', limit=None, adjust='none'):
        symbol(market,code)
        if adjust not in ('none','qfq','hfq'): raise DataError('ADJUSTMENT_INVALID')
        secid = ('116.' if market == 'HK' else ('1.' if code[0] in '659' else '0.')) + code
        j = self._get('push2his.eastmoney.com', '/api/qt/stock/kline/get', {
            'secid':secid, 'fields1':'f1,f2,f3,f4,f5,f6',
            'fields2':'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61',
            'klt':101,'fqt':{'none':0,'qfq':1,'hfq':2}[adjust],
            'beg': start, 'end':end,'lmt':100000,'ut':'fa5fd1943c7b386f172d6893dbfba10'})
        raw = j.get('klines')
        if not isinstance(raw, list) or not raw: raise ProviderError('NO_KLINES')
        out=[]
        for x in raw:
            parts=x.split(',')
            if len(parts)<6: raise DataError('BAD_KLINE_FIELDS')
            out.append(bar(market,code,parts[0],parts[1],parts[3],parts[4],parts[2],parts[5],self.name,parts[6] if len(parts)>6 else None,adjust))
        return out[-limit:] if limit else out

    def universe(self, market, code=None):
        if market not in ('A','HK'): raise DataError('INVALID_MARKET')
        fs = 'm:128' if market=='HK' else 'm:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048,m:0+t:81+s:262144'
        out={}; total=None; size=200
        for page in range(1, 250):
            j = self._get('push2.eastmoney.com','/api/qt/clist/get',{
                'pn':page,'pz':size,'po':1,'np':1,'ut':'fa5fd1943c7b386f172d6893dbfba10',
                'fltt':2,'invt':2,'fid':'f6','fs':fs,'fields':'f12,f14,f2,f3,f5,f6,f86'})
            total=int(j.get('total') or 0)
            diff=j.get('diff') or []
            data=diff if isinstance(diff, list) else list(diff.values())
            if not data and total and len(out)<total: raise ProviderError(f'UNIVERSE_PAGE_EMPTY_{page}')
            for r in data:
                c=str(r.get('f12',''))
                if not (len(c)==(5 if market=='HK' else 6) and c.isdecimal()): continue
                name=str(r.get('f14') or '').strip()
                if not name: continue
                out[c]={'key':f'{market}:{c}','market':market,'code':c,'name':name,
                        'price':numeric(r.get('f2')),'source':self.name,'catalogFetchedAt':datetime.now(timezone.utc).isoformat()}
            if total and page*size>=total: break
        if not total or len(out)<total*0.90: raise ProviderError(f'UNIVERSE_INCOMPLETE:{len(out)}/{total}')
        return list(out.values())

class AKShare:
    name='akshare'
    def __init__(self, sdk=None): self._sdk=sdk
    @property
    def sdk(self):
        if self._sdk is None:
            import akshare
            self._sdk=akshare
        return self._sdk
    def bars(self, market, code, start='19900101', end='20500101', limit=None, adjust='none'):
        symbol(market,code)
        adj = {'none':'','qfq':'qfq','hfq':'hfq'}[adjust]
        fn = self.sdk.stock_hk_hist if market=='HK' else self.sdk.stock_zh_a_hist
        frame = fn(symbol=code,period='daily',start_date=start,end_date=end,adjust=adj)
        records=frame.to_dict(orient='records')
        out=[bar(market,code,r['日期'],r['开盘'],r['最高'],r['最低'],r['收盘'],r['成交量'],self.name,r.get('成交额'),adjust) for r in records]
        return sorted(out,key=lambda r:r['date'])[-limit:] if limit else sorted(out,key=lambda r:r['date'])
    def universe(self,market,code=None):
        if market not in ('A','HK'): raise DataError('INVALID_MARKET')
        frame = self.sdk.stock_hk_spot_em() if market=='HK' else self.sdk.stock_zh_a_spot_em()
        out=[]
        for r in frame.to_dict(orient='records'):
            c=str(r.get('代码','')).zfill(5 if market=='HK' else 6)
            if not (c.isdecimal() and len(c)==(5 if market=='HK' else 6)): continue
            name=str(r.get('名称') or '').strip()
            if not name: continue
            out.append({'key':f'{market}:{c}','market':market,'code':c,'name':name,
                        'price':numeric(r.get('最新价')),'source':self.name,
                        'catalogFetchedAt':datetime.now(timezone.utc).isoformat()})
        if len(out)<20: raise ProviderError('SUSPICIOUS_SHORT_DIRECTORY')
        return out
    def finance(self,market,code,kind=None,start='20000101',end='20500101'):
        # 新浪的上市公司三表逐股数据，在一些金融/新股标的上不完整。
        if market!='A': raise ProviderError('AKSHARE_HK_FINANCE_UNSUPPORTED')
        if kind not in ('balance','income','cashflow',None): raise DataError('INVALID_KIND')
        prefix= 'sh' if code[0] in '659' else 'bj' if code[0] in '48' else 'sz'
        out=[]
        for typ,label in [('balance','资产负债表'),('income','利润表'),('cashflow','现金流量表')]:
            if kind and kind!=typ: continue
            frame=self.sdk.stock_financial_report_sina(stock=label,symbol=prefix+code)
            for r in frame.to_dict(orient='records'):
                dt=r.get('报告日') or r.get('报告日期') or r.get('报告期')
                if not dt: continue
                d=iso_date(str(dt)[:10]); ymd=d.replace('-','')
                if start<=ymd<=end: out.append(financial(market,code,typ,d,self.name,r))
        return out

class Tushare:
    name='tushare'
    def __init__(self, token=None, pro=None): self.token=token or os.getenv('TUSHARE_TOKEN',''); self._pro=pro
    @property
    def pro(self):
        if self._pro is None:
            if not self.token: raise ProviderError('TUSHARE_TOKEN_MISSING')
            import tushare as ts
            self._pro=ts.pro_api(self.token)
        return self._pro
    def bars(self,market,code,start='19900101',end='20500101',limit=None,adjust='none'):
        if adjust!='none': raise ProviderError('TUSHARE_BARS_RAW_ONLY')
        name='hk_daily' if market=='HK' else 'daily'
        frame=getattr(self.pro,name)(ts_code=ts_code(market,code),start_date=start,end_date=end)
        out=[bar(market,code,r['trade_date'],r['open'],r['high'],r['low'],r['close'],r.get('vol',0),self.name,r.get('amount')) for r in frame.to_dict(orient='records')]
        return sorted(out,key=lambda r:r['date'])[-limit:] if limit else sorted(out,key=lambda r:r['date'])
    def universe(self,market,code=None):
        if market=='HK': frame=self.pro.hk_basic()
        elif market=='A':
            frame=self.pro.stock_basic(exchange='',list_status='L',fields='ts_code,symbol,name,market,list_date')
        else: raise DataError('INVALID_MARKET')
        out=[]
        for r in frame.to_dict(orient='records'):
            tc=str(r.get('ts_code',''))
            c=tc.split('.')[0]
            if not re.fullmatch(r'\d{5}' if market=='HK' else r'\d{6}',c):continue
            if market=='HK' and not tc.endswith('.HK'):continue
            if market=='A' and not re.fullmatch(r'\d{6}\.(SH|SZ|BJ)',tc):continue
            name=str(r.get('name','')).strip()
            if not name:continue
            out.append({'key':f'{market}:{c}','market':market,'code':c,'name':name,
                        'source':self.name,'catalogFetchedAt':datetime.now(timezone.utc).isoformat()})
        if len(out)<20: raise ProviderError('SUSPICIOUS_SHORT_DIRECTORY')
        return out
    def finance(self,market,code,kind=None,start='20000101',end='20500101'):
        symbol(market,code)
        out=[]
        kinds=['income','balance','cashflow'] if kind is None else [kind]
        for k in kinds:
            if k not in ('income','balance','cashflow'):raise DataError('INVALID_KIND')
            fn = {'balance':'hk_balancesheet' if market=='HK' else 'balancesheet',
                  'income':'hk_income' if market=='HK' else 'income',
                  'cashflow':'hk_cashflow' if market=='HK' else 'cashflow'}[k]
            frame=getattr(self.pro,fn)(ts_code=ts_code(market,code),start_date=start,end_date=end)
            records=frame.to_dict(orient='records')
            if market=='HK':
                # HK API returns one ROW PER INDICATOR: group into one report per period.
                periods={}
                for r in records:
                    p=r.get('end_date')
                    if not p:continue
                    periods.setdefault(str(p),{})[str(r.get('ind_name') or 'unknown')]=r.get('ind_value')
                for p,fields in periods.items():out.append(financial(market,code,k,p,self.name,fields))
            else:
                for r in records:
                    p=r.get('end_date')
                    if p:out.append(financial(market,code,k,p,self.name,r,notice=str(r.get('ann_date') or '') or None))
        return out

class YahooFinance:
    name='yfinance'
    def __init__(self, sdk=None):self._sdk=sdk
    @property
    def sdk(self):
        if self._sdk is None:
            import yfinance
            self._sdk=yfinance
        return self._sdk
    def _ticker(self,market,code):
        symbol(market,code)
        return code+'.HK' if market=='HK' else code+('.SS' if code[0] in '659' else '.BJ' if code[0] in '48' else '.SZ')
    def bars(self,market,code,start='19900101',end='20500101',limit=None,adjust='none'):
        if adjust!='none':raise ProviderError('YFINANCE_RAW_ONLY')
        ticker=self.sdk.Ticker(self._ticker(market,code))
        frame=ticker.history(start=iso_date(start),end=iso_date(end),interval='1d',auto_adjust=False)
        records=frame.reset_index().to_dict(orient='records')
        out=[bar(market,code,str(r['Date'])[:10],r['Open'],r['High'],r['Low'],r['Close'],r['Volume'],self.name) for r in records]
        return out[-limit:] if limit else out
    def finance(self,market,code,kind=None,start='20000101',end='20500101'):
        if market not in ('HK','A'):raise DataError('INVALID_MARKET')
        t=self.sdk.Ticker(self._ticker(market,code))
        out=[]
        for k,attr in [('income','income_stmt'),('balance','balance_sheet'),('cashflow','cashflow')]:
            if kind and k!=kind:continue
            frame=getattr(t,attr)
            if frame is None or frame.empty:continue
            for period,values in frame.to_dict().items():
                d=iso_date(str(period)[:10]); ymd=d.replace('-','')
                if start<=ymd<=end:
                    out.append(financial(market,code,k,d,self.name,values,currency=None))
        return out

REGISTRY={'eastmoney':EastMoney,'akshare':AKShare,'tushare':Tushare,'yfinance':YahooFinance}
