import os
from pathlib import Path
import yaml
from .providers import REGISTRY
from .core import Fallback

DEFAULT_PATH=Path(__file__).resolve().parents[2]/'config'/'data_sources.yml'
def load_config(path=None):
    with open(path or os.getenv('QD_CONFIG',DEFAULT_PATH),encoding='utf-8') as f: return yaml.safe_load(f)
def fallback(category,config,providers=None):
    if providers is None:providers={name:cls() for name,cls in REGISTRY.items()}
    names=config['sources'][category]
    if not names or any(n not in providers for n in names):raise ValueError('INVALID_PROVIDER_CONFIGURATION')
    return Fallback([providers[n] for n in names])
