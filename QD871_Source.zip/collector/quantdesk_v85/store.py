"""Transactional SQLite cache and resumable checkpoints with explicit gaps."""
import sqlite3, json
from datetime import datetime,timezone
from .core import symbol

class Store:
 def __init__(self,path):
    self.db=sqlite3.connect(str(path),timeout=30,check_same_thread=False)
    self.db.execute('PRAGMA journal_mode=WAL')
    self.db.executescript('''
    CREATE TABLE IF NOT EXISTS instruments (id TEXT PRIMARY KEY, market TEXT NOT NULL, code TEXT NOT NULL, name TEXT NOT NULL, provider TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS bars (id TEXT PRIMARY KEY, market TEXT NOT NULL, code TEXT NOT NULL, date TEXT NOT NULL, adjustment TEXT NOT NULL, provider TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS finance (id TEXT PRIMARY KEY, market TEXT NOT NULL, code TEXT NOT NULL, period TEXT NOT NULL, kind TEXT NOT NULL, provider TEXT NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS attempts (task TEXT PRIMARY KEY, status TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL, details TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS bars_symbol_date ON bars (market,code,date);
    CREATE INDEX IF NOT EXISTS fin_symbol_date ON finance (market,code,period);
    CREATE TABLE IF NOT EXISTS candles (id TEXT PRIMARY KEY,market TEXT NOT NULL,code TEXT NOT NULL,interval TEXT NOT NULL,moment TEXT NOT NULL,adjustment TEXT NOT NULL,provider TEXT NOT NULL,payload TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS candles_query ON candles (market,code,interval,moment);
    ''')
    self.db.commit()
 def close(self):self.db.close()
 def save(self,table,rows):
    if table not in ('instruments','bars','finance'):raise ValueError('ILLEGAL_TABLE')
    with self.db:
     if table=='bars' and rows:
      # An adjustment/provider change must not create a spliced historical series.
      market,code=rows[0]['market'],rows[0]['code']
      if any(r['market']!=market or r['code']!=code or r.get('adjustment')!=rows[0].get('adjustment') for r in rows):
       raise ValueError('MIXED_SERIES_BATCH')
      old=self.db.execute('SELECT DISTINCT adjustment,provider FROM bars WHERE market=? AND code=?',(market,code)).fetchall()
      if any(a!=rows[0].get('adjustment','none') or p!=rows[0].get('source','unknown') for a,p in old):
       self.db.execute('DELETE FROM bars WHERE market=? AND code=?',(market,code))
     for r in rows:
      key=r['key']; source=r.get('source','unknown')
      if table=='instruments':
       self.db.execute('INSERT OR REPLACE INTO instruments VALUES (?,?,?,?,?,?)',(key,r['market'],r['code'],r['name'],source,json.dumps(r,ensure_ascii=False)))
      elif table=='bars':
       self.db.execute('INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?)',(key,r['market'],r['code'],r['date'],r.get('adjustment','none'),source,json.dumps(r,ensure_ascii=False)))
      else:
       self.db.execute('INSERT OR REPLACE INTO finance VALUES (?,?,?,?,?,?,?)',(key,r['market'],r['code'],r['reportDate'],r['type'],source,json.dumps(r,ensure_ascii=False)))
    return len(rows)
 def mark(self,key,status,details=''):
    if status not in ('complete','partial','failed'):raise ValueError('INVALID_STATUS')
    with self.db:self.db.execute('''INSERT INTO attempts VALUES (?, ?, 1, ?, ?)
     ON CONFLICT(task) DO UPDATE SET status=excluded.status,n=n+1,updated_at=excluded.updated_at,details=excluded.details''',
     (key,status,datetime.now(timezone.utc).isoformat(),str(details)[:2000]))
 def status(self,key,max_age_days=None):
    r=self.db.execute('SELECT status,updated_at FROM attempts WHERE task=?',(key,)).fetchone()
    if not r:return None
    if max_age_days is not None:
     try:
      age=(datetime.now(timezone.utc)-datetime.fromisoformat(r[1])).total_seconds()/86400
      if age>max_age_days:return 'stale'
     except (ValueError,TypeError):return 'stale'
    return r[0]
 def instruments(self,market):
    return [json.loads(r[0]) for r in self.db.execute('SELECT payload FROM instruments WHERE market=? ORDER BY code',(market,))]
 def rows(self,table,market,code,limit=None):
    symbol(market,code)
    if table not in ('bars','finance'):raise ValueError('ILLEGAL_TABLE')
    order='date' if table=='bars' else 'period'
    q=f'SELECT payload FROM {table} WHERE market=? AND code=? ORDER BY {order} DESC'
    if limit:q+=' LIMIT '+str(max(1,min(200000,int(limit))))
    return list(reversed([json.loads(r[0]) for r in self.db.execute(q,(market,code))]))
 def save_series(self,rows):
    if not rows:return 0
    market,code,interval=rows[0]['market'],rows[0]['code'],rows[0]['interval']
    if any((r['market'],r['code'],r['interval'],r['adjustment'])!=(market,code,interval,rows[0]['adjustment']) for r in rows):
     raise ValueError('MIXED_SERIES')
    with self.db:
     existing=self.db.execute('SELECT DISTINCT adjustment,provider FROM candles WHERE market=? AND code=? AND interval=?',(market,code,interval)).fetchall()
     if any(a!=rows[0]['adjustment'] or p!=rows[0]['source'] for a,p in existing):
      self.db.execute('DELETE FROM candles WHERE market=? AND code=? AND interval=?',(market,code,interval))
     for r in rows:self.db.execute('INSERT OR REPLACE INTO candles VALUES (?,?,?,?,?,?,?,?)',
       (r['key'],market,code,interval,r['moment'],r['adjustment'],r['source'],json.dumps(r,ensure_ascii=False)))
    return len(rows)
 def get_series(self,market,code,interval,limit=0):
    symbol(market,code)
    q='SELECT payload FROM candles WHERE market=? AND code=? AND interval=? ORDER BY moment DESC'
    if limit:q+=' LIMIT '+str(min(int(limit),200000))
    return list(reversed([json.loads(r[0]) for r in self.db.execute(q,(market,code,interval))]))
 def coverage(self):
    output={}
    for market in ('A','HK'):
     known=int(self.db.execute('SELECT COUNT(*) FROM instruments WHERE market=?',(market,)).fetchone()[0])
     has_bars=int(self.db.execute('SELECT COUNT(DISTINCT code) FROM bars WHERE market=?',(market,)).fetchone()[0])
     has_220=int(self.db.execute('SELECT COUNT(*) FROM (SELECT code FROM bars WHERE market=? GROUP BY code HAVING COUNT(*)>=220)',(market,)).fetchone()[0])
     has_500=int(self.db.execute('SELECT COUNT(*) FROM (SELECT code FROM bars WHERE market=? GROUP BY code HAVING COUNT(*)>=500)',(market,)).fetchone()[0])
     has_fin=int(self.db.execute('SELECT COUNT(DISTINCT code) FROM finance WHERE market=?',(market,)).fetchone()[0])
     three=int(self.db.execute("SELECT COUNT(*) FROM (SELECT code,period FROM finance WHERE market=? AND kind IN ('income','balance','cashflow') GROUP BY code,period HAVING COUNT(DISTINCT kind)=3)",(market,)).fetchone()[0])
     with_three=int(self.db.execute("SELECT COUNT(DISTINCT code) FROM (SELECT code,period FROM finance WHERE market=? AND kind IN ('income','balance','cashflow') GROUP BY code,period HAVING COUNT(DISTINCT kind)=3)",(market,)).fetchone()[0])
     missing_bars=[r[0] for r in self.db.execute('SELECT i.code FROM instruments i WHERE i.market=? AND NOT EXISTS(SELECT 1 FROM bars b WHERE b.market=i.market AND b.code=i.code) LIMIT 25',(market,))]
     missing_fin=[r[0] for r in self.db.execute('SELECT i.code FROM instruments i WHERE i.market=? AND NOT EXISTS(SELECT 1 FROM finance f WHERE f.market=i.market AND f.code=i.code) LIMIT 25',(market,))]
     output[market]={'localUniverse':known,'symbolsWithAnyKline':has_bars,'symbolsWith220Bars':has_220,
                     'symbolsWith500Bars':has_500,'symbolsWithAnyFinancial':has_fin,
                     'symbolsWithThreeStatementsSamePeriod':with_three,
                     'symbolPeriodsWithThreeStatements':three,'universeOfficiallyVerified':False,
                     'kline220CoverageLocalPct':round(100*has_220/known,2) if known else None,
                     'finThreeCoverageLocalPct':round(100*with_three/known,2) if known else None,
                     'missingBarsExamples':missing_bars,'missingFinanceExamples':missing_fin}
    attempts={}
    for state,n in self.db.execute('SELECT status,COUNT(*) FROM attempts GROUP BY status'):attempts[state]=n
    return {'markets':output,'attempts':attempts,'warning':'分母仅为本地已采集目录；可用三表数量不能证明历史所有报告期完整；不证明交易所全市场100%覆盖'}
