"""Actual provider smoke test: requires internet; never emits a green result without live data."""
from datetime import date,datetime
import json
from .config import fallback,load_config

def run(cfg=None,samples=(('A','600519'),('HK','00700'))):
 cfg=cfg or load_config(); report={'test':'live-provider-smoke','onlineTest':True,'passed':False,'samples':[]}
 for market,code in samples:
  item={'market':market,'code':code,'bars':{'passed':False},'finance':{'passed':False}}
  for kind in ('bars','finance'):
   try:
    args=({'start':cfg['history']['start'],'end':cfg['history']['end'],'adjust':cfg['history']['adjustment']} if kind=='bars' else
          {'start':cfg['finance']['start'],'end':cfg['finance']['end']})
    r=fallback(kind,cfg).fetch(kind,market,code,**args)
    if kind=='bars':
     last=r.rows[-1]['date']
     age=(date.today()-date.fromisoformat(last)).days
     ok=len(r.rows)>=220 and -1<=age<=30
     item[kind]={'passed':ok,'count':len(r.rows),'latest':last,'calendarAgeDays':age,'provider':r.source,'errors':r.errors,
                 'criteria':'at least 220 bars, last no more than 30 calendar days old'}
    else:
     byperiod={}
     for x in r.rows:byperiod.setdefault(x['reportDate'],set()).add(x['type'])
     ok=any({'income','balance','cashflow'}.issubset(types) for types in byperiod.values())
     item[kind]={'passed':ok,'count':len(r.rows),'provider':r.source,'errors':r.errors,
                 'periodsWithThree':[p for p,kinds in byperiod.items() if {'income','balance','cashflow'}.issubset(kinds)]}
   except Exception as exc:item[kind]={'passed':False,'error':str(exc)[:350]}
  report['samples'].append(item)
 report['passed']=all(x[k]['passed'] for x in report['samples'] for k in ('bars','finance'))
 return report
