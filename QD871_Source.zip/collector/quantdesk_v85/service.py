"""REST service. Default localhost only; publish over HTTPS with authentication if remote."""
import os
from functools import lru_cache
from pathlib import Path
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from .core import DataError, ProviderError, symbol
from .config import load_config, fallback
from .store import Store

@lru_cache(maxsize=1)
def context():
    cfg=load_config()
    db=Store(os.environ.get('QD_DB_PATH',cfg['storage']['sqlite_path']))
    return cfg,db

app=FastAPI(title='QuantDesk V8.5 Collector',version='8.5.0')
app.add_middleware(CORSMiddleware,allow_origins=['https://appassets.androidplatform.net','http://localhost','http://127.0.0.1'],
                   allow_origin_regex=r'http://localhost:\d+|http://127\.0\.0\.1:\d+',allow_methods=['GET'],allow_headers=['Content-Type'])

@app.get('/v1/health')
def health():
    cfg,_=context()
    return {'version':'8.5.0','markets':cfg['markets'],'backend':'ready','dataVerified':False}

@app.get('/v1/coverage')
def coverage():return context()[1].coverage()

@app.get('/v1/universe/{market}')
def universe(market:str,refresh:bool=False):
    if market not in ('A','HK'):raise HTTPException(422,'INVALID_MARKET')
    cfg,store=context()
    cached=store.instruments(market)
    if cached and not refresh:return {'rows':cached,'source':'sqlite-cache','count':len(cached),'status':'observed'}
    try:
        result=fallback('universe',cfg).fetch('universe',market)
        store.save('instruments',result.rows)
        return {'rows':result.rows,'source':result.source,'count':len(result.rows),'errors':result.errors,'status':'observed'}
    except (DataError,ProviderError) as e:raise HTTPException(503,str(e))

@app.get('/v1/bars/{market}/{code}')
def bars(market:str,code:str,limit:int=Query(650,ge=1,le=200000),refresh:bool=False):
    try:symbol(market,code)
    except DataError as e:raise HTTPException(422,str(e))
    cfg,store=context()
    cached=store.rows('bars',market,code,limit)
    if cached and not refresh and len(cached)>=min(220,limit):
        return {'rows':cached,'source':'sqlite-cache','status':'observed','adjustment':cached[0]['adjustment'],'count':len(cached)}
    try:
        result=fallback('bars',cfg).fetch('bars',market,code,start=cfg['history']['start'],end=cfg['history']['end'],
                                          limit=limit,adjust=cfg['history']['adjustment'])
        store.save('bars',result.rows)
        return {'rows':result.rows,'source':result.source,'errors':result.errors,'count':len(result.rows),
                'adjustment':result.rows[0]['adjustment'],'status':'observed'}
    except (DataError,ProviderError) as e:
        if cached:return {'rows':cached,'source':'sqlite-cache','status':'stale-on-provider-failure','errors':[str(e)],'count':len(cached)}
        raise HTTPException(503,str(e))

@app.get('/v1/finance/{market}/{code}')
def finance(market:str,code:str,kind:str|None=None,refresh:bool=False):
    try:symbol(market,code)
    except DataError as e:raise HTTPException(422,str(e))
    if kind and kind not in ('summary','income','balance','cashflow'):raise HTTPException(422,'INVALID_KIND')
    cfg,store=context()
    cached=[r for r in store.rows('finance',market,code) if not kind or r['type']==kind]
    if cached and not refresh:return {'rows':cached,'source':'sqlite-cache','status':'observed','types':sorted(set(x['type'] for x in cached))}
    try:
        result=fallback('finance',cfg).fetch('finance',market,code,kind=kind,start=cfg['finance']['start'],end=cfg['finance']['end'])
        store.save('finance',result.rows)
        have=sorted(set(x['type'] for x in result.rows))
        return {'rows':result.rows,'source':result.source,'errors':result.errors,'status':'observed',
                'types':have,'threeTypesObserved':set(cfg['finance']['required_types']).issubset(have)}
    except (DataError,ProviderError) as e:
        if cached:return {'rows':cached,'source':'sqlite-cache','status':'stale-on-provider-failure','errors':[str(e)]}
        raise HTTPException(503,str(e))

@app.get('/v1/series/{market}/{code}')
def multi_frequency_series(market:str,code:str,interval:str='day',adjust:str='none',limit:int=Query(650,ge=1,le=200000),refresh:bool=False):
    from .series import INTERVALS,get_series
    try:symbol(market,code)
    except DataError as e:raise HTTPException(422,str(e))
    if interval not in INTERVALS or adjust not in ('none','qfq','hfq'):
        raise HTTPException(422,'INVALID_INTERVAL_OR_ADJUSTMENT')
    _,store=context()
    cached=store.get_series(market,code,interval,limit)
    if cached and cached[0]['adjustment']==adjust and not refresh:
        return {'rows':cached,'source':'sqlite-cache','count':len(cached),'interval':interval,
                'adjustment':adjust,'status':'observed','allTradingPeriodsVerified':False}
    try:
        result=get_series(market,code,interval,adjust,limit=limit)
        store.save_series(result['rows'])
        return result
    except (DataError,ProviderError) as e:
        if cached and cached[0]['adjustment']==adjust:
            return {'rows':cached,'source':'sqlite-cache','count':len(cached),'status':'stale-on-provider-failure',
                    'interval':interval,'adjustment':adjust,'allTradingPeriodsVerified':False,'errors':[str(e)]}
        raise HTTPException(503,str(e))
