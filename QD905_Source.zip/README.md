# QuantDesk V9.0.5 — 免数据 API Token 版（源码）

这是 **源码工程，不是已打包好的 APK，也不是已采齐的全市场数据库**。GitHub Actions 尚需真实编译及 Android 手机联网验收。

## 版本目标

- 从 **V9.0.4** 修改，不修改已能工作的 A 股 / 港股日 K 数据源与每日增量 WorkManager 调度。
- **取消 Tushare Token**：没有 Token 输入框，没有请求 `api.tushare.pro`，也不需要财经数据平台账号。
- **A 股三大财务报表**：东方财富公开接口 `zcfzbDateAjaxNew/zcfzbAjaxNew`、`lrbDateAjaxNew/lrbAjaxNew`、`xjllbDateAjaxNew/xjllbAjaxNew`。按报告期提取近两年原始字段，逐公司校验证券代码、报告日期，存进 `dataset_rows`；源失效时报错，不写假数据。
- **港股财务指标和分红**：东方财富公开 HK F10 `RPT_CUSTOM_HKF10_FN_MAININDICATORMAX` 和 `RPT_HKF10_MAIN_DIVBASIC`。**港股完整的利润表 / 资产负债表 / 现金流量表尚未接入经验证的无密钥结构化接口**，不能称为已覆盖三大表。指标快照也不能冒充完整财报。
- **旧数据继承**：保留 `applicationId=com.quantdesk.asharecollector88`、SQLite 文件名 `quantdesk-a-share-2y.sqlite3`、SQLite v4，版本码增加为 `905`。旧 K 线不删除；财报原始行保留 `provider`、报告期、公告日期（上游提供时）及原始 JSON。
- **失败与限制**：财报 0 行记为 EMPTY，保留七天后再次检查；HTTP 异常写入日志；港股接口返回不完整不得冒充完整。

## 实际数据能力 / 边界

| 数据集 | A 股 | 港股 |
|---|---|---|
| 近两年日 K | 保留 V9.0.4 的三源下载和 SQLite 断点续传 | 保留港股公开行情源下载及缺口标记 |
| 每日增量日 K | WorkManager，受 Android 调度、省电、网络影响 | 同左 |
| 利润表 | 公开 Eastmoney HSF10 报告期接口（需手机联网验收） | **未覆盖完整三表** |
| 资产负债表 | 同上 | **未覆盖完整三表** |
| 现金流量表 | 同上 | **未覆盖完整三表** |
| 财务指标 / 分红 | 先保存三张报表原始字段供后续量化计算 | Eastmoney HK F10 指标快照及分红（需联网验收） |

*公开接口可能限流、改版或返回缺字段。财务报告的公告日、币种、调整及合并口径不一致时，未来做历史回测应先做点时可得性校验；不应把抓取日视为报告公布日。*

**注意：** `DailySources.EAST_TOKEN` 是东方财富公开行情 URL 中固定的 `ut` 参数，**不是用户个人 Token**，没有任何登录/注册页面；本版本要求零个人数据服务凭证。

## GitHub 直接编译（原仓库，无须删除旧版本）

1. 上传 `QD905_Source.zip` 到 GitHub 仓库 **根目录**，不要解压。
2. 上传独立 `QD905_Build.yml` 到 `.github/workflows/`。
3. 打开 `https://github.com/dingmeijie127/stock/actions/workflows/QD905_Build.yml`，选择 `Run workflow`。
4. 工作流只会解压 `QD905_Source.zip`，不会尝试旧版源码。构建时需要联网下载 A 股、港股真实股票目录（失败会停止编译，不发布空目录 APK）。
5. 构建成功后在 Artifacts 下载 APK。**尚未真实验证整个 Android 构建和外部行情源。**

## 不丢数据库的重要条件

旧版本可以覆盖安装，**前提是 APK 包名一致、`versionCode` 递增、签名证书一致**。源码保持前两项，但 GitHub 默认临时 debug 签名仍然可能变化。

- 在旧 APK 内先导出 SQLite 并确认导出的备份不为零；不要先卸载旧应用。
- 最可靠办法：长期固定一份签名密钥，GitHub Secrets 配置 `QD_KEYSTORE_B64`、`QD_SIGNING_ALIAS`、`QD_SIGNING_STORE_PASSWORD`、`QD_SIGNING_KEY_PASSWORD`。新版继续沿用同一份。
- 若已下载的旧版 APK 是另一张证书签名，首次迁移必须用原版导出的 SQLite 经新版安全导入；迁移期间严格保留备份文件。切勿把 keystore、密码提交到公开仓库。

## 本地自测范围

- `python -m pytest -q tests`：数据库结构、迁移、旧 K 线不删除、HK 日线回退、工作流/签名路径。
- `tests/java/PublicFinanceTest.java`：使用模拟 Eastmoney JSON 测 A 股三表、港股指标/分红、报告期、证券代码、源标记、拒绝未支持港股三表；不需网络。
- `javac` 编译其他日线解析、时间窗口和港股代码单元测试。

**只有离线测试通过，不等于** 手机能稳定拿到近两年 A/H 全量财务数据；正式量化系统仍需交易日历、证券存续历史、财务公告可得日期和口径核验。
