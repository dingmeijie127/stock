package com.quantdesk.download;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** V9.0: one local A/H database, two-year initial history then daily incremental updates. */
public final class MainActivity extends Activity {
    private static final int EXPORT_DB=2101, EXPORT_LOG=2102, POST_NOTIFICATIONS_REQUEST=2103, IMPORT_DB=2104;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status,counts,log,diagnostic,financeCount,autoCount,importStatus;
    private ProgressBar progress;
    private boolean visible;
    private static final AtomicBoolean IMPORTING = MarketDb.IMPORT_IN_PROGRESS;
    private final Runnable refresh = new Runnable(){
        @Override public void run(){if(visible){if(!IMPORTING.get())refreshUI();handler.postDelayed(this,5000);}}
    };
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setPadding(dp(4),dp(7),dp(4),dp(7));return t;}
    private void addButton(LinearLayout root,String name,View.OnClickListener click){
        Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setOnClickListener(click);
        root.addView(b,new LinearLayout.LayoutParams(-1,-2));
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(12),dp(16),dp(12));
        ScrollView scroll=new ScrollView(this);scroll.addView(page);setContentView(scroll);
        page.addView(text("QuantDesk V9.0.5 · 无Token公开数据版",21));
        page.addView(text("已下载的日K保留不重下；新日期增量更新。A股/港股同一个SQLite，财报独立采集。",14));
        status=text("正在检查数据库…",16);page.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);page.addView(progress);
        counts=text("A股：0  港股：0  日K：0",15);page.addView(counts);
        diagnostic=text("当前：尚未开始",14);page.addView(diagnostic);
        addButton(page,"开始 / 继续 / 每日增量更新 A股+港股日K",v->start(HarvestService.START));
        autoCount=text("每日自动更新：未启用",14);page.addView(autoCount);
        addButton(page,"开启每天自动更新 A股+港股日K",v->{
            try{DailyUpdateScheduler.setEnabled(this,true);refreshUI();
                status.setText("已安排每天港股时间20:30后自动执行（系统可能延迟）");}
            catch(Exception e){status.setText("自动任务设置失败："+e.getMessage());}
        });
        addButton(page,"立即执行一次自动增量检查",v->{
            try{DailyUpdateScheduler.setEnabled(this,true);DailyUpdateScheduler.runOnce(this);
                status.setText("已安排后台增量检查，查看自动更新进度和日志");}
            catch(Exception e){status.setText("增量任务启动失败："+e.getMessage());}
        });
        addButton(page,"关闭每天自动更新",v->{
            try{DailyUpdateScheduler.setEnabled(this,false);refreshUI();
                status.setText("已取消自动调度；旧数据库不受影响");}
            catch(Exception e){status.setText("关闭失败："+e.getMessage());}
        });

        page.addView(text("免费公开财务数据（不需要 Token）：A股三大报表；港股财务指标和分红。港股完整三大报表尚未覆盖。",14));
        addButton(page,"采集公开财报与财务指标（无需 Token）",v->startFinance());
        financeCount=text("财报：尚未开始",14);page.addView(financeCount);
        addButton(page,"暂停下载",v->pause());
        addButton(page,"导出 SQLite（换版本前先备份）",v->export(EXPORT_DB));
        addButton(page,"导入旧版 SQLite（合并、不覆盖）",v->importOld());
        importStatus=text("数据库导入：尚未执行",14);page.addView(importStatus);
        addButton(page,"导出日志",v->export(EXPORT_LOG));
        page.addView(text("最新采集日志（自动刷新）",17));
        log=text("暂无记录",12);log.setTextIsSelectable(true);page.addView(log);
        try{DailyUpdateScheduler.ensureScheduled(this);}catch(Exception ex){android.util.Log.e("QuantDesk","自动任务恢复失败，不影响手动下载",ex);}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},POST_NOTIFICATIONS_REQUEST);
        }
    }
    private void start(String act){
        try{
            if(IMPORTING.get()){status.setText("正在导入数据库，完成后再开始采集");return;}
            Intent command=new Intent(this,HarvestService.class);command.setAction(act);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(command);else startService(command);
            status.setText("已启动采集请求，请查看进度与日志");
        }catch(Exception e){status.setText("启动失败："+e.getMessage());}
    }
    private void startFinance(){
        if(IMPORTING.get()){status.setText("数据库正在导入，财报任务暂不能启动");return;}
        if(HarvestService.RUNNING.get()){
            status.setText("当前有采集任务在运行，请先等待日K完成或暂停后再启动财报；任务不会假装启动");
            return;
        }
        start(HarvestService.START_FINANCE);
    }
    private void pause(){
        try{
            Intent command=new Intent(this,HarvestService.class);command.setAction(HarvestService.PAUSE);
            startService(command);status.setText("正在暂停，等待当前网络请求结束…");
        }catch(Exception e){status.setText("暂停失败："+e.getMessage());}
    }
    private void refreshUI(){
        try(MarketDb db=new MarketDb(this)){
            JSONObject o=db.overview(),f=db.financeOverview(),auto=db.autoOverview();
            int total=o.optInt("total"),done=o.optInt("done"),failed=o.optInt("failed");
            progress.setProgress(total==0?0:Math.min(100,(done+failed)*100/total));
            counts.setText(String.format(Locale.CHINA,
                "股票 A:%,d  港:%,d  已完成：%,d  失败：%,d\n日K A:%,d  港:%,d  总计:%,d",
                o.optInt("a_count"),o.optInt("hk_count"),done,failed,
                o.optInt("a_bars"),o.optInt("hk_bars"),o.optInt("bars")));
            status.setText("日K状态："+o.optString("phase","未开始")+"  "+o.optString("start","")+" 至 "+o.optString("end",""));
            diagnostic.setText("当前："+o.optString("active","")+"\n"+o.optString("detail",""));
            financeCount.setText("财报/量化："+f.optString("phase","未开始")+" · 已保存记录 "+f.optInt("records")+
                    " · 已处理 "+f.optInt("complete")+"/"+f.optInt("total")+
                    " · 失败 "+f.optInt("failed")+"\n"+f.optString("active","")+" "+f.optString("detail",""));
            autoCount.setText("每日自动更新："+(DailyUpdateScheduler.enabled(this)?"已开启（约每日20:30香港时间后）":"已关闭")+
                "\n上次目标日 "+auto.optString("target","尚无")+" · 状态 "+auto.optString("phase","待执行")+
                " · 已处理 "+auto.optInt("processed")+" · 新增K线 "+auto.optInt("new_bars")+
                " · 失败 "+auto.optInt("failures")+" · 当前可执行剩余 "+auto.optInt("remaining")+" · 暂停市场 "+auto.optInt("blocked_markets")+
                "\n上次检查："+(auto.optLong("updated",0)>0?
                    new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new java.util.Date(auto.optLong("updated"))):"从未执行")+
                "\n"+auto.optString("detail",""));
            if(HarvestService.RUNNING.get())diagnostic.append("\n"+HarvestService.LIVE);
            String recent=db.logs(35);log.setText(recent.isEmpty()?"暂无日志":recent);
        }catch(Exception e){status.setText("数据库读取失败："+e.getMessage());}
    }
    private void export(int type){
        if(type==EXPORT_DB && (HarvestService.RUNNING.get() || IMPORTING.get())){
            Toast.makeText(this,"请先暂停并等待采集结束，再导出完整数据库",Toast.LENGTH_LONG).show();return;
        }
        Intent picker=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        picker.setType(type==EXPORT_DB?"application/octet-stream":"text/plain");
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.putExtra(Intent.EXTRA_TITLE,type==EXPORT_DB?"QuantDesk90-AHK.sqlite3":"QuantDesk90-采集日志.txt");
        try{startActivityForResult(picker,type);}catch(ActivityNotFoundException ex){
            Toast.makeText(this,"没有文件保存应用",Toast.LENGTH_LONG).show();
        }
    }
    private void importOld(){
        if(HarvestService.RUNNING.get() || IMPORTING.get()){
            Toast.makeText(this,"采集或导入正在进行，请先暂停并等待结束",Toast.LENGTH_LONG).show();return;
        }
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("*/*");
        try{startActivityForResult(pick,IMPORT_DB);}catch(Exception e){importStatus.setText("无法打开文件选择器："+e.getMessage());}
    }
    private void importAsync(Uri uri){
        // Prevent simultaneous imports and block WorkManager/foreground collection while importing.
        if(!IMPORTING.compareAndSet(false,true)){
            importStatus.setText("已有数据库导入正在运行，请不要重复点击");return;
        }
        if(HarvestService.RUNNING.get()){
            IMPORTING.set(false);importStatus.setText("采集仍在运行，请先暂停后导入");return;
        }
        importStatus.setText("正在读取备份（不会清空现有日K）…");
        new Thread(()->{
            File folder=new File(getFilesDir(),"imports");
            File temp=new File(folder,"incoming-"+System.nanoTime()+".sqlite3");
            try{
                if(!folder.isDirectory()&&!folder.mkdirs())throw new java.io.IOException("无法创建数据库临时目录");
                long copied=0,lastUpdate=0;
                try(InputStream in=getContentResolver().openInputStream(uri);
                    FileOutputStream out=new FileOutputStream(temp)){
                    if(in==null)throw new IllegalArgumentException("备份文件无法打开");
                    byte[] buf=new byte[131072];int n;
                    while((n=in.read(buf))!=-1){
                        if(n==0)continue;
                        copied+=n;
                        if(copied>4L*1024*1024*1024)throw new IllegalArgumentException("备份超过4GB，停止导入");
                        if(temp.getUsableSpace()<128L*1024*1024)throw new IllegalStateException("手机存储空间不足128MB，已安全停止");
                        out.write(buf,0,n);
                        long now=System.currentTimeMillis();
                        if(now-lastUpdate>1200){
                            final long mb=copied/1048576;
                            runOnUiThread(()->importStatus.setText("正在复制SQLite备份："+mb+" MB"));
                            lastUpdate=now;
                        }
                    }
                    out.getFD().sync();
                }
                SqliteBackupFormat.requireValidFile(temp);
                final long started=System.currentTimeMillis();
                final java.util.concurrent.atomic.AtomicLong lastReport=new java.util.concurrent.atomic.AtomicLong(0);
                try(MarketDb db=new MarketDb(getApplicationContext())){
                    db.mergeBackup(temp,msg->{
                        long now=System.currentTimeMillis();
                        if(now-lastReport.getAndSet(now)>900)
                            runOnUiThread(()->importStatus.setText(msg));
                    });
                    db.log("INFO","导入SQLite成功；已下载日K和财务记录不删除；耗时 "+(System.currentTimeMillis()-started)/1000+"秒");
                }
                runOnUiThread(()->{importStatus.setText("数据库合并成功，原K线保留、重复自动跳过");
                    Toast.makeText(this,"导入完成，可以继续增量下载",Toast.LENGTH_LONG).show();});
            }catch(Throwable e){
                // Android may otherwise kill an unhandled import thread without showing an error.
                String error=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
                android.util.Log.e("QuantDeskImport","数据库合并失败",e);
                runOnUiThread(()->importStatus.setText("导入失败，已保存的原数据不会清空："+error));
            }finally{
                if(temp.exists()&&!temp.delete())android.util.Log.w("QuantDeskImport","Temporary SQLite cleanup failed");
                new File(temp.getPath()+"-wal").delete();
                new File(temp.getPath()+"-shm").delete();
                IMPORTING.set(false);
            }
        },"qd903-safe-import").start();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==IMPORT_DB){importAsync(uri);return;}
        new Thread(()->{
            try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                if(out==null)throw new IllegalStateException("无法创建输出文件");
                if(request==EXPORT_DB){
                    if(HarvestService.RUNNING.get())throw new IllegalStateException("任务仍在运行，请先暂停");
                    try(MarketDb db=new MarketDb(this)){db.checkpoint();}
                    File database=getDatabasePath(MarketDb.NAME);
                    try(FileInputStream in=new FileInputStream(database)){
                        byte[] b=new byte[65536];int n;long copied=0;
                        while((n=in.read(b))!=-1){
                            out.write(b,0,n);copied+=n;
                            if(copied%(10L*1024*1024)<65536){
                                final long mb=copied/1048576;
                                runOnUiThread(()->status.setText("正在导出数据库："+mb+" MB"));
                            }
                        }
                    }
                }else if(request==EXPORT_LOG){
                    try(MarketDb db=new MarketDb(this)){
                        out.write(db.logs(3000).getBytes(StandardCharsets.UTF_8));
                    }
                }
                out.flush();
                runOnUiThread(()->Toast.makeText(this,"备份已保存，请确认文件存在后再卸载旧版",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                String message="导出失败："+e.getMessage();
                runOnUiThread(()->status.setText(message));
            }
        },"qd89-export").start();
    }
    @Override protected void onResume(){super.onResume();visible=true;handler.removeCallbacks(refresh);refresh.run();}
    @Override protected void onPause(){visible=false;handler.removeCallbacks(refresh);super.onPause();}
}
