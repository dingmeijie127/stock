package com.quantdesk.download;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

/** Bounded WorkManager batches; each committed bar is persistent, restart/upgrade safe. */
public final class DailyUpdateWorker extends Worker {
    // An ordinary Worker is time-limited by Android. Never try to download all symbols in one run.
    private static final long MAX_BATCH_MS=6L*60*1000;
    private static final int EACH_MARKET=30;
    public DailyUpdateWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();
        if(!DailyUpdateScheduler.enabled(c))return Result.success();
        if(MarketDb.IMPORT_IN_PROGRESS.get())return Result.retry();
        if(!HarvestService.RUNNING.compareAndSet(false,true))return Result.retry();
        long started=System.currentTimeMillis();
        try(MarketDb db=new MarketDb(c)){
            // Catalog comes from verified APK assets. It is not re-downloaded on the phone.
            if(db.countA()==0||db.countHK()==0)Universe.install(c,db);
            LocalDate target=RangePlanner.safeEndDay(ZonedDateTime.now(ZoneId.of("Asia/Hong_Kong")));
            String day=target.toString();
            LocalDate baseline=target.minusYears(2);
            db.autoState(day,"running","","网络已就绪，逐股票检查增量");
            int failedA=0,failedHK=0,processed=0;
            List<MarketDb.Security> batch=db.autoPending(day,EACH_MARKET);
            for(MarketDb.Security stock:batch){
                if(isStopped()||!DailyUpdateScheduler.enabled(c))break;
                if(System.currentTimeMillis()-started>MAX_BATCH_MS)break;
                String code=stock.code,exchange=stock.exchange,market="HK".equals(exchange)?"HK":"A";
                db.autoState(day,"running",market+":"+code,"自动更新：本批次 "+processed+" 条；新K线 "+db.autoNewBars(day));
                try {
                    LocalDate start=RangePlanner.nextDailyStart(baseline,target,db.latestBarDay(code));
                    String unresolved=db.oldestIncompleteStart(code);
                    if(unresolved!=null){
                        LocalDate pending=LocalDate.parse(unresolved);
                        if(pending.isBefore(baseline))pending=baseline;
                        if(start==null||pending.isBefore(start))start=pending;
                    }
                    if(start==null){
                        db.autoAttempt(code,day,"noop",0,null);
                    }else{
                        DailySources.Result result=DailySources.downloadBars(code,exchange,start,target);
                        // Use existing atomic K-line+checkpoint transaction. No old history deletion.
                        if(result.skippedBars>0){
                            db.writePartial(code,start.toString(),day,result.bars,result.skippedBars);
                            db.autoAttempt(code,day,"partial",result.bars.size(),"Skipped invalid OHLCV rows: "+result.skippedBars);
                            db.log("AUTO_PARTIAL",market+":"+code+" 有效K线 "+result.bars.size()+
                                "，异常缺失 "+result.skippedBars+"；已存库但未标记完整");
                        }else{
                            db.writeSuccess(code,start.toString(),day,result.bars);
                            db.autoAttempt(code,day,"saved",result.bars.size(),null);
                            db.log("AUTO",market+":"+code+" "+result.provider+" 新增 "+result.bars.size()+" 根日K");
                        }
                    }
                    if("HK".equals(market))failedHK=0;else failedA=0;
                }catch(Exception ex){
                    String err=ex.getClass().getSimpleName()+": "+String.valueOf(ex.getMessage());
                    if(err.length()>420)err=err.substring(0,420);
                    db.autoAttempt(code,day,"failed",0,err);
                    db.log("AUTO_ERROR",market+":"+code+" "+err);
                    int failures="HK".equals(market)?++failedHK:++failedA;
                    if(failures>=8){
                        db.autoBlock(day,market,"同一市场连续8只失败，今天自动任务暂停该市场，明日可重试");
                        db.log("AUTO_ERROR",market+"连续8只股票失败；暂不继续该市场，另一市场照常");
                    }
                }
                processed++;
            }
            int remaining=db.autoRemaining(day),failures=db.autoFailures(day);
            String detail="自动增量：已处理 "+db.autoProcessed(day)+"，新增 "+db.autoNewBars(day)+
                " 根K线，失败 "+failures+"，待处理 "+remaining;
            if(isStopped()||!DailyUpdateScheduler.enabled(c)){
                db.autoState(day,"paused","",detail);return Result.success();
            }
            db.autoState(day,remaining>0?"batch":(failures>0||db.autoBlocked(day)>0?"partial":"done"),"",detail);
            db.log("AUTO",detail);
            if(remaining>0 && DailyUpdateScheduler.enabled(c)){
                // Queue the next constrained batch. Android may defer it to save battery.
                DailyUpdateScheduler.enqueueNext(c,90_000L);
            }
            return Result.success();
        }catch(Exception e){
            // The next OS-managed attempt will reuse persisted per-stock checkpoints.
            try(MarketDb db=new MarketDb(c)){
                String reason=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
                db.log("AUTO_ERROR","每日自动更新初始化失败："+reason);
                db.autoState("","error","",reason);
            }catch(Exception ignored){}
            return Result.retry();
        }finally{HarvestService.RUNNING.set(false);}
    }
}
