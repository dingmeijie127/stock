package com.quantdesk.download;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.time.ZonedDateTime;
import java.util.concurrent.TimeUnit;

/** User opt-in, persistent, inexact 24-hour HK-close sync. */
public final class DailyUpdateScheduler {
    static final String PERIODIC="quantdesk_ah_daily_v902", CATCHUP="quantdesk_ah_catchup_v902";
    static final String PREF="qd_auto_update", ENABLED="enabled";
    private DailyUpdateScheduler(){}
    public static boolean enabled(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(ENABLED,false);}
    static Constraints constraints(){return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();}
    public static void setEnabled(Context c,boolean isEnabled){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(ENABLED,isEnabled).apply();
        if(isEnabled)schedule(c);else{
            WorkManager.getInstance(c).cancelUniqueWork(PERIODIC);
            WorkManager.getInstance(c).cancelUniqueWork(CATCHUP);
        }
    }
    public static void ensureScheduled(Context c){if(enabled(c))schedule(c);}
    private static void schedule(Context c){
        long delay=ScheduleClock.delayToNextHKRun(ZonedDateTime.now());
        PeriodicWorkRequest work=new PeriodicWorkRequest.Builder(DailyUpdateWorker.class,24,TimeUnit.HOURS)
            .setConstraints(constraints())
            .setInitialDelay(delay,TimeUnit.MILLISECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.MINUTES)
            .build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(PERIODIC,ExistingPeriodicWorkPolicy.KEEP,work);
    }
    /** Explicit manual trigger of the SAME checkpointed automatic worker. */
    public static void runOnce(Context c){enqueueNext(c,0);}
    static void enqueueNext(Context c,long delayMs){
        OneTimeWorkRequest work=new OneTimeWorkRequest.Builder(DailyUpdateWorker.class)
            .setConstraints(constraints())
            .setInitialDelay(delayMs,TimeUnit.MILLISECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.MINUTES)
            .build();
        // APPEND_OR_REPLACE permits a running batch to append its next batch, not cancel itself.
        WorkManager.getInstance(c).enqueueUniqueWork(CATCHUP,ExistingWorkPolicy.APPEND_OR_REPLACE,work);
    }
}
