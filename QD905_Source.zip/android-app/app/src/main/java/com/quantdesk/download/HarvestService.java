package com.quantdesk.download;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicBoolean;

/** Foreground harvest: persistent job status and per-stock atomic SQLite transactions. */
public final class HarvestService extends Service {
    public static final String START="com.quantdesk.download.START",START_FINANCE="com.quantdesk.download.START_FINANCE",PAUSE="com.quantdesk.download.PAUSE";
    public static final AtomicBoolean RUNNING=new AtomicBoolean(false);
    public static volatile String LIVE="尚未开始";
    private final AtomicBoolean paused=new AtomicBoolean(false);
    private PowerManager.WakeLock wake;
    private String from="",to="";
    private long lastNotify;
    private long lastWakeRenew;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent==null)return START_NOT_STICKY;
        if(PAUSE.equals(intent.getAction())){
            if(RUNNING.get()){
                paused.set(true);LIVE="正在暂停（当前请求完成后停止）";notifyProgress(0,0);
            }
            return START_NOT_STICKY;
        }
        boolean isFinance=START_FINANCE.equals(intent.getAction());
        if(!START.equals(intent.getAction())&&!isFinance)return START_NOT_STICKY;
        if(MarketDb.IMPORT_IN_PROGRESS.get()){LIVE="正在合并SQLite备份，采集任务请稍后开始";return START_NOT_STICKY;}
        if(!RUNNING.compareAndSet(false,true))return START_NOT_STICKY;
        paused.set(false);LIVE=isFinance?"准备采集免费公开财报（A股三表；港股指标/分红）":"服务启动，准备A股及港股股票清单";
        notifyProgress(0,0); // startForeground is called immediately, before network and database work
        try{
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"qd90:daily-download");wake.setReferenceCounted(false);wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();}
        }catch(Exception e){Log.w("QD88","Wake lock unavailable",e);}
        new Thread(isFinance?this::harvestFinance:this::harvest,isFinance?"qd89-finance-thread":"qd89-kline-thread").start();
        return START_NOT_STICKY;
    }
    private void notifyProgress(int complete,int total){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(manager==null)return;
        String channel="qd88_history";
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(channel,"A股/港股历史数据下载",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,3,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("QuantDesk · A股+港股两年日线")
            .setContentText(LIVE.length()>85?LIVE.substring(0,85):LIVE)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
            .setProgress(Math.max(1,total),complete,total<=0).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(880,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(880,n);
    }
    private void update(MarketDb db,String stage,String code,String detail,int completed,int total){
        LIVE=detail;db.state(from,to,stage,code,detail);
        long now=System.currentTimeMillis();
        if(now-lastNotify>=2500 || !"running".equals(stage)){
            lastNotify=now;notifyProgress(completed,total);
        }
    }
    private void harvest() {
        MarketDb db=new MarketDb(getApplicationContext());
        int consecutiveFailed=0;
        try{
            LocalDate today=RangePlanner.safeEndDay(java.time.ZonedDateTime.now(ZoneId.of("Asia/Hong_Kong")));
            String[] dates=db.windowOrNew(today.minusYears(2).toString(),today.toString());
            from=dates[0];to=dates[1];
            db.state(from,to,"running","","正在导入安装包内 A股+港股清单");
            db.log("INFO","开始/恢复："+from+" 至 "+to);
            int total=Universe.install(getApplicationContext(),db);
            db.log("INFO","A股+港股本地目录加载完成："+total+"只；无需联网请求股票目录");
            update(db,"running","","已加载 "+total+" 只股票，开始下载历史日K",db.completed(from,to),total);
            ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            if(cm==null||cm.getActiveNetwork()==null)
                throw new IllegalStateException("网络未连接：股票目录已加载，但无法下载K线；联网后继续");
            int done=db.completed(from,to);
            LocalDate a=LocalDate.parse(from),b=LocalDate.parse(to);
            java.util.List<MarketDb.Security> pending=db.remaining(from,to);
            {
                int counter=0;
                String lastMarket="";
                java.util.Set<String> unavailableMarkets=new java.util.HashSet<>();
                for(MarketDb.Security stock:pending){
                    String market="HK".equals(stock.exchange)?"HK":"A";
                    if(!market.equals(lastMarket)){consecutiveFailed=0;lastMarket=market;}
                    if(unavailableMarkets.contains(market))continue;
                    if(paused.get()){
                        db.log("INFO","用户暂停。已完成 "+done+"/"+total);
                        update(db,"paused","","已暂停，下次点击开始继续",done,total);return;
                    }
                    if(wake!=null && System.currentTimeMillis()-lastWakeRenew>8L*60*1000){
                        wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();
                    }
                    String code=stock.code,exchange=stock.exchange;
                    update(db,"running",code,"下载 "+code+"  ("+done+"/"+total+")",done,total);
                    try {
                        String last=db.latestBarDay(code);
                        LocalDate missingFrom=RangePlanner.nextDailyStart(a,b,last);
                        String oldPartial=db.oldestIncompleteStart(code);
                        if(oldPartial!=null){
                            LocalDate redo=LocalDate.parse(oldPartial);
                            if(redo.isBefore(a))redo=a;
                            if(missingFrom==null||redo.isBefore(missingFrom))missingFrom=redo;
                        }
                        if(missingFrom==null){
                            db.markDailyReused(code,from,to);done++;consecutiveFailed=0;
                            db.log("REUSE",code+" 已有K线截至 "+last+"，跳过历史重下 ("+done+"/"+total+")");
                        }else{
                            DailySources.Result result=DailySources.downloadBars(code,exchange,missingFrom,b);
                            if(result.skippedBars>0){
                                db.writePartial(code,from,to,result.bars,result.skippedBars);
                                consecutiveFailed=0;
                                db.log("PARTIAL",code+" "+result.provider+" 保存有效日K "+result.bars.size()+
                                    " 根，但跳过异常记录 "+result.skippedBars+" 条；将来重试缺口，未计完整成功");
                            }else{
                                db.writeSuccess(code,from,to,result.bars);
                                done++;consecutiveFailed=0;
                                db.log("OK",code+" "+result.provider+" 新增 "+result.bars.size()+" 根日K ("+done+"/"+total+")");
                            }
                        }
                        if(done%10==0)update(db,"running",code,"成功 "+done+"/"+total+"；日K累计 "+db.countBars(),done,total);
                    }catch(Exception e){
                        consecutiveFailed++;
                        String error=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
                        if(error.length()>500)error=error.substring(0,500);
                        db.writeFailure(code,from,to,error);
                        db.log("ERROR",code+" " +error);
                        if(consecutiveFailed>=15){
                            String stop=market+"市场连续15只股票下载失败，疑似整条行情源故障；本轮延后该市场剩余任务（未记成功），恢复网络后可继续";
                            unavailableMarkets.add(market);
                            db.log("ERROR",stop);
                            update(db,"running",code,stop,done,total);
                        }
                    }
                    counter++;
                    if(counter%10==0)update(db,"running",code,"进度 "+done+"/"+total+"；失败 "+db.failed(from,to),done,total);
                    Thread.sleep(550L);
                }
            }
            db.auditMarket("A",from,to); db.auditMarket("HK",from,to);
            int incomplete=db.remaining(from,to).size();
            String finish="A股+港股采集批次结束：完整成功 "+db.completed(from,to)+"/"+total+
                "，失败 "+db.failed(from,to)+"，尚未完整处理 "+incomplete+"，累计日K "+db.countBars()+" 条；可再次续传";
            db.log("INFO",finish);
            update(db,incomplete>0?"partial":"complete","",finish,db.completed(from,to),total);
        }catch(InterruptedException e){
            Thread.currentThread().interrupt();
            update(db,"paused","","任务被系统中断，已保存完成检查点",db.completed(from,to),db.countSymbols());
        }catch(Exception e){
            String reason=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
            db.log("ERROR","采集中断："+reason);
            update(db,"error","","采集中断："+reason,db.completed(from,to),db.countSymbols());
        }finally{
            db.close();RUNNING.set(false);
            if(wake!=null&&wake.isHeld())wake.release();
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    private void harvestFinance(){
        MarketDb db=new MarketDb(getApplicationContext());
        try{
            db.log("INFO","财报采用公开数据源，无需 Token；港股完整三表尚未支持结构化自动采集");
            LocalDate today=LocalDate.now(ZoneId.of("Asia/Shanghai")),begin=today.minusYears(2);
            String fromDay=begin.toString(),toDay=today.toString();
            int count=Universe.install(getApplicationContext(),db);
            int total=0,processed=0,failed=0,transientErrors=0;
            java.util.List<MarketDb.Security> securities=db.allSecurities();
            for(MarketDb.Security stock:securities)total+=FinancialSources.datasetsFor(stock.exchange).length;
            db.financeState("running","","公开接口：A股三大报表，港股财务指标/分红；无Token",total,0,0);
            String previousMarket="";
            java.util.Set<String> failedMarkets=new java.util.HashSet<>();
            for(MarketDb.Security stock:securities){
                String market="HK".equals(stock.exchange)?"HK":"A";
                if(!market.equals(previousMarket)){transientErrors=0;previousMarket=market;}
                if(failedMarkets.contains(market))continue;
                for(String dataset:FinancialSources.datasetsFor(stock.exchange)){
                    if(paused.get()){
                        db.financeState("paused",stock.code,"已暂停；数据库已保存",total,processed,failed);return;
                    }
                    if(wake!=null && System.currentTimeMillis()-lastWakeRenew>8L*60*1000){
                        wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();
                    }
                    processed++;
                    if(db.recentlyCheckedDataJob(stock.code,dataset,fromDay,toDay))continue;
                    // Financial statements may be restated: recheck the rolling window; raw hashes de-duplicate.
                    // Never infer that all earlier fiscal periods are complete from a latest-to_day.
                    LocalDate requested=begin;
                    String start=requested.toString();
                    try{
                        java.util.List<org.json.JSONObject> rows=FinancialSources.fetch(dataset,stock.code,stock.exchange,requested,today);
                        int saved;
                        if(rows.isEmpty()){
                            db.saveEmptyDataJob(stock.code,dataset,fromDay,toDay);
                            saved=0;
                            db.log("EMPTY",stock.exchange+":"+stock.code+" "+dataset+" 返回0行；7天后复核，不把空数据当完整");
                        }else{
                            saved=db.saveData(stock.code,dataset,start,toDay,rows);
                            db.log("DATA",stock.exchange+":"+stock.code+" "+dataset+" 返回 "+saved+" 条；原K线保留");
                        }
                        transientErrors=0;
                    }catch(Exception ex){
                        failed++;transientErrors++;String err=ex.getClass().getSimpleName()+" "+String.valueOf(ex.getMessage());
                        if(err.length()>360)err=err.substring(0,360);
                        db.dataFailure(stock.code,dataset,start,toDay,err);
                        db.log("ERROR",stock.code+" "+dataset+" "+err);
                        if(transientErrors>=12){
                            String stop=market+" 财务接口连续12次失败；跳过该市场剩余财报，另一市场继续";
                            db.log("ERROR",stop);failedMarkets.add(market);
                            break;
                        }
                    }
                    String progress="公开财务 "+processed+"/"+total+"；累计记录 "+db.countDataRows()+" 行；错误 "+failed;
                    LIVE=stock.exchange+":"+stock.code+" "+dataset+" · "+progress;
                    if(processed%4==0){db.financeState("running",stock.code+" "+dataset,progress,total,processed,failed);notifyProgress(processed,total);}
                    Thread.sleep(900L); // reduce load on public providers
                }
            }
            String detail="公开财报采集结束，数据库行数 "+db.countDataRows()+"；失败 "+failed+"；港股完整三大报表未覆盖";
            db.financeState(failed==0&&db.countHK()==0?"complete":"partial","",detail,total,processed,failed);
            db.log("INFO",detail);LIVE=detail;notifyProgress(processed,total);
        }catch(InterruptedException ex){
            Thread.currentThread().interrupt();db.log("INFO","财务采集线程中断；可以继续");
            db.financeState("paused","","任务中断，已有记录仍保留",0,0,0);
        }catch(Exception ex){
            String message=ex.getClass().getSimpleName()+" "+String.valueOf(ex.getMessage());
            db.log("ERROR","财务采集中断："+message);db.financeState("error","",message,0,0,0);
        }finally{
            db.close();RUNNING.set(false);
            if(wake!=null&&wake.isHeld())wake.release();
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    @Override public void onDestroy(){paused.set(true);if(wake!=null&&wake.isHeld())wake.release();super.onDestroy();}
}
