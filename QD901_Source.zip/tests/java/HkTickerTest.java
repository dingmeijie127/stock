package com.quantdesk.download;
public final class HkTickerTest {
    private static void eq(String expected,String found){
        if(!expected.equals(found))throw new AssertionError("Expected " + expected+" found " +found);
    }
    public static void main(String[] args){
        eq("00700",HongKongSources.normalized("700"));
        eq("116.00700",HongKongSources.eastmoneySecid("00700"));
        eq("0700.HK",HongKongSources.yahooSymbol("00700"));
        eq("0001.HK",HongKongSources.yahooSymbol("00001"));
        eq("9988.HK",HongKongSources.yahooSymbol("09988"));
        eq("00700.HK",FinancialSources.tsCode("00700","HK"));
        eq("600519.SH",FinancialSources.tsCode("600519","SH"));
        if(FinancialSources.datasetsFor("HK").length!=4)throw new AssertionError("Wrong HK dataset count");
        if(FinancialSources.datasetsFor("SH").length!=9)throw new AssertionError("Wrong A dataset count");
        System.out.println("HK ticker and market dataset contract OK");
    }
}
