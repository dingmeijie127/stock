# QuantDesk V9.0.1 — A股 + 港股本地历史数据库（源码）

这不是已经包含全市场历史数据的安装包。首次安装后，采集程序需要联网回填近两年行情。

## 本版范围

- 基于 V8.8.1/V8.9 的原生 Android 采集器，**不替换已能工作的 A 股日线链路**。
- 同一个 SQLite 数据库 `quantdesk-a-share-2y.sqlite3`，同一个 Android applicationId `com.quantdesk.asharecollector88`。
- SQLite v2 -> v3 为增量迁移；保留旧表、已下载日 K、任务状态和财报原始行；不执行 DROP TABLE。
- A 股（6 位）和港股（5 位，`HK`）独立标记。港股同时支持东方财富日 K + Yahoo 日 K 备用，逐笔记录来源和成交量单位；不捏造历史行情。
- 香港股票现有**公开现货清单**在 GitHub 编译 APK 时从 优先从 GitHub 上维护的港交所证券 CSV 镜像下载（筛选普通股票），再回退 AKShare / 东方财富下载后打包；清单少于 1,000 时 **停止构建**，不会编译一个目录为空的 APK。A 股目录同样需要 >=3,500。
- 手机在首次启动时读取两个内置清单。后台前台服务按股票下载最近两年日线，进度、错误和成功行落到数据库；两个市场的连续失败互不阻断。每次任务结束分别记录 A/H 股票任务完成数（不冒充交易日级完整率）。
- 日常点击“开始/每日增量更新”会从数据库每只股票已保存的**最后交易日的下一天**下载，保留旧行并跳过已有日线；既有历史日期无须重复下载。暂停后状态可续传。香港时间 19:00 前只采集至上一交易日，避免收盘前不完整日线。
- A 股 9 组 Tushare 财务/量化数据集；港股 `hk_income`、`hk_balancesheet`、`hk_cashflow`、`hk_fina_indicator`（需要 **Tushare 港股财报单独授权**）。财报原始字段、科目及报告期保存在 `dataset_rows`，访问失败独立记录到 `data_jobs`。
- 提供导出 SQLite、导入旧 SQLite 合并（`INSERT OR IGNORE`）和导出日志。数据库备份导入功能不会删除旧日 K。

## 数据质量边界（量化前必须了解）

1. “两年”指滚动两年**日 K**，不是已核对的全历史停复牌、退市、分时或逐笔数据。股票清单基于构建时仍在公开行情源内的现货列表，并**不能保证包含近两年已退市的所有股票**，不能直接当作无幸存者偏差的回测股票池。
2. Yahoo 港股回退行情有拆股调整差异；数据库每根 K 线保留 provider/raw，量化策略前需要统一复权/币种和交易日历，不能不经核验将不同源价格混合回测。
3. 港股 Tushare 财报大多只有“报告期/财务科目”，没有可靠公告日期字段；不能当作当日已知信息做历史回测。三大财报需要单独权限，拒绝时日志写 ACCESS，不会虚构记录。
4. 当前**不含设备自动定时唤醒**功能，日常在 APP 点击“开始/每日增量更新”即可增量更新；手机后台运行受 Android 系统数据同步任务时限/厂商省电策略影响，进程被杀后再次开始可续传。
5. GitHub 构建时拉取实时股票清单和 Android 构建依赖会受到网络/服务商变化影响。构建失败时请读取对应 Actions 的错误步骤，**不要把离线单测算作联网验收**。

## 最重要：保留你之前下载的数据

**一定先在旧版 APP 里“导出 SQLite”，确认备份文件能打开，然后再考虑卸载旧 APP。**

- 如果新旧 APK 使用**同一个签名证书**，同一包名安装升级会保留应用内的原数据库。
- 每次 GitHub Runner 构建的默认 debug APK **签名不保证一致**。如无法直接覆盖安装，先导出旧 SQLite 再卸载旧 APK / 安装新 APK，在 V9.0.1 中按“导入旧版 SQLite（合并、不覆盖）”恢复数据。导入不覆盖旧记录。
- 为以后实现真正的一键升级，建议配置固定的 GitHub Secrets：`QD_KEYSTORE_B64`、`QD_SIGNING_ALIAS`、`QD_SIGNING_STORE_PASSWORD`、`QD_SIGNING_KEY_PASSWORD`，由工作流用统一 keystore 打包 release APK。不能从现有 debug 包恢复私钥；首次启用固定签名仍要备份迁移一次。
- 手机浏览器下载的 SQLite 文件可能含交易行为和 Token 附属信息，妥善保管。Token 使用 Android Keystore 加密保存，不包含在源码 ZIP 中。

## GitHub 上传（无需删除旧版）

**同一个仓库** `dingmeijie127/stock`：

- 仓库根目录上传 **`QD901_Source.zip`**（不要解压）。
- `.github/workflows/` 文件夹直接上传 **`QD901_Build.yml`**。
- Actions 中打开 `QuantDesk V9.0.1 - A/H Market Database and Incremental APK` → Run workflow，分支 `main`。
- 新工作流只读取 `QD901_Source.zip`，不会回退读取旧的源码 ZIP；上传后也可能因 push 触发一次构建。

## 自动测试（不需要真实数据商连接）

```bash
python -m pip install pytest PyYAML
python -m pytest -q tests
javac -encoding UTF-8 -d /tmp/qd90-tests \
  android-app/app/src/main/java/com/quantdesk/download/Bar.java \
  android-app/app/src/main/java/com/quantdesk/download/RangePlanner.java \
  tests/java/BarTest.java tests/java/RangePlannerTest.java
```

## 第一次实机验收标准

安装启动 → 显示 A 股股票数、港股股票数（都不能是 0）→ 开始日 K → “日 K A/港”真实行数增长 → 导出 SQLite，用 SQLite 工具核验 `instruments`, `daily_bars`, `tasks`, `dataset_rows` → 再次启动只补新交易日。

**需要外部实际验证的部分**：GitHub 的全 APK 编译、手机运行、公开数据源实时下载成功率、港股财报账户权限、覆盖率/交易所授权范围。

## V9.0.1 构建问题修复记录

- V9.0 在 GitHub 上失败的步骤是 **编译时获取港股清单**，不是 APK 代码编译失败：AKShare 对应接口 RemoteDisconnected，东方财富返回 HTTP 502。
- 新版本港股清单首先从公开的 `irachex/open-stock-data` 港交所 CSV 读取（原始字段 `code,region,name,exchange,type`），只选择 `HKEX / HK / stock`，排除 ETF/基金及非港交所代码，要求不少于 1,000 只，并验证参考代码 `00005` / `00700`。失败再尝试原 AKShare、东方财富接口；来源和抓取时间写入 `hk_universe_meta.json`。
- 这是**真实的上市证券清单镜像**，不是虚构代码，但仍不代表全市场历史已退市股票齐全，且第三方更新时效须另验。
- 若以上所有来源同时中断，构建仍然终止并报告具体错误，不会悄悄生成一个港股目录为空的 APK。
- 本地测试使用模拟响应验证 fallback，不等于已在 GitHub 真正抓到当前港股清单。
