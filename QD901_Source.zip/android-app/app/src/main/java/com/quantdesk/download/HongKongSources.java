package com.quantdesk.download;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/** HK cash equity daily bars: Eastmoney unadjusted; Yahoo fallback may be split-adjusted.
 *  Preserve provider, units and raw payload for downstream audits. No invented rows.
 */
public final class HongKongSources {
    private HongKongSources(){}
    public static String normalized(String raw){
        if(raw==null||!raw.matches("[0-9]{1,5}"))throw new IllegalArgumentException("Invalid HK ticker");
        return ("00000"+raw).substring(raw.length());
    }
    public static String yahooSymbol(String raw){
        String normalized=normalized(raw);
        // Yahoo Finance uses 4-digit HK tickers like 0700.HK for HKEX 00700.HK.
        return (normalized.startsWith("0") ? normalized.substring(1) : normalized)+".HK";
    }
    public static String eastmoneySecid(String raw){return "116."+normalized(raw);}
    private static String date(LocalDate d){return d.toString().replace("-","");}
    private static String get(String url) throws Exception {
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        connection.setConnectTimeout(10000);connection.setReadTimeout(20000);
        connection.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/122 Safari/537.36");
        connection.setRequestProperty("Referer","https://quote.eastmoney.com/");
        try{
            int status=connection.getResponseCode();
            if(status!=200)throw new IOException("HK HTTP "+status+" host="+connection.getURL().getHost());
            try(InputStream stream=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=stream.read(buffer))!=-1){
                    if(out.size()+n>4_000_000)throw new IOException("HK provider response too large");
                    out.write(buffer,0,n);
                }
                return out.toString("UTF-8");
            }
        }finally{connection.disconnect();}
    }
    public static List<Bar> parseEastmoney(JSONObject data,LocalDate start,LocalDate end) throws Exception{
        JSONArray records=data.optJSONArray("klines");
        if(records==null||records.length()==0)throw new IOException("HK Eastmoney daily list empty");
        List<Bar> bars=new ArrayList<>();
        for(int i=0;i<records.length();i++){
            String raw=records.getString(i);
            String[] p=raw.split(",",-1);
            if(p.length<7)throw new IOException("HK Eastmoney bad OHLC row");
            String day=p[0];
            if(day.compareTo(start.toString())<0||day.compareTo(end.toString())>0)continue;
            Double amount=p[6].isEmpty()||p[6].equals("-")?null:Double.valueOf(p[6]);
            // HK Eastmoney's HK historical volume is reported as shares (not A-share 100-share lots).
            bars.add(new Bar(day,Double.parseDouble(p[1]),Double.parseDouble(p[3]),Double.parseDouble(p[4]),
                Double.parseDouble(p[2]),Double.parseDouble(p[5]),amount,"eastmoney_hk","SHARES",raw));
        }
        if(bars.isEmpty())throw new IOException("HK Eastmoney no bars in date range");
        return bars;
    }
    public static DailySources.Result eastmoney(String code,LocalDate from,LocalDate to) throws Exception{
        String url="https://push2his.eastmoney.com/api/qt/stock/kline/get?secid="+eastmoneySecid(code)+
            "&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61"+
            "&klt=101&fqt=0&beg="+date(from)+"&end="+date(to)+
            "&lmt=900&ut="+DailySources.EAST_TOKEN;
        JSONObject root=new JSONObject(get(url));
        JSONObject market=root.optJSONObject("data");
        if(market==null)throw new IOException("HK Eastmoney data empty rc="+root.optInt("rc",-1));
        List<Bar> bars=parseEastmoney(market,from,to);
        if(bars.size()>=900)throw new IOException("HK Eastmoney row cap; incomplete window");
        return new DailySources.Result(bars,"eastmoney_hk");
    }
    public static List<Bar> parseYahoo(JSONObject root,LocalDate start,LocalDate end) throws Exception{
        JSONObject chart=root.optJSONObject("chart");
        if(chart==null)throw new IOException("HK Yahoo chart missing");
        JSONArray result=chart.optJSONArray("result");
        if(result==null||result.length()==0)throw new IOException("HK Yahoo result missing");
        JSONObject series=result.getJSONObject(0);
        JSONArray timestamps=series.optJSONArray("timestamp");
        if(timestamps==null||timestamps.length()==0)throw new IOException("HK Yahoo timestamps absent");
        JSONObject quote=series.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray opens=quote.getJSONArray("open"),highs=quote.getJSONArray("high"),
            lows=quote.getJSONArray("low"),closes=quote.getJSONArray("close"),volumes=quote.getJSONArray("volume");
        List<Bar> bars=new ArrayList<>();
        for(int i=0;i<timestamps.length();i++){
            if(i>=opens.length()||i>=highs.length()||i>=lows.length()||i>=closes.length()||i>=volumes.length()||
                opens.isNull(i)||highs.isNull(i)||lows.isNull(i)||closes.isNull(i)||volumes.isNull(i))continue;
            String day=Instant.ofEpochSecond(timestamps.getLong(i)).atZone(ZoneId.of("Asia/Hong_Kong")).toLocalDate().toString();
            if(day.compareTo(start.toString())<0||day.compareTo(end.toString())>0)continue;
            JSONObject raw=new JSONObject().put("timestamp",timestamps.getLong(i))
                .put("open",opens.getDouble(i)).put("high",highs.getDouble(i))
                .put("low",lows.getDouble(i)).put("close",closes.getDouble(i))
                .put("volume",volumes.getDouble(i))
                .put("adjustment_note","Yahoo OHLC may be split-adjusted; inspect provider on every stored bar");
            bars.add(new Bar(day,opens.getDouble(i),highs.getDouble(i),lows.getDouble(i),closes.getDouble(i),
                volumes.getDouble(i),null,"yahoo_hk","SHARES",raw.toString()));
        }
        if(bars.isEmpty())throw new IOException("HK Yahoo no valid bars");
        return bars;
    }
    public static DailySources.Result yahoo(String code,LocalDate from,LocalDate to) throws Exception{
        String ticker=yahooSymbol(code);
        long start=from.atStartOfDay(ZoneId.of("Asia/Hong_Kong")).toEpochSecond();
        long end=to.plusDays(1).atStartOfDay(ZoneId.of("Asia/Hong_Kong")).toEpochSecond();
        String url="https://query1.finance.yahoo.com/v8/finance/chart/"+URLEncoder.encode(ticker,"UTF-8")+
            "?period1="+start+"&period2="+end+"&interval=1d";
        return new DailySources.Result(parseYahoo(new JSONObject(get(url)),from,to),"yahoo_hk");
    }
    public static DailySources.Result download(String code,LocalDate from,LocalDate to) throws Exception{
        String em;
        try{return eastmoney(code,from,to);}catch(Exception e){em=e.getClass().getSimpleName()+":"+e.getMessage();}
        try{return yahoo(code,from,to);}catch(Exception e){
            throw new IOException("HK eastmoney="+em+"; yahoo="+e.getClass().getSimpleName()+":"+e.getMessage());
        }
    }
}
