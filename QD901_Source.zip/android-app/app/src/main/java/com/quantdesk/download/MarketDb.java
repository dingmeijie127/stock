package com.quantdesk.download;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import org.json.JSONObject;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/** Android-local SQLite. Each security's daily bars and success checkpoint commit atomically. */
public final class MarketDb extends SQLiteOpenHelper {
    public static final String NAME="quantdesk-a-share-2y.sqlite3";
    public MarketDb(Context context){super(context,NAME,null,3);setWriteAheadLoggingEnabled(true);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE instruments(code TEXT PRIMARY KEY,name TEXT NOT NULL,exchange TEXT NOT NULL,source TEXT NOT NULL)");
        d.execSQL("CREATE TABLE daily_bars(code TEXT NOT NULL,day TEXT NOT NULL,o REAL NOT NULL,h REAL NOT NULL,l REAL NOT NULL,c REAL NOT NULL,vol REAL NOT NULL,vol_unit TEXT NOT NULL,amount REAL,provider TEXT NOT NULL,raw TEXT NOT NULL,PRIMARY KEY(code,day))");
        d.execSQL("CREATE INDEX daily_by_day ON daily_bars(day,code)");
        d.execSQL("CREATE TABLE tasks(code TEXT NOT NULL,start_day TEXT NOT NULL,end_day TEXT NOT NULL,status TEXT NOT NULL,rows INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,error TEXT,updated INTEGER NOT NULL,PRIMARY KEY(code,start_day,end_day))");
        d.execSQL("CREATE TABLE log(id INTEGER PRIMARY KEY AUTOINCREMENT,at INTEGER NOT NULL,level TEXT NOT NULL,message TEXT NOT NULL)");
        d.execSQL("CREATE TABLE state(id INTEGER PRIMARY KEY CHECK(id=1),start_day TEXT,end_day TEXT,phase TEXT,active TEXT,detail TEXT,updated INTEGER)");
        createQuantTables(d);
        createMarketTables(d);
    }
    // v1→v2 is additive; NEVER drop daily_bars, instruments, tasks or logs.
    @Override public void onUpgrade(SQLiteDatabase d,int old,int updated) {
        if(old<=1 && updated>=2) createQuantTables(d);
        if(old<=2 && updated>=3) createMarketTables(d);
    }
    private static void createQuantTables(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS dataset_rows(code TEXT NOT NULL,dataset TEXT NOT NULL,record_id TEXT NOT NULL,period TEXT,announcement_day TEXT,event_day TEXT,provider TEXT NOT NULL,raw_json TEXT NOT NULL,received_at INTEGER NOT NULL,PRIMARY KEY(code,dataset,record_id))");
        d.execSQL("CREATE INDEX IF NOT EXISTS data_rows_lookup ON dataset_rows(dataset,code,announcement_day,event_day)");
        d.execSQL("CREATE TABLE IF NOT EXISTS data_jobs(code TEXT NOT NULL,dataset TEXT NOT NULL,from_day TEXT NOT NULL,to_day TEXT NOT NULL,status TEXT NOT NULL,rows INTEGER NOT NULL DEFAULT 0,attempts INTEGER NOT NULL DEFAULT 0,error TEXT,checked_at INTEGER NOT NULL,PRIMARY KEY(code,dataset,from_day,to_day))");
        d.execSQL("CREATE TABLE IF NOT EXISTS finance_state(id INTEGER PRIMARY KEY CHECK(id=1),phase TEXT,active TEXT,detail TEXT,total INTEGER DEFAULT 0,complete INTEGER DEFAULT 0,failed INTEGER DEFAULT 0,updated INTEGER)");
    }
    // v3 market audit: additive tables only, no deletion of v8.8.1/v8.9 historical records.
    private static void createMarketTables(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS market_audit(market TEXT NOT NULL,day TEXT NOT NULL,checked_at INTEGER NOT NULL,symbols INTEGER NOT NULL,bars INTEGER NOT NULL,missing INTEGER NOT NULL,detail TEXT,PRIMARY KEY(market,day))");
        d.execSQL("CREATE INDEX IF NOT EXISTS instruments_market ON instruments(exchange,code)");
    }
    /** Batch completeness is based on successfully committed per-symbol tasks, not claimed
     * exchange trading-day completeness. An empty/permission-denied result is NOT success. */
    public void auditMarket(String market,String start,String end){
        boolean hk="HK".equals(market);
        String marketWhere=hk?"s.exchange='HK'":"s.exchange!='HK'";
        int symbols=hk?countHK():countA();
        int done=count("SELECT count(*) FROM instruments s JOIN tasks t ON t.code=s.code WHERE "+marketWhere+
            " AND t.start_day=? AND t.end_day=? AND t.status='complete'",new String[]{start,end});
        int missing=Math.max(0,symbols-done);
        String detail="本次批次股票任务完成 "+done+"/"+symbols+"，并非逐交易日完整率；未完成 "+missing;
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO market_audit(market,day,checked_at,symbols,bars,missing,detail) VALUES(?,?,?,?,?,?,?)",
            new Object[]{market,end,System.currentTimeMillis(),symbols,hk?countHKBars():countABars(),missing,detail});
    }
    public int countHK(){return count("SELECT count(*) FROM instruments WHERE exchange='HK'",null);}
    public int countA(){return count("SELECT count(*) FROM instruments WHERE exchange!='HK'",null);}
    public int countHKBars(){return count("SELECT count(*) FROM daily_bars WHERE code IN (SELECT code FROM instruments WHERE exchange='HK')",null);}
    public int countABars(){return count("SELECT count(*) FROM daily_bars WHERE code IN (SELECT code FROM instruments WHERE exchange!='HK')",null);}
    public int countSymbols(){return count("SELECT count(*) FROM instruments",null);}
    public int countBars(){return count("SELECT count(*) FROM daily_bars",null);}
    private int count(String sql,String[] args){try(Cursor c=getReadableDatabase().rawQuery(sql,args)){return c.moveToFirst()?c.getInt(0):0;}}
    public int completed(String start,String end){return count("SELECT count(*) FROM tasks WHERE start_day=? AND end_day=? AND status='complete'",new String[]{start,end});}
    public int failed(String start,String end){return count("SELECT count(*) FROM tasks WHERE start_day=? AND end_day=? AND status='failed'",new String[]{start,end});}
    public String[] windowOrNew(String newStart,String newEnd){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT start_day,end_day,phase FROM state WHERE id=1",null)){
            if(c.moveToFirst()){
                String prior=c.getString(2);
                // Resume the saved window only while its end day is still current.
                // Otherwise progress into a NEW daily window; the actual daily_bars
                // rows are persistent and per-security max(day) prevents re-download.
                if(("running".equals(prior)||"paused".equals(prior)||"error".equals(prior)||"partial".equals(prior)) &&
                    newEnd.equals(c.getString(1)) && c.getString(0)!=null)
                    return new String[]{c.getString(0),c.getString(1)};
            }
        }
        return new String[]{newStart,newEnd};
    }
    public void state(String start,String end,String phase,String active,String detail){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO state(id,start_day,end_day,phase,active,detail,updated) VALUES(1,?,?,?,?,?,?)",
             new Object[]{start,end,phase,active,detail,System.currentTimeMillis()});
    }
    public JSONObject overview(){
        JSONObject o=new JSONObject();
        try {
            String start="",end="",phase="not_started",active="",detail="";
            try(Cursor c=getReadableDatabase().rawQuery("SELECT start_day,end_day,phase,active,detail FROM state WHERE id=1",null)){
                if(c.moveToFirst()) { start=c.getString(0);end=c.getString(1);phase=c.getString(2);active=c.getString(3);detail=c.getString(4); }
            }
            o.put("start",start);o.put("end",end);o.put("phase",phase);o.put("active",active);o.put("detail",detail);
            o.put("total",countSymbols());o.put("bars",countBars());
            o.put("a_count",countA());o.put("hk_count",countHK());
            o.put("a_bars",countABars());o.put("hk_bars",countHKBars());
            o.put("done",completed(start,end));o.put("failed",failed(start,end));
        }catch(Exception ignored){}
        return o;
    }
    public static final class Security {
        public final String code,exchange;
        Security(String code,String exchange){this.code=code;this.exchange=exchange;}
    }
    /** Snapshot the pending list BEFORE committing new task rows; avoids a mutable SQLite cursor. */
    public List<Security> allSecurities(){
        List<Security> securities=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT code,exchange FROM instruments ORDER BY CASE WHEN exchange='HK' THEN 1 ELSE 0 END,code",null)){
            while(c.moveToNext())securities.add(new Security(c.getString(0),c.getString(1)));
        }
        return securities;
    }
    public List<Security> remaining(String start,String end){
        List<Security> result=new ArrayList<>();
        try(Cursor cursor=getReadableDatabase().rawQuery(
            "SELECT s.code,s.exchange FROM instruments s WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.code=s.code AND t.start_day=? AND t.end_day=? AND t.status='complete') ORDER BY CASE WHEN s.exchange='HK' THEN 1 ELSE 0 END,s.code",
            new String[]{start,end})){
            while(cursor.moveToNext())result.add(new Security(cursor.getString(0),cursor.getString(1)));
        }
        return result;
    }
    public void writeSuccess(String code,String start,String end,List<Bar> rows) {
        if(rows.isEmpty())throw new IllegalArgumentException("Empty history cannot be complete");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            SQLiteStatement stmt=db.compileStatement("INSERT OR REPLACE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            try {
                for(Bar b:rows){
                    if(b.date.compareTo(start)<0||b.date.compareTo(end)>0)throw new IllegalArgumentException("Out of range K-line");
                    stmt.clearBindings();stmt.bindString(1,code);stmt.bindString(2,b.date);
                    stmt.bindDouble(3,b.open);stmt.bindDouble(4,b.high);stmt.bindDouble(5,b.low);
                    stmt.bindDouble(6,b.close);stmt.bindDouble(7,b.volume);stmt.bindString(8,b.volumeUnit);
                    if(b.amount!=null)stmt.bindDouble(9,b.amount);else stmt.bindNull(9);
                    stmt.bindString(10,b.source);stmt.bindString(11,b.raw);
                    stmt.executeInsert();
                }
            }finally{stmt.close();}
            db.execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',?,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,NULL,?)",
                    new Object[]{code,start,end,rows.size(),code,start,end,System.currentTimeMillis()});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    /** Mark a current window as satisfied by already-stored bars; no network request. */
    public void markDailyReused(String code,String start,String end){
        if(latestBarDay(code)==null)throw new IllegalStateException("Cannot reuse without saved bars");
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',0,0,NULL,?)",
            new Object[]{code,start,end,System.currentTimeMillis()});
    }
    /** A full prior download already contains the latest requested date. Do not make any HTTP request. */
    public void markUpToDate(String code,String start,String end){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',0,0,NULL,?)",
                new Object[]{code,start,end,System.currentTimeMillis()});
    }
    /** A legitimate zero-row finance response is not proof a company has no history. Recheck later. */
    public void saveEmptyDataJob(String code,String dataset,String start,String end){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,'empty',0,1,NULL,?)",
            new Object[]{code,dataset,start,end,System.currentTimeMillis()});
    }
    public boolean recentlyCheckedDataJob(String code,String dataset,String start,String end){
        long weekAgo=System.currentTimeMillis()-7L*86400*1000;
        return count("SELECT count(*) FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=? AND (status='complete' OR (status='empty' AND checked_at>?))",
            new String[]{code,dataset,start,end,String.valueOf(weekAgo)})>0;
    }
    public void writeFailure(String code,String start,String end,String message){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'failed',0,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,?,?)",
                new Object[]{code,start,end,code,start,end,message,System.currentTimeMillis()});
    }
    public void log(String level,String message){
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("INSERT INTO log(at,level,message) VALUES(?,?,?)",new Object[]{System.currentTimeMillis(),level,message});
        db.execSQL("DELETE FROM log WHERE id < (SELECT coalesce(max(id),0)-3000 FROM log)");
    }
    public String logs(int limit){
        StringBuilder out=new StringBuilder();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT datetime(at/1000,'unixepoch','localtime'),level,message FROM log ORDER BY id DESC LIMIT "+Math.max(1,Math.min(limit,3000)),null)){
            while(c.moveToNext()){out.append(c.getString(0)).append(' ').append(c.getString(1)).append(' ').append(c.getString(2)).append('\n');}
        }
        return out.toString();
    }
    public void checkpoint(){SQLiteDatabase db=getWritableDatabase();try(Cursor c=db.rawQuery("PRAGMA wal_checkpoint(FULL)",null)){if(c.moveToFirst()&&c.getInt(0)!=0)throw new IllegalStateException("SQLite checkpoint busy");}}

    /** Existing bar dates are authoritative: extending the two-year window does NOT reload saved years. */
    public String latestBarDay(String code){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT max(day) FROM daily_bars WHERE code=?",new String[]{code})){
            return c.moveToFirst()?c.getString(0):null;
        }
    }
    public int countDataRows(){return count("SELECT count(*) FROM dataset_rows",null);}
    public int countDataJobs(){return count("SELECT count(*) FROM data_jobs WHERE status='complete'",null);}
    public boolean hasDataJob(String code,String dataset,String start,String end){
        return count("SELECT count(*) FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=? AND status='complete'",new String[]{code,dataset,start,end})>0;
    }
    public String latestDataJobEnd(String code,String dataset){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT max(to_day) FROM data_jobs WHERE code=? AND dataset=? AND status='complete'",new String[]{code,dataset})){
            return c.moveToFirst()?c.getString(0):null;
        }
    }
    private static String digest(String s){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] result=md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder();
            for(byte b:result)out.append(String.format(java.util.Locale.ROOT,"%02x",b & 255));
            return out.toString();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    /** Full provider fields and announcement dates are retained for point-in-time analysis.
        SHA256 primary keys make repeat imports idempotent; revisions are kept as distinct snapshots. */
    public int saveData(String code,String dataset,String start,String end,List<JSONObject> rows){
        if(!code.matches("[0-9]{5}|[0-9]{6}"))throw new IllegalArgumentException("Bad stock code");
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{
            SQLiteStatement st=d.compileStatement("INSERT OR IGNORE INTO dataset_rows(code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at) VALUES(?,?,?,?,?,?,?,?,?)");
            int total=0;
            try{
                for(JSONObject row:rows){
                    String identity=row.optString("ts_code",code);
                    if(!identity.startsWith(code+"."))throw new IllegalArgumentException("Provider returned another stock: "+identity);
                    String raw=row.toString(),period=row.optString("end_date",""),announcement=row.optString("ann_date",row.optString("f_ann_date","")),
                           event=row.optString("trade_date",row.optString("ex_date",row.optString("record_date","")));
                    if(raw.length()>300000)throw new IllegalArgumentException("Oversized data row");
                    st.clearBindings();st.bindString(1,code);st.bindString(2,dataset);st.bindString(3,digest(raw));
                    st.bindString(4,period);st.bindString(5,announcement);st.bindString(6,event);
                    st.bindString(7,"tushare");st.bindString(8,raw);st.bindLong(9,System.currentTimeMillis());
                    st.executeInsert();total++;
                }
            }finally{st.close();}
            d.execSQL("INSERT OR REPLACE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,'complete',?,COALESCE((SELECT attempts FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=?),0)+1,NULL,?)",
                new Object[]{code,dataset,start,end,total,code,dataset,start,end,System.currentTimeMillis()});
            d.setTransactionSuccessful();return total;
        }finally{d.endTransaction();}
    }
    public void dataFailure(String code,String dataset,String start,String end,String error){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,'failed',0,COALESCE((SELECT attempts FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=?),0)+1,?,?)",
                new Object[]{code,dataset,start,end,code,dataset,start,end,error,System.currentTimeMillis()});
    }
    public void financeState(String phase,String active,String detail,int total,int done,int failed){
        getWritableDatabase().execSQL("INSERT OR REPLACE INTO finance_state(id,phase,active,detail,total,complete,failed,updated) VALUES(1,?,?,?,?,?,?,?)",
                new Object[]{phase,active,detail,total,done,failed,System.currentTimeMillis()});
    }
    public JSONObject financeOverview(){
        JSONObject out=new JSONObject();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT phase,active,detail,total,complete,failed FROM finance_state WHERE id=1",null)){
            if(c.moveToFirst()){
                out.put("phase",c.getString(0));out.put("active",c.getString(1));out.put("detail",c.getString(2));
                out.put("total",c.getInt(3));out.put("complete",c.getInt(4));out.put("failed",c.getInt(5));
            }
            out.put("records",countDataRows());out.put("jobs",countDataJobs());
        }catch(Exception ignored){}
        return out;
    }
    public interface ImportProgress { void report(String message); }
    private static void requireColumns(SQLiteDatabase db,String table,String... columns){
        java.util.HashSet<String> names=new java.util.HashSet<>();
        try(Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null)){
            while(c.moveToNext())names.add(c.getString(1));
        }
        for(String column:columns)if(!names.contains(column))throw new IllegalArgumentException("备份缺少表/字段 "+table+"."+column);
    }
    private static boolean tableExists(SQLiteDatabase db,String table){
        try(Cursor c=db.rawQuery("SELECT count(*) FROM sqlite_master WHERE type='table' AND name=?",new String[]{table})){
            return c.moveToFirst()&&c.getInt(0)>0;
        }
    }
    /** Merge a legacy v1 or v2 SQLite export WITHOUT overwriting already-collected records.
        The input must be a local temporary file copied from Android SAF by the caller. */
    public void mergeBackup(File archive,ImportProgress callback){
        SQLiteDatabase old=SQLiteDatabase.openDatabase(archive.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        try{
            requireColumns(old,"instruments","code","name","exchange","source");
            requireColumns(old,"daily_bars","code","day","o","h","l","c","vol","vol_unit","provider","raw");
            try(Cursor c=old.rawQuery("PRAGMA quick_check(1)",null)){
                if(!c.moveToFirst()||!"ok".equalsIgnoreCase(c.getString(0)))throw new IllegalArgumentException("SQLite备份完整性校验失败");
            }
            // Validate every present source table's columns BEFORE starting any import transaction.
            if(tableExists(old,"tasks"))requireColumns(old,"tasks","code","start_day","end_day","status","rows","attempts","error","updated");
            if(tableExists(old,"dataset_rows"))requireColumns(old,"dataset_rows","code","dataset","record_id","period","announcement_day","event_day","provider","raw_json","received_at");
            if(tableExists(old,"data_jobs"))requireColumns(old,"data_jobs","code","dataset","from_day","to_day","status","rows","attempts","error","checked_at");
            SQLiteDatabase target=getWritableDatabase();
            String[] tables={"instruments","daily_bars","tasks","dataset_rows","data_jobs"};
            String[] inserts={
                "INSERT OR IGNORE INTO instruments(code,name,exchange,source) VALUES(?,?,?,?)",
                "INSERT OR IGNORE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                "INSERT OR IGNORE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,?,?,?,?,?)",
                "INSERT OR IGNORE INTO dataset_rows(code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at) VALUES(?,?,?,?,?,?,?,?,?)",
                "INSERT OR IGNORE INTO data_jobs(code,dataset,from_day,to_day,status,rows,attempts,error,checked_at) VALUES(?,?,?,?,?,?,?,?,?)"
            };
            String[] columns={
                "code,name,exchange,source","code,day,o,h,l,c,vol,vol_unit,amount,provider,raw",
                "code,start_day,end_day,status,rows,attempts,error,updated",
                "code,dataset,record_id,period,announcement_day,event_day,provider,raw_json,received_at",
                "code,dataset,from_day,to_day,status,rows,attempts,error,checked_at"
            };
            for(int ti=0;ti<tables.length;ti++){
                if(!tableExists(old,tables[ti]))continue;
                String[] fields=columns[ti].split(",");
                requireColumns(old,tables[ti],fields);
                callback.report("正在合并 "+tables[ti]+"；已下载行情不会删除");
                int merged=0, batch=0;
                SQLiteStatement st=target.compileStatement(inserts[ti]);
                try(Cursor c=old.rawQuery("SELECT "+columns[ti]+" FROM "+tables[ti],null)){
                    try {
                        while(c.moveToNext()){
                            if(batch==0)target.beginTransaction();
                            st.clearBindings();
                            for(int k=0;k<fields.length;k++){
                                int pos=k+1,type=c.getType(k);
                                if(type==Cursor.FIELD_TYPE_NULL)st.bindNull(pos);
                                else if(type==Cursor.FIELD_TYPE_INTEGER)st.bindLong(pos,c.getLong(k));
                                else if(type==Cursor.FIELD_TYPE_FLOAT)st.bindDouble(pos,c.getDouble(k));
                                else st.bindString(pos,c.getString(k));
                            }
                            st.executeInsert();merged++;batch++;
                            if(batch==1000){
                                target.setTransactionSuccessful();target.endTransaction();
                                batch=0;callback.report("合并 "+tables[ti]+": "+merged);
                            }
                        }
                        if(batch>0){target.setTransactionSuccessful();target.endTransaction();}
                    }finally{if(target.inTransaction())target.endTransaction();}
                }finally{st.close();}
                callback.report("已合并 "+tables[ti]+" 共 "+merged+" 行（重复数据自动跳过）");
            }
        }finally{old.close();}
    }

}
