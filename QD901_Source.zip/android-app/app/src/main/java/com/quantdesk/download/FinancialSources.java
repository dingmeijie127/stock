package com.quantdesk.download;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Tushare Pro REST adapter. API response -> named raw fields; never fabricate report values. */
public final class FinancialSources {
    public static final String[] DATASETS={
        "income","balancesheet","cashflow","fina_indicator",
        "daily_basic","adj_factor","dividend","forecast","express"
    };
    public static final String[] HK_DATASETS={"hk_income","hk_balancesheet","hk_cashflow","hk_fina_indicator"};
    public static String[] datasetsFor(String exchange){return "HK".equals(exchange)?HK_DATASETS:DATASETS;}
    private static final String ENDPOINT="https://api.tushare.pro";
    private FinancialSources(){}
    public static final class PermissionException extends IOException {
        public PermissionException(String message){super(message);}
    }
    public static String tsCode(String code,String exchange){
        if("HK".equals(exchange)){
            if(!code.matches("[0-9]{5}"))throw new IllegalArgumentException("Invalid HK symbol");
            return code+".HK";
        }
        if(!code.matches("[0-9]{6}") || !(exchange.equals("SH")||exchange.equals("SZ")||exchange.equals("BJ")))
            throw new IllegalArgumentException("Invalid A-share symbol");
        return code+"."+exchange;
    }
    private static boolean validName(String name){
        for(String allowed:DATASETS)if(allowed.equals(name))return true;
        for(String allowed:HK_DATASETS)if(allowed.equals(name))return true;
        return false;
    }
    private static String compact(LocalDate date){return date.toString().replace("-","");}
    public static JSONObject requestObject(String dataset,String ticker,LocalDate start,LocalDate end,String token) throws Exception{
        if(!validName(dataset))throw new IllegalArgumentException("Unsupported finance dataset: "+dataset);
        if(token==null||token.trim().length()<12)throw new PermissionException("请设置自己的 Tushare Token");
        JSONObject params=new JSONObject().put("ts_code",ticker);
        // HK statements filter by REPORT PERIOD, mainland statements by announcement date.
        // dividend expects ts_code alone.
        if(!"dividend".equals(dataset)){
            params.put("start_date",compact(start));params.put("end_date",compact(end));
        }
        JSONObject body=new JSONObject().put("api_name",dataset).put("token",token.trim())
            .put("params",params).put("fields","");
        HttpURLConnection connection=(HttpURLConnection)new URL(ENDPOINT).openConnection();
        connection.setRequestMethod("POST");connection.setConnectTimeout(12000);connection.setReadTimeout(25000);
        connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
        connection.setRequestProperty("Accept","application/json");
        connection.setDoOutput(true);
        try{
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream output=connection.getOutputStream()){output.write(bytes);}
            int status=connection.getResponseCode();
            if(status!=200)throw new IOException("Tushare HTTP "+status);
            try(InputStream input=connection.getInputStream();ByteArrayOutputStream result=new ByteArrayOutputStream()){
                byte[] b=new byte[8192];int n;
                while((n=input.read(b))!=-1){
                    if(result.size()+n>15_000_000)throw new IOException("Tushare response exceeds 15 MB");
                    result.write(b,0,n);
                }
                return new JSONObject(result.toString("UTF-8"));
            }
        }finally{connection.disconnect();}
    }
    /** Public for offline fixture-based contract tests; response parser does not require network. */
    public static List<JSONObject> parse(JSONObject response,String dataset,String ticker,LocalDate start,LocalDate end) throws Exception{
        if(!validName(dataset))throw new IllegalArgumentException("Bad dataset");
        int code=response.optInt("code",-1);
        if(code!=0){
            String msg=response.optString("msg","remote API error");
            if(code==2002 || msg.contains("权限") || msg.contains("积分") || msg.toLowerCase().contains("permission"))
                throw new PermissionException("Tushare "+dataset+" 需要相应权限 (code="+code+")："+msg);
            throw new IOException("Tushare "+dataset+" API code="+code+" "+msg);
        }
        JSONObject d=response.optJSONObject("data");
        if(d==null)throw new IOException("Tushare "+dataset+" missing data");
        JSONArray fields=d.optJSONArray("fields"),items=d.optJSONArray("items");
        if(fields==null||items==null||fields.length()==0)throw new IOException("Tushare "+dataset+" missing fields/items");
        List<JSONObject> output=new ArrayList<>();
        for(int i=0;i<items.length();i++){
            JSONArray one=items.optJSONArray(i);
            if(one==null||one.length()!=fields.length())throw new IOException("Tushare field count mismatch at row "+i);
            JSONObject row=new JSONObject();
            for(int j=0;j<fields.length();j++)row.put(fields.getString(j),one.isNull(j)?JSONObject.NULL:one.get(j));
            if(!ticker.equals(row.optString("ts_code","")))throw new IOException("Tushare symbol mismatch: "+row.optString("ts_code"));
            // dividend ignores date filters; keep in-window relevant events only.
            if("dividend".equals(dataset)){
                String relevant=row.optString("ann_date",row.optString("ex_date",""));
                if(relevant.matches("[0-9]{8}") && (relevant.compareTo(compact(start))<0||relevant.compareTo(compact(end))>0))continue;
            }
            output.add(row);
        }
        if(dataset.startsWith("hk_") && output.size()>=10000)
            throw new IOException("HK financial report may be truncated at provider row cap (10000)");
        if("hk_fina_indicator".equals(dataset) && output.size()>=200)
            throw new IOException("HK indicator page cap (200): narrow date ranges before marking complete");
        return output;
    }
    public static List<JSONObject> fetch(String dataset,String code,String exchange,LocalDate start,LocalDate end,String token) throws Exception{
        String ticker=tsCode(code,exchange);
        return parse(requestObject(dataset,ticker,start,end,token),dataset,ticker,start,end);
    }
}
