package com.quantdesk.download;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** V9.0: one local A/H database, two-year initial history then daily incremental updates. */
public final class MainActivity extends Activity {
    private static final int EXPORT_DB=2101, EXPORT_LOG=2102, POST_NOTIFICATIONS_REQUEST=2103, IMPORT_DB=2104;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status,counts,log,diagnostic,financeCount;
    private ProgressBar progress;
    private EditText tokenInput;
    private boolean visible;
    private final Runnable refresh = new Runnable(){
        @Override public void run(){if(visible){refreshUI();handler.postDelayed(this,1600);}}
    };
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setPadding(dp(4),dp(7),dp(4),dp(7));return t;}
    private void addButton(LinearLayout root,String name,View.OnClickListener click){
        Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setOnClickListener(click);
        root.addView(b,new LinearLayout.LayoutParams(-1,-2));
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(12),dp(16),dp(12));
        ScrollView scroll=new ScrollView(this);scroll.addView(page);setContentView(scroll);
        page.addView(text("QuantDesk V9.0 · A股 + 港股历史数据库",21));
        page.addView(text("已下载的日K保留不重下；新日期增量更新。A股/港股同一个SQLite，财报独立采集。",14));
        status=text("正在检查数据库…",16);page.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);page.addView(progress);
        counts=text("A股：0  港股：0  日K：0",15);page.addView(counts);
        diagnostic=text("当前：尚未开始",14);page.addView(diagnostic);
        addButton(page,"开始 / 继续 / 每日增量更新 A股+港股日K",v->start(HarvestService.START));
        page.addView(text("财报与量化数据 · 使用你自己的 Tushare Token（需要足够权限）",14));
        tokenInput=new EditText(this);tokenInput.setSingleLine(true);
        tokenInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tokenInput.setHint("个人 Tushare Token（本机加密）");page.addView(tokenInput);
        addButton(page,"保存 Token",v->saveToken());
        addButton(page,"开始 / 继续采集A股+港股财报（需Token及授权）",v->startFinance());
        financeCount=text("财报：尚未开始",14);page.addView(financeCount);
        addButton(page,"暂停下载",v->pause());
        addButton(page,"导出 SQLite（换版本前先备份）",v->export(EXPORT_DB));
        addButton(page,"导入旧版 SQLite（合并、不覆盖）",v->importOld());
        addButton(page,"导出日志",v->export(EXPORT_LOG));
        page.addView(text("最新采集日志（自动刷新）",17));
        log=text("暂无记录",12);log.setTextIsSelectable(true);page.addView(log);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},POST_NOTIFICATIONS_REQUEST);
        }
    }
    private void start(String act){
        try{
            Intent command=new Intent(this,HarvestService.class);command.setAction(act);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(command);else startService(command);
            status.setText("已启动采集请求，请查看进度与日志");
        }catch(Exception e){status.setText("启动失败："+e.getMessage());}
    }
    private void saveToken(){
        try{
            new TokenVault(this).save(tokenInput.getText().toString());tokenInput.setText("");
            Toast.makeText(this,"Token 已在本机加密保存",Toast.LENGTH_LONG).show();
        }catch(Exception e){status.setText("Token 保存失败："+e.getMessage());}
    }
    private void startFinance(){
        try{
            if(new TokenVault(this).load().isEmpty()){
                status.setText("请先保存 Tushare Token，日K仍可独立下载");return;
            }
            start(HarvestService.START_FINANCE);
        }catch(Exception e){status.setText("财务任务启动失败："+e.getMessage());}
    }
    private void pause(){
        try{
            Intent command=new Intent(this,HarvestService.class);command.setAction(HarvestService.PAUSE);
            startService(command);status.setText("正在暂停，等待当前网络请求结束…");
        }catch(Exception e){status.setText("暂停失败："+e.getMessage());}
    }
    private void refreshUI(){
        try(MarketDb db=new MarketDb(this)){
            JSONObject o=db.overview(),f=db.financeOverview();
            int total=o.optInt("total"),done=o.optInt("done"),failed=o.optInt("failed");
            progress.setProgress(total==0?0:Math.min(100,(done+failed)*100/total));
            counts.setText(String.format(Locale.CHINA,
                "股票 A:%,d  港:%,d  已完成：%,d  失败：%,d\n日K A:%,d  港:%,d  总计:%,d",
                o.optInt("a_count"),o.optInt("hk_count"),done,failed,
                o.optInt("a_bars"),o.optInt("hk_bars"),o.optInt("bars")));
            status.setText("日K状态："+o.optString("phase","未开始")+"  "+o.optString("start","")+" 至 "+o.optString("end",""));
            diagnostic.setText("当前："+o.optString("active","")+"\n"+o.optString("detail",""));
            financeCount.setText("财报/量化："+f.optString("phase","未开始")+" · 已保存记录 "+f.optInt("records")+
                    " · 已处理 "+f.optInt("complete")+"/"+f.optInt("total")+
                    " · 失败 "+f.optInt("failed")+"\n"+f.optString("active","")+" "+f.optString("detail",""));
            if(HarvestService.RUNNING.get())diagnostic.append("\n"+HarvestService.LIVE);
            String recent=db.logs(35);log.setText(recent.isEmpty()?"暂无日志":recent);
        }catch(Exception e){status.setText("数据库读取失败："+e.getMessage());}
    }
    private void export(int type){
        if(type==EXPORT_DB && HarvestService.RUNNING.get()){
            Toast.makeText(this,"请先暂停并等待采集结束，再导出完整数据库",Toast.LENGTH_LONG).show();return;
        }
        Intent picker=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        picker.setType(type==EXPORT_DB?"application/octet-stream":"text/plain");
        picker.addCategory(Intent.CATEGORY_OPENABLE);
        picker.putExtra(Intent.EXTRA_TITLE,type==EXPORT_DB?"QuantDesk90-AHK.sqlite3":"QuantDesk90-采集日志.txt");
        try{startActivityForResult(picker,type);}catch(ActivityNotFoundException ex){
            Toast.makeText(this,"没有文件保存应用",Toast.LENGTH_LONG).show();
        }
    }
    private void importOld(){
        if(HarvestService.RUNNING.get()){
            Toast.makeText(this,"请先暂停所有采集任务后再合并旧数据库",Toast.LENGTH_LONG).show();return;
        }
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("*/*");
        try{startActivityForResult(pick,IMPORT_DB);}catch(Exception e){status.setText("无法打开文件选择器："+e.getMessage());}
    }
    private void importAsync(Uri uri){
        status.setText("正在校验和合并旧版 SQLite…");
        new Thread(()->{
            File temp=new File(getCacheDir(),"qd89_import_backup.sqlite3");
            try{
                try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(temp)){
                    if(in==null)throw new IllegalArgumentException("无法读取备份文件");
                    byte[] b=new byte[131072];int n;long bytes=0;
                    while((n=in.read(b))!=-1){
                        bytes+=n;if(bytes>4L*1024*1024*1024)throw new IllegalArgumentException("备份文件超过 4GB 上限");
                        out.write(b,0,n);
                    }
                    out.getFD().sync();
                }
                try(MarketDb db=new MarketDb(this)){
                    db.mergeBackup(temp,m->runOnUiThread(()->status.setText(m)));
                    db.log("INFO","已合并旧版 SQLite；重复行跳过，日K/财务数据不会清空");
                }
                runOnUiThread(()->{Toast.makeText(this,"数据库合并成功，已下载日K无需重下",Toast.LENGTH_LONG).show();refreshUI();});
            }catch(Exception e){
                String error=e.getClass().getSimpleName()+" "+String.valueOf(e.getMessage());
                runOnUiThread(()->status.setText("导入失败，原数据未清空："+error));
            }finally{if(temp.exists())temp.delete();}
        },"qd89-import-sqlite").start();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==IMPORT_DB){importAsync(uri);return;}
        new Thread(()->{
            try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                if(out==null)throw new IllegalStateException("无法创建输出文件");
                if(request==EXPORT_DB){
                    if(HarvestService.RUNNING.get())throw new IllegalStateException("任务仍在运行，请先暂停");
                    try(MarketDb db=new MarketDb(this)){db.checkpoint();}
                    File database=getDatabasePath(MarketDb.NAME);
                    try(FileInputStream in=new FileInputStream(database)){
                        byte[] b=new byte[65536];int n;long copied=0;
                        while((n=in.read(b))!=-1){
                            out.write(b,0,n);copied+=n;
                            if(copied%(10L*1024*1024)<65536){
                                final long mb=copied/1048576;
                                runOnUiThread(()->status.setText("正在导出数据库："+mb+" MB"));
                            }
                        }
                    }
                }else if(request==EXPORT_LOG){
                    try(MarketDb db=new MarketDb(this)){
                        out.write(db.logs(3000).getBytes(StandardCharsets.UTF_8));
                    }
                }
                out.flush();
                runOnUiThread(()->Toast.makeText(this,"备份已保存，请确认文件存在后再卸载旧版",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                String message="导出失败："+e.getMessage();
                runOnUiThread(()->status.setText(message));
            }
        },"qd89-export").start();
    }
    @Override protected void onResume(){super.onResume();visible=true;handler.removeCallbacks(refresh);refresh.run();}
    @Override protected void onPause(){visible=false;handler.removeCallbacks(refresh);super.onPause();}
}
