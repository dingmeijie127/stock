package com.quantdesk.download;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Token stored encrypted with an Android Keystore AES/GCM key; never included in logs or exports. */
public final class TokenVault {
    private static final String ALIAS="QuantDesk_Tushare_AES_V1",STORE="qd89_token";
    private final SharedPreferences prefs;
    public TokenVault(Context context){prefs=context.getSharedPreferences(STORE,Context.MODE_PRIVATE);}
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(ALIAS)){
            KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());gen.generateKey();
        }
        return (SecretKey)ks.getKey(ALIAS,null);
    }
    public void save(String token) throws Exception {
        String t=token.trim();if(t.length()<12)throw new IllegalArgumentException("Token 长度不符合要求");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        String iv=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP);
        String ct=Base64.encodeToString(cipher.doFinal(t.getBytes("UTF-8")),Base64.NO_WRAP);
        if(!prefs.edit().putString("iv",iv).putString("blob",ct).commit())throw new IllegalStateException("无法保存 Token");
    }
    public String load() throws Exception{
        String iv=prefs.getString("iv",null),blob=prefs.getString("blob",null);
        if(iv==null||blob==null)return "";
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(blob,Base64.NO_WRAP)),"UTF-8");
    }
}
