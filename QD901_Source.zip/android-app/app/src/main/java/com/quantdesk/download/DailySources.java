package com.quantdesk.download;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/** Actual public daily K line providers. No offline/demo data is accepted as historical bars. */
public final class DailySources {
    public static final String EAST_TOKEN="bd1d9ddb04089700cf9c27f6f7426281";
    public static final class Result {
        public final List<Bar> bars;public final String provider;
        Result(List<Bar> bars,String provider){this.bars=bars;this.provider=provider;}
    }
    private DailySources(){}
    private static String response(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(9000);c.setReadTimeout(17000);c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/122 Mobile Safari/537.36");
        c.setRequestProperty("Accept","application/json,text/plain,*/*");
        c.setRequestProperty("Referer","https://quote.eastmoney.com/");
        try {
            int status=c.getResponseCode();
            if(status!=200)throw new IOException("HTTP_"+status+" host="+c.getURL().getHost());
            try(InputStream input=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=input.read(buffer))!=-1){
                    if(out.size()+n>3000000)throw new IOException("response-too-large");
                    out.write(buffer,0,n);
                }
                return out.toString("UTF-8");
            }
        }finally{c.disconnect();}
    }
    private static String strip(String s){return s.replace("-","");}
    private static void validateSymbol(String code,String exchange){
        if(!code.matches("[0-9]{6}")||!(exchange.equals("SH")||exchange.equals("SZ")||exchange.equals("BJ")))
            throw new IllegalArgumentException("not a valid A-share symbol");
    }
    public static Result eastmoney(String code,String exchange,LocalDate from,LocalDate to) throws Exception {
        validateSymbol(code,exchange);
        String secid=(exchange.equals("SH")?"1.":"0.")+code;
        String url="https://push2his.eastmoney.com/api/qt/stock/kline/get?secid="+secid+
            "&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61"+
            "&klt=101&fqt=0&beg="+strip(from.toString())+"&end="+strip(to.toString())+
            "&lmt=900&ut="+EAST_TOKEN;
        JSONObject json=new JSONObject(response(url));
        JSONObject data=json.optJSONObject("data");
        if(data==null)throw new IOException("Eastmoney data empty rc="+json.optInt("rc",-1));
        JSONArray records=data.optJSONArray("klines");
        if(records==null||records.length()==0)throw new IOException("Eastmoney no K lines");
        List<Bar> bars=new ArrayList<>();
        for(int i=0;i<records.length();i++){
            Bar bar=Bar.eastmoney(records.getString(i));
            if(bar.date.compareTo(from.toString())>=0 && bar.date.compareTo(to.toString())<=0)bars.add(bar);
        }
        if(bars.isEmpty())throw new IOException("Eastmoney no rows in selected two-year window");
        if(bars.size()>=900)throw new IOException("Eastmoney suspected K-line row cap");
        return new Result(bars,"eastmoney");
    }
    public static Result yahoo(String code,String exchange,LocalDate from,LocalDate to) throws Exception {
        validateSymbol(code,exchange);
        String ticker=code+(exchange.equals("SH")?".SS":exchange.equals("SZ")?".SZ":".BJ");
        long start=from.atStartOfDay(ZoneId.of("Asia/Shanghai")).toEpochSecond();
        long end=to.plusDays(1).atStartOfDay(ZoneId.of("Asia/Shanghai")).toEpochSecond();
        String url="https://query1.finance.yahoo.com/v8/finance/chart/"+ticker+
                "?period1="+start+"&period2="+end+"&interval=1d";
        JSONObject chart=new JSONObject(response(url)).optJSONObject("chart");
        if(chart==null)throw new IOException("Yahoo chart missing");
        JSONArray results=chart.optJSONArray("result");
        if(results==null||results.length()==0)throw new IOException("Yahoo no result");
        JSONObject series=results.getJSONObject(0);
        JSONArray times=series.optJSONArray("timestamp");
        if(times==null||times.length()==0)throw new IOException("Yahoo timestamps missing");
        JSONObject quote=series.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray o=quote.getJSONArray("open"),h=quote.getJSONArray("high"),l=quote.getJSONArray("low"),c=quote.getJSONArray("close"),v=quote.getJSONArray("volume");
        List<Bar> bars=new ArrayList<>();
        for(int i=0;i<times.length();i++){
            if(i>=o.length()||i>=h.length()||i>=l.length()||i>=c.length()||i>=v.length()||
               o.isNull(i)||h.isNull(i)||l.isNull(i)||c.isNull(i)||v.isNull(i))continue;
            String day=Instant.ofEpochSecond(times.getLong(i)).atZone(ZoneId.of("Asia/Shanghai")).toLocalDate().toString();
            if(day.compareTo(from.toString())<0||day.compareTo(to.toString())>0)continue;
            JSONObject raw=new JSONObject().put("source","Yahoo chart").put("timestamp",times.getLong(i))
               .put("open",o.getDouble(i)).put("high",h.getDouble(i)).put("low",l.getDouble(i))
               .put("close",c.getDouble(i)).put("volume",v.getDouble(i));
            bars.add(new Bar(day,o.getDouble(i),h.getDouble(i),l.getDouble(i),c.getDouble(i),v.getDouble(i),
                             null,"yahoo","SHARES",raw.toString()));
        }
        if(bars.isEmpty())throw new IOException("Yahoo no valid bars in selected two-year window");
        return new Result(bars,"yahoo");
    }
    /** Tencent historical day bars. The provider reports native volume units; do not silently convert. */
    public static Result tencent(String code,String exchange,LocalDate from,LocalDate to) throws Exception {
        validateSymbol(code,exchange);
        if(exchange.equals("BJ"))throw new IOException("Tencent Beijing market is not verified");
        String symbol=(exchange.equals("SH")?"sh":"sz")+code;
        String param=symbol+",day,,,650";
        String url="https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param="+param;
        JSONObject root=new JSONObject(response(url));
        JSONObject data=root.optJSONObject("data");
        if(data==null||data.optJSONObject(symbol)==null)throw new IOException("Tencent missing symbol data");
        JSONObject market=data.getJSONObject(symbol);
        JSONArray rows=market.optJSONArray("day");
        if(rows==null||rows.length()==0)throw new IOException("Tencent daily bars empty");
        List<Bar> bars=new ArrayList<>();
        for(int i=0;i<rows.length();i++){
            JSONArray p=rows.optJSONArray(i);
            if(p==null||p.length()<6)continue;
            String day=p.getString(0);
            if(day.compareTo(from.toString())<0||day.compareTo(to.toString())>0)continue;
            bars.add(new Bar(day,p.getDouble(1),p.getDouble(3),p.getDouble(4),p.getDouble(2),
                    p.getDouble(5),null,"tencent","TENCENT_NATIVE",p.toString()));
        }
        if(bars.isEmpty())throw new IOException("Tencent no rows in two-year window");
        return new Result(bars,"tencent");
    }
    public static Result downloadBars(String code,String exchange,LocalDate from,LocalDate to) throws Exception {
        if("HK".equals(exchange))return HongKongSources.download(code,from,to);
        String failEast;
        try{return eastmoney(code,exchange,from,to);}
        catch(Exception e){failEast=e.getClass().getSimpleName()+":"+e.getMessage();}
        String failTencent;
        try{return tencent(code,exchange,from,to);}
        catch(Exception e){failTencent=e.getClass().getSimpleName()+":"+e.getMessage();}
        try{return yahoo(code,exchange,from,to);}
        catch(Exception e){throw new IOException("eastmoney="+failEast+"; tencent="+failTencent+"; yahoo="+
                             e.getClass().getSimpleName()+":"+e.getMessage());}
    }
}
