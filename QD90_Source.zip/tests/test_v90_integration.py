"""Migration / mixed-market database tests against real SQLite + source contracts."""
from pathlib import Path
import re
import sqlite3

R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'
DB=(J/'MarketDb.java').read_text()
UNIVERSE=(J/'Universe.java').read_text()
HK=(J/'HongKongSources.java').read_text()
MAIN=(J/'MainActivity.java').read_text()
SERVICE=(J/'HarvestService.java').read_text()
FINANCE=(J/'FinancialSources.java').read_text()
DDL=re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB)


def new_sqlite():
    con=sqlite3.connect(':memory:')
    for stmt in DDL: con.execute(stmt)
    return con


def test_v2_to_v3_migration_keeps_old_rows():
    db=new_sqlite()
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('600519','茅台','SH','old'))
    db.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',(
        '600519','2026-10-23',1600,1700,1500,1650,100,'LOTS_100_SHARES',1000,'eastmoney','old-real'))
    db.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?)',('600519','2024-10-25','2026-10-25','complete',1,1,None,1))
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('00700','腾讯','HK','real_hk_listing'))
    db.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',(
        '00700','2026-10-23',600,630,590,610,100000,'SHARES',62000000,'eastmoney_hk','real-hk'))
    assert db.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==2
    assert db.execute('SELECT c FROM daily_bars WHERE code=?',('600519',)).fetchone()[0]==1650
    assert db.execute('SELECT c FROM daily_bars WHERE code=?',('00700',)).fetchone()[0]==610
    assert {'market_audit','dataset_rows','data_jobs','finance_state'}.issubset(
        set(x[0] for x in db.execute('SELECT name FROM sqlite_master')))
    for stmt in DDL[6:]: db.execute(stmt)  # repeated additive IF NOT EXISTS migration
    assert db.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==2


def test_incremental_date_window_keeps_old_rows_and_deduplicates():
    db=new_sqlite()
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('00700','腾讯','HK','real'))
    base=('00700','2026-10-23',600,630,590,610,50000,'SHARES',None,'eastmoney_hk','raw')
    db.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',base)
    db.execute('INSERT OR IGNORE INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',base)
    new=('00700','2026-10-26',605,635,600,624,60000,'SHARES',None,'eastmoney_hk','raw2')
    db.execute('INSERT OR IGNORE INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',new)
    assert db.execute('SELECT day FROM daily_bars WHERE code="00700" ORDER BY day').fetchall()==[
        ('2026-10-23',),('2026-10-26',)]
    assert 'RangePlanner.nextDailyStart' in SERVICE
    assert 'db.latestBarDay(code)' in SERVICE


def test_hk_finance_records_source_and_market_and_does_not_delete_a():
    db=new_sqlite()
    db.execute('INSERT INTO dataset_rows VALUES(?,?,?,?,?,?,?,?,?)',(
        '00700','hk_income','h1','20260630','','','tushare',
        '{"ts_code":"00700.HK","end_date":"20260630","ind_name":"营业额","ind_value":123}',1000))
    db.execute('INSERT OR IGNORE INTO dataset_rows VALUES(?,?,?,?,?,?,?,?,?)',(
        '00700','hk_income','h1','20260630','','','tushare',
        '{"ts_code":"00700.HK","end_date":"20260630","ind_name":"营业额","ind_value":123}',1000))
    assert db.execute('SELECT COUNT(*) FROM dataset_rows WHERE code="00700"').fetchone()[0]==1
    assert 'hk_income' in FINANCE and 'hk_balancesheet' in FINANCE and 'hk_cashflow' in FINANCE
    assert 'datasetsFor(stock.exchange)' in SERVICE
    assert '"HK".equals(exchange)' in FINANCE
    assert 'new TokenVault' in SERVICE


def test_one_database_and_migration_paths_no_drop():
    assert 'quantdesk-a-share-2y.sqlite3' in DB
    assert 'DROP TABLE' not in DB
    assert 'CREATE TABLE IF NOT EXISTS market_audit' in DB
    assert 'mergeBackup(temp' in MAIN
    assert 'INSERT OR IGNORE INTO daily_bars' in DB
    assert "applicationId 'com.quantdesk.asharecollector88'" in (R/'android-app/app/build.gradle').read_text()
    assert 'versionCode 900' in (R/'android-app/app/build.gradle').read_text()


def test_real_list_snapshot_required_and_provider_fallbacks():
    assert 'context.getAssets().open("hk_universe.tsv")' in UNIVERSE
    assert 'count<1000' in UNIVERSE
    assert 'context.getAssets().open("universe.tsv")' in UNIVERSE
    assert '116.' in HK and 'query1.finance.yahoo.com' in HK
    assert 'HK Eastmoney no bars' in HK
    assert 'unavailableMarkets' in SERVICE


def test_data_not_claimed_complete_on_empty_finance():
    assert 'db.saveEmptyDataJob' in SERVICE
    assert 'db.recentlyCheckedDataJob' in SERVICE
    assert 'HK financial report may be truncated' in FINANCE
