"""Build-time snapshot of the *reported active* HK universe for mobile SQLite.

Public feed is not an authoritative all-historical/delisted securities master.
Never synthesize a universe or silently ship an empty catalog.
"""
import argparse
import csv
import json
import re
from datetime import datetime, timezone
from pathlib import Path


def normalize_hk_code(value):
    s = str(value).strip().upper()
    if s.endswith('.HK'):
        s = s[:-3]
    if s.isdigit() and 1 <= len(s) <= 5:
        return s.zfill(5)
    return None


def assemble(rows):
    found = {}
    for raw_code, raw_name, source in rows:
        code = normalize_hk_code(raw_code)
        name = str(raw_name or '').replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').strip()
        if code and name and name not in ('--', 'None', 'nan'):
            found.setdefault(code, (code, name, 'HK', source))
    return found


def from_akshare():
    import akshare as ak
    errors = []
    for method in ('stock_hk_spot_em', 'stock_hk_main_board_spot_em'):
        try:
            frame = getattr(ak, method)()
            rows = [(str(r['代码']), str(r['名称']), 'akshare:' + method) for _, r in frame.iterrows()]
            if len(assemble(rows)) >= 1000:
                return rows, method
            errors.append(method + ': returned less than 1000 symbols')
        except Exception as ex:
            errors.append(method + ': ' + str(ex)[:150])
    raise RuntimeError('; '.join(errors))


def from_eastmoney():
    """Direct HK spot list fallback. The Eastmoney endpoint may change."""
    import urllib.parse
    import urllib.request
    rows = []
    seen = set()
    for pn in range(1, 30):
        params = urllib.parse.urlencode({
            'pn': pn, 'pz': 500, 'po': 1, 'np': 1,
            'ut': 'bd1d9ddb04089700cf9c27f6f7426281',
            'fid': 'f12', 'fltt': 2, 'invt': 2,
            'fs': 'm:116,m:113,m:114,m:115,m:128', 'fields': 'f12,f14',
        })
        req = urllib.request.Request('https://push2.eastmoney.com/api/qt/clist/get?' + params,
                                     headers={'User-Agent': 'Mozilla/5.0', 'Referer': 'https://quote.eastmoney.com/'})
        with urllib.request.urlopen(req, timeout=35) as resp:
            payload = resp.read(5_000_000)
        data = json.loads(payload).get('data') or {}
        entries = data.get('diff') or []
        if isinstance(entries, dict):
            entries = list(entries.values())
        if not entries:
            break
        for entry in entries:
            code = normalize_hk_code(entry.get('f12', ''))
            name = str(entry.get('f14') or '').strip()
            if code and name and code not in seen:
                rows.append((code, name, 'eastmoney:hk_clist'))
                seen.add(code)
        if len(entries) < 500:
            break
    if len(assemble(rows)) < 1000:
        raise RuntimeError(f'Eastmoney HK list returned only {len(assemble(rows))} codes')
    return rows, 'eastmoney:hk_clist'


def write_snapshot(rows, output, minimum=1000, source='test'):
    records = assemble(rows)
    if len(records) < minimum:
        raise ValueError(f'HK universe too small: {len(records)} < {minimum}')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with (output / 'hk_universe.tsv').open('w', encoding='utf-8', newline='') as stream:
        wr = csv.writer(stream, delimiter='\t', lineterminator='\n')
        wr.writerow(['code', 'name', 'exchange', 'source'])
        for code in sorted(records):
            wr.writerow(records[code])
    (output / 'hk_universe_meta.json').write_text(json.dumps({
        'source': source, 'as_of_utc': datetime.now(timezone.utc).isoformat(),
        'count': len(records), 'market': 'HK',
        'coverage_note': 'Spot universe only; delisted securities and non-equity instruments are not verified.'
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    return len(records)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--min-count', type=int, default=1000)
    parser.add_argument('--fixture', help='only for offline tests, never production')
    parser.add_argument('--test-mode', action='store_true')
    a = parser.parse_args(argv)
    if a.fixture:
        if not a.test_mode:
            raise SystemExit('::error::Production HK roster cannot use test fixture')
        with open(a.fixture, encoding='utf-8') as f:
            rows = [(r['code'], r['name'], 'test_fixture') for r in csv.DictReader(f)]
        source = 'test_fixture'
    else:
        errors = []
        for name, fn in (('AKShare', from_akshare), ('Eastmoney', from_eastmoney)):
            try:
                rows, detail = fn()
                if len(assemble(rows)) >= a.min_count:
                    source = name + ':' + detail
                    break
                errors.append(name + ': below threshold')
            except Exception as ex:
                errors.append(name + ': ' + str(ex)[:250])
        else:
            raise SystemExit('::error::HK catalog download FAILED; refusing empty APK. ' + ' | '.join(errors))
    count = write_snapshot(rows, a.output, minimum=a.min_count, source=source)
    print('Real HK spot universe:', count, source)


if __name__ == '__main__':
    main()
