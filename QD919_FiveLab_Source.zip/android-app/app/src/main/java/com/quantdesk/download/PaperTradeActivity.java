package com.quantdesk.download;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/** Separate, non-brokerage experimental portfolio. Interactive A-share paper trading dashboard. */
public final class PaperTradeActivity extends Activity {
    private static final int EXPORT=3101,EXPORT_DB=3102;
    private static final int NAVY=Color.rgb(17,32,57),BLUE=Color.rgb(41,96,216);
    private static final int BG=Color.rgb(245,247,251),MUTED=Color.rgb(99,113,137);
    private static final int RED=Color.rgb(204,55,64),GREEN=Color.rgb(23,140,102);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private TextView message,accountInfo,sectionName,marketInfo,overviewInfo,diagnosticInfo,automaticInfo;
    private LinearLayout tabRow,listPane,strategyRow;
    private EditText search;
    private String activeTab="持仓",latestDay="",filter="";
    private int selectedStrategy=0;
    private Button autoSwitch;
    private EquityCurveView equityChart;
    private Dashboard current;
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable surface(int color,int radius){
        GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(dp(radius));return b;
    }
    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private LinearLayout.LayoutParams margins(int width,int height,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,height);p.bottomMargin=dp(bottom);return p;
    }
    private Button button(String label,int color,View.OnClickListener onClick){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(Color.WHITE);
        b.setBackground(surface(color,12));b.setPadding(dp(9),dp(8),dp(9),dp(8));b.setOnClickListener(onClick);return b;
    }
    private LinearLayout card(){
        LinearLayout box=column();box.setBackground(surface(Color.WHITE,16));box.setPadding(dp(15),dp(14),dp(15),dp(14));return box;
    }
    private void addCard(LinearLayout root,LinearLayout card){root.addView(card,margins(-1,-2,12));}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(Color.WHITE);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout screen=column();screen.setPadding(dp(14),0,dp(14),dp(26));scroll.addView(screen);setContentView(scroll);
        LinearLayout toolbar=column();toolbar.setBackground(surface(NAVY,0));toolbar.setPadding(dp(16),dp(16),dp(16),dp(16));
        screen.addView(toolbar,margins(-1,-2,14));
        TextView back=text("‹  返回行情数据库",13,Color.rgb(185,204,239),false);back.setOnClickListener(v->finish());toolbar.addView(back);
        gap(toolbar,13);
        toolbar.addView(text("五策略量化实验室 V9.1.8 / A股",22,Color.WHITE,true));
        gap(toolbar,5);
        toolbar.addView(text("先分析强/弱/震荡 → 分仓设置风险预算 → 分级信号/观察池 → 模拟成交验证",12,Color.rgb(181,201,234),false));
        gap(toolbar,12);
        accountInfo=text("读取模拟资产中…",16,Color.WHITE,true);
        accountInfo.setLineSpacing(dp(5),1);toolbar.addView(accountInfo);
        gap(toolbar,8);marketInfo=text("市场广度：尚未完成扫描",12,Color.rgb(185,204,239),false);
        marketInfo.setLineSpacing(dp(3),1);toolbar.addView(marketInfo);
        message=text("准备读取本地日K",12,MUTED,false);screen.addView(message,margins(-1,-2,12));
        LinearLayout accountsCard=card();accountsCard.addView(text("五个独立策略账户（每户初始 ¥100,000）",16,NAVY,true));
        gap(accountsCard,8);strategyRow=column();accountsCard.addView(strategyRow);
        gap(accountsCard,7);overviewInfo=text("各账户净值载入中…",12,MUTED,false);
        accountsCard.addView(overviewInfo);
        gap(accountsCard,9);accountsCard.addView(text("当前策略仓 · 净值轨迹",13,NAVY,true));
        equityChart=new EquityCurveView(this);accountsCard.addView(equityChart,margins(-1,dp(148),0));
        addCard(screen,accountsCard);
        LinearLayout actions=card();actions.addView(text("策略模拟交易",16,NAVY,true));gap(actions,8);
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);
        Button buy=button("＋ 模拟买入",RED,v->manualDialog("BUY","",100));
        Button sell=button("－ 模拟卖出",GREEN,v->manualDialog("SELL","",100));
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(49),1);half.rightMargin=dp(5);
        a.addView(buy,half);
        LinearLayout.LayoutParams other=new LinearLayout.LayoutParams(0,dp(49),1);other.leftMargin=dp(5);
        a.addView(sell,other);actions.addView(a);gap(actions,8);
        actions.addView(button("① 分析全市场 → 扫描五种算法",BLUE,v->runAction("SCAN")),margins(-1,dp(46),8));
        actions.addView(button("② 按当日风险预算生成五仓模拟委托",BLUE,v->runAction("AUTO")),margins(-1,dp(46),8));
        autoSwitch=button("",NAVY,v->new AlertDialog.Builder(this).setTitle("启用后台自动模拟交易？")
            .setMessage("每12小时尝试读取本地最新有效日K；依次分析市场、给五个模拟账户选股、生成虚拟买卖委托。次日行情入库后才会模拟成交。仅在手机允许后台任务时执行，不保证准点，不发送真实券商订单。")
            .setNegativeButton("取消",null)
            .setPositiveButton("切换开关",(d,w)->{
                boolean now=!PaperAutoWorker.enabled(this);PaperAutoWorker.schedule(this,now);updateAutoSwitch();
            }).show());
        updateAutoSwitch();actions.addView(autoSwitch,margins(-1,dp(44),8));
        actions.addView(button("③ 固定参数历史逐日回放 · 验证五策略",NAVY,v->runAction("VALIDATE")),margins(-1,dp(46),8));
        actions.addView(button("确认候选策略委托",NAVY,v->new AlertDialog.Builder(this).setTitle("确认自动模拟委托")
            .setMessage("仅对今日已扫描的BUY/SELL信号创建模拟委托，五仓按牛/熊/震荡分别限制总仓位、单股仓位及持仓数量，观察池不会买入。下一个有效交易日日K开盘模拟成交并计入滑点和费用。是否继续？")
            .setNegativeButton("返回",null).setPositiveButton("创建模拟委托",(d,w)->runAction("ORDER")).show()),margins(-1,dp(46),8));
        actions.addView(button("下一日K结算五个模拟仓委托",GREEN,v->runAction("SETTLE")),margins(-1,dp(44),0));
        addCard(screen,actions);
        LinearLayout diagnostics=card();
        diagnostics.addView(text("每日交易决策 · 市场仓位预算与信号诊断",16,NAVY,true));gap(diagnostics,7);
        diagnosticInfo=text("请先扫描：各仓将显示股票仓位上限、允许信号、观察池和等待原因。",12,NAVY,false);
        diagnosticInfo.setLineSpacing(dp(4),1);diagnostics.addView(diagnosticInfo);
        gap(diagnostics,9);
        automaticInfo=text("自动运行记录尚无；后台开启不代表已完成成交。",12,MUTED,false);
        diagnostics.addView(automaticInfo);
        addCard(screen,diagnostics);
        LinearLayout table=card();sectionName=text("模拟账户明细",16,NAVY,true);table.addView(sectionName);
        gap(table,10);tabRow=new LinearLayout(this);tabRow.setOrientation(LinearLayout.HORIZONTAL);table.addView(tabRow);
        gap(table,8);
        search=new EditText(this);search.setTextSize(13);search.setSingleLine(true);
        search.setHint("按股票代码筛选（例如 600519）");search.setBackground(surface(BG,10));
        search.setPadding(dp(12),dp(9),dp(12),dp(9));table.addView(search,margins(-1,dp(46),6));
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filter=s.toString().trim();renderRows();}
            @Override public void afterTextChanged(Editable e){}
        });
        listPane=column();table.addView(listPane);addCard(screen,table);
        LinearLayout files=card();files.addView(text("导出及实验说明",16,NAVY,true));gap(files,9);
        files.addView(button("导出当前策略的委托与成交 CSV",BLUE,v->exportFile(EXPORT)),margins(-1,dp(44),7));
        files.addView(button("备份独立模拟账本 SQLite",NAVY,v->exportFile(EXPORT_DB)),margins(-1,dp(44),10));
        files.addView(text("模拟自动交易须手机定期同步行情。信号收盘产生、下一有效日K开盘模拟成交；五仓资金相互隔离，单仓T+1、手数、滑点及手续费均独立。市场数据库只读。",12,MUTED,false));
        gap(files,8);
        files.addView(text("缠论分型为简化模型，不是完整的笔/线段/中枢算法。回放只用当前股票池和未复权日K，存在幸存者偏差、除权缺口和涨跌停排队偏差；必须查看样本数和区间，不保证胜率。",12,MUTED,false));
        addCard(screen,files);
        PaperAutoWorker.schedule(this,PaperAutoWorker.enabled(this));
        refreshTabs();runAction("REFRESH");
    }
    private static final class Holding {
        String code,name,boughtDay,quoteDay;int qty;double basis,price;
        Holding(String code,String name,int qty,double basis,double price,String boughtDay,String quoteDay){
            this.code=code;this.name=name;this.qty=qty;this.basis=basis;this.price=price;
            this.boughtDay=boughtDay;this.quoteDay=quoteDay;
        }
    }
    private static final class Dashboard {
        String day,summary,performance,ledger,message,marketSummary,validation,automatic;
        String[] overview=new String[StrategySuite.IDS.length];
        List<Double> curve=Collections.emptyList();
        List<Holding> holdings=new ArrayList<>();
        List<PaperTradingStore.Signal> signals=Collections.emptyList();
        List<PaperTradingStore.OrderView> orders=Collections.emptyList();
    }
    private void updateAutoSwitch(){
        if(autoSwitch!=null)autoSwitch.setText(PaperAutoWorker.enabled(this)?"后台模拟自动交易：已开启（12小时尝试）":"后台模拟自动交易：关闭 · 点击开启");
    }
    private String selectedId(){return StrategySuite.IDS[selectedStrategy];}
    private void runAction(String action){
        if(!busy.compareAndSet(false,true)){message.setText("后台操作中，请完成后再试");return;}
        message.setText("正在处理 "+action+" · 使用本地历史日K与隔离模拟账本");
        final String sid=selectedId();
        new Thread(()->{
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore paper=new PaperTradingStore(getApplicationContext())){
                String day=PaperTradingStore.asOf(market),note="";
                long[] ids=paper.accounts();
                if(day.isEmpty())note="行情数据库无有效完成日K，不能选股或成交";
                else if("SCAN".equals(action)||"AUTO".equals(action)){
                    for(long id:ids)paper.settle(market,id,day);
                    note=paper.scanAll(market,day,(now,total)->{
                        if(now%400==0||now==total)ui.post(()->message.setText("大盘+股票策略进度 " +now+"/"+total));
                    });
                    PaperAutoWorker.prefs(this).edit().putString("market_summary",note)
                        .putString("scan_day",day).apply();
                    if("AUTO".equals(action))for(int i=0;i<ids.length;i++)
                        note+="\n"+StrategySuite.title(StrategySuite.IDS[i])+"："+paper.placeSuggestedOrders(market,ids[i],day);
                }else if("ORDER".equals(action)){
                    StringBuilder notes=new StringBuilder();
                    for(int i=0;i<ids.length;i++)notes.append(StrategySuite.title(StrategySuite.IDS[i]))
                        .append("：").append(paper.placeSuggestedOrders(market,ids[i],day)).append("\n");
                    note=notes.toString();
                }else if("SETTLE".equals(action)){
                    StringBuilder notes=new StringBuilder();for(int i=0;i<ids.length;i++)
                        notes.append(StrategySuite.title(StrategySuite.IDS[i])).append("：")
                            .append(paper.settle(market,ids[i],day)).append("\n");
                    note=notes.toString();
                }else if("VALIDATE".equals(action)){
                    note=runValidation(market,day);
                }
                Dashboard next=readDashboard(market,paper,paper.account(sid),day);
                next.message=note.isEmpty()?"五个策略模拟账户已载入；未发送任何真实交易委托":note;
                ui.post(()->show(next));
            }catch(Exception ex){
                android.util.Log.e("QDFiveLab","模拟仓异常",ex);
                ui.post(()->message.setText("模拟仓操作失败："+ex.getClass().getSimpleName()+"  "+ex.getMessage()));
            }finally{busy.set(false);}
        },"qd-five-"+action).start();
    }
    private String runValidation(MarketDb market,String asOf){
        List<PaperTradingStore.Security> all=PaperTradingStore.universe(market);
        // Stable, deterministic sample independent of returns or strategy selections.
        all.sort((x,y)->Integer.compare(x.code.hashCode()^0x5b71,y.code.hashCode()^0x5b71));
        List<StrategyValidator.Sample> sample=new ArrayList<>();
        int limit=Math.min(StrategyValidator.MAX_SYMBOLS,all.size());
        for(int i=0;i<limit;i++){
            String code=all.get(i).code;
            List<SwingStrategy.Candle> bars=PaperTradingStore.historyForValidation(market,code,asOf);
            sample.add(new StrategyValidator.Sample(code,bars));
            if(i%60==0){int progress=i;ui.post(()->message.setText("回放样本数据载入 "+progress+"/"+limit));}
        }
        List<StrategyValidator.Report> reports=StrategyValidator.run(sample);
        StringBuilder result=new StringBuilder("固定参数逐日历史回放（当前股票池抽样；不是独立样本验证）");
        for(StrategyValidator.Report report:reports)result.append("\n\n").append(report.explain());
        result.append("\n\n局限：当前股票池的幸存者偏差、未复权行情、部分涨跌停无法成交、缺少真实指数和退市股票、未进行参数调优/独立样本验证；未用未来数据产生信号。");
        String value=result.toString();
        PaperAutoWorker.prefs(this).edit().putString("validation",value).putString("validation_day",asOf).apply();
        return "历史回放已执行：见【战绩】页。";
    }
    private Dashboard readDashboard(MarketDb market,PaperTradingStore paper,long account,String day){
        Dashboard d=new Dashboard();d.day=day;
        d.marketSummary=PaperAutoWorker.prefs(this).getString("market_summary","市场广度尚未计算，点击分析全市场");
        d.validation=PaperAutoWorker.prefs(this).getString("validation","尚未执行固定参数历史回放，暂不能报告历史回放胜率。");
        d.automatic=PaperAutoWorker.prefs(this).getString("last_auto_run","尚未运行后台自动交易；请先更新日K或手动点击扫描。");
        for(int i=0;i<StrategySuite.IDS.length;i++){
            long id=paper.account(StrategySuite.IDS[i]);
            d.overview[i]=paper.summary(market,id,day).split("\n持仓 ")[0];
        }
        d.curve=paper.equityCurve(account);
        d.summary=paper.summary(market,account,day);
        d.performance=paper.performance(account);d.ledger=paper.recentLedger(account);
        d.signals=paper.signals(account,day);d.orders=paper.orders(account,100);
        for(Map.Entry<String,PaperTradingStore.Position> e:paper.positions(account).entrySet()){
            PaperTradingStore.Position p=e.getValue();
            List<SwingStrategy.Candle> bars=PaperTradingStore.history(market,p.code,day);
            SwingStrategy.Candle last=bars.isEmpty()?null:bars.get(bars.size()-1);
            d.holdings.add(new Holding(p.code,PaperTradingStore.securityName(market,p.code),p.qty,p.basis,
                last==null?p.basis:last.close,p.boughtDay,last==null?"无":last.day));
        }
        Collections.sort(d.holdings,(a,b)->a.code.compareTo(b.code));
        return d;
    }
    private void show(Dashboard d){
        current=d;latestDay=d.day;
        accountInfo.setText(StrategySuite.title(selectedId())+"\n"+d.summary.split("\n持仓 ")[0]);
        String firstLine=d.marketSummary.split("\n",2)[0];
        marketInfo.setText(firstLine);
        String selectedLine="尚无该策略最新诊断，点击【分析全市场】。";
        for(String line:d.marketSummary.split("\n"))
            if(line.startsWith(StrategySuite.title(selectedId())+"：")){selectedLine=line;break;}
        diagnosticInfo.setText("策略规则："+StrategySuite.formula(selectedId())+"\n"+selectedLine+
            "\n观察池 ≠ 买点；每日会给出仓位计划和等待原因，交易信号必须达到触发条件。弱市轻仓≠保证每天成交。");
        automaticInfo.setText("自动任务："+(PaperAutoWorker.enabled(this)?"已开启（每12小时尝试）":"已关闭")+
            "\n"+(d.automatic.length()>200?d.automatic.substring(0,200)+"…":d.automatic));
        equityChart.setValues(d.curve);
        refreshStrategyRow(d);
        overviewInfo.setText("每个实验仓初始本金10万元；5个账户独立核算，不互相调拨或合并成绩。\n"+
            (PaperAutoWorker.enabled(this)?"自动模拟：开 · 手机后台允许时定期执行":"自动模拟：关 · 需要手动扫描或运行"));
        message.setText(d.message==null?"模拟账户已更新":d.message);
        refreshTabs();renderRows();
    }
    private void refreshStrategyRow(Dashboard d){
        strategyRow.removeAllViews();
        for(int i=0;i<StrategySuite.IDS.length;i++){
            final int selected=i;String id=StrategySuite.IDS[i];
            TextView t=text(StrategySuite.title(id)+(i==selectedStrategy?"    ● 当前仓":""),14,
                i==selectedStrategy?BLUE:NAVY,true);
            t.setPadding(dp(10),dp(11),dp(10),dp(11));t.setBackground(surface(i==selectedStrategy?Color.rgb(233,239,255):BG,9));
            final String details=d.overview[i];
            t.setOnClickListener(v->{if(busy.get()){Toast.makeText(this,"当前交易/扫描处理中，完成后再切换账户",Toast.LENGTH_SHORT).show();return;}selectedStrategy=selected;runAction("REFRESH");});
            strategyRow.addView(t,margins(-1,-2,4));
            // One-line return/size preview, tied to this specific paper account.
            String[] fields=details.split("\n");
            if(fields.length>1){TextView stats=text(fields[1],11,MUTED,false);stats.setPadding(dp(10),0,0,dp(5));
                strategyRow.addView(stats,margins(-1,-2,3));}
        }
    }
    private void refreshTabs(){
        if(tabRow==null)return;tabRow.removeAllViews();
        for(String name:new String[]{"持仓","信号","诊断","委托","战绩","流水"}){
            TextView t=text(name,13,name.equals(activeTab)?BLUE:MUTED,name.equals(activeTab));
            t.setGravity(Gravity.CENTER);t.setPadding(dp(3),dp(10),dp(3),dp(10));
            t.setBackground(surface(name.equals(activeTab)?Color.rgb(233,239,255):BG,10));
            t.setOnClickListener(v->{activeTab=name;refreshTabs();renderRows();});
            LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(0,dp(42),1);layout.rightMargin=dp(3);
            tabRow.addView(t,layout);
        }
    }
    private boolean match(String code){return filter.isEmpty()||code.contains(filter);}
    private void detail(String header,String sub,int color,View.OnClickListener action,String label){
        LinearLayout box=column();box.setPadding(dp(11),dp(12),dp(11),dp(12));
        box.setBackground(surface(BG,12));
        box.addView(text(header,15,color,true));gap(box,4);
        TextView explanation=text(sub,12,MUTED,false);explanation.setLineSpacing(dp(3),1);box.addView(explanation);
        if(action!=null){gap(box,8);box.addView(button(label,BLUE,action),margins(-1,dp(40),0));}
        listPane.addView(box,margins(-1,-2,8));
    }
    private void renderRows(){
        if(listPane==null)return;
        listPane.removeAllViews();if(current==null){listPane.addView(text("本地模拟账户读取中…",13,MUTED,false));return;}
        int count=0;
        if("持仓".equals(activeTab)){
            sectionName.setText(StrategySuite.title(selectedId())+" · 持仓 "+current.holdings.size()+"只");
            for(Holding p:current.holdings){if(!match(p.code))continue;count++;
                double pnl=(p.price/p.basis-1)*100;
                detail(p.code+"  "+p.name+"    " +String.format(Locale.CHINA,"%+.2f%%",pnl),
                    "持仓 "+p.qty+" 股 | 成本 ¥"+fmt(p.basis)+" | 最新 ¥"+fmt(p.price)+
                        "\n买入 "+p.boughtDay+" | 行情 "+p.quoteDay,pnl>=0?RED:GREEN,
                    v->manualDialog("SELL",p.code,p.qty),"卖出该持仓");
            }
        }else if("信号".equals(activeTab)){
            sectionName.setText(StrategySuite.title(selectedId())+" · 候选信号 "+current.day);
            for(PaperTradingStore.Signal s:current.signals){if(!match(s.code))continue;count++;
                int color="BUY".equals(s.action)?RED:"SELL".equals(s.action)?GREEN:NAVY;
                detail(("BUY".equals(s.action)?"允许候选买入":"SELL".equals(s.action)?"候选卖出":"HOLD".equals(s.action)?"持仓观察":"WATCH".equals(s.action)?"观察池（不可自动买入）":"BLOCKED".equals(s.action)?"仅供研究·市场风控禁止买入":"数据警告")+
                    "  "+s.code+"  ¥"+fmt(s.price),
                    "分数 "+fmt(s.score)+" | "+s.reason,color,
                    "BUY".equals(s.action)?v->manualDialog("BUY",s.code,100):null,"按此股票手动下单");
            }
        }else if("诊断".equals(activeTab)){
            sectionName.setText("策略诊断 · 技术触发与风控过滤原因");
            String part="尚未完成当日市场扫描";
            for(String line:current.marketSummary.split("\n"))
                if(line.startsWith(StrategySuite.title(selectedId())+"：")){part=line;break;}
            detail("当前大盘状态",current.marketSummary.split("\n",2)[0],NAVY,null,"");
            detail("当前策略筛选计数",part,NAVY,null,"");
            detail("本策略选股逻辑",StrategySuite.formula(selectedId()),NAVY,null,"");
            detail("为何仍然空仓？","系统每天计算强/弱/震荡并分别给五个账户设置仓位预算；技术形态不达标时进入观察池，绝不把观察当成交。可买信号也可能因仓位、现金、100股手数或下一日无法成交而继续空仓；诊断计数仅反映最近一次扫描。",MUTED,null,"");
            count=4;
        }else if("委托".equals(activeTab)){
            sectionName.setText("模拟委托 · 最近100笔");
            for(PaperTradingStore.OrderView o:current.orders){if(!match(o.code))continue;count++;
                String status="PENDING".equals(o.status)?"待成交":"FILLED".equals(o.status)?"已成交":"已撤销";
                detail("#"+o.id+"  "+o.code+"   "+("BUY".equals(o.side)?"买入":"卖出")+"  "+status,
                    "委托日 "+o.day+" · "+o.qty+"股\n"+("FILLED".equals(o.status)?"成交 "+o.fillDay+" @ ¥"+fmt(o.fillPrice):o.reason),
                    "BUY".equals(o.side)?RED:GREEN,
                    "PENDING".equals(o.status)?v->confirmCancel(o.id):null,"撤销未成交委托");
            }
        }else if("战绩".equals(activeTab)){
            sectionName.setText("收益风险分析");
            detail("策略交易记录统计（非历史回放）",current.performance,NAVY,null,"");
            detail("时间顺序历史回放 · 5种策略",current.validation,NAVY,null,"");count++;
        }else{
            sectionName.setText("最近交易流水");detail("模拟成交与委托",current.ledger,NAVY,null,"");count++;
        }
        if(count==0)detail("暂无记录","先点击【分析全市场】查看BUY与观察池；【诊断】页会解释风险预算及等待原因。空仓允许但每天应有明确决策；不能强制交易或编造胜率。",MUTED,null,"");
    }
    private static String fmt(double n){return String.format(Locale.CHINA,"%.2f",n);}
    private void manualDialog(String side,String presetCode,int defaultQty){
        if(latestDay.isEmpty()){Toast.makeText(this,"请先载入有效行情",Toast.LENGTH_SHORT).show();return;}
        LinearLayout form=column();form.setPadding(dp(22),dp(10),dp(22),dp(3));
        form.addView(text("股票代码（A股6位）",13,NAVY,true));
        EditText code=new EditText(this);code.setSingleLine(true);code.setInputType(2);
        code.setHint("600519");code.setText(presetCode);form.addView(code);
        form.addView(text("股数（100股整数倍）",13,NAVY,true));
        EditText qty=new EditText(this);qty.setSingleLine(true);qty.setInputType(2);
        qty.setText(""+defaultQty);form.addView(qty);
        form.addView(text("最新信号日："+latestDay+"。这是次交易日开盘的模拟委托，不会发送真实订单。",12,MUTED,false));
        new AlertDialog.Builder(this).setTitle("BUY".equals(side)?"模拟买入":"模拟卖出").setView(form)
            .setNegativeButton("取消",null).setPositiveButton("确认委托",(dlg,which)->{
                int shares;
                try{shares=Integer.parseInt(qty.getText().toString().trim());}catch(Exception ex){message.setText("请输入有效股数");return;}
                manualOrder(side,code.getText().toString().trim(),shares);
            }).show();
    }
    private void manualOrder(String side,String code,int qty){
        if(!busy.compareAndSet(false,true)){message.setText("后台任务运行中，请完成后操作");return;}
        message.setText("正在校验模拟委托与持仓…");
        final String sid=selectedId();
        new Thread(()->{
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore p=new PaperTradingStore(getApplicationContext())){
                long a=p.account(sid);String day=PaperTradingStore.asOf(market);
                String result=p.manualOrder(market,a,day,code,side,qty);
                Dashboard d=readDashboard(market,p,a,day);d.message=result;
                ui.post(()->{activeTab="委托";show(d);});
            }catch(Exception ex){ui.post(()->message.setText("下单失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-manual-order").start();
    }
    private void confirmCancel(long id){
        new AlertDialog.Builder(this).setTitle("撤销委托 #"+id)
            .setMessage("只能撤销还未模拟成交的委托；已成交无法撤销。")
            .setNegativeButton("返回",null).setPositiveButton("确认撤销",(dlg,which)->cancel(id)).show();
    }
    private void cancel(long id){
        if(!busy.compareAndSet(false,true)){message.setText("后台任务运行中，暂不能撤单");return;}
        final String sid=selectedId();
        new Thread(()->{
            try(MarketDb m=new MarketDb(getApplicationContext());PaperTradingStore p=new PaperTradingStore(getApplicationContext())){
                long a=p.account(sid);String msg=p.cancelPending(a,id);String day=PaperTradingStore.asOf(m);
                Dashboard d=readDashboard(m,p,a,day);d.message=msg;ui.post(()->show(d));
            }catch(Exception ex){ui.post(()->message.setText("撤单失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-cancel").start();
    }
    private void exportFile(int kind){
        if(busy.get()){message.setText("模拟任务运行中，请完成后导出");return;}
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(kind==EXPORT?"text/csv":"application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE,kind==EXPORT?"QD-FiveLab-当前策略模拟交易.csv":"QD-FiveLab-五策略模拟账本.sqlite3");
        try{startActivityForResult(intent,kind);}catch(Exception ex){message.setText("无法打开文件保存窗口："+ex.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if((request!=EXPORT&&request!=EXPORT_DB)||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri target=data.getData();
        if(!busy.compareAndSet(false,true)){message.setText("模拟任务仍在运行，暂不能导出");return;}
        message.setText("正在导出模拟账户…");
        final String sid=selectedId();
        new Thread(()->{
            try(PaperTradingStore p=new PaperTradingStore(getApplicationContext());
                OutputStream stream=getContentResolver().openOutputStream(target,"w")){
                if(stream==null)throw new IllegalStateException("保存地址不可写");
                if(request==EXPORT){
                    OutputStreamWriter writer=new OutputStreamWriter(stream,StandardCharsets.UTF_8);
                    p.exportLedger(p.account(sid),writer);writer.flush();
                }else{
                    p.accounts();p.checkpoint();
                    File source=getDatabasePath(PaperTradingStore.NAME);
                    try(FileInputStream input=new FileInputStream(source)){
                        byte[] buffer=new byte[65536];int n;
                        while((n=input.read(buffer))!=-1)stream.write(buffer,0,n);
                    }stream.flush();
                }
                ui.post(()->{message.setText("模拟账户导出完成");Toast.makeText(this,"文件已保存",Toast.LENGTH_LONG).show();});
            }catch(Exception ex){ui.post(()->message.setText("导出失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-lab-export").start();
    }
}
