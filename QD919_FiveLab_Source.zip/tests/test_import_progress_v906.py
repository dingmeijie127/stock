from pathlib import Path
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'

def test_visible_import_progress_is_not_ohlcv_progress():
    src=(J/'MainActivity.java').read_text()
    assert 'private ProgressBar progress, importProgressBar' in src
    assert 'importProgressBar.setMax(100)' in src
    assert '阶段 3/3：合并' in src
    assert '已检查 ' in src and '重复自动跳过' in src
    assert 'ImportProgressMeter.copyPercent' in src
    assert 'ImportProgressMeter.mergePercent' in src
    assert 'importProgressBar.setProgress(100)' in src

def test_progress_callbacks_happen_after_committed_batches():
    code=(J/'MarketDb.java').read_text()
    assert 'long overallTotal=0,overallInspected=0,overallMerged=0' in code
    assert 'SELECT count(*) FROM ' in code
    assert 'batch=0;callback.onProgress' in code
    assert code.index('target.setTransactionSuccessful();target.endTransaction();') < code.index('batch=0;callback.onProgress')
    assert 'DROP TABLE' not in code

def test_version_and_workflow_match():
    workflow=(R/'.github/workflows/QD919_FiveLab_Build.yml').read_text()
    assert "z=Path('QD919_FiveLab_Source.zip')" in workflow
    assert 'versionCode 919' in workflow
    assert 'ImportProgressMeterTest.java' in workflow
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in (R/'android-app/app/build.gradle').read_text()
