"""Five independent accounts, honest market regime/backtest, opt-in simulation, isolated signing."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'
W=(R/'.github/workflows/QD919_FiveLab_Build.yml').read_text()

def test_market_database_untouched_and_read_only_market_apis():
    paper=(J/'PaperTradingStore.java').read_text()
    assert 'CREATE TABLE equity_snapshots' in paper and 'CREATE TABLE accounts' in paper
    assert 'getReadableDatabase().rawQuery' in paper
    assert 'MarketDb.NAME' not in paper
    assert 'DROP TABLE' not in paper
    assert 'historyForValidation' in paper
    assert 'equityCurve(' in paper

def test_five_independent_accounts_and_distinct_strategy_logic():
    s=(J/'StrategySuite.java').read_text()
    p=(J/'PaperTradingStore.java').read_text()
    for id in ('CHAN_FRACTAL_FLAG_V1','DONCHIAN_ATR_V1','BOLLINGER_REVERSAL_V1','MOMENTUM_LOWVOL_V1','SwingStrategy.VERSION'):
        assert id in s
    assert 'account(String strategy)' in p
    assert 'public long[] accounts()' in p
    assert 'scanAll(' in p and 'marketRegime(' in p
    for f in ('highest(', 'lowest(', 'bottomFractal(', 'rsi14('):
        assert f in s

def test_market_regime_missing_data_refuses_entries():
    x=(J/'MarketRegime.java').read_text()
    s=(J/'StrategySuite.java').read_text()
    assert 'observed<200' in x and 'coverage<0.55' in x
    assert 'above20' in x and 'above60' in x and 'advancing' in x
    assert 'BEAR.equals(mode)' in x and 'RiskPolicy.forMode' in x
    assert 'regime.allowed(id)' in s

def test_historical_replay_no_same_bar_fills():
    v=(J/'StrategyValidator.java').read_text()
    assert 'PaperTradeRules.fillPrice' in v
    assert 'replay(' in v and 'tally.observe(' in v
    assert '95%% Wilson' in v
    assert 'MAX_SYMBOLS=450' in v
    assert 'currentEquity(' in v

def test_interactive_five_strategy_page_and_opt_in_auto_worker():
    a=(J/'PaperTradeActivity.java').read_text()
    worker=(J/'PaperAutoWorker.java').read_text()
    for name in ('五个独立策略账户','市场广度','runValidation','模拟委托','selectedStrategy','refreshStrategyRow'):
        assert name in a or name in worker
    assert 'getBoolean("auto_paper",false)' in worker
    assert 'PeriodicWorkRequest' in worker and '12,TimeUnit.HOURS' in worker
    assert 'paper.scanAll' in worker and 'paper.placeSuggestedOrders' in worker
    assert 'PaperTradingStore.asOf(market)' in worker
    assert 'Broker' not in worker

def test_unique_apk_identity_and_signing_from_old_lab():
    g=(R/'android-app/app/build.gradle').read_text()
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in g
    assert "versionCode 919" in g
    for secret in ('KEYSTORE_B64','SIGNING_ALIAS','SIGNING_STORE_PASSWORD','SIGNING_KEY_PASSWORD'):
        assert f'secrets.QD_FIVELAB01_{secret}' in W
    assert 'QD_RSI2LAB01_' not in W
    assert 'QD919_FiveLab_Source.zip' in W
    assert 'StrategySuiteTest.java' in W and 'StrategyValidatorTest.java' in W
    assert 'EquityCurveView.java' in W


def test_v918_raw_signals_distinct_from_market_gate_and_no_paper_db_migration():
    engine=(J/'StrategySuite.java').read_text()
    store=(J/'PaperTradingStore.java').read_text()
    screen=(J/'PaperTradeActivity.java').read_text()
    assert 'public static Assessment assess(' in engine
    assert '"BLOCKED"' in engine and 'researchMode=' in engine
    assert '"READY".equals(decision.category)' in store
    assert '"BLOCKED".equals(decision.category)' in store
    assert "action='BUY'" in store # Only executable BUY enters order query
    assert '技术触发但市场拦截' in store
    assert '数据不足/质量' in store
    assert '诊断' in screen and '自动任务' in screen
    assert 'super(context,NAME,null,1)' in store # Same ledger schema, account continuity
    assert "versionCode 919" in (R/'android-app/app/build.gradle').read_text()


def test_v919_actionable_regime_budgets_watchlists_and_no_db_change():
    risk=(J/'RiskPolicy.java').read_text()
    engine=(J/'StrategySuite.java').read_text()
    store=(J/'PaperTradingStore.java').read_text()
    ui=(J/'PaperTradeActivity.java').read_text()
    assert 'newCapital(' in risk and 'maxPositions' in risk
    assert 'BEAR.equals(mode)' in risk and 'RANGE.equals(mode)' in risk and 'BULL.equals(mode)' in risk
    assert 'public static SwingStrategy.Advice watch(' in engine
    assert 'RISK_PLAN_CODE' in store and 'planFromSignals' in store
    assert 'paperInvested' in store and 'trimToRisk' in store
    assert "action='BUY'" in store and '"WATCH"' in store
    assert '观察池' in ui
    assert 'super(context,NAME,null,1)' in store
