# QuantDesk V8.5 — A 股 / 港股多数据源采集版（源码）

> **重要**：这是基于用户提供的 `QuantDesk-V8.4-DataFirst-APK.zip` 内 **APK 的可恢复 HTML/JS 资源**升级，并重新编写了 Android Java 容器及 Python 数据服务。原 ZIP 没有 Android Studio 原始 Java/Gradle 项目，也没有原 APK 签名密钥。新 Java 容器与原生后台队列不是原始实现，不能宣称与 V8.4 二进制完全等效。

## GitHub 编译：本次已修正 `pip install -e ./collector` 的目录错误

这次提供 **两个独立下载文件**：`QuantDesk85_CollectorFix_Source.zip` 与 `android-build.yml`。

最适合手机操作的方法（**无需手动解压源码**）：

1. 将 **源码 ZIP 原样上传到 GitHub 仓库根目录**，文件名保持 `QuantDesk85_CollectorFix_Source.zip`。如仓库已有旧版源码文件，可先保留；新工作流会优先使用这份最新 ZIP。
2. 将编译 YAML 作为 `.github/workflows/android-build.yml` 提交并覆盖旧配置。**注意：YAML 不能只放在仓库根目录**，GitHub Actions 必须从 `.github/workflows/` 加载它。
3. 前往 GitHub → Actions → `QuantDesk V8.5 - Build Android APK` → Run workflow。流程会自动解开 ZIP、定位 `collector/pyproject.toml`、运行 Python/JS 测试、尝试构建 Android Debug APK。
4. 构建成功后下载 Artifact：`QuantDesk-V8.5-APK`。

另一种方式：本 ZIP **自身已内置相同的 `.github/workflows/android-build.yml`**。可以在电脑解压整个 ZIP 后上传所有项目文件（注意 GitHub 根目录能看到 `collector/`、`android-app/`、`tests/`），这样独立 YAML 无需额外提交。

如果之前只上传过根目录一个旧 ZIP 和一个没有放到 `.github/workflows` 的 YAML，新的工作流并不会被 GitHub 自动发现；务必检查仓库 Code 标签下存在 `.github/workflows/android-build.yml`。

注意：Android SDK 仍使用 `setup-android@v4` + `platform-tools` 避开已废弃的 `tools` 包。这份版本修复的是 **上传目录/ZIP 解包及 pip 安装路径**；自动构建和在线市场数据仍须在 GitHub/联网环境验证，不代表 APK 已成功编译或财报已全量抓取。

## 1. 能做什么，什么尚不能保证

- A 股沪/深/京，港股五位代码：股票目录、公开报价、**日 K 线（原始未复权默认）**、额外日/周/月及1/5/15/30/60分钟 K线查询缓存、三大财报原始字段；本机保留已获取的数据及逐股票失败记录。
- 来源优先顺序见 `config/data_sources.yml`；可配置 `AKShare / 东方财富 / Tushare（个人令牌和相应权限）/ Yahoo Finance`。旧前端还保留腾讯、新浪报价后备。各数据商的稳定性、许可与覆盖范围不同，不会预装真实股票数据或编造缺失结果。
- A/HK 财务报表：收入/利润、资产负债、现金流三表为目标，但港股会有年报/半年报、财年不同、**Tushare 港股财报需独立授权**。表字段以 `rawFields` 原样保存，不能想当然认为不同会计制度、币种、单位可直接比较。
- 数据检查：OHLC、代码、日期、复权标志，逐只覆盖、≥220/≥500 根、本地目录分母、同一报告期三表；缺口导出、SQLite 断点续传、网络重试与原始来源标注。部分抓取成功 **不等于全市场或历史所有年份完整**。
- 当前后台批量全市场历史回填任务以**日 K**为主；新增 `/v1/series/{market}/{code}?interval=week|month|1m|5m|15m|30m|60m` 按需采集其他周期并在服务端SQLite缓存。**1分钟数据一般仅可获取近5个交易日，其他分钟数据也有上游历史窗口限制，不能宣称历史全部补齐。**目前没有完成 Tick、分时档位、全市场退市股、港交所披露易附件全文、所有衍生数据。要采集交易所级完整数据，应购买对应授权并对照官方证券目录/交易日历核验。

## 2. 目录

| 路径 | 说明 |
|---|---|
| `web/` | 从 APK 提取的旧 HTML/JS + V8.5 桥接、采集面板、财报覆盖率审计 |
| `android-app/` | 重新开发的 Android Studio Java WebView 容器与 native Tushare POST/代理源码 |
| `collector/quantdesk_v85/` | Python 可选 AKShare/Tushare/Yahoo/东财采集、数据验收、SQLite、REST API |
| `config/data_sources.yml` | 数据源优先级、网络节流/重试、日 K 起止日期与币种注意事项 |
| `.github/workflows/android-build.yml` | GitHub Actions Android Debug APK 构建任务 |
| `tests/` | Python/Node 离线契约测试 |
| `tests/` | 不依赖证券商联网的自动化回归测试与模拟响应 |

## 3. 在电脑部署采集服务

在项目根目录执行（推荐 Python 3.11，系统安装 Node 22 用于 JS 测试）：

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e ./collector
python -m pip install -r requirements-providers.txt
python -m pip install pytest httpx
pytest -q tests
node --test tests/*.test.cjs
```

Tushare 需要自己的 Token（**不写入 YAML/源码/APK**）和对应积分、额外港股数据权限：

```bash
export TUSHARE_TOKEN='仅在自己电脑设置令牌'
# Windows PowerShell: $env:TUSHARE_TOKEN='你的令牌'
```

测试小规模可运行：

```bash
python -m quantdesk_v85.cli backfill --markets A HK --limit-symbols 10
python -m quantdesk_v85.cli coverage
python -m quantdesk_v85.cli live-check  # 实际联网验证A/HK示例日K+三表；失败返回退出码2
python -m quantdesk_v85.cli serve
# 查看 http://127.0.0.1:8765/v1/health 和 /v1/coverage
```

全部抓取（可能是几千只证券、数十万次请求，取决于可用接口）：

```bash
python -m quantdesk_v85.cli backfill --markets A HK
```

默认保存 `./quantdesk-v85.sqlite3`；支持 `--db /你的目录/data.sqlite3` 指定路径。**空响应、权限不足或 429 等都不能算成功**，命令输出 `gaps` 和 `failed`，下次重新执行会跳过已有完成任务，继续 `partial/failed`。

**注意**：网络强烈限流时请把 YAML 里的 `minimum_interval_seconds` 调大；大批量请求需要遵守上游条款、不得抓取无权访问的数据。没有对应 Tushare 权限也可以运行公开源，但无法保证港股财报齐全。

## 4. 手机连接方法

服务默认只绑定电脑 **127.0.0.1:8765**，这是安全默认值。手机想连接电脑上的服务，必须由你自己部署带 TLS 证书、用户访问控制、请求限流的 **HTTPS 反向代理**，再在新版页面的 `V8.5 · A股 / 港股多源数据采集` 中输入该地址。请勿将未经认证的财务数据采集 API 直接公开到互联网；**不要在页面 URL 中附加 Tushare Token**。

手机版新增配置/体检/从后台库按每市场 10 只试导入或填写 0 导入所有。K 线/三表分别入原 IndexedDB，并保存失败原因；若不填写采集服务地址，旧 V8.4 前台东财、腾讯等接口仍可使用，但不能补齐港股全部财报。旧版 `QuantDeskBackground` 原生后台队列并未从 APK 中恢复，旧「建立 / 更新数据库」大按钮可能提示没有原生后台，**请改用新增 V8.5 采集面板**。

## 5. Android APK 构建

**当前交付包含 Android Studio 构建源码和 GitHub Actions YAML，但本交付环境未安装 Android SDK/Gradle，故没有声称 APK 在本机编译通过。**

1. 将本工程上传至自己的 GitHub 私有仓库（不要上传 Token）。
2. 运行 Actions → **QuantDesk V8.5 - Build Android APK** → Run workflow。
3. 工作流通过 Python/JS 测试后使用 Android SDK 35、Gradle 8.9 构建 Debug APK。下载 `QuantDesk-V8.5-APK` Actions Artifact，解压后获得 `QuantDesk-V8.5-debug.apk`。
4. 正式发布需自己配置 Android 签名与签名密钥。由于原 ZIP 没有旧 APK 签名密钥且新包 ID 为 `com.quantdesk.v85`，**不是可覆盖安装且保留旧应用数据的升级包**；旧应用账本/数据需要先备份并在新版按支持的格式恢复，勿先卸载旧版。

## 6. 自测范围

运行 `pytest -q tests` 和 `node --test tests/*.test.cjs`。测试包含：

- A/HK 代码及交换所后缀，日线 OHLC 字段、排序、重复日期、负成交量，禁止复权混用。
- 同一公司港股三表指标按期合并及原始字段；多数据源部分返回与全部失败报告。
- SQLite 原子写入、跨源复权切换、防止假「全部覆盖」、失败检查点续抓。
- REST 接口输入验证、获取、覆盖统计的模拟集成测试；V8.4 K 线验证器回归；恶意/带口令的服务 URL 拒绝。

**测试不会发出真实市场请求**。实际公网/供应商联通性、个人付费接口权限、A/HK 每一只股票全历史财报的完整性，必须在你可联网的运行环境中现场核实。原始 APK 自身也从未附带全市场 K 线和财务数据库。

## 7. 有依据的数据源文档

- [AKShare API 文档](https://akshare.akfamily.xyz/) — A/HK 股票日 K、行情、部分 A 股财报（公开接口结构可能调整）。
- [Tushare 权限说明](https://tushare.pro/document/1?doc_id=108) — 不同接口分级，额外港股历史日线、港股财报需相应授权。
- [Tushare 港股复权日线](https://tushare.pro/document/2?doc_id=339)；[港股资产负债表](https://tushare.pro/document/2?doc_id=390)。
- Yahoo Finance `yfinance` — 适合独立对比、少量公开历史，不等同保证港交所完整报表。

**最终判断是否“全”看 `coverage` 统计和缺口列表，不看声明或配置了多少个数据源。**
