package com.quantdesk.download;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicBoolean;

/** Foreground harvest: persistent job status and per-stock atomic SQLite transactions. */
public final class HarvestService extends Service {
    public static final String START="com.quantdesk.download.START",START_FINANCE="com.quantdesk.download.START_FINANCE",START_FAST="com.quantdesk.download.START_FAST",PAUSE="com.quantdesk.download.PAUSE";
    public static final AtomicBoolean RUNNING=new AtomicBoolean(false);
    public static volatile String LIVE="尚未开始";
    private final AtomicBoolean paused=new AtomicBoolean(false);
    private PowerManager.WakeLock wake;
    private String from="",to="";
    private long lastNotify;
    private long lastWakeRenew;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent==null)return START_NOT_STICKY;
        if(PAUSE.equals(intent.getAction())){
            if(RUNNING.get()){
                paused.set(true);LIVE="正在暂停（当前请求完成后停止）";notifyProgress(0,0);
            }
            return START_NOT_STICKY;
        }
        boolean isFinance=START_FINANCE.equals(intent.getAction());
        boolean isFast=START_FAST.equals(intent.getAction());
        if(!START.equals(intent.getAction())&&!isFinance&&!isFast)return START_NOT_STICKY;
        if(MarketDb.IMPORT_IN_PROGRESS.get()){LIVE="正在合并SQLite备份，采集任务请稍后开始";return START_NOT_STICKY;}
        if(!RUNNING.compareAndSet(false,true))return START_NOT_STICKY;
        paused.set(false);LIVE=isFinance?"准备采集免费公开财报（A股三表；港股指标/分红）":
            isFast?"快速增量已接收：先查询SQLite最新K线日期":"全量补齐已接收：核对SQLite历史缺口";
        notifyProgress(0,0); // startForeground is called immediately, before network and database work
        try{
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"qd90:daily-download");wake.setReferenceCounted(false);wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();}
        }catch(Exception e){Log.w("QD88","Wake lock unavailable",e);}
        new Thread(isFinance?this::harvestFinance:isFast?this::harvestFast:this::harvest,
            isFinance?"qd-finance":isFast?"qd-manual-fast":"qd-full-history").start();
        return START_NOT_STICKY;
    }
    private void notifyProgress(int complete,int total){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(manager==null)return;
        String channel="qd88_history";
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(channel,"A股/港股历史数据下载",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,3,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,channel).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("QuantDesk · 正在采集并写入本地SQLite")
            .setContentText(LIVE.length()>85?LIVE.substring(0,85):LIVE)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi)
            .setProgress(Math.max(1,total),complete,total<=0).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(880,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(880,n);
    }
    private void update(MarketDb db,String stage,String code,String detail,int completed,int total){
        LIVE=detail;db.state(from,to,stage,code,detail);
        long now=System.currentTimeMillis();
        if(now-lastNotify>=2500 || !"running".equals(stage)){
            lastNotify=now;notifyProgress(completed,total);
        }
    }
    private void renewWake(){
        if(wake!=null && System.currentTimeMillis()-lastWakeRenew>8L*60*1000){
            wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();
        }
    }
    private void cleanup(){
        RUNNING.set(false);
        if(wake!=null&&wake.isHeld())wake.release();
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    private void requireNetwork(){
        ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if(cm==null||cm.getActiveNetwork()==null)
            throw new IllegalStateException("没有可用网络：本地SQLite完好，请联网后重试");
    }
    /** Explicit full repair: a legacy 'complete' task is NOT proof of stored coverage.
     *  Only v5 verified_history is trusted to skip history. Missing interior trading
     *  sessions are checked against days actually saved for liquid reference symbols.
     */
    private void harvest(){
        try(MarketDb db=new MarketDb(getApplicationContext())){
            LocalDate today=RangePlanner.safeEndDay(java.time.ZonedDateTime.now(ZoneId.of("Asia/Hong_Kong")));
            LocalDate begin=today.minusYears(2);
            from=begin.toString();to=today.toString();
            db.state(from,to,"running","","正在加载SQLite和股票目录；不删除原数据");
            db.manualState("full","running",0,0,"全量补齐已启动：读取股票目录与本地K线日期");
            db.log("USER","用户点击：全量补齐（历史日K+缺失财报）");
            int total=Universe.install(getApplicationContext(),db);
            requireNetwork();
            java.util.List<MarketDb.Security> securities=db.allSecurities();
            java.util.List<String> aCalendar=db.referenceDays("A",from,to);
            java.util.List<String> hkCalendar=db.referenceDays("HK",from,to);
            int processed=0, verified=db.verifiedCount(from,to),errors=0,newRows=0;
            int failedA=0,failedHK=0;
            java.util.Set<String> blocked=new java.util.HashSet<>();
            db.manualState("full","running",0,total,"已读入 "+total+" 只股票，开始核查历史日期");
            update(db,"running","","已读入 "+total+" 只股票；已核实 "+verified+" 只，开始检查历史缺口",verified,total);
            for(MarketDb.Security stock:securities){
                if(paused.get()){
                    db.manualState("full","paused",processed,total,"用户暂停；已保存 "+newRows+" 根，可继续");
                    update(db,"paused","","用户暂停：已处理 "+processed+"，新增 "+newRows+" 根；数据库已保存，可继续",verified,total);
                    return;
                }
                renewWake();
                String code=stock.code,market="HK".equals(stock.exchange)?"HK":"A";
                if(blocked.contains(market))continue;
                processed++;
                update(db,"running",code,"全量检查 "+processed+"/"+total+" · "+market+":"+code+
                    " · 已核实 "+verified+" · 新增 "+newRows+" · 错误 "+errors,verified,total);
                try{
                    String[] coverage=db.verifiedHistory(code);
                    java.util.List<String> current=db.barDays(code,from,to);
                    java.util.List<String> sessions="HK".equals(market)?hkCalendar:aCalendar;
                    java.util.List<HistoryGapPlanner.Span> missing=HistoryGapPlanner.plan(begin,today,current,
                        sessions,coverage==null?null:coverage[0],coverage==null?null:coverage[1]);
                    if(missing.isEmpty()){
                        if(coverage==null || coverage[0].compareTo(from)>0 || coverage[1].compareTo(to)<0){
                            db.markVerifiedHistory(code,from,to);
                            verified++;
                        }
                        continue;
                    }
                    if(missing.size()>12){
                        db.log("GAP",market+":"+code+" 有 "+missing.size()+" 段疑似缺口；本轮只处理前12段，剩余继续补");
                    }
                    int thisStock=0;
                    boolean partial=false;
                    for(int i=0;i<missing.size() && i<12;i++){
                        if(paused.get()){partial=true;break;}
                        HistoryGapPlanner.Span span=missing.get(i);
                        DailySources.Result result=DailySources.downloadBars(code,stock.exchange,span.from,span.to);
                        if(result.bars.isEmpty())throw new IllegalStateException("行情源未提供缺口 "+span);
                        int added=db.appendDailyBars(code,span.from.toString(),span.to.toString(),result.bars);
                        thisStock+=added;newRows+=added;
                        if(result.skippedBars>0){
                            partial=true;
                            db.log("PARTIAL",code+" "+span+" 返回无效K线 "+result.skippedBars+" 根；保留缺口待核实");
                        }
                    }
                    if(missing.size()>12)partial=true;
                    if(!partial){
                        db.markVerifiedHistory(code,from,to);
                        verified++;
                    }else{
                        db.writeFailure(code,from,to,"尚有未核实的历史缺口或用户暂停");
                    }
                    if(!missing.isEmpty())db.log(partial?"PARTIAL":"OK",market+":"+code+
                        " 检查 "+missing.size()+" 段，新增 "+thisStock+" 根，"+(partial?"未核实完":"已记录核实范围"));
                }catch(Exception ex){
                    errors++;
                    String error=ex.getClass().getSimpleName()+": "+String.valueOf(ex.getMessage());
                    if(error.length()>350)error=error.substring(0,350);
                    db.writeFailure(code,from,to,error);
                    db.log("ERROR",market+":"+code+" 全量补齐失败："+error);
                    if("HK".equals(market))failedHK++;else failedA++;
                    if(("HK".equals(market)?failedHK:failedA)>=12){
                        blocked.add(market);
                        db.log("ERROR",market+" 连续请求失败，暂停该市场本轮全量请求；另一个市场仍继续；下次手动点击可重试");
                    }
                }
                if(processed%5==0){
                    String detail="全量处理 "+processed+"/"+total+" · 核实 "+verified+
                        " · 新增 "+newRows+" 根 · 失败 "+errors;
                    db.manualState("full","running",processed,total,detail);
                    update(db,"running",code,detail,verified,total);
                }
            }
            int pending=total-db.verifiedCount(from,to);
            String summary="全量K线阶段结束：已核实 "+db.verifiedCount(from,to)+"/"+total+
                "，新增 "+newRows+" 根，失败 "+errors+"，待补 "+pending+
                "；旧记录未覆盖";
            db.log("USER",summary);
            db.manualState("full",pending>0?"partial":"complete",processed,total,summary);
            update(db,pending>0?"partial":"complete","",summary,db.verifiedCount(from,to),total);
            if(!paused.get()){
                db.manualState("full","running",processed,total,summary+"；正在检查到期财报…");
                db.log("USER","全量补齐下一阶段：检查并补充本地缺失的财报");
                collectFinance(db,true);
                org.json.JSONObject fin=db.financeOverview();
                String fp=fin.optString("phase","partial");
                db.manualState("full",paused.get()?"paused":
                    pending==0&&"up_to_date".equals(fp)?"complete":"partial",
                    processed,total,summary+"；财报 "+fp+"："+fin.optString("detail",""));
            }
        }catch(InterruptedException e){
            Thread.currentThread().interrupt();
            try(MarketDb db=new MarketDb(this)){
                update(db,"paused","","全量下载被中断，保存的数据仍在SQLite中",db.verifiedCount(from,to),db.countSymbols());
            }
        }catch(Exception e){
            String reason=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
            try(MarketDb db=new MarketDb(this)){
                db.log("ERROR","全量任务中断："+reason);
                db.manualState("full","error",0,0,"全量启动/执行失败："+reason);
                update(db,"error","","全量启动/执行失败："+reason,db.verifiedCount(from,to),db.countSymbols());
            }catch(Exception nested){Log.e("QD-FULL","Failed to persist task error",nested);}
        }finally{cleanup();}
    }
    private void harvestFast(){
        try(MarketDb db=new MarketDb(getApplicationContext())){
            LocalDate today=RangePlanner.safeEndDay(java.time.ZonedDateTime.now(ZoneId.of("Asia/Hong_Kong")));
            from=today.minusYears(2).toString();to=today.toString();
            db.autoState(to,"running","","手动快速增量已接收，正在查询SQLite实际最后K线日期");
            db.manualState("fast","running",0,0,"正在检查SQLite最新K线日期");
            db.log("USER","用户点击：手动快速增量，忽略旧的WorkManager等待队列");
            if(db.countA()==0||db.countHK()==0)Universe.install(getApplicationContext(),db);
            requireNetwork();
            ManualFastSync.run(db,today,()->paused.get(),(message,done,total)->{
                LIVE=message;
                db.manualState("fast","running",done,total,message);
                if(System.currentTimeMillis()-lastNotify>1800){lastNotify=System.currentTimeMillis();notifyProgress(done,total);}
            });
            org.json.JSONObject outcome=db.autoOverview();
            String phase=paused.get()?"paused":outcome.optString("phase","partial");
            org.json.JSONObject progress=db.manualOverview();
            db.manualState("fast",phase,progress.optInt("processed"),progress.optInt("total"),
                outcome.optString("detail","快速增量结束"));
            if(paused.get())db.autoState(to,"paused","","用户暂停；已经插入的日K已保留，可再次点击继续");
        }catch(Exception e){
            String error=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
            LIVE="快速增量失败："+error;
            try(MarketDb db=new MarketDb(this)){
                db.autoState(to,"error","",LIVE);db.manualState("fast","error",0,0,LIVE);db.log("ERROR",LIVE);
            }catch(Exception nested){Log.e("QD-FAST","Failed to persist fast sync error",nested);}
        }finally{cleanup();}
    }
    private static final class FinanceJob {
        final MarketDb.Security stock;
        final String dataset;
        final LocalDate start;
        FinanceJob(MarketDb.Security stock,String dataset,LocalDate start){
            this.stock=stock;this.dataset=dataset;this.start=start;
        }
    }
    private void harvestFinance(){
        try(MarketDb db=new MarketDb(getApplicationContext())){
            collectFinance(db,false);
        }finally{cleanup();}
    }
    private void collectFinance(MarketDb db,boolean fullAudit){
        try{
            db.log("INFO","财报采用公开数据源，无需 Token；港股完整三表尚未支持结构化自动采集");
            LocalDate today=LocalDate.now(ZoneId.of("Asia/Shanghai")),begin=today.minusYears(2);
            String toDay=today.toString();
            Universe.install(getApplicationContext(),db);
            java.util.List<MarketDb.Security> securities=db.allSecurities();
            java.util.Map<String,MarketDb.FinanceCheckpoint> checkpoints=db.financeCheckpoints();
            java.util.List<FinanceJob> jobs=new java.util.ArrayList<>();
            int reused=0,cooledJobs=0;
            long now=System.currentTimeMillis();
            android.content.SharedPreferences circuit=getSharedPreferences("qd_finance_market_circuit",MODE_PRIVATE);
            for(MarketDb.Security stock:securities){
                for(String dataset:FinancialSources.datasetsFor(stock.exchange)){
                    MarketDb.FinanceCheckpoint cp=checkpoints.get(stock.code+"|"+dataset);
                    if(fullAudit){
                        boolean verified=db.fullFinanceVerified(stock.code,dataset,begin.toString(),toDay);
                        LocalDate start=FinanceCoveragePlanner.neededStart(dataset,begin,today,
                            db.savedFinancePeriods(stock.code,dataset),
                            cp==null?null:cp.lastSavedPeriod,verified);
                        if(start==null){
                            reused++;
                            db.markFinanceVerified(stock.code,dataset,begin.toString(),toDay);
                            continue;
                        }
                        if(circuit.getLong("until_"+("HK".equals(stock.exchange)?"HK":"A"),0L)>now){
                            cooledJobs++;continue;
                        }
                        jobs.add(new FinanceJob(stock,dataset,start));
                        continue;
                    }
                    if(cp!=null&&cp.hasSavedRows&&
                        !FinanceRefreshPolicy.newReportPeriodMayExist(dataset,cp.lastSavedPeriod,today)){
                        reused++;continue; // Actual saved report is already current: zero HTTP.
                    }
                    if(cp!=null&&!FinanceRefreshPolicy.due(cp.status,cp.checkedAt,now,dataset)){
                        if("complete".equals(cp.status))reused++;else cooledJobs++;
                        continue;
                    }
                    if(circuit.getLong("until_"+("HK".equals(stock.exchange)?"HK":"A"),0L)>now){
                        cooledJobs++;continue;
                    }
                    LocalDate requested=FinanceRefreshPolicy.requestMissingStart(begin,today,
                        cp==null?null:cp.lastSuccessfulEnd,
                        cp==null?null:cp.lastSavedPeriod,dataset);
                    jobs.add(new FinanceJob(stock,dataset,requested));
                }
            }
            int total=jobs.size(),processed=0,failed=0,unresolved=0,transientErrors=0;
            int savedRecords=db.countDataRows();
            db.log("FINANCE_SKIP",(fullAudit?"全量财报缺期检查：":"普通财报续补：")+
                "成功缓存跳过 "+reused+" 项；失败/空结果/市场保护冷却 "+cooledJobs+
                " 项；待请求 "+total+" 项（首采两年，成功后滚动15个月）");
            if(total==0){
                String msg="财报本次无到期网络请求；成功缓存 "+reused+" 项、冷却待补 "+cooledJobs+
                    " 项、累计保存 "+savedRecords+" 行";
                db.financeState(cooledJobs==0?"up_to_date":"partial","",msg,0,0,0);
                db.log("FINANCE_SKIP",msg);LIVE=msg;notifyProgress(0,0);return;
            }
            db.financeState("running","","本轮待联网 "+total+" 项；成功缓存 "+reused+
                " 项；冷却待补 "+cooledJobs+" 项",total,0,0);
            String previousMarket="";
            java.util.Set<String> failedMarkets=new java.util.HashSet<>();
            int deferredMarket=0;
            for(FinanceJob job:jobs){
                MarketDb.Security stock=job.stock;
                String dataset=job.dataset;
                String market="HK".equals(stock.exchange)?"HK":"A";
                if(!market.equals(previousMarket)){transientErrors=0;previousMarket=market;}
                if(failedMarkets.contains(market)){deferredMarket++;continue;}
                if(paused.get()){
                    db.financeState("paused",stock.code,"已暂停；已有数据及检查点保留",total,processed,failed);return;
                }
                if(wake!=null && System.currentTimeMillis()-lastWakeRenew>8L*60*1000){
                    wake.acquire(12L*60*1000);lastWakeRenew=System.currentTimeMillis();
                }
                processed++;
                try{
                    java.util.List<org.json.JSONObject> rows=FinancialSources.fetch(dataset,stock.code,stock.exchange,job.start,today);
                    if(rows.isEmpty()){
                        if(fullAudit)unresolved++;
                        db.saveEmptyDataJob(stock.code,dataset,job.start.toString(),toDay);
                        db.log("EMPTY",stock.exchange+":"+stock.code+" "+dataset+" 0行，7天后复核，不记完整");
                    }else{
                        int newlySaved=db.saveData(stock.code,dataset,job.start.toString(),toDay,rows);
                        savedRecords+=newlySaved;
                        db.log("DATA",stock.exchange+":"+stock.code+" "+dataset+
                            " 返回 "+rows.size()+" 条，实际新入库 "+newlySaved+" 条");
                        if(fullAudit){
                            java.util.List<String> nowSaved=db.savedFinancePeriods(stock.code,dataset);
                            String lastPeriod=null;
                            for(String p:nowSaved){
                                LocalDate parsed=FinanceRefreshPolicy.parsePeriod(p);
                                if(parsed!=null&&(lastPeriod==null||parsed.isAfter(FinanceRefreshPolicy.parsePeriod(lastPeriod))))
                                    lastPeriod=p;
                            }
                            LocalDate stillNeeded="hk_dividend".equals(dataset)?null:
                                FinanceCoveragePlanner.neededStart(dataset,begin,today,
                                    nowSaved,lastPeriod,false);
                            if(stillNeeded==null){
                                db.markFinanceVerified(stock.code,dataset,begin.toString(),toDay);
                            }else{
                                unresolved++;
                                db.log("FINANCE_GAP",stock.code+" "+dataset+
                                    " 仍有未核实报告期，至少需要 "+stillNeeded+"，不标记全量完成");
                            }
                        }
                    }
                    transientErrors=0;
                }catch(Exception ex){
                    failed++;transientErrors++;String err=ex.getClass().getSimpleName()+" "+String.valueOf(ex.getMessage());
                    if(err.length()>360)err=err.substring(0,360);
                    db.dataFailure(stock.code,dataset,job.start.toString(),toDay,err);
                    db.log("ERROR",stock.code+" "+dataset+" "+err);
                    if(transientErrors>=12){
                        db.log("ERROR",market+" 财务接口连续12次失败；本轮跳过该市场剩余请求，24小时后可重试");
                        failedMarkets.add(market);
                        circuit.edit().putLong("until_"+market,System.currentTimeMillis()+86400000L).apply();
                    }
                }
                String progress="本轮请求 "+processed+"/"+total+"，成功缓存 "+reused+
                    "，冷却待补 "+cooledJobs+"；累计数据 "+savedRecords+" 行；失败 "+failed;
                LIVE=stock.exchange+":"+stock.code+" "+dataset+" · "+progress;
                if(processed%4==0){db.financeState("running",stock.code+" "+dataset,progress,total,processed,failed);notifyProgress(processed,total);}
                Thread.sleep(900L); // only throttle actual network requests, not cached jobs
            }
            String detail="本次联网 "+processed+" 项、成功缓存 "+reused+" 项、冷却待补 "+cooledJobs+
                " 项、市场故障延期 "+deferredMarket+" 项；数据库记录 "+savedRecords+
                " 行，失败 "+failed+"、仍有未核实报告期 "+unresolved+"；港股完整三大报表未覆盖";
            db.financeState(failed==0&&deferredMarket==0&&cooledJobs==0&&unresolved==0?"up_to_date":"partial","",detail,total,processed,failed);
            db.log("INFO",detail);LIVE=detail;notifyProgress(processed,total);
        }catch(InterruptedException ex){
            Thread.currentThread().interrupt();db.log("INFO","财务采集线程中断；已保存数据和检查点");
            db.financeState("paused","","任务中断，已有记录仍保留",0,0,0);
        }catch(Exception ex){
            String message=ex.getClass().getSimpleName()+" "+String.valueOf(ex.getMessage());
            db.log("ERROR","财务采集中断："+message);db.financeState("error","",message,0,0,0);
        }
    }
    @Override public void onDestroy(){paused.set(true);if(wake!=null&&wake.isHeld())wake.release();super.onDestroy();}
}
