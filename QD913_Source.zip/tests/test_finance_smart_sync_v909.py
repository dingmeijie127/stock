"""V9.0.9 deterministic regression contracts: financial request dedupe and fail-backoff.
Provider availability is not asserted by these tests.
"""
from pathlib import Path
import re,sqlite3,subprocess, tempfile

R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'
DB=(J/'MarketDb.java').read_text()
FIN=(J/'FinanceRefreshPolicy.java').read_text()
SVC=(J/'HarvestService.java').read_text()
SCH=(J/'DailyUpdateScheduler.java').read_text()
MAIN=(J/'MainActivity.java').read_text()


def db():
    db=sqlite3.connect(':memory:')
    for q in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB):db.execute(q)
    return db


def test_finance_jobs_are_persistent_across_calendar_dates():
    c=db()
    c.execute('INSERT INTO data_jobs VALUES (?,?,?,?,?,?,?,?,?)',('00700','hk_indicator','2024-10-26','2026-10-26','complete',7,1,None,100000))
    # Prior v908 equality wrongly repeated HTTP tomorrow, despite already saved data.
    assert c.execute('SELECT COUNT(*) FROM data_jobs WHERE code=? AND dataset=? AND from_day=? AND to_day=? AND status=?',
                     ('00700','hk_indicator','2024-10-27','2026-10-27','complete')).fetchone()[0]==0
    assert c.execute('SELECT code,dataset,status,checked_at,to_day FROM data_jobs ORDER BY checked_at DESC').fetchone()==(
        '00700','hk_indicator','complete',100000,'2026-10-26')
    assert 'db.financeCheckpoints()' in SVC
    assert 'FinanceRefreshPolicy.due' in SVC
    assert 'ORDER BY checked_at DESC' in DB
    assert 'cp.lastSuccessfulEnd' in SVC


def test_manual_fast_sync_does_not_retry_all_failed_again():
    ordinary=SCH.split('public static void runOnce(Context c){',1)[1].split('public static void retryFailuresOnce',1)[0]
    special=SCH.split('public static void retryFailuresOnce(Context c){',1)[1].split('static void enqueueNext',1)[0]
    assert 'resetFastTransientFailures' not in ordinary
    assert 'resetFastTransientFailures(day)' in special
    assert '② 快速增量｜只追加最新缺失日K' in MAIN
    assert 'HistoryGapPlanner.plan' in SVC
    assert 'INSERT OR IGNORE INTO daily_bars' in DB


def test_finance_does_not_recount_whole_database_on_each_request():
    assert 'savedRecords+=newlySaved;' in SVC
    assert '返回 '+ '"+rows.size()+" 条，实际新入库' in SVC
    assert 'st.executeInsert()!=-1' in DB
    assert 'Thread.sleep(900L)' in SVC
    assert 'qd_finance_market_circuit' in SVC
    assert 'cooledJobs==0?"up_to_date":"partial"' in SVC
    assert 'recentlyCheckedDataJob' not in SVC  # one bulk checkpoint query, not per-symbol SQL
    assert 'requestStart' in FIN


def test_finance_policy_real_java_compiles_and_runs():
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(J/'FinanceRefreshPolicy.java'),
                        str(R/'tests/java/FinanceRefreshPolicyTest.java')],check=True)
        p=subprocess.run(['java','-cp',tmp,'com.quantdesk.download.FinanceRefreshPolicyTest'],
                         text=True,capture_output=True,check=True)
        assert 'passed' in p.stdout


def test_no_destructive_migrations_and_correct_build_files():
    assert 'DROP TABLE' not in DB
    assert 'super(context,NAME,null,5)' in DB
    assert 'versionCode 913' in (R/'android-app/app/build.gradle').read_text()
    wf=(R/'.github/workflows/QD913_Build.yml').read_text()
    assert "z=Path('QD913_Source.zip')" in wf
    assert 'FinanceRefreshPolicyTest.java' in wf
