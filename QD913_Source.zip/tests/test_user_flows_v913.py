"""V9.1.3 contract tests of real SQLite queries + pure-Java planning.

NOT Android device tests. Provider connectivity, APK signatures and foreground
service permissions require GitHub Android build and installation acceptance.
"""
from pathlib import Path
import re
import sqlite3
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'android-app/app/src/main/java/com/quantdesk/download'
DB=(JAVA/'MarketDb.java').read_text()
SERVICE=(JAVA/'HarvestService.java').read_text()
MAIN=(JAVA/'MainActivity.java').read_text()
FAST=(JAVA/'ManualFastSync.java').read_text()


def memory_db():
    connection=sqlite3.connect(':memory:')
    for ddl in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB):
        connection.execute(ddl)
    return connection


def test_old_rows_survive_additive_v5_and_manual_status():
    db=memory_db()
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('00700','Tencent','HK','legacy'))
    old=('00700','2026-10-23',600,620,595,610,1000,'SHARES',None,'hk','original-json')
    db.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',old)
    db.execute('INSERT INTO dataset_rows VALUES(?,?,?,?,?,?,?,?,?)',
               ('00700','hk_indicator','old-q','2026-03-31','','','legacy','{"old":true}',12))
    db.execute("INSERT INTO verified_history VALUES('00700','2024-10-26','2026-10-23',1)")
    db.execute("INSERT OR REPLACE INTO manual_sync_state VALUES(1,'full','partial',4,100,'still missing',10)")
    db.execute('INSERT OR IGNORE INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',old)
    assert db.execute('SELECT raw FROM daily_bars').fetchone()[0]=='original-json'
    assert db.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==1
    assert db.execute('SELECT raw_json FROM dataset_rows').fetchone()[0]=='{"old":true}'
    assert db.execute('SELECT mode,phase FROM manual_sync_state').fetchone()==('full','partial')
    assert 'if(old<=4 && updated>=5) createCoverageTables(d)' in DB
    assert 'DROP TABLE' not in DB


def test_full_cover_does_not_trust_legacy_task_status():
    assert 'db.verifiedHistory(code)' in SERVICE
    assert 'HistoryGapPlanner.plan(begin,today,current,' in SERVICE
    assert 'db.barDays(code,from,to)' in SERVICE
    assert 'db.markVerifiedHistory(code,from,to)' in SERVICE
    assert 'db.appendDailyBars(code,span.from.toString(),span.to.toString(),result.bars)' in SERVICE
    assert 'INSERT OR IGNORE INTO daily_bars' in DB
    assert 'fullFinanceVerified' in DB and 'FinanceCoveragePlanner.neededStart' in SERVICE


def test_second_manual_button_starts_foreground_directly():
    assert '② 快速增量｜只追加最新缺失日K' in MAIN
    assert '① 全量补齐｜历史K线缺口 + 财报' in MAIN
    assert 'v->start(HarvestService.START_FAST)' in MAIN
    assert 'isFast?this::harvestFast:this::harvest' in SERVICE
    assert 'ManualFastSync.run(db,today' in SERVICE
    assert 'db.planManualDaily(target)' in FAST
    assert 'enqueueUniqueWork' not in FAST
    assert 'ExistingWorkPolicy.KEEP' not in SERVICE
    assert 'date=day.toString()' not in FAST  # no invented quote timestamps


def test_status_and_errors_remain_visible_during_long_operations():
    assert 'tapNotice.setText("已经点击「"' in MAIN
    assert 'manualStatus.setText(' in MAIN
    assert 'manualProgress.setProgress' in MAIN
    assert 'new Thread(()->{' in MAIN
    assert 'manualState("fast","error"' in SERVICE
    assert 'manualState("full","error"' in SERVICE
    assert 'db.log("FAST_ERROR"' in FAST
    assert 'db.log("ERROR",market+":"+code+" 全量补齐失败："' in SERVICE
    assert '用户暂停' in SERVICE and '暂停当前任务' in MAIN


def test_manual_query_ignores_old_workmanager_attempts():
    assert 'public FastPlan planManualDaily' in DB
    start=DB.index('public FastPlan planManualDaily')
    end=DB.index('public void autoAttempt',start)
    code=DB[start:end]
    assert 'FROM instruments s ORDER BY' in code
    assert 'auto_daily_attempts' not in code
    assert 'latest.compareTo(targetDay)>=0' in code
    assert 'plan.pending.add' in code


def test_planning_and_financial_periods_compiled_and_executed():
    with tempfile.TemporaryDirectory() as dst:
        sources=[JAVA/'HistoryGapPlanner.java',ROOT/'tests/java/HistoryGapPlannerTest.java',
                 JAVA/'FinanceRefreshPolicy.java',JAVA/'FinanceCoveragePlanner.java',
                 ROOT/'tests/java/FinanceCoveragePlannerTest.java']
        subprocess.run(['javac','-encoding','UTF-8','-d',dst,*map(str,sources)],check=True,capture_output=True)
        for cls in ('HistoryGapPlannerTest','FinanceCoveragePlannerTest'):
            out=subprocess.run(['java','-cp',dst,f'com.quantdesk.download.{cls}'],
                               check=True,capture_output=True,text=True)
            assert 'PASS' in out.stdout
