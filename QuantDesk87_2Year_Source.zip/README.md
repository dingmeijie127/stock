# QuantDesk V8.7 · A 股 + 港股最近两年日K线数据库采集 APK

**目标：为后续自选股、因子选股和量化回测先获得本地历史数据。**

## 当前真正实现的范围

- 采用原生 Android Activity 显示“创建/打开数据库”“开始/续传后台下载”“暂停”“导出 SQLite”“导出下载日志”。页面显示进度条、当前证券、成功/失败/跳过数量和已获得 K 线条数。
- 原生 Android 前台服务（Foreground Service，`dataSync`）后台运行、通知栏显示进度；屏幕关闭后尝试继续工作。持久化 SQLite 断点。系统强杀或受省电策略影响后，需要重新打开 APK 点“开始/继续”，不会从头重采已经确认的证券区间。
- 先建立并刷新 A 股、港股证券目录，随后仅采集**向前滚动两年**的日 K（OHLCV，当前为不复权）。每只证券按约一年分成两个时段，以免大响应被截断。
- 东财历史日线首选，Yahoo Finance 备用；配置 Tushare Token 后增加相应有权限的备用行情源。真实响应仅通过 OHLC 校验后落库，保留来源与原始行。
- 日 K 行用复合主键 `(market, code, interval, adjustment, timestamp)` 去重，`fetch_tasks` 记录分段成功/失败，`harvest_state` 记录整体进度，`harvest_logs` 持续记录事件（保留最近 1500 条），`data_gaps` 标记失败与异常短历史。
- 网络失败最多两轮源切换，连续 25 只失败则保护性停止，防止接口全面故障时无尽请求。低于 300 MB 可用空间也会停止以避免数据库损坏。默认仅 Wi-Fi，勾选才允许计费移动网络。
- 旧版 `quantdesk-market-v86.sqlite3` 自动从 SQLite schema 1 升级为 2，历史 K 线与财报表保留，不会主动删除。
- 保留旧版分析界面入口，但它**尚未直接切换到读取新 SQLite 数据库做全市场选股**，这是下一阶段。

## 清楚限定

1. V8.7 **第一阶段采集的是最近两年日K线**。三大财报表、分钟线和原有采集器代码仍留在工程内，但不再作为第一次下载的阻塞环节。本版本不声称已完成两年财报的全面采集。
2. 免费公开接口不保证全部退市证券、完整交易日历、被停牌的日期、各种复权因子或严格的金融数据授权； `observed` 意味着接口返回并落库，不是交易所级全量认证。
3. 股票列表是多个公开列表合并，未与所有交易所的历史上市/退市全清单核对；没有数据时会报错/记缺口，绝不虚构。
4. 安卓后台服务会受到厂商省电、网络中断、Android 前台服务时限等影响。当前 targetSdk 34；高版本系统可限制运行时长。任务检查点可供再次点击开始续传，**不保证系统杀进程后自动启动**。
5. APK 在当前提供源码的环境**未实际构建并安装到手机**，也未能对实时数据源联网实抓。下面所有测试是离线测试。GitHub Actions 的真实编译/设备测试仍要运行一次。

## 手机实际使用

1. 安装 GitHub Actions 生成的 APK；授权通知以显示后台下载状态。保持充足的手机存储和电量，建议关闭该应用的省电限制。
2. 连接 Wi‑Fi（或有意开启移动数据选项）。第一次点 **① 创建/打开本地 SQLite 数据库**。
3. 点 **② 开始/继续：后台下载最近两年日K**。页面立即显示“任务启动中”，通知栏出现后台任务。
4. 页面每 3 秒刷新 `已处理/总数`、百分比、成功、失败、跳过、K线数、当前证券与 15 条日志。进度写入 SQLite，任务在后台持续工作。
5. 点 **③ 暂停** 可终止后续请求；稍等正在进行的 HTTP 请求结束，再次点 **② 开始/继续** 跳过成功的分段。
6. 出现连续失败可点 **导出下载日志 .txt** 发送排查；采集停止后点 **④ 导出 SQLite**，将数据库备份到手机文件夹。
7. 在下方输入 `600519` 或 `00700` 可检查本地已保存的日线覆盖范围；不是拿到空响应也算下载完成。

## 在现有 GitHub 仓库用两个文件编译

- 把 `QuantDesk87_2Year_Source.zip` **直接上传到仓库根目录，不用解压**。
- 把 `QuantDesk87_Build.yml` 上传到仓库 `.github/workflows/` 目录（不用复制内容）。如果此前旧版 YAML 还在，建议删除旧工作流，避免操作混淆。
- 打开 GitHub → Actions → **QuantDesk V8.7 - Two-Year A-HK Downloader APK** → Run workflow。成功后下载 Artifact `QuantDesk-V8.7-TwoYear-APK`，其中是 debug APK。

## 结构说明

- `android-app/app/src/main/java/com/quantdesk/v85/MainActivity.java`：原生按钮、进度条、日志、导出。
- `HarvestService.java`：后台前台服务、通知、暂停、WakeLock。
- `NativeCollector.java`：A/HK 目录，二年日K分段与多源备用、落库。
- `HarvestPolicy.java`：日期范围、检查点、进度计算（可在普通 JVM 自测）。
- `DailyBar.java`：实际日K字段解析和 OHLCV 校验（通过 JVM 样本测试）。
- `VaultDb.java`：SQLite schema、升级、日志/进度/失败。
- `tests/test_two_year_android_contract.py`：数据库 DDL、迁移与前端-服务绑定逻辑的离线测试。
- `tests/HarvestPolicyTest.java`：实际执行的日期计算与边界测试；`DailyBarTest.java`：行情 CSV 行解析与非法 OHLCV 测试。
- `.github/workflows/android-build.yml`：源码内置同内容编译工作流；单独的 YAML 也已提供。

## 本地可运行自测（并非手机 APK 测试）

```bash
python -m pip install -e ./collector pytest httpx
python -m pytest -q tests
node --test tests/*.test.cjs
mkdir -p build/classes
javac -encoding UTF-8 -d build/classes android-app/app/src/main/java/com/quantdesk/v85/{MarketRules,HarvestPolicy,DailyBar}.java tests/{MarketRulesTest,HarvestPolicyTest,DailyBarTest}.java
java -cp build/classes MarketRulesTest
java -cp build/classes HarvestPolicyTest
java -cp build/classes DailyBarTest
```
