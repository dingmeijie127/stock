"""Fast daily planner: real SQLite indexed queries, idempotency and no fake completeness."""
from pathlib import Path
import sqlite3,re,time
ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'android-app/app/src/main/java/com/quantdesk/download'
DB=(JAVA/'MarketDb.java').read_text()
WORK=(JAVA/'DailyUpdateWorker.java').read_text()
MAIN=(JAVA/'MainActivity.java').read_text()

# Parse the actual SQLite schema declared in the Android application, not invented tables.
def schema():
    c=sqlite3.connect(':memory:')
    for q in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB):
        c.execute(q)
    return c

def test_one_sql_cursor_determines_latest_and_pending_without_modifying_history():
    c=schema()
    symbols=[('600519','SH'),('000001','SZ'),('00700','HK'),('00005','HK')]
    for code,market in symbols:
        c.execute('INSERT INTO instruments VALUES(?,?,?,?)',(code,code,market,'verified'))
    for code,day in [('600519','2026-10-26'),('000001','2026-10-23'),('00700','2026-10-23')]:
        c.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',(code,day,100,103,99,101,100,'LOTS',None,'test','fixture'))
    # A valid snapshot from exactly 2026-10-26 is idempotent.
    q='''SELECT s.code,s.exchange,
         (SELECT b.day FROM daily_bars b WHERE b.code=s.code ORDER BY b.day DESC LIMIT 1),
         (SELECT min(t.start_day) FROM tasks t WHERE t.code=s.code AND t.status='partial'),
         (SELECT a.status FROM auto_daily_attempts a WHERE a.code=s.code AND a.target_day=?)
         FROM instruments s ORDER BY CASE WHEN s.exchange='HK' THEN 1 ELSE 0 END,s.code'''
    rows=c.execute(q,('2026-10-26',)).fetchall()
    due={r[0] for r in rows if (r[2] or '')<'2026-10-26' and r[4] is None}
    assert due=={'000001','00700','00005'}
    before=c.execute('SELECT COUNT(*) FROM daily_bars').fetchone()[0]
    c.execute('INSERT OR IGNORE INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',('600519','2026-10-26',999,1000,998,999,100,'LOTS',None,'new','wrong'))
    assert c.execute("SELECT c FROM daily_bars WHERE code='600519'").fetchone()[0]==101
    assert c.execute('SELECT COUNT(*) FROM daily_bars').fetchone()[0]==before
    assert 'DROP TABLE' not in DB

def test_fast_path_is_bounded_and_does_not_treat_missing_data_as_success():
    for required in ['4L*60*1000+20_000','QUOTE_STAGE_MS=120_000',
                     'newFixedThreadPool(PARALLEL)','TencentBatchQuotes.pages',
                     'db.autoAttempt(candidate.code,day,"backfill"',
                     '"stale"','"partial"','autoUnresolved(day)',
                     'saveFastQuoteBatch','saveFastTail']:
        assert required in WORK or required in DB,required
    assert 'Thread.sleep(550L)' not in WORK
    assert 'INSERT OR IGNORE INTO daily_bars' in DB
    assert '"fast"' not in WORK  # stage is running/partial/done, not fake success

def test_new_ui_distinguishes_incremental_and_backfill():
    assert '一键极速增量（日K+到期财报，目标5分钟）' in MAIN
    assert '首次两年历史下载 / 缺口修复' in MAIN
    assert 'DailyUpdateScheduler.runOnce(this)' in MAIN
    assert 'start(HarvestService.START)' in MAIN

def test_large_indexed_database_plan_under_local_test_budget():
    # Test that planning 5000 symbols is indexed and practical, not 5000 JDBC calls.
    c=schema()
    sym=[(f'{i:06d}',f'{i:06d}','SH','test') for i in range(5000)]
    c.executemany('INSERT INTO instruments VALUES(?,?,?,?)',sym)
    data=[]
    for i in range(5000):
        code=f'{i:06d}'
        for day in range(30):
            data.append((code,f'2026-09-{day+1:02d}',100,102,98,101,100,'LOTS',None,'test','raw'))
    c.executemany('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',data)
    q='''SELECT s.code,s.exchange,
        (SELECT b.day FROM daily_bars b WHERE b.code=s.code ORDER BY b.day DESC LIMIT 1),
        (SELECT min(t.start_day) FROM tasks t WHERE t.code=s.code AND t.status='partial'),
        (SELECT a.status FROM auto_daily_attempts a WHERE a.code=s.code AND a.target_day=?)
        FROM instruments s ORDER BY CASE WHEN s.exchange='HK' THEN 1 ELSE 0 END,s.code'''
    started=time.perf_counter()
    rows=c.execute(q,('2026-09-30',)).fetchall()
    elapsed=time.perf_counter()-started
    assert len(rows)==5000
    assert all(row[2]=='2026-09-30' for row in rows)
    # Broad local sanity guard; not a mobile benchmark or whole-network SLA.
    assert elapsed<8,elapsed
    assert 'SEARCH' in ' '.join(str(x) for row in c.execute('EXPLAIN QUERY PLAN '+q,('2026-09-30',)) for x in row)
