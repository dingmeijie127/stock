package com.quantdesk.download;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.util.List;

public final class PublicFinanceTest {
  static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
  public static void main(String[] args) throws Exception {
    LocalDate start=LocalDate.parse("2024-10-25"),end=LocalDate.parse("2026-10-25");
    String html="<html><input type='hidden' value='4' id='hidctype'></html>";
    FinancialSources.Transport a=url->{
      if(url.contains("/Index?"))return html;
      if(url.contains("DateAjaxNew"))return new JSONObject().put("data",new JSONArray()
         .put(new JSONObject().put("REPORT_DATE","2026-09-30"))
         .put(new JSONObject().put("REPORT_DATE","2020-01-01"))).toString();
      if(url.contains("AjaxNew"))return new JSONObject().put("data",new JSONArray()
         .put(new JSONObject().put("REPORT_DATE","2026-09-30").put("TOTAL_OPERATE_INCOME",12345.5))).toString();
      throw new AssertionError("Unexpected public URL "+url);
    };
    for(String d:new String[]{"income","balancesheet","cashflow"}){
       List<JSONObject> list=FinancialSources.fetch(d,"600519","SH",start,end,a);
       ok(list.size()==1,"wrong A rows "+d);
       ok("600519.SH".equals(list.get(0).optString("ts_code")),"wrong A ticker");
       ok("eastmoney_public".equals(list.get(0).optString("_qd_provider")),"wrong source");
       ok("2026-09-30".equals(list.get(0).optString("_qd_report_date")),"date not saved");
    }
    FinancialSources.Transport hk=url->{
      ok(url.contains("RPT_CUSTOM_HKF10_FN_MAININDICATORMAX")||url.contains("RPT_HKF10_MAIN_DIVBASIC"),"bad HK report");
      if(url.contains("DIVBASIC"))return new JSONObject().put("result",new JSONObject().put("data",new JSONArray().put(
           new JSONObject().put("SECURITY_CODE","00700").put("EX_DIVIDEND_DATE","2026-05-01")))).toString();
      return new JSONObject().put("result",new JSONObject().put("data",new JSONArray().put(
           new JSONObject().put("SECUCODE","00700.HK").put("REPORT_DATE","2026-06-30")
             .put("BASIC_EPS",12.34)))).toString();
    };
    ok(FinancialSources.fetch("hk_indicator","00700","HK",start,end,hk).size()==1,"missing HK indicator");
    ok(FinancialSources.fetch("hk_dividend","00700","HK",start,end,hk).size()==1,"missing HK dividend");
    boolean blocked=false;
    try{FinancialSources.fetch("hk_income","00700","HK",start,end,hk);}catch(Exception e){blocked=true;}
    ok(blocked,"must not claim unavailable HK statements");
    blocked=false;
    try{FinancialSources.fetch("income","00700","HK",start,end,hk);}catch(Exception e){blocked=true;}
    ok(blocked,"HK cannot masquerade as A income");
    ok(FinancialSources.datasetsFor("HK").length==2,"wrong HK dataset list");
    ok(FinancialSources.datasetsFor("SH").length==3,"wrong A dataset list");
    System.out.println("PublicFinancial fixtures: A three statements, HK indicator/dividend, symbol matching, date filter, permission-free all PASS");
  }
}
