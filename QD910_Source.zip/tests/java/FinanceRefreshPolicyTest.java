package com.quantdesk.download;
import java.time.LocalDate;

public final class FinanceRefreshPolicyTest {
    private static void ok(boolean yes,String reason){if(!yes)throw new AssertionError(reason);}
    public static void main(String[] args){
        long now=1761000000000L,day=86400000L;
        ok(FinanceRefreshPolicy.due(null,0,now,"income"),"new source should run");
        ok(!FinanceRefreshPolicy.due("complete",now-day,now,"income"),"A downloaded yesterday, skip");
        ok(FinanceRefreshPolicy.due("complete",now-7*day,now,"income"),"A 7-day refresh");
        ok(!FinanceRefreshPolicy.due("complete",now-7*day,now,"hk_indicator"),"HK 14d interval");
        ok(FinanceRefreshPolicy.due("complete",now-14*day,now,"hk_indicator"),"HK overdue");
        ok(!FinanceRefreshPolicy.due("failed",now-23*60*60*1000L,now,"cashflow"),"don't hammer failing source");
        ok(FinanceRefreshPolicy.due("failed",now-day,now,"cashflow"),"failed due next day");
        ok(!FinanceRefreshPolicy.due("empty",now-day,now,"hk_dividend"),"empty source backoff");
        ok(FinanceRefreshPolicy.due("empty",now-7*day,now,"hk_dividend"),"empty recheck");
        LocalDate today=LocalDate.of(2026,10,26),baseline=today.minusYears(2);
        ok(FinanceRefreshPolicy.requestStart(baseline,today,null).equals(baseline),"first fetch two years");
        ok(FinanceRefreshPolicy.requestStart(baseline,today,"2026-09-01").equals(today.minusMonths(15)),"incremental report correction overlap");
        ok(FinanceRefreshPolicy.requestStart(baseline,today,"2026-10-25").equals(today.minusMonths(15)),"don't use naive 14-day report overlap");
        System.out.println("FinanceRefreshPolicyTest passed");
    }
}
