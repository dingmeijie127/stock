package com.quantdesk.download;
import java.time.ZoneId;
import java.time.ZonedDateTime;
public final class ScheduleClockTest {
    static void assertMs(long actual,long expected,String label){
        if(actual!=expected)throw new AssertionError(label+": "+actual+" != "+expected);
    }
    public static void main(String[] args){
        ZoneId hk=ZoneId.of("Asia/Hong_Kong");
        ZoneId utc=ZoneId.of("UTC");
        assertMs(ScheduleClock.delayToNextHKRun(ZonedDateTime.of(2026,10,26,19,30,0,0,hk)),60L*60*1000,"after close in one hour");
        assertMs(ScheduleClock.delayToNextHKRun(ZonedDateTime.of(2026,10,26,20,30,0,0,hk)),24L*60*60*1000,"already at deadline");
        assertMs(ScheduleClock.delayToNextHKRun(ZonedDateTime.of(2026,10,26,12,30,0,0,utc)),24L*60*60*1000,"UTC converts to HK time");
        assertMs(ScheduleClock.delayToNextHKRun(ZonedDateTime.of(2026,10,26,21,0,0,0,hk)),23L*60*60*1000+30L*60*1000,"after close next day");
        System.out.println("ScheduleClock: 4 assertions passed");
    }
}
