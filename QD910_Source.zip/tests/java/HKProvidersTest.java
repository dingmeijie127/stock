package com.quantdesk.download;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.ZoneId;
import java.io.IOException;
public final class HKProvidersTest {
  static long ts(int d){return LocalDate.of(2026,10,d).atTime(12,0).atZone(ZoneId.of("Asia/Hong_Kong")).toEpochSecond();}
  static void eq(int wanted,int actual){if(wanted!=actual)throw new AssertionError(wanted+" != "+actual);}
  static JSONObject quote(){
    JSONObject q=new JSONObject().put("open",new JSONArray().put(10.0).put(0).put(10.3))
       .put("high",new JSONArray().put(11.0).put(0).put(11.1))
       .put("low",new JSONArray().put(9.5).put(0).put(9.8))
       .put("close",new JSONArray().put(10.4).put(0).put(10.8))
       .put("volume",new JSONArray().put(500).put(0).put(600));
    JSONObject series=new JSONObject().put("timestamp",new JSONArray().put(ts(21)).put(ts(22)).put(ts(23)))
       .put("indicators",new JSONObject().put("quote",new JSONArray().put(q)));
    return new JSONObject().put("chart",new JSONObject().put("result",new JSONArray().put(series)));
  }
  public static void main(String[] args) throws Exception {
    HongKongSources.Parsed yahoo=HongKongSources.parseYahooChecked(quote(),LocalDate.of(2026,10,20),LocalDate.of(2026,10,25));
    eq(2,yahoo.bars.size());eq(1,yahoo.skippedRows);
    JSONArray valid=new JSONArray().put("2026-10-23").put("10").put("10.2").put("10.6").put("9.7").put("330");
    JSONObject stock=new JSONObject().put("day",new JSONArray().put(valid));
    JSONObject response=new JSONObject().put("data",new JSONObject().put("hk00700",stock));
    eq(1,HongKongSources.parseTencent(response,"00700",LocalDate.of(2026,10,20),LocalDate.of(2026,10,25)).size());
    JSONObject adjusted=new JSONObject().put("data",new JSONObject().put("hk00700",new JSONObject().put("qfqday",new JSONArray().put(valid))));
    boolean refused=false;
    try{HongKongSources.parseTencent(adjusted,"00700",LocalDate.of(2026,10,20),LocalDate.of(2026,10,25));}
    catch(IOException e){refused=e.getMessage().contains("adjusted series refused");}
    if(!refused)throw new AssertionError("Adjusted HK data silently mixed with unadjusted DB");
    System.out.println("PASS: Yahoo one invalid day skipped; Tencent raw day accepted; qfqday rejected");
  }
}
