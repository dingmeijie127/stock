package com.quantdesk.download;
import java.time.LocalDate;
/** Executed by javac/java during GitHub build, no network or Android dependencies. */
public final class RangePlannerTest{
  private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
  public static void main(String[] args){
    LocalDate begin=LocalDate.of(2024,10,24),end=LocalDate.of(2026,10,24);
    check(RangePlanner.nextDailyStart(begin,end,null).equals(begin),"fresh DB full backfill");
    check(RangePlanner.nextDailyStart(begin,end,"2026-10-23").equals(end),"old bars reused; only missing tail");
    check(RangePlanner.nextDailyStart(begin,end,"2026-10-24")==null,"already downloaded, skip all");
    check(RangePlanner.nextDailyStart(begin,end,"2024-10-01").equals(begin),"outdated history");
    check(RangePlanner.nextDatasetStart(begin,end,null).equals(begin),"finance initial backfill");
    check(RangePlanner.nextDatasetStart(begin,end,"2026-10-24")==null,"finance repeated launch skip");
    check(RangePlanner.nextDatasetStart(begin,end,"2026-10-23").equals(LocalDate.of(2026,10,9)),"finance revision overlap");
    java.time.ZoneId hk=java.time.ZoneId.of("Asia/Hong_Kong");
    check(RangePlanner.safeEndDay(java.time.ZonedDateTime.of(2026,10,26,10,0,0,0,hk))
        .equals(LocalDate.of(2026,10,23)),"morning uses Friday");
    check(RangePlanner.safeEndDay(java.time.ZonedDateTime.of(2026,10,26,20,0,0,0,hk))
        .equals(LocalDate.of(2026,10,26)),"after close same day");
    check(RangePlanner.safeEndDay(java.time.ZonedDateTime.of(2026,10,25,21,0,0,0,hk))
        .equals(LocalDate.of(2026,10,23)),"Sunday uses Friday");
    System.out.println("RangePlanner: 10 checks passed");
  }
}
