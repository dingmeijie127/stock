package com.quantdesk.download;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
public final class SqliteBackupFormatTest {
    public static void main(String[] args)throws Exception {
        File good=File.createTempFile("qd-sqlite", ".sqlite3");
        File bad=File.createTempFile("qd-fake", ".sqlite3");
        try {
            byte[] contents=new byte[1024];
            byte[] header="SQLite format 3\0".getBytes(StandardCharsets.US_ASCII);
            System.arraycopy(header,0,contents,0,header.length);
            try(FileOutputStream o=new FileOutputStream(good)){o.write(contents);}
            try(FileOutputStream o=new FileOutputStream(bad)){o.write("This is just a text preview".getBytes(StandardCharsets.UTF_8));}
            SqliteBackupFormat.requireValidFile(good);
            boolean rejected=false;
            try{SqliteBackupFormat.requireValidFile(bad);}catch(IOException e){rejected=true;}
            if(!rejected)throw new AssertionError("Must reject a text/zip substitute");
            System.out.println("SQLITE_SIGNATURE_TEST_OK");
        }finally{good.delete();bad.delete();}
    }
}
