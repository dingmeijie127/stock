package com.quantdesk.download;
public final class HKBarQualityTest {
  public static void main(String[] args){
    Bar valid=HKBarQuality.validOrNull("2026-10-23",10.0,11.0,9.0,10.5,200,null,"yahoo_hk","SHARES","valid");
    if(valid==null || valid.close!=10.5)throw new AssertionError("Valid row discarded");
    if(HKBarQuality.validOrNull("2026-10-23",0,0,0,0,0,null,"yahoo_hk","SHARES","suspended")!=null)
      throw new AssertionError("Zero-price row was not discarded");
    if(HKBarQuality.validOrNull("2026-10-23",12,11,9,10,200,null,"yahoo_hk","SHARES","bad")!=null)
      throw new AssertionError("Inconsistent OHLC row was not discarded");
    System.out.println("PASS: valid Yahoo HK row saved; two bad rows rejected individually");
  }
}
