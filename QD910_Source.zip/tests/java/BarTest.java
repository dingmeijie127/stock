package com.quantdesk.download;
public final class BarTest {
  public static void main(String[] args){
    Bar b=Bar.eastmoney("2026-10-23,100.00,101.00,103.00,99.00,420,400000.00,1,0.01,0.9,0");
    if(!b.date.equals("2026-10-23")||b.high!=103||b.low!=99||b.close!=101||b.volume!=420)
      throw new IllegalStateException("Incorrect Eastmoney field order");
    boolean rejected=false;
    try{Bar.eastmoney("2026-10-23,102,100,101,99,50,10");}catch(IllegalArgumentException e){rejected=true;}
    if(!rejected)throw new IllegalStateException("invalid OHLC was accepted");
    rejected=false;
    try{Bar.eastmoney("broken");}catch(IllegalArgumentException e){rejected=true;}
    if(!rejected)throw new IllegalStateException("invalid row accepted");
    System.out.println("PASS: Eastmoney schema + OHLC rejection");
  }
}
