package com.quantdesk.download;
public final class ImportProgressMeterTest {
    private static void eq(int expected,int actual){if(expected!=actual)throw new AssertionError(expected+" != "+actual);}
    public static void main(String[] args){
        eq(-1,ImportProgressMeter.copyPercent(123,-1));
        eq(0,ImportProgressMeter.copyPercent(0,100));
        eq(5,ImportProgressMeter.copyPercent(50,100));
        eq(10,ImportProgressMeter.copyPercent(200,100));
        eq(15,ImportProgressMeter.mergePercent(0,100));
        eq(57,ImportProgressMeter.mergePercent(50,100));
        eq(99,ImportProgressMeter.mergePercent(100,100));
        eq(99,ImportProgressMeter.mergePercent(150,100));
        eq(15,ImportProgressMeter.mergePercent(0,0));
        eq(15,ImportProgressMeter.mergePercent(3,0));
        System.out.println("ImportProgressMeterTest OK");
    }
}
