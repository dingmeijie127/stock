import com.quantdesk.download.Bar;
public final class BarTest {
  static void check(boolean ok,String what){if(!ok)throw new AssertionError(what);}
  public static void main(String[] args){
    Bar b=Bar.eastmoney("2026-10-23,1500.00,1520.00,1530.00,1490.00,12345.00,188800.00,3.0,1.0,20,0.1");
    check(b.open==1500.00,"open");check(b.close==1520.00,"close");
    check(b.high==1530.00,"high");check(b.low==1490.00,"low");
    check("LOTS_100_SHARES".equals(b.volumeUnit),"volume units");
    try{Bar.eastmoney("2026-10-23,5,4,3,2,100,200");throw new AssertionError("should reject bad high");}
    catch(IllegalArgumentException expected){}
    System.out.println("BarTest OK");
  }
}
