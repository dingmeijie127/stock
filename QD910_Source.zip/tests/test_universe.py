import importlib.util
import csv
import tempfile
from pathlib import Path

SCRIPT=Path(__file__).resolve().parents[1]/'scripts'/'build_universe.py'
spec=importlib.util.spec_from_file_location('universe_builder',SCRIPT)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def test_exchange_and_ticker_validation():
    assert m.normalize_code('sh.600519') == ('600519','SH')
    assert m.normalize_code('sz.000001') == ('000001','SZ')
    assert m.normalize_code('bj.830799') == ('830799','BJ')
    assert m.normalize_code('sh.000001') is None  # SSE index, not a stock
    assert m.normalize_code('sz.399001') is None  # SZSE index
    assert m.normalize_code('123456') is None


def test_dedup_and_reject_placeholder_names():
    output=m.assemble([('sh.600519','贵州茅台','bao'),('600519','Duplicate','ak'),('sz.000001','平安银行','bao'),('600000','--','bao')])
    assert len(output)==2
    assert output['600519']['name']=='贵州茅台'


def test_fixture_requires_test_mode(tmp_path):
    f=tmp_path/'fixture.csv'
    f.write_text('code,name\nsh.600519,贵州茅台\nsz.000001,平安银行\n', encoding='utf-8')
    try:
        m.main(['--output',str(tmp_path/'out'),'--fixture',str(f),'--min-count','2'])
    except SystemExit as exc:
        assert 'Fixture cannot be used' in str(exc)
    else:
        assert False, 'Fixture was incorrectly accepted for release'
    m.main(['--output',str(tmp_path/'out'),'--fixture',str(f),'--min-count','2','--test-mode'])
    assert (tmp_path/'out'/'universe.tsv').read_text(encoding='utf-8').count('\n')==3


def test_no_b_shares_and_north_market_9_codes():
    assert m.normalize_code('sh.900901') is None
    assert m.normalize_code('sz.200002') is None
    assert m.normalize_code('bj.920118') == ('920118','BJ')
    assert m.normalize_code('920118') == ('920118','BJ')
