"""Offline HK listing validation; fixture rows are never bundled into release APK."""
import csv
import importlib.util
from pathlib import Path
import pytest

P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('hk_universe', P/'scripts/build_hk_universe.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_hk_code_canonical_and_invalid():
    assert module.normalize_hk_code('700') == '00700'
    assert module.normalize_hk_code('0700.HK') == '00700'
    assert module.normalize_hk_code('00700.HK') == '00700'
    assert module.normalize_hk_code('00001') == '00001'
    assert module.normalize_hk_code('10000.HK') == '10000'
    assert module.normalize_hk_code('600519.SH') is None
    assert module.normalize_hk_code('abc') is None
    assert module.normalize_hk_code('000000') is None


def test_hk_snapshot_is_5_digits_and_unique(tmp_path):
    rows=[('700','腾讯控股','real'),('00700','重复','real'),('5','汇丰控股','real'),('X','unknown','real')]
    count=module.write_snapshot(rows,tmp_path,minimum=2,source='test')
    assert count==2
    with (tmp_path/'hk_universe.tsv').open(encoding='utf-8') as f:
        entries=list(csv.DictReader(f,delimiter='\t'))
    assert entries[0]['code']=='00005'
    assert entries[1]['code']=='00700'
    assert all(x['exchange']=='HK' for x in entries)


def test_fixture_forbidden_in_release(tmp_path):
    fixture=tmp_path/'fake.csv'
    fixture.write_text('code,name\n700,腾讯\n5,汇丰\n',encoding='utf-8')
    with pytest.raises(SystemExit,match='cannot use test fixture'):
        module.main(['--output',str(tmp_path/'out'),'--fixture',str(fixture),'--min-count','2'])
    module.main(['--output',str(tmp_path/'out'),'--fixture',str(fixture),'--min-count','2','--test-mode'])
    assert (tmp_path/'out/hk_universe.tsv').is_file()


def test_insufficient_list_fails_before_apk(tmp_path):
    with pytest.raises(ValueError,match='too small'):
        module.write_snapshot([('00700','腾讯','x')],tmp_path,minimum=1000)
