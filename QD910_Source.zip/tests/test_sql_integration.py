"""Execute the exact Android CREATE TABLE and checkpoint SQL against real SQLite."""
import re
import sqlite3
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DB_SRC=(ROOT/'android-app/app/src/main/java/com/quantdesk/download/MarketDb.java').read_text()

def test_real_sqlite_schema_import_and_resume():
    conn=sqlite3.connect(':memory:')
    creation=re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB_SRC)
    assert len(creation)>=5,len(creation)
    for sql in creation:
        conn.execute(sql)
    conn.execute("INSERT OR IGNORE INTO instruments(code,name,exchange,source) VALUES (?,?,?,?)",('600519','贵州茅台','SH','test fixture'))
    assert conn.execute('SELECT count(*) FROM instruments').fetchone()[0]==1
    rows=[('600519','2026-10-22',1500,1520,1490,1510,100,'LOTS_100_SHARES',20000,'eastmoney','fixture'),
          ('600519','2026-10-23',1501,1521,1491,1511,90,'LOTS_100_SHARES',18000,'eastmoney','fixture')]
    start,end='2024-10-24','2026-10-24'
    with conn:
        conn.executemany('INSERT OR REPLACE INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)',rows)
        conn.execute("INSERT OR REPLACE INTO tasks(code,start_day,end_day,status,rows,attempts,error,updated) VALUES(?,?,?,'complete',?,COALESCE((SELECT attempts FROM tasks WHERE code=? AND start_day=? AND end_day=?),0)+1,NULL,?)",
                     ('600519',start,end,len(rows),'600519',start,end,111))
    assert conn.execute('SELECT COUNT(*) FROM daily_bars').fetchone()[0]==2
    assert conn.execute('SELECT rows,attempts FROM tasks WHERE code="600519"').fetchone()==(2,1)
    # A second run should skip the completed security, not silently rewrite it.
    pending=conn.execute("SELECT s.code FROM instruments s WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.code=s.code AND t.start_day=? AND t.end_day=? AND t.status='complete')",(start,end)).fetchall()
    assert pending==[]
    try:
        with conn:
            conn.execute('INSERT INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                         ('600519','2026-10-21',1,1,1,1,1,'SHARES',1,'test','test'))
            raise ValueError('simulate app crash during a security save')
    except ValueError:
        pass
    assert conn.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==2
    conn.close()
