"""Mocked production-style CSV provider fallback; no false claim of live network validation."""
from pathlib import Path
import importlib.util
import io
import csv
import pytest
P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('hk', P/'scripts/build_hk_universe.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def csv_payload(n=1400):
    output=io.StringIO(); w=csv.writer(output)
    w.writerow(['code','region','name','exchange','type'])
    w.writerow(['00700','HK','TENCENT','HKEX','stock'])
    w.writerow(['00005','HK','HSBC','HKEX','stock'])
    for i in range(1000,1000+n):
        w.writerow([str(i).zfill(5),'HK','STOCK '+str(i),'HKEX','stock'])
    w.writerow(['02800','HK','ETF','HKEX','fund'])
    w.writerow(['99988','US','OTHER','NASDAQ','stock'])
    return output.getvalue().encode('utf-8-sig')


def test_github_fallback_working_when_eastmoney_and_akshare_offline(monkeypatch):
    monkeypatch.setattr(m,'_request_csv',lambda url: csv_payload())
    def offline(): raise RuntimeError('RemoteDisconnected / HTTP 502')
    monkeypatch.setattr(m,'from_akshare',offline)
    monkeypatch.setattr(m,'from_eastmoney',offline)
    rows, detail=m.from_hkex_github_csv()
    result=m.assemble(rows)
    assert len(result)>1000
    assert '00700' in result and '00005' in result
    assert '02800' not in result
    assert '99988' not in result
    assert 'githubusercontent' in detail


def test_invalid_csv_is_not_used_as_full_market(monkeypatch):
    monkeypatch.setattr(m,'_request_csv',lambda url: b'code,name\n00700,Tencent\n')
    with pytest.raises(RuntimeError,match='HKEX CSV must contain'):
        m.from_hkex_github_csv()


def test_no_placeholder_records_and_snapshot_lineage(tmp_path):
    rows=m.parse_hkex_stock_csv(csv_payload())
    total=m.write_snapshot(rows,tmp_path,minimum=1000,source='HKEX_GitHub_CSV')
    assert total>1000
    assert (tmp_path/'hk_universe.tsv').read_text().startswith('code\tname\texchange\tsource\n')
    import json
    meta=json.loads((tmp_path/'hk_universe_meta.json').read_text())
    assert meta['source']=='HKEX_GitHub_CSV'
    assert 'delisted' in meta['coverage_note']
