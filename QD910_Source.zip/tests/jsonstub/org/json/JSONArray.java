package org.json;
import java.util.List;
import java.util.ArrayList;
public class JSONArray {
 private final List<Object> values=new ArrayList<>();
 public JSONArray(){}
 public JSONArray put(Object val){values.add(val);return this;}
 public int length(){return values.size();}
 public Object get(int i){if(i<0||i>=values.size())throw new JSONException("index:"+i);return values.get(i);}
 public boolean isNull(int i){return get(i)==null;}
 public JSONArray optJSONArray(int i){return i>=0&&i<values.size()&&values.get(i) instanceof JSONArray?(JSONArray)values.get(i):null;}
 public JSONObject optJSONObject(int i){return i>=0&&i<values.size()&&values.get(i) instanceof JSONObject?(JSONObject)values.get(i):null;}
 public JSONObject getJSONObject(int i){Object v=get(i);if(!(v instanceof JSONObject))throw new JSONException("no object:"+i);return (JSONObject)v;}
 public String getString(int i){return String.valueOf(get(i));}
 public double getDouble(int i){Object v=get(i);if(v instanceof Number)return ((Number)v).doubleValue();try{return Double.parseDouble(getString(i));}catch(Exception e){throw new JSONException("not a number:"+i);}}
 public long getLong(int i){Object v=get(i);if(v instanceof Number)return ((Number)v).longValue();return Long.parseLong(getString(i));}
 public String toString(){return values.toString();}
}
