package org.json;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;
public class JSONObject {
 private final Map<String,Object> map=new LinkedHashMap<>();
 private static final Map<String,Map<String,Object>> copies=new ConcurrentHashMap<>();
 public JSONObject(){}
 public JSONObject(String raw){Map<String,Object> m=copies.get(raw);if(m==null)throw new JSONException("No registered JSON fixture: "+raw);map.putAll(m);}
 public JSONObject put(String k,Object v){map.put(k,v);return this;}
 public String optString(String k,String d){Object x=map.get(k);return x==null?d:String.valueOf(x);}
 public String optString(String k){return optString(k,"");}
 public JSONObject optJSONObject(String k){return map.get(k) instanceof JSONObject?(JSONObject)map.get(k):null;}
 public JSONArray optJSONArray(String k){return map.get(k) instanceof JSONArray?(JSONArray)map.get(k):null;}
 public JSONObject getJSONObject(String k){JSONObject v=optJSONObject(k);if(v==null)throw new JSONException("missing object:"+k);return v;}
 public JSONArray getJSONArray(String k){JSONArray v=optJSONArray(k);if(v==null)throw new JSONException("missing array:"+k);return v;}
 public int optInt(String k,int defaultValue){Object x=map.get(k);return x instanceof Number?((Number)x).intValue():defaultValue;}
 public String toString(){String key="FAKE_JSON_"+System.identityHashCode(this);copies.put(key,new LinkedHashMap<>(map));return key;}
}
