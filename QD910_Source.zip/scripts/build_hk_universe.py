"""Build-time snapshot of the *reported active* HK universe for mobile SQLite.

Public feed is not an authoritative all-historical/delisted securities master.
Never synthesize a universe or silently ship an empty catalog.
"""
import argparse
import csv
import base64
import json
import re
import io
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path


def normalize_hk_code(value):
    s = str(value).strip().upper()
    if s.endswith('.HK'):
        s = s[:-3]
    if s.isdigit() and 1 <= len(s) <= 5:
        return s.zfill(5)
    return None


def assemble(rows):
    found = {}
    for raw_code, raw_name, source in rows:
        code = normalize_hk_code(raw_code)
        name = str(raw_name or '').replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').strip()
        if code and name and name not in ('--', 'None', 'nan'):
            found.setdefault(code, (code, name, 'HK', source))
    return found



# Maintained public mirror of the HKEX active securities list, independent of
# Eastmoney/AKShare. Its stock/fund classification is retained and audited.
HKEX_CSV_URLS = (
    'https://raw.githubusercontent.com/irachex/open-stock-data/main/symbols/HKEX.csv',
    'https://api.github.com/repos/irachex/open-stock-data/contents/symbols/HKEX.csv?ref=main',
    'https://cdn.jsdelivr.net/gh/irachex/open-stock-data@main/symbols/HKEX.csv',
)


def parse_hkex_stock_csv(payload):
    """Only *stocks*; never promote ETF/fund/warrant rows to ordinary shares."""
    if isinstance(payload, bytes):
        payload = payload.decode('utf-8-sig')
    rows = []
    reader = csv.DictReader(io.StringIO(payload.lstrip('\ufeff')))
    if reader.fieldnames is None or not {'code','name','region','exchange','type'}.issubset(reader.fieldnames):
        raise ValueError('HKEX CSV must contain code,region,name,exchange,type')
    for row in reader:
        if (row.get('region') or '').upper() != 'HK':
            continue
        if (row.get('exchange') or '').upper() != 'HKEX':
            continue
        if (row.get('type') or '').strip().lower() != 'stock':
            continue
        code = normalize_hk_code(row.get('code',''))
        name = (row.get('name') or '').strip()
        if code and name:
            rows.append((code, name, 'github:irachex/open-stock-data:HKEX.csv'))
    return rows


def _request_csv(url, retries=2):
    errors = []
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'QuantDesk-collector/9.0.1 (public HKEX securities snapshot)',
                'Accept': 'text/csv,text/plain,*/*',
                'Cache-Control': 'no-cache',
            })
            with urllib.request.urlopen(req, timeout=25) as response:
                payload = response.read(2_000_000)
            if 'api.github.com/repos/' in url:
                obj = json.loads(payload)
                if obj.get('encoding') != 'base64' or not obj.get('content'):
                    raise ValueError('GitHub Contents API response without base64 content')
                payload = base64.b64decode(obj['content'], validate=False)
            if len(payload) < 10_000:
                raise ValueError('HKEX CSV unexpectedly small')
            return payload
        except Exception as exc:
            errors.append(type(exc).__name__ + ':' + str(exc)[:160])
            if attempt + 1 < retries:
                time.sleep(1)
    raise RuntimeError('; '.join(errors))


def from_hkex_github_csv():
    errors = []
    for url in HKEX_CSV_URLS:
        try:
            rows = parse_hkex_stock_csv(_request_csv(url))
            unique = assemble(rows)
            if len(unique) < 1000:
                raise ValueError(f'only {len(unique)} ordinary HK stocks')
            for known in ('00700', '00005'):
                if known not in unique:
                    raise ValueError(f'missing reference listing {known}')
            return rows, url
        except Exception as ex:
            errors.append(url + ': ' + str(ex)[:250])
    raise RuntimeError(' | '.join(errors))

def from_akshare():
    import akshare as ak
    errors = []
    for method in ('stock_hk_spot_em', 'stock_hk_main_board_spot_em'):
        try:
            frame = getattr(ak, method)()
            rows = [(str(r['代码']), str(r['名称']), 'akshare:' + method) for _, r in frame.iterrows()]
            if len(assemble(rows)) >= 1000:
                return rows, method
            errors.append(method + ': returned less than 1000 symbols')
        except Exception as ex:
            errors.append(method + ': ' + str(ex)[:150])
    raise RuntimeError('; '.join(errors))


def from_eastmoney():
    """Direct HK spot list fallback. The Eastmoney endpoint may change."""
    import urllib.parse
    import urllib.request
    rows = []
    seen = set()
    for pn in range(1, 30):
        params = urllib.parse.urlencode({
            'pn': pn, 'pz': 500, 'po': 1, 'np': 1,
            'ut': 'bd1d9ddb04089700cf9c27f6f7426281',
            'fid': 'f12', 'fltt': 2, 'invt': 2,
            'fs': 'm:116,m:113,m:114,m:115,m:128', 'fields': 'f12,f14',
        })
        req = urllib.request.Request('https://push2.eastmoney.com/api/qt/clist/get?' + params,
                                     headers={'User-Agent': 'Mozilla/5.0', 'Referer': 'https://quote.eastmoney.com/'})
        with urllib.request.urlopen(req, timeout=35) as resp:
            payload = resp.read(5_000_000)
        data = json.loads(payload).get('data') or {}
        entries = data.get('diff') or []
        if isinstance(entries, dict):
            entries = list(entries.values())
        if not entries:
            break
        for entry in entries:
            code = normalize_hk_code(entry.get('f12', ''))
            name = str(entry.get('f14') or '').strip()
            if code and name and code not in seen:
                rows.append((code, name, 'eastmoney:hk_clist'))
                seen.add(code)
        if len(entries) < 500:
            break
    if len(assemble(rows)) < 1000:
        raise RuntimeError(f'Eastmoney HK list returned only {len(assemble(rows))} codes')
    return rows, 'eastmoney:hk_clist'


def write_snapshot(rows, output, minimum=1000, source='test'):
    records = assemble(rows)
    if len(records) < minimum:
        raise ValueError(f'HK universe too small: {len(records)} < {minimum}')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with (output / 'hk_universe.tsv').open('w', encoding='utf-8', newline='') as stream:
        wr = csv.writer(stream, delimiter='\t', lineterminator='\n')
        wr.writerow(['code', 'name', 'exchange', 'source'])
        for code in sorted(records):
            wr.writerow(records[code])
    (output / 'hk_universe_meta.json').write_text(json.dumps({
        'source': source, 'downloaded_at_utc': datetime.now(timezone.utc).isoformat(),
        'count': len(records), 'market': 'HK',
        'coverage_note': 'Current public roster only; delisted securities are not covered. CSV is a third-party replication of HKEX current listings; date of original list is not independently verified.'
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    return len(records)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--min-count', type=int, default=1000)
    parser.add_argument('--fixture', help='only for offline tests, never production')
    parser.add_argument('--test-mode', action='store_true')
    a = parser.parse_args(argv)
    if a.fixture:
        if not a.test_mode:
            raise SystemExit('::error::Production HK roster cannot use test fixture')
        with open(a.fixture, encoding='utf-8') as f:
            rows = [(r['code'], r['name'], 'test_fixture') for r in csv.DictReader(f)]
        source = 'test_fixture'
    else:
        errors = []
        for name, fn in (('HKEX_GitHub_CSV', from_hkex_github_csv), ('AKShare', from_akshare), ('Eastmoney', from_eastmoney)):
            try:
                rows, detail = fn()
                if len(assemble(rows)) >= a.min_count:
                    source = name + ':' + detail
                    break
                errors.append(name + ': below threshold')
            except Exception as ex:
                errors.append(name + ': ' + str(ex)[:250])
        else:
            raise SystemExit('::error::HK catalog download FAILED; refusing empty APK. ' + ' | '.join(errors))
    count = write_snapshot(rows, a.output, minimum=a.min_count, source=source)
    print('Real HK spot universe:', count, source)


if __name__ == '__main__':
    main()
