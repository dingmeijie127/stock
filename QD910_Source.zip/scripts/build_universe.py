"""Obtain an actual A-share roster BEFORE producing the APK.

Do not fabricate a universe from numeric ticker ranges. If a verified roster is
unavailable, fail the build rather than ship an APK that always says 'empty'.
"""
import argparse
import csv
import json
import re
import sys
from datetime import date, timedelta, datetime, timezone
from pathlib import Path


def normalize_code(raw: str):
    raw = str(raw).strip().lower()
    if raw.endswith('.0') and raw[:-2].isdigit():
        raw = raw[:-2]
    if raw.startswith(('sh.', 'sz.', 'bj.')):
        exchange, ticker = raw[:2].upper(), raw[3:]
    elif re.fullmatch(r'\d{6}', raw):
        ticker = raw
        exchange = ('BJ' if ticker.startswith(('4', '8', '92')) else
                    'SH' if ticker.startswith('6') else 'SZ')
    else:
        return None
    if not re.fullmatch(r'\d{6}', ticker):
        return None
    valid = ((exchange == 'SH' and ticker.startswith('6')) or
             (exchange == 'SZ' and ticker.startswith(('0', '3')) and not ticker.startswith('399')) or
             (exchange == 'BJ' and ticker.startswith(('4', '8', '92'))))
    if not valid:
        return None
    return (ticker, exchange)


def assemble(rows):
    universe = {}
    for raw_code, raw_name, source in rows:
        code = normalize_code(raw_code)
        name = str(raw_name or '').strip().replace('\t', ' ').replace('\r', ' ').replace('\n', ' ')
        if code and name and name not in ('--', 'None', 'nan'):
            ticker, ex = code
            if ticker not in universe:
                universe[ticker] = dict(code=ticker, name=name, exchange=ex, source=source)
    return universe


def from_baostock():
    import baostock as bs
    login = bs.login()
    if login.error_code != '0':
        raise RuntimeError('baostock login: ' + login.error_msg)
    try:
        for age in range(0, 16):
            d = date.today() - timedelta(days=age)
            if d.weekday() > 4:
                continue
            result = bs.query_all_stock(d.isoformat())
            if result.error_code != '0':
                continue
            rows = []
            while result.next():
                fields = dict(zip(result.fields, result.get_row_data()))
                rows.append((fields.get('code',''), fields.get('code_name',''), 'baostock:'+d.isoformat()))
            universe = assemble(rows)
            if len(universe) >= 3500:
                return list((x['code'],x['name'],x['source']) for x in universe.values()), d.isoformat()
        raise RuntimeError('baostock: recent market sessions failed 3500 stock validation')
    finally:
        bs.logout()


def from_akshare():
    import akshare as ak
    errors = []
    for method, code_col, name_col in [
        ('stock_info_a_code_name','code','name'),
        ('stock_zh_a_spot_em','代码','名称'),
    ]:
        try:
            df = getattr(ak, method)()
            rows = [(str(row[code_col]), str(row[name_col]), 'akshare:'+method) for _,row in df.iterrows()]
            if len(assemble(rows)) >= 3500:
                return rows, date.today().isoformat()
            errors.append(method+':too_few')
        except Exception as e:
            errors.append(method+':'+str(e)[:180])
    raise RuntimeError('; '.join(errors))



def from_github_snapshot():
    """Independent public weekly A-share roster fallback; source is auditable."""
    import urllib.request
    url='https://raw.githubusercontent.com/guidebee/china-stock-data/main/data/company/companies.json'
    req=urllib.request.Request(url, headers={'User-Agent':'QuantDesk/8.8 (open source personal A-share data builder)'})
    with urllib.request.urlopen(req, timeout=35) as fd:
        payload=fd.read(8_000_000)
    items=json.loads(payload)
    if isinstance(items,dict):
        items=items.get('companies',items.get('data',[]))
    rows=[]
    for item in items:
        if item.get('stock_type') not in ('sh_a','sz_a','kcb','hs_bjs'):
            continue
        symbol=str(item.get('symbol','')).lower()
        code=normalize_code(symbol[:2]+'.'+symbol[2:]) if re.fullmatch(r'(sh|sz|bj)\d{6}',symbol) else normalize_code(item.get('code',''))
        if code and item.get('name'):
            rows.append((code[0],item['name'],'github:guidebee/china-stock-data'))
    if len(assemble(rows))<3500:
        raise RuntimeError('Public GitHub snapshot did not meet 3500 ticker threshold')
    return rows,date.today().isoformat()+' (weekly snapshot provider; upstream date unverified)'

def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--output', required=True)
    p.add_argument('--min-count', type=int, default=3500)
    p.add_argument('--fixture', help='ONLY for offline unit tests, never real builds')
    p.add_argument('--test-mode', action='store_true')
    args = p.parse_args(argv)
    if args.fixture:
        if not args.test_mode:
            raise SystemExit('Fixture cannot be used in release build')
        with open(args.fixture, encoding='utf-8', newline='') as fd:
            rows = [(r['code'],r['name'],'test_fixture') for r in csv.DictReader(fd)]
        snapshot = 'test-only'
        provider = 'test_fixture'
    else:
        failures=[]
        rows=[]
        for name, collector in [('BaoStock',from_baostock), ('AKShare',from_akshare), ('GitHubStockSnapshot',from_github_snapshot)]:
            try:
                rows,snapshot=collector()
                if len(assemble(rows))>=args.min_count:
                    provider=name
                    break
                failures.append(name+':insufficient securities')
            except Exception as e:
                failures.append(name+':'+str(e)[:350])
        else:
            raise SystemExit('::error::Failed to fetch REAL A-share universe. '+' | '.join(failures))
    unique=assemble(rows)
    if len(unique)<args.min_count:
        raise SystemExit(f'::error::Universe too small: {len(unique)} < {args.min_count}')
    if not args.test_mode and (sum(1 for item in unique.values() if item['exchange']=='SH')<1000 or
                               sum(1 for item in unique.values() if item['exchange']=='SZ')<1500):
        raise SystemExit('::error::SH/SZ exchange coverage sanity check failed')
    root=Path(args.output)
    root.mkdir(parents=True, exist_ok=True)
    with (root/'universe.tsv').open('w',encoding='utf-8',newline='') as fd:
        writer=csv.writer(fd, delimiter='\t',lineterminator='\n')
        writer.writerow(['code','name','exchange','source'])
        for key in sorted(unique):
            item=unique[key]
            writer.writerow([item['code'],item['name'],item['exchange'],item['source']])
    meta=dict(source=provider, as_of=snapshot, generated_at=datetime.now(timezone.utc).isoformat(), count=len(unique),
              note='Point-in-time currently available listing, NOT historical delisted universe')
    (root/'universe_meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print('A-share roster:',meta)
    return len(unique)


if __name__ == '__main__':
    main()
