package com.quantdesk.download;

/** Pure Java daily OHLCV, validated before SQLite commit. */
public final class Bar {
    public final String date, source, raw, volumeUnit;
    public final double open,high,low,close,volume;
    public final Double amount;
    public Bar(String date,double open,double high,double low,double close,double volume,Double amount,
               String source,String volumeUnit,String raw) {
        if(!date.matches("\\d{4}-\\d{2}-\\d{2}"))throw new IllegalArgumentException("bad date");
        if(!Double.isFinite(open)||!Double.isFinite(high)||!Double.isFinite(low)||!Double.isFinite(close)||
           !Double.isFinite(volume)||low<=0||high<low||open<low-0.00001||open>high+0.00001||
           close<low-0.00001||close>high+0.00001||volume<0)
           throw new IllegalArgumentException("bad OHLCV");
        this.date=date;this.open=open;this.high=high;this.low=low;this.close=close;
        this.volume=volume;this.amount=amount;this.source=source;this.volumeUnit=volumeUnit;this.raw=raw;
    }
    /** Eastmoney: date,open,close,high,low,volume,amount,...; volume is lots (100 shares). */
    public static Bar eastmoney(String raw) {
        String[] p=raw.split(",",-1);
        if(p.length<7)throw new IllegalArgumentException("bad eastmoney fields");
        Double amount=p[6].isEmpty()||p[6].equals("-")?null:Double.valueOf(p[6]);
        return new Bar(p[0],Double.parseDouble(p[1]),Double.parseDouble(p[3]),Double.parseDouble(p[4]),
                       Double.parseDouble(p[2]),Double.parseDouble(p[5]),amount,"eastmoney","LOTS_100_SHARES",raw);
    }
}
