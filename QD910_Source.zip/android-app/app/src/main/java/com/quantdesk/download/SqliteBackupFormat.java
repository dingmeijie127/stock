package com.quantdesk.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;

/** Reject HTML, ZIP, empty/truncated documents before the Android SQLite driver opens them. */
public final class SqliteBackupFormat {
    private static final byte[] MAGIC={ 'S','Q','L','i','t','e',' ','f','o','r','m','a','t',' ','3',0 };
    private SqliteBackupFormat(){}
    public static void requireValidFile(File f) throws IOException {
        if(f==null || !f.isFile() || f.length()<100)throw new IOException("这不是有效的SQLite数据库文件（过小或不存在）");
        try(FileInputStream in=new FileInputStream(f)){
            byte[] got=new byte[16];
            int len=0,n;
            while(len<got.length && (n=in.read(got,len,got.length-len))!=-1)len+=n;
            if(!Arrays.equals(got,MAGIC))throw new IOException("文件不是SQLite数据库，请选择从QuantDesk导出的.sqlite3文件，不要选ZIP或TXT");
        }
    }
}
