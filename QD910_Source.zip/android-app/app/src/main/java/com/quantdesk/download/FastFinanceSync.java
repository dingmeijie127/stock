package com.quantdesk.download;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Bounded incremental financial *follow-up*, never a falsely completed full-market audit.
 *  Existing dataset_rows and successful per-company checkpoints are always reused.
 */
public final class FastFinanceSync {
    private static final int MAX_REQUESTS=100, PARALLEL=4, INFLIGHT=4;
    private static final long RESERVE_MS=35_000;
    private FastFinanceSync(){}
    public interface Continue { boolean active(); }
    public static final class Result {
        public int attempted,saved,failed,pending,unchanged,empty;
    }
    private static final class Job {
        final MarketDb.Security security;
        final String dataset;
        final LocalDate start,end;
        Job(MarketDb.Security security,String dataset,LocalDate start,LocalDate end){
            this.security=security;this.dataset=dataset;this.start=start;this.end=end;
        }
        String market(){return "HK".equals(security.exchange)?"HK":"A";}
    }
    private static final class Response {
        final Job job;final List<JSONObject> rows;final String error;
        Response(Job job,List<JSONObject> rows,String error){this.job=job;this.rows=rows;this.error=error;}
    }
    private static Future<Response> submit(CompletionService<Response> queue,Job job){
        return queue.submit(()->{
            try{
                return new Response(job,FinancialSources.fetch(job.dataset,job.security.code,
                    job.security.exchange,job.start,job.end),null);
            }catch(Exception ex){
                String message=ex.getClass().getSimpleName()+":"+String.valueOf(ex.getMessage());
                return new Response(job,null,message.length()>300?message.substring(0,300):message);
            }
        });
    }
    /** Executes only items DUE by the persisted database checkpoint; cap limits requests,
     *  not completeness. After the cap, remaining companies keep their previous status. */
    public static Result run(Context context,MarketDb db,long endMs,Continue keepGoing) throws Exception {
        Result result=new Result();
        long end=Math.max(0,endMs-RESERVE_MS);
        LocalDate today=LocalDate.now(ZoneId.of("Asia/Shanghai"));
        LocalDate baseline=today.minusYears(2);
        long now=System.currentTimeMillis();
        Map<String,MarketDb.FinanceCheckpoint> checked=db.financeCheckpoints();
        SharedPreferences circuit=context.getSharedPreferences("qd_finance_market_circuit",Context.MODE_PRIVATE);
        List<Job> a=new ArrayList<>(),hk=new ArrayList<>();
        for(MarketDb.Security security:db.allSecurities()){
            String market="HK".equals(security.exchange)?"HK":"A";
            for(String dataset:FinancialSources.datasetsFor(security.exchange)){
                MarketDb.FinanceCheckpoint cp=checked.get(security.code+"|"+dataset);
                if(cp!=null&&!FinanceRefreshPolicy.due(cp.status,cp.checkedAt,now,dataset)){
                    result.unchanged++;continue;
                }
                // Error circuit reduces repeated calls while source is demonstrably broken.
                if(circuit.getLong("until_"+market,0)>now){result.pending++;continue;}
                LocalDate start=FinanceRefreshPolicy.requestStart(baseline,today,
                    cp==null?null:cp.lastSuccessfulEnd);
                Job job=new Job(security,dataset,start,today);
                if("HK".equals(market))hk.add(job);else a.add(job);
            }
        }
        List<Job> due=new ArrayList<>(a.size()+hk.size());
        for(int i=0;i<Math.max(a.size(),hk.size());i++){
            if(i<a.size())due.add(a.get(i));
            if(i<hk.size())due.add(hk.get(i));
        }
        if(due.isEmpty()){
            db.log("FINANCE_FAST","本次无到期财报请求；缓存/冷却跳过 "+result.unchanged+
                " 项，延期 "+result.pending+" 项");
            return result;
        }
        ExecutorService pool=Executors.newFixedThreadPool(PARALLEL);
        CompletionService<Response> completion=new ExecutorCompletionService<>(pool);
        List<Future<Response>> inflight=new ArrayList<>();
        int next=0,failA=0,failHK=0;boolean stopA=false,stopHK=false;
        int max=Math.min(MAX_REQUESTS,due.size());
        try{
            while(next<max && inflight.size()<INFLIGHT && keepGoing.active()&&System.currentTimeMillis()<end)
                inflight.add(submit(completion,due.get(next++)));
            while(!inflight.isEmpty() && keepGoing.active()&&System.currentTimeMillis()<end){
                Future<Response> f=completion.poll(500,TimeUnit.MILLISECONDS);
                if(f==null)continue;
                inflight.remove(f);
                Response r=f.get();result.attempted++;
                String market=r.job.market();
                if(r.error!=null){
                    result.failed++;
                    db.dataFailure(r.job.security.code,r.job.dataset,r.job.start.toString(),today.toString(),r.error);
                    if("HK".equals(market))failHK++;else failA++;
                    if(("HK".equals(market)?failHK:failA)==8){
                        if("HK".equals(market))stopHK=true;else stopA=true;
                        circuit.edit().putLong("until_"+market,System.currentTimeMillis()+6*3600_000L).apply();
                        db.log("FINANCE_ERROR",market+" 财报接口连续失败8次，本轮停止该市场其余请求，冷却6小时");
                    }
                    if(result.failed<=6)db.log("FINANCE_ERROR",market+":"+r.job.security.code+" "+r.error);
                }else{
                    if("HK".equals(market))failHK=0;else failA=0;
                    if(r.rows.isEmpty()){
                        result.empty++;
                        db.saveEmptyDataJob(r.job.security.code,r.job.dataset,r.job.start.toString(),today.toString());
                    }else{
                        result.saved+=db.saveData(r.job.security.code,r.job.dataset,
                            r.job.start.toString(),today.toString(),r.rows);
                    }
                }
                if(result.attempted%20==0)
                    db.financeState("running","","增量财报联网 "+result.attempted+
                        "/"+due.size()+" 项，新增 "+result.saved+" 行，失败 "+result.failed,
                        due.size(),result.attempted,result.failed);
                while(next<max && inflight.size()<INFLIGHT && keepGoing.active() && System.currentTimeMillis()<end){
                    Job candidate=due.get(next++);
                    if(("A".equals(candidate.market())&&stopA)||("HK".equals(candidate.market())&&stopHK))continue;
                    inflight.add(submit(completion,candidate));
                }
            }
        }finally{
            for(Future<Response> f:inflight)f.cancel(true);
            pool.shutdownNow();
        }
        result.pending+=due.size()-result.attempted;
        String message="财报快更已联网 "+result.attempted+" 项；新增 "+result.saved+
            " 行；无数据 "+result.empty+" 项；失败 "+result.failed+
            " 项；到期但未检查 "+result.pending+" 项；缓存跳过 "+result.unchanged+
            " 项。限额/接口故障不会冒充财报全部完成";
        db.financeState(result.pending==0&&result.failed==0&&result.empty==0?"up_to_date":"partial",
            "",message,due.size(),result.attempted,result.failed);
        db.log("FINANCE_FAST",message);
        return result;
    }
}
