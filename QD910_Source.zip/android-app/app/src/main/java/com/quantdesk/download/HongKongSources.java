package com.quantdesk.download;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/** HK cash equity daily bars: Eastmoney unadjusted; Yahoo fallback may be split-adjusted.
 *  Preserve provider, units and raw payload for downstream audits. No invented rows.
 */
public final class HongKongSources {
    private HongKongSources(){}
    public static String normalized(String raw){
        if(raw==null||!raw.matches("[0-9]{1,5}"))throw new IllegalArgumentException("Invalid HK ticker");
        return ("00000"+raw).substring(raw.length());
    }
    public static String yahooSymbol(String raw){
        String normalized=normalized(raw);
        // Yahoo Finance uses 4-digit HK tickers like 0700.HK for HKEX 00700.HK.
        return (normalized.startsWith("0") ? normalized.substring(1) : normalized)+".HK";
    }
    public static String eastmoneySecid(String raw){return "116."+normalized(raw);}
    private static String date(LocalDate d){return d.toString().replace("-","");}
    /** Retry transport failures only; never silently replace missing/invalid market data. */
    private static String get(String url) throws Exception {return get(url,false);}
    private static String get(String url,boolean fast) throws Exception {
        IOException last=null;
        for(int attempt=0;attempt<(fast?1:2);attempt++){
            try{return getOnce(url,fast);}catch(IOException error){
                last=error;
                if(fast || attempt==1 || error.getMessage()!=null &&
                    (error.getMessage().contains("HTTP 400") || error.getMessage().contains("HTTP 404")))throw error;
                try{Thread.sleep(500L*(attempt+1));}
                catch(InterruptedException interrupt){Thread.currentThread().interrupt();throw new IOException("HK request interrupted",interrupt);}
            }
        }
        throw last;
    }
    private static String getOnce(String url,boolean fast) throws Exception {
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        // Fast incremental mode must not spend a minute on each failing endpoint.
        connection.setConnectTimeout(fast?3500:10000);connection.setReadTimeout(fast?5500:20000);
        connection.setUseCaches(false);connection.setRequestProperty("Connection","close");
        connection.setRequestProperty("Accept","application/json,text/plain,*/*");
        connection.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/122 Safari/537.36");
        if(url.contains("eastmoney.com"))connection.setRequestProperty("Referer","https://quote.eastmoney.com/");
        else if(url.contains("gtimg.cn"))connection.setRequestProperty("Referer","https://finance.qq.com/");
        else connection.setRequestProperty("Referer","https://finance.yahoo.com/");
        try{
            int status=connection.getResponseCode();
            if(status!=200)throw new IOException("HK HTTP "+status+" host="+connection.getURL().getHost());
            try(InputStream stream=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=stream.read(buffer))!=-1){
                    if(out.size()+n>4_000_000)throw new IOException("HK provider response too large");
                    out.write(buffer,0,n);
                }
                return out.toString("UTF-8");
            }
        }finally{connection.disconnect();}
    }
    public static List<Bar> parseEastmoney(JSONObject data,LocalDate start,LocalDate end) throws Exception{
        JSONArray records=data.optJSONArray("klines");
        if(records==null||records.length()==0)throw new IOException("HK Eastmoney daily list empty");
        List<Bar> bars=new ArrayList<>();
        for(int i=0;i<records.length();i++){
            String raw=records.getString(i);
            String[] p=raw.split(",",-1);
            if(p.length<7)throw new IOException("HK Eastmoney bad OHLC row");
            String day=p[0];
            if(day.compareTo(start.toString())<0||day.compareTo(end.toString())>0)continue;
            Double amount=p[6].isEmpty()||p[6].equals("-")?null:Double.valueOf(p[6]);
            // HK Eastmoney's HK historical volume is reported as shares (not A-share 100-share lots).
            bars.add(new Bar(day,Double.parseDouble(p[1]),Double.parseDouble(p[3]),Double.parseDouble(p[4]),
                Double.parseDouble(p[2]),Double.parseDouble(p[5]),amount,"eastmoney_hk","SHARES",raw));
        }
        if(bars.isEmpty())throw new IOException("HK Eastmoney no bars in date range");
        return bars;
    }
    public static DailySources.Result eastmoney(String code,LocalDate from,LocalDate to) throws Exception{
        return eastmoney(code,from,to,false);
    }
    private static DailySources.Result eastmoney(String code,LocalDate from,LocalDate to,boolean fast) throws Exception{
        String url="https://push2his.eastmoney.com/api/qt/stock/kline/get?secid="+eastmoneySecid(code)+
            "&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61"+
            "&klt=101&fqt=0&beg="+date(from)+"&end="+date(to)+
            "&lmt=900&ut="+DailySources.EAST_TOKEN;
        JSONObject root=new JSONObject(get(url,fast));
        JSONObject market=root.optJSONObject("data");
        if(market==null)throw new IOException("HK Eastmoney data empty rc="+root.optInt("rc",-1));
        List<Bar> bars=parseEastmoney(market,from,to);
        if(bars.size()>=900)throw new IOException("HK Eastmoney row cap; incomplete window");
        return new DailySources.Result(bars,"eastmoney_hk");
    }
    /** Parsed Yahoo quotes can contain nulls, zero prices or high/low inconsistencies for
     *  suspended/corporate-action sessions. Preserve only VALID observations; never
     *  poison an entire stock because of one row. skippedRows makes the batch incomplete. */
    public static final class Parsed {
        public final List<Bar> bars;
        public final int skippedRows;
        Parsed(List<Bar> bars,int skippedRows){this.bars=bars;this.skippedRows=skippedRows;}
    }
    public static Parsed parseYahooChecked(JSONObject root,LocalDate start,LocalDate end) throws Exception{
        JSONObject chart=root.optJSONObject("chart");
        if(chart==null)throw new IOException("HK Yahoo chart missing");
        JSONArray result=chart.optJSONArray("result");
        if(result==null||result.length()==0)throw new IOException("HK Yahoo result missing: "+String.valueOf(chart.optJSONObject("error")));
        JSONObject series=result.getJSONObject(0);
        JSONArray timestamps=series.optJSONArray("timestamp");
        if(timestamps==null||timestamps.length()==0)throw new IOException("HK Yahoo timestamps absent");
        JSONObject quote=series.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray opens=quote.getJSONArray("open"),highs=quote.getJSONArray("high"),
            lows=quote.getJSONArray("low"),closes=quote.getJSONArray("close"),volumes=quote.getJSONArray("volume");
        List<Bar> bars=new ArrayList<>();int skipped=0;
        for(int i=0;i<timestamps.length();i++){
            if(timestamps.isNull(i)){skipped++;continue;}
            String day=Instant.ofEpochSecond(timestamps.getLong(i)).atZone(ZoneId.of("Asia/Hong_Kong")).toLocalDate().toString();
            if(day.compareTo(start.toString())<0||day.compareTo(end.toString())>0)continue;
            if(i>=opens.length()||i>=highs.length()||i>=lows.length()||i>=closes.length()||i>=volumes.length()||
                opens.isNull(i)||highs.isNull(i)||lows.isNull(i)||closes.isNull(i)||volumes.isNull(i)){
                skipped++;continue;
            }
            try{
                double open=opens.getDouble(i),high=highs.getDouble(i),low=lows.getDouble(i),close=closes.getDouble(i),volume=volumes.getDouble(i);
                JSONObject raw=new JSONObject().put("timestamp",timestamps.getLong(i))
                    .put("open",open).put("high",high).put("low",low).put("close",close).put("volume",volume)
                    .put("adjustment_note","Yahoo provider OHLC; corporate-action adjustment requires independent verification");
                Bar bar=HKBarQuality.validOrNull(day,open,high,low,close,volume,null,"yahoo_hk","SHARES",raw.toString());
                if(bar==null){skipped++;continue;}
                bars.add(bar);
            }catch(org.json.JSONException|NumberFormatException error){skipped++;}
        }
        if(bars.isEmpty())throw new IOException("HK Yahoo no valid OHLCV; invalid_or_missing_rows="+skipped);
        return new Parsed(bars,skipped);
    }
    public static List<Bar> parseYahoo(JSONObject root,LocalDate start,LocalDate end) throws Exception{
        return parseYahooChecked(root,start,end).bars;
    }
    public static DailySources.Result yahoo(String code,LocalDate from,LocalDate to) throws Exception{
        return yahoo(code,from,to,false);
    }
    private static DailySources.Result yahoo(String code,LocalDate from,LocalDate to,boolean fast) throws Exception{
        String ticker=yahooSymbol(code);
        long start=from.atStartOfDay(ZoneId.of("Asia/Hong_Kong")).toEpochSecond();
        long end=to.plusDays(1).atStartOfDay(ZoneId.of("Asia/Hong_Kong")).toEpochSecond();
        String url="https://query1.finance.yahoo.com/v8/finance/chart/"+URLEncoder.encode(ticker,"UTF-8")+
            "?period1="+start+"&period2="+end+"&interval=1d";
        Parsed parsed=parseYahooChecked(new JSONObject(get(url,fast)),from,to);
        return new DailySources.Result(parsed.bars,"yahoo_hk",parsed.skippedRows);
    }
    /** Tencent's HK-SPECIFIC kline endpoint, not the A-share fqkline URL.
     *  Only the raw 'day' key is accepted. Never silently mix 'qfqday' adjusted
     *  prices with the already-saved unadjusted HK day series. */
    public static List<Bar> parseTencent(JSONObject root,String code,LocalDate start,LocalDate end) throws Exception{
        String symbol="hk"+normalized(code);
        JSONObject data=root.optJSONObject("data");
        JSONObject stock=data==null?null:data.optJSONObject(symbol);
        if(stock==null)throw new IOException("Tencent HK ticker missing "+symbol);
        JSONArray rows=stock.optJSONArray("day");
        if(rows==null||rows.length()==0)throw new IOException("Tencent HK has no unadjusted 'day' rows; adjusted series refused");
        List<Bar> bars=new ArrayList<>();int skipped=0;
        for(int i=0;i<rows.length();i++){
            JSONArray row=rows.optJSONArray(i);
            if(row==null||row.length()<6){skipped++;continue;}
            try{
                String day=row.getString(0);
                if(day.compareTo(start.toString())<0||day.compareTo(end.toString())>0)continue;
                Bar bar=HKBarQuality.validOrNull(day,row.getDouble(1),row.getDouble(3),row.getDouble(4),
                    row.getDouble(2),row.getDouble(5),null,"tencent_hk_unadjusted","TENCENT_HK_NATIVE",row.toString());
                if(bar==null){skipped++;continue;}
                bars.add(bar);
            }catch(org.json.JSONException|NumberFormatException e){skipped++;}
        }
        if(bars.isEmpty())throw new IOException("Tencent HK no valid unadjusted daily bars, skipped="+skipped);
        // The caller does not accept a partly invalid series as an audited complete history.
        if(skipped>0)throw new IOException("Tencent HK contains invalid unadjusted rows: "+skipped);
        return bars;
    }
    public static DailySources.Result tencent(String code,LocalDate from,LocalDate to) throws Exception{
        return tencent(code,from,to,false);
    }
    private static DailySources.Result tencent(String code,LocalDate from,LocalDate to,boolean fast) throws Exception{
        String url="https://web.ifzq.gtimg.cn/appstock/app/hkfqkline/get?param=hk"+normalized(code)+",day,,,750";
        String payload=get(url,fast).trim();
        if(!payload.startsWith("{")){
            int begin=payload.indexOf('{'),end=payload.lastIndexOf('}');
            if(begin<0||end<=begin)throw new IOException("Tencent HK returned neither JSON nor JSONP");
            payload=payload.substring(begin,end+1);
        }
        return new DailySources.Result(parseTencent(new JSONObject(payload),code,from,to),"tencent_hk_unadjusted");
    }
    public static DailySources.Result download(String code,LocalDate from,LocalDate to) throws Exception{
        return downloadInternal(code,from,to,false);
    }
    /** Short, non-retrying transport for the bounded five-minute daily job. */
    public static DailySources.Result downloadFast(String code,LocalDate from,LocalDate to) throws Exception{
        return downloadInternal(code,from,to,true);
    }
    private static DailySources.Result downloadInternal(String code,LocalDate from,LocalDate to,boolean fast) throws Exception{
        String em;
        try{return eastmoney(code,from,to,fast);}catch(Exception e){em=e.getClass().getSimpleName()+":"+e.getMessage();}
        String tencentError;
        try{return tencent(code,from,to,fast);}catch(Exception e){tencentError=e.getClass().getSimpleName()+":"+e.getMessage();}
        try{return yahoo(code,from,to,fast);}catch(Exception e){
            throw new IOException("HK eastmoney="+em+"; tencent="+tencentError+
                "; yahoo="+e.getClass().getSimpleName()+":"+e.getMessage());
        }
    }
}
