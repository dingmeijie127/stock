package com.quantdesk.download;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Public Eastmoney financial data. No Tushare account, API token or fabricated reports.
 *  Mainland: three statements by report period. HK: indicator snapshot & dividend events.
 *  IMPORTANT HK indicator fields are NOT a substitute for all three financial statements.
 */
public final class FinancialSources {
    public static final String[] DATASETS={"income","balancesheet","cashflow"};
    public static final String[] HK_DATASETS={"hk_indicator","hk_dividend"};
    public static String[] datasetsFor(String market){return "HK".equals(market)?HK_DATASETS:DATASETS;}
    private static final String A_ROOT="https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/";
    private static final String HK_ROOT="https://datacenter.eastmoney.com/securities/api/data/v1/get";
    private FinancialSources(){}

    /** Injectable transport enables end-to-end, fixture-driven tests without accessing live providers. */
    public interface Transport { String get(String url) throws Exception; }
    static final Transport NETWORK=url->{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (compatible; QuantDesk/9.0.5; personal data research)");
        c.setRequestProperty("Accept","application/json,text/html;q=0.9,*/*;q=0.8");
        try{
            int status=c.getResponseCode();if(status!=200)throw new IOException("HTTP "+status+" ("+new URL(url).getHost()+")");
            try(InputStream in=c.getInputStream();ByteArrayOutputStream buffer=new ByteArrayOutputStream()){
                byte[] b=new byte[8192];int n;
                while((n=in.read(b))>=0){if(buffer.size()+n>6_000_000)throw new IOException("Financial response over 6 MB");buffer.write(b,0,n);}
                return buffer.toString("UTF-8");
            }
        }finally{c.disconnect();}
    };
    private static String q(String v){try{return URLEncoder.encode(v,"UTF-8");}catch(Exception e){throw new IllegalStateException(e);}}
    public static String emCode(String code,String exchange){
        if("HK".equals(exchange)){
            if(!code.matches("[0-9]{5}"))throw new IllegalArgumentException("Invalid HK code");
            return code+".HK";
        }
        if(!code.matches("[0-9]{6}")||!("SH".equals(exchange)||"SZ".equals(exchange)||"BJ".equals(exchange)))
            throw new IllegalArgumentException("Invalid A-share code / exchange");
        return exchange+code;
    }
    private static String prefix(String dataset){
        switch(dataset){
            case "income":return "lrb";
            case "balancesheet":return "zcfzb";
            case "cashflow":return "xjllb";
            default:throw new IllegalArgumentException("Unverified public A dataset: "+dataset);
        }
    }
    public static List<JSONObject> fetch(String dataset,String code,String exchange,LocalDate start,LocalDate end) throws Exception{
        return fetch(dataset,code,exchange,start,end,NETWORK);
    }
    public static List<JSONObject> fetch(String dataset,String code,String exchange,LocalDate start,LocalDate end,Transport http) throws Exception{
        if(start.isAfter(end))throw new IllegalArgumentException("start after end");
        String symbol=emCode(code,exchange);
        if("HK".equals(exchange)){
            if(!"hk_indicator".equals(dataset)&&!"hk_dividend".equals(dataset))
                throw new IOException("HK full three financial statements are not verified in a public structured source; not marking complete: "+dataset);
            return fetchHK(dataset,code,start,end,http);
        }
        return fetchA(dataset,symbol,code,exchange,start,end,http);
    }
    private static String companyType(String html) throws IOException{
        Matcher input=Pattern.compile("<input\\b[^>]*\\bid\\s*=\\s*['\"]hidctype['\"][^>]*>",Pattern.CASE_INSENSITIVE).matcher(html);
        Matcher alternative=Pattern.compile("<input\\b[^>]*\\bvalue\\s*=\\s*['\"][^'\"]+['\"][^>]*\\bid\\s*=\\s*['\"]hidctype['\"][^>]*>",Pattern.CASE_INSENSITIVE).matcher(html);
        String tag;
        if(input.find())tag=input.group();else if(alternative.find())tag=alternative.group();
        else throw new IOException("Eastmoney company type missing; cannot safely request statement");
        Matcher value=Pattern.compile("\\bvalue\\s*=\\s*['\"]([0-9]+)['\"]",Pattern.CASE_INSENSITIVE).matcher(tag);
        if(!value.find())throw new IOException("Eastmoney hidctype missing numeric value");
        return value.group(1);
    }
    private static List<JSONObject> jsonArray(String text,String context) throws Exception{
        JSONObject json=new JSONObject(text);
        JSONArray rows=json.optJSONArray("data");
        if(rows==null)throw new IOException(context+" has no data array (provider changed or response empty)");
        if(rows.length()>2000)throw new IOException(context+" over row safety limit");
        List<JSONObject> result=new ArrayList<>();
        for(int i=0;i<rows.length();i++){
            JSONObject r=rows.optJSONObject(i);
            if(r==null)throw new IOException(context+" unexpected row "+i);
            result.add(r);
        }
        return result;
    }
    private static String onlyDate(String v){
        if(v==null)return "";
        Matcher m=Pattern.compile("^(\\d{4})[-/]?(\\d{2})[-/]?(\\d{2})").matcher(v);
        if(!m.find())return "";
        return m.group(1)+"-"+m.group(2)+"-"+m.group(3);
    }
    /** Record metadata is explicit; the original provider columns are preserved unchanged. */
    private static JSONObject verifiedRow(JSONObject original,String ticker,String provider,String periodField) throws Exception{
        JSONObject copy=new JSONObject(original.toString());
        String found=copy.optString("SECUCODE",copy.optString("ts_code",""));
        if(!found.isEmpty()&&!found.equalsIgnoreCase(ticker))throw new IOException("Provider symbol mismatch: "+found+" != "+ticker);
        String securityCode=copy.optString("SECURITY_CODE","");
        if(!securityCode.isEmpty()&&!securityCode.equals(ticker.split("\\.")[0]))
            throw new IOException("Provider SECURITY_CODE mismatch: "+securityCode+" != "+ticker);
        copy.put("ts_code",ticker);
        copy.put("_qd_provider",provider);
        copy.put("_qd_report_date",periodField);
        return copy;
    }
    private static List<JSONObject> fetchA(String dataset,String symbol,String code,String market,LocalDate start,LocalDate end,Transport http) throws Exception{
        String type=prefix(dataset),ticker=code+"."+market;
        String html=http.get(A_ROOT+"Index?type=web&code="+q(symbol.toLowerCase(Locale.ROOT)));
        String company=companyType(html);
        String base="?companyType="+q(company)+"&reportDateType=0&code="+q(symbol);
        List<JSONObject> dateRows=jsonArray(http.get(A_ROOT+type+"DateAjaxNew"+base),"report date "+dataset);
        LinkedHashSet<String> periods=new LinkedHashSet<>();
        for(JSONObject row:dateRows){
            String day=onlyDate(row.optString("REPORT_DATE",""));
            if(!day.isEmpty()&&day.compareTo(start.toString())>=0&&day.compareTo(end.toString())<=0)periods.add(day);
        }
        List<JSONObject> output=new ArrayList<>();List<String> all=new ArrayList<>(periods);
        for(int offset=0;offset<all.size();offset+=5){
            StringBuilder dates=new StringBuilder();
            for(int i=offset;i<Math.min(all.size(),offset+5);i++){if(dates.length()>0)dates.append(',');dates.append(all.get(i));}
            String url=A_ROOT+type+"AjaxNew"+base+"&reportType=1&dates="+q(dates.toString());
            List<JSONObject> rows=jsonArray(http.get(url),"report "+dataset);
            for(JSONObject row:rows){
                String day=onlyDate(row.optString("REPORT_DATE",""));
                if(day.isEmpty())throw new IOException("Financial row without report date: "+dataset);
                if(day.compareTo(start.toString())<0||day.compareTo(end.toString())>0)continue;
                output.add(verifiedRow(row,ticker,"eastmoney_public",day));
            }
        }
        return output;
    }
    private static List<JSONObject> fetchHK(String dataset,String code,LocalDate start,LocalDate end,Transport http) throws Exception{
        boolean dividend="hk_dividend".equals(dataset);
        String report=dividend?"RPT_HKF10_MAIN_DIVBASIC":"RPT_CUSTOM_HKF10_FN_MAININDICATORMAX";
        String filter=dividend?"(SECURITY_CODE=\""+code+"\")(IS_BFP=\"0\")":"(SECUCODE=\""+code+".HK\")";
        // Explicit columns and sort keys mirror the publicly documented Eastmoney F10 schema.
        String columns=dividend?
            "SECURITY_CODE,UPDATE_DATE,REPORT_TYPE,EX_DIVIDEND_DATE,DIVIDEND_DATE,TRANSFER_END_DATE,YEAR,PLAN_EXPLAIN,IS_BFP":
            "ORG_CODE,SECUCODE,SECURITY_CODE,SECURITY_NAME_ABBR,SECURITY_INNER_CODE,REPORT_DATE,BASIC_EPS,"+
            "PER_NETCASH_OPERATE,BPS,BPS_NEDILUTED,COMMON_ACS,PER_SHARES,ISSUED_COMMON_SHARES,HK_COMMON_SHARES,"+
            "TOTAL_MARKET_CAP,HKSK_MARKET_CAP,OPERATE_INCOME,OPERATE_INCOME_SQ,OPERATE_INCOME_QOQ,"+
            "OPERATE_INCOME_QOQ_SQ,HOLDER_PROFIT,HOLDER_PROFIT_SQ,HOLDER_PROFIT_QOQ,HOLDER_PROFIT_QOQ_SQ,PE_TTM,"+
            "PE_TTM_SQ,PB_TTM,PB_TTM_SQ,NET_PROFIT_RATIO,NET_PROFIT_RATIO_SQ,ROE_AVG,ROE_AVG_SQ,ROA,"+
            "ROA_SQ,DIVIDEND_TTM,DIVIDEND_LFY,DIVI_RATIO,DIVIDEND_RATE,IS_CNY_CODE";
        String url=HK_ROOT+"?reportName="+q(report)+"&columns="+q(columns)+"&filter="+q(filter)+
            "&pageNumber=1&pageSize=200&sortTypes="+q(dividend?"-1,-1":"-1")+
            "&sortColumns="+q(dividend?"NOTICE_DATE,EX_DIVIDEND_DATE":"REPORT_DATE")+
            "&source=F10&client=PC&quoteColumns=";
        JSONObject response=new JSONObject(http.get(url));
        JSONObject container=response.optJSONObject("result");
        if(container==null)throw new IOException("HK "+dataset+" missing result (cannot mark complete)");
        JSONArray items=container.optJSONArray("data");
        if(items==null)throw new IOException("HK "+dataset+" missing result.data");
        if(items.length()>=200)throw new IOException("HK "+dataset+" page cap reached; pagination required before completeness claim");
        List<JSONObject> result=new ArrayList<>();
        for(int i=0;i<items.length();i++){
            JSONObject row=items.optJSONObject(i);if(row==null)throw new IOException("HK invalid report row");
            String field=dividend?"EX_DIVIDEND_DATE":"REPORT_DATE";
            String when=onlyDate(row.optString(field,""));
            if(when.isEmpty())throw new IOException("HK report row lacks "+field);
            if(when.compareTo(start.toString())<0||when.compareTo(end.toString())>0)continue;
            result.add(verifiedRow(row,code+".HK","eastmoney_public",when));
        }
        return result;
    }
}
