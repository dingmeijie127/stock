package com.quantdesk.download;

import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
/** Pure-Java Hong Kong market-close scheduling. Android may deliver the work later. */
public final class ScheduleClock {
    private ScheduleClock(){}
    public static long delayToNextHKRun(ZonedDateTime now){
        ZonedDateTime local=now.withZoneSameInstant(ZoneId.of("Asia/Hong_Kong"));
        ZonedDateTime next=local.withHour(20).withMinute(30).withSecond(0).withNano(0);
        if(!next.isAfter(local))next=next.plusDays(1);
        return Duration.between(local,next).toMillis();
    }
}
