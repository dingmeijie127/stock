package com.quantdesk.download;

import java.time.LocalDate;

/** Append-only historical backfill: keep existing two-year bars intact across releases. */
public final class RangePlanner {
    private RangePlanner(){}
    /** Returns the first missing TAIL date, or null if latest data reaches target. */
    public static LocalDate nextDailyStart(LocalDate baseline,LocalDate end,String lastStored){
        if(lastStored==null||lastStored.isEmpty())return baseline;
        LocalDate next=LocalDate.parse(lastStored).plusDays(1);
        if(next.isAfter(end))return null;
        return next.isBefore(baseline)?baseline:next;
    }
    /** Both mainland and HK markets use UTC+08. Wait until after 19:00 for finalized EOD.
     * Weekends are excluded; official exchange holidays need a later gap audit.
     */
    public static LocalDate safeEndDay(java.time.ZonedDateTime nowHK) {
        java.time.ZonedDateTime cutoff = nowHK.withHour(19).withMinute(0).withSecond(0).withNano(0);
        LocalDate day = nowHK.toLocalDate();
        if(nowHK.isBefore(cutoff)) day = day.minusDays(1);
        while(day.getDayOfWeek().getValue() >= 6) day = day.minusDays(1);
        return day;
    }
    /** Allow a two-week overlap for corrections; nothing before baseline re-downloads. */
    public static LocalDate nextDatasetStart(LocalDate baseline,LocalDate end,String previousJobEnd){
        if(previousJobEnd==null||previousJobEnd.isEmpty())return baseline;
        LocalDate previous=LocalDate.parse(previousJobEnd);
        if(!previous.isBefore(end))return null;
        LocalDate overlap=previous.minusDays(14);
        return overlap.isBefore(baseline)?baseline:overlap;
    }
}
