package com.quantdesk.download;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.util.concurrent.TimeUnit;

/** User opt-in, persistent, inexact 24-hour HK-close sync. */
public final class DailyUpdateScheduler {
    static final String PERIODIC="quantdesk_ah_daily_v902", CATCHUP="quantdesk_ah_catchup_v902";
    static final String PREF="qd_auto_update", ENABLED="enabled";
    private DailyUpdateScheduler(){}
    public static boolean enabled(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(ENABLED,false);}
    static Constraints constraints(){return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();}
    public static void setEnabled(Context c,boolean isEnabled){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean(ENABLED,isEnabled).apply();
        if(isEnabled)schedule(c);else{
            WorkManager.getInstance(c).cancelUniqueWork(PERIODIC);
            WorkManager.getInstance(c).cancelUniqueWork(CATCHUP);
        }
    }
    public static void ensureScheduled(Context c){if(enabled(c))schedule(c);}
    private static void schedule(Context c){
        long delay=ScheduleClock.delayToNextHKRun(ZonedDateTime.now());
        PeriodicWorkRequest work=new PeriodicWorkRequest.Builder(DailyUpdateWorker.class,24,TimeUnit.HOURS)
            .setConstraints(constraints())
            .setInitialDelay(delay,TimeUnit.MILLISECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.MINUTES)
            .build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(PERIODIC,ExistingPeriodicWorkPolicy.KEEP,work);
    }
    /** Ordinary tap must not clear the same-day failure circuit breaker. */
    public static void runOnce(Context c){
        OneTimeWorkRequest work=new OneTimeWorkRequest.Builder(DailyUpdateWorker.class)
            .setConstraints(constraints())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.MINUTES).build();
        WorkManager.getInstance(c).enqueueUniqueWork(CATCHUP,ExistingWorkPolicy.KEEP,work);
    }
    /** User explicitly asks to re-open failed quote sources after network has recovered. */
    public static void retryFailuresOnce(Context c){
        if(!MarketDb.IMPORT_IN_PROGRESS.get() && !HarvestService.RUNNING.get()){
            String day=RangePlanner.safeEndDay(ZonedDateTime.now(ZoneId.of("Asia/Hong_Kong"))).toString();
            try(MarketDb db=new MarketDb(c)){
                int count=db.resetFastTransientFailures(day);
                db.log("AUTO_FAST","强制重试 "+count+" 只当日失败/无数据股票；不会删除已存K线");
            }
        }
        runOnce(c);
    }
    static void enqueueNext(Context c,long delayMs){
        OneTimeWorkRequest work=new OneTimeWorkRequest.Builder(DailyUpdateWorker.class)
            .setConstraints(constraints())
            .setInitialDelay(delayMs,TimeUnit.MILLISECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.MINUTES)
            .build();
        // APPEND_OR_REPLACE permits a running batch to append its next batch, not cancel itself.
        WorkManager.getInstance(c).enqueueUniqueWork(CATCHUP,ExistingWorkPolicy.APPEND_OR_REPLACE,work);
    }
}
