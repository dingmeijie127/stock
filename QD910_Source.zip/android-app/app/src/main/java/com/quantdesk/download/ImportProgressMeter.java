package com.quantdesk.download;

/** Pure progress math. The last 1% is reserved until the import has committed. */
public final class ImportProgressMeter {
    private ImportProgressMeter(){}
    /** 0..10% for copying; -1 for unknown source length (show spinner). */
    public static int copyPercent(long copied,long expected){
        if(expected<=0)return -1;
        if(copied<=0)return 0;
        return (int)Math.min(10,Math.floor(10.0*copied/expected));
    }
    /** 15..99% for merge (the SQLite validation phase is indeterminate). */
    public static int mergePercent(long inspected,long total){
        if(total<=0)return 15;
        if(inspected<=0)return 15;
        return (int)Math.min(99,15+Math.floor(84.0*inspected/total));
    }
}
