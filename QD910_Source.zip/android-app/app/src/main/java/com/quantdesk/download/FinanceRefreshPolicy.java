package com.quantdesk.download;

import java.time.LocalDate;

/** Financial providers are report-period sources, not live tick feeds.
 *  Database row de-duplication alone is NOT request de-duplication.
 */
public final class FinanceRefreshPolicy {
    private static final long DAY_MS=86400000L;
    private FinanceRefreshPolicy(){}
    /** Back off unsuccessful sources; don't retry failed/empty requests on every tap.
     *  Reporting season still gets a weekly successful-data refresh.
     */
    public static long retryAfterMillis(String status,String dataset){
        if ("failed".equals(status)) return DAY_MS;
        if ("empty".equals(status)) return 7L*DAY_MS;
        if ("complete".equals(status)) return dataset.startsWith("hk_") ? 14L*DAY_MS : 7L*DAY_MS;
        return 0;
    }
    public static boolean due(String status,long checkedAt,long now,String dataset){
        return status==null || checkedAt<=0 || now<checkedAt ||
            now-checkedAt>=retryAfterMillis(status,dataset);
    }
    /** First successful scan gets two years. Subsequent scheduled scans need only
     *  a rolling 15-month report-period window (late publications/revisions).
     *  Older restatements need a separate, deliberate full audit, not every tap.
     */
    public static LocalDate requestStart(LocalDate baseline,LocalDate today,String lastSuccessfulEnd){
        if(lastSuccessfulEnd==null||lastSuccessfulEnd.isEmpty())return baseline;
        LocalDate overlap=today.minusMonths(15);
        return overlap.isAfter(baseline)?overlap:baseline;
    }
}
