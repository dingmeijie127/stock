package com.quantdesk.download;

/** Reject a malformed third-party trading day without aborting a valid whole series. */
public final class HKBarQuality {
    private HKBarQuality(){}
    public static Bar validOrNull(String day,double open,double high,double low,double close,
            double volume,Double amount,String source,String volumeUnit,String raw){
        try {return new Bar(day,open,high,low,close,volume,amount,source,volumeUnit,raw);}
        catch(IllegalArgumentException invalid){return null;}
    }
}
