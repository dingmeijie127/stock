"""GitHub Actions live network canary for HK raw daily bars.

This is not an Android device integration test; a pass only proves a GitHub
runner can parse legitimate historical HK daily data from one provider.
"""
import json
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

CODE = '00700'
URLS = [
    ('tencent_hkfq', f'https://web.ifzq.gtimg.cn/appstock/app/hkfqkline/get?param=hk{CODE},day,,,20'),
    ('tencent_fq', f'https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=hk{CODE},day,,,20'),
    ('eastmoney_hk', 'https://push2his.eastmoney.com/api/qt/stock/kline/get?'
     f'secid=116.{CODE}&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57'
     '&klt=101&fqt=0&beg=20261001&end=20501231&lmt=20&ut=bd1d9ddb04089700cf9c27f6f7426281'),
]

def parse(provider, data):
    if provider.startswith('tencent'):
        start, end = data.find('{'), data.rfind('}')
        if start < 0 or end <= start:
            raise ValueError('Tencent response missing JSON object')
        obj = json.loads(data[start:end+1])
        node = (obj.get('data') or {}).get('hk'+CODE) or {}
        bars = node.get('day') or []
        if not bars and node.get('qfqday'):
            raise ValueError('only adjusted qfqday available: refuse mixing into raw SQLite')
    else:
        obj = json.loads(data)
        bars = (obj.get('data') or {}).get('klines') or []
    if not bars:
        raise ValueError('no unadjusted daily K bars')
    dates = [b.split(",",1)[0] if isinstance(b,str) else b[0] for b in bars]
    if not all(re.fullmatch(r'\d{4}-\d{2}-\d{2}', str(d)) for d in dates):
        raise ValueError('invalid date(s)')
    return len(bars), str(dates[-1])

def main():
    good = []
    for name, url in URLS:
        try:
            req = Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Referer': 'https://quote.eastmoney.com/',
                                        'Accept': 'application/json,text/plain,*/*'})
            with urlopen(req, timeout=8) as response:
                payload = response.read(1_000_001)
                if len(payload)>1_000_000: raise ValueError('provider response too long')
                body = payload.decode('utf-8', errors='replace')
                count, day = parse(name, body)
                print(f'PASS {name}: {count} historical raw daily bars, newest={day}')
                good.append(name)
        except Exception as error:
            print(f'FAIL {name}: {type(error).__name__}: {error}')
    if not good:
        print('::error::No live HK provider returned unadjusted day bars; refuse to label this build network-verified.')
        return 1
    print('GitHub runner live HK provider canary passed:', ', '.join(good))
    return 0

if __name__=='__main__':
    sys.exit(main())
