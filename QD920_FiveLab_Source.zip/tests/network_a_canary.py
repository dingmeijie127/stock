"""Diagnostic GitHub runner probe; NOT required for APK compilation.
Only raw fqt=0 recent A-share historical data is accepted; no mock fallback.
"""
import json
from datetime import date,timedelta
from urllib.request import Request,urlopen


def probe(code,secid):
    end=date.today().strftime('%Y%m%d')
    start=(date.today()-timedelta(days=60)).strftime('%Y%m%d')
    url=('https://push2his.eastmoney.com/api/qt/stock/kline/get?'
         f'secid={secid}&fields1=f1,f2,f3,f4,f5,f6&'
         'fields2=f51,f52,f53,f54,f55,f56,f57&'
         f'klt=101&fqt=0&beg={start}&end={end}&lmt=90')
    req=Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':'https://quote.eastmoney.com/'})
    with urlopen(req,timeout=12) as response:
        if response.status!=200:
            raise ValueError(f'HTTP {response.status}')
        raw=response.read(300000)
    data=json.loads(raw).get('data') or {}
    candles=data.get('klines') or []
    if not candles:
        raise ValueError('no klines returned')
    fields=candles[-1].split(',')
    if len(fields)<7 or float(fields[2])<=0 or float(fields[3])<float(fields[4]):
        raise ValueError('last OHLC cannot be parsed')
    return code,len(candles),fields[0]


def main():
    good=0
    for code,secid in [('600519','1.600519'),('000001','0.000001')]:
        try:
            print('A_PROBE_OK:',probe(code,secid));good+=1
        except Exception as ex:
            print(f'::warning::A_PROBE_FAIL {code}: {type(ex).__name__} {str(ex)[:250]}')
    if not good:
        print('::warning::A-share live provider could not be verified from runner. APK can compile but is NOT network-verified.')
        raise SystemExit(1)
    print('A-share provider probe succeeded for',good,'/2 stocks. This does NOT prove mobile Android connectivity or SQLite write.')

if __name__=='__main__': main()
