"""Cache-first finance regression: imported financial records without job history.
Only asserts actual SQLite and pure-Java policy behavior; not provider connectivity.
"""
from pathlib import Path
import sqlite3, re, subprocess, tempfile

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'android-app/app/src/main/java/com/quantdesk/download'
DB=(SRC/'MarketDb.java').read_text()
FAST=(SRC/'FastFinanceSync.java').read_text()
FULL=(SRC/'HarvestService.java').read_text()


def test_imported_financial_rows_form_cache_even_without_data_jobs():
    c=sqlite3.connect(':memory:')
    for ddl in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB):
        c.execute(ddl)
    c.execute("INSERT INTO instruments VALUES('600519','贵州茅台','SH','legacy')")
    row=('600519','income','old-1','2026-06-30','2026-08-21','','legacy','{}',1)
    c.execute('INSERT INTO dataset_rows VALUES (?,?,?,?,?,?,?,?,?)',row)
    row2=('600519','income','old-2','2026-09-30','2026-10-24','','legacy','{}',2)
    c.execute('INSERT INTO dataset_rows VALUES (?,?,?,?,?,?,?,?,?)',row2)
    assert c.execute('SELECT COUNT(*) FROM data_jobs').fetchone()[0]==0
    sql=("SELECT r.code,r.dataset,MAX(REPLACE(REPLACE(SUBSTR(r.period,1,10),'-',''),'/','')),"+
         "MAX(r.received_at) FROM dataset_rows r JOIN instruments i ON i.code=r.code " +
         "WHERE i.exchange IN ('SH','SZ','BJ') GROUP BY r.code,r.dataset")
    assert "SELECT r.code,r.dataset,MAX(REPLACE(REPLACE(SUBSTR(r.period,1,10)" in DB
    assert "GROUP BY r.code,r.dataset" in DB
    assert c.execute(sql).fetchone()==('600519','income','20260930',2)
    assert 'checkpoint=new FinanceCheckpoint("cached",0L)' in DB
    for caller in (FAST,FULL):
        assert 'cp.hasSavedRows' in caller
        assert 'newReportPeriodMayExist(dataset,cp.lastSavedPeriod,today)' in caller
        assert 'requestMissingStart' in caller


def test_date_strings_from_both_legacy_and_current_imports_normalize():
    c=sqlite3.connect(':memory:')
    c.execute('CREATE TABLE dataset_rows (code TEXT,dataset TEXT,period TEXT,received_at INTEGER)')
    c.executemany('INSERT INTO dataset_rows VALUES (?,?,?,?)',[
        ('00700','hk_indicator','20250331',1),
        ('00700','hk_indicator','2025-09-30 00:00:00',2),
        ('00700','hk_indicator','20260331',3),
    ])
    sql=("SELECT MAX(REPLACE(REPLACE(SUBSTR(period,1,10),'-',''),'/','')) FROM dataset_rows")
    assert c.execute(sql).fetchone()[0]=='20260331'


def test_a_completed_quarter_is_reused_until_new_quarter_window():
    with tempfile.TemporaryDirectory() as work:
        subprocess.run(['javac','-d',work,str(SRC/'FinanceRefreshPolicy.java'),
                        str(ROOT/'tests/java/FinanceRefreshPolicyTest.java')],check=True)
        result=subprocess.run(['java','-cp',work,'com.quantdesk.download.FinanceRefreshPolicyTest'],
                              capture_output=True,text=True,check=True)
        assert 'passed' in result.stdout
