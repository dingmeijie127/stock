"""Regression checks for account-first interface, honest live quote and isolated paper ledger."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'

def test_portfolio_first_navigation_and_full_holdings():
    ui=(J/'PaperTradeActivity.java').read_text()
    for x in ('buildHome()','openAccount(int position)','openHome()','refreshStrategyRow',
              '当前参考估值','持仓成本','参考现价','持仓市值','quoteSource','买入日期','等待下一有效交易日日K',
              '真实模拟成交','待成交','成交金额','成交价','当前没有','报价'):
        assert x in ui,x
    assert '五策略量化实验室 V9.2.0' in ui
    assert 'String[]{"持仓","委托","成交","信号","战绩","诊断","流水"}' in ui

def test_price_provenance_and_segregation_from_execution():
    api=(J/'PaperLiveQuotes.java').read_text()
    store=(J/'PaperTradingStore.java').read_text()
    ui=(J/'PaperTradeActivity.java').read_text()
    assert 'https://qt.gtimg.cn/q=' in api and 'setReadTimeout' in api
    assert 'usable(Quote quote,String savedDay' in api
    assert '不写回账本' in ui and '不作为自动成交价格' in ui
    assert 'PaperLiveQuotes.fetch(codes)' in ui
    assert 'PaperLiveQuotes' not in store
    assert 'public List<FillView> fills(long account,int limit)' in store
    assert 'LEFT JOIN signals s' in store
    assert 'super(context,NAME,null,1)' in store

def test_version_signing_matching():
    g=(R/'android-app/app/build.gradle').read_text()
    w=(R/'.github/workflows/QD920_FiveLab_Build.yml').read_text()
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in g
    assert 'versionCode 920' in g
    assert 'QD920_FiveLab_Source.zip' in w
    assert "QD_FIVELAB01_KEYSTORE_B64" in w
    assert 'PaperLiveQuotesTest.java' in w and 'PaperLiveQuotes.java' in w
