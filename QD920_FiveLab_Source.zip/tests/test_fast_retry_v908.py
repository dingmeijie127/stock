"""V9.0.8 regression: retry failed stock without rewriting historical bars.
Public-provider availability cannot be validated by offline tests.
"""
from pathlib import Path
import re
import sqlite3

ROOT=Path(__file__).resolve().parents[1]
J=ROOT/'android-app/app/src/main/java/com/quantdesk/download'
DB=(J/'MarketDb.java').read_text()
WORK=(J/'DailyUpdateWorker.java').read_text()
SCH=(J/'DailyUpdateScheduler.java').read_text()
HK=(J/'HongKongSources.java').read_text()
DAILY=(J/'DailySources.java').read_text()


def database():
    db=sqlite3.connect(':memory:')
    for statement in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB):
        db.execute(statement)
    return db


def test_manual_retry_only_erases_a_transients_and_preserves_hk_and_price_data():
    db=database()
    day='2026-10-23'
    symbols=[('600519','SH','saved'),('000001','SZ','failed'),('600000','SH','stale'),
             ('00001','HK','failed'),('00005','HK','stale'),('00700','HK','partial'),('00002','HK','backfill')]
    for code,market,status in symbols:
        db.execute('INSERT INTO instruments VALUES (?,?,?,?)',(code,code,market,'real'))
        db.execute('INSERT INTO daily_bars VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                   (code,'2026-10-22',10,11,9,10,100,'SHARES',None,'test','existing'))
        db.execute('INSERT INTO auto_daily_attempts VALUES (?,?,?,?,?,?)',
                   (code,day,status,0,None,1))
    db.execute('INSERT INTO auto_daily_block VALUES (?,?,?)',(day,'HK','outage'))
    db.execute('INSERT INTO auto_daily_block VALUES (?,?,?)',(day,'A','outage'))
    # Capture BOTH concatenated string literals; the old test only read the first fragment.
    m=re.search(r'db\.execSQL\("(DELETE FROM auto_daily_attempts [^"]+)"\s*\+\s*"([^"]+)"',DB)
    assert m, 'A-only SQL missing'
    db.execute(m.group(1)+m.group(2),(day,))
    block=re.search(r'db\.execSQL\("(DELETE FROM auto_daily_block [^"]+)"',DB)
    assert block
    db.execute(block.group(1),(day,))
    remaining={code:status for code,status in db.execute('SELECT code,status FROM auto_daily_attempts')}
    assert remaining=={'600519':'saved','00001':'failed','00005':'stale',
                       '00700':'partial','00002':'backfill'}
    assert db.execute('SELECT market FROM auto_daily_block').fetchall()==[('HK',)]
    assert db.execute('SELECT COUNT(*) FROM daily_bars').fetchone()[0]==len(symbols)


def test_manual_retry_does_not_stack_jobs_and_refuses_false_complete():
    assert 'resetFastTransientFailures(day)' in SCH
    assert 'ExistingWorkPolicy.KEEP' in SCH
    assert 'Historical' not in SCH
    assert 'autoMissingBars(day)' in WORK
    assert 'missing==0&&unresolved==0&&blocked==0?"done":"partial"' in WORK
    assert 'DailySources.downloadFast(' in WORK
    assert 'saveFastTail' in WORK


def test_fast_transport_budget_does_not_change_historical_network_budget():
    assert 'fast?3500:10000' in HK
    assert 'fast?5500:20000' in HK
    assert 'attempt<(fast?1:2)' in HK
    assert 'downloadInternal(code,from,to,false)' in HK
    assert 'downloadInternal(code,from,to,true)' in HK
    assert 'fast?3500:9000' in DAILY
    assert 'fast?5500:17000' in DAILY
    assert 'downloadInternal(code,exchange,from,to,false)' in DAILY
    assert 'downloadInternal(code,exchange,from,to,true)' in DAILY
