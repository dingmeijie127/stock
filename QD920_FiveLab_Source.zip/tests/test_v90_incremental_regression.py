"""Regression: never stick to yesterday's interrupted window, never replace legacy DB."""
from pathlib import Path
from datetime import date, timedelta
import re, sqlite3

R=Path(__file__).resolve().parents[1]
JAVA=R/'android-app/app/src/main/java/com/quantdesk/download'
DB=(JAVA/'MarketDb.java').read_text()
S=(JAVA/'HarvestService.java').read_text()
P=(JAVA/'RangePlanner.java').read_text()

def test_new_day_is_not_frozen_by_old_error_or_pause():
    assert 'newEnd.equals(c.getString(1))' in DB
    assert 'new String[]{newStart,newEnd}' in DB
    assert 'RangePlanner.safeEndDay' in S

def test_no_reset_of_previous_downloaded_rows():
    assert 'DROP TABLE' not in DB and 'DELETE FROM daily_bars' not in DB
    assert 'HistoryGapPlanner.plan' in S
    assert 'db.barDays(code,from,to)' in S
    assert 'quantdesk-a-share-2y.sqlite3' in DB

def test_both_markets_supported_with_independent_providers():
    assert '"HK".equals(exchange)' in (JAVA/'DailySources.java').read_text()
    assert 'HongKongSources.download' in (JAVA/'DailySources.java').read_text()
    assert '"HK".equals(stock.exchange)' in S
    assert 'blocked.contains(market)' in S
    assert 'hk_universe.tsv' in (JAVA/'Universe.java').read_text()

def test_hk_financial_dataset_is_independent():
    finance=(JAVA/'FinancialSources.java').read_text()
    assert all(x in finance for x in ('hk_indicator','hk_dividend'))
    assert 'new TokenVault' not in S
    assert 'db.dataFailure' in S

def test_end_of_batch_audit_does_not_claim_exchange_calendar_complete():
    assert 'db.referenceDays("A",from,to)' in S and 'db.allASecurities()' in S
    assert 'market_audit' in DB and '并非逐交易日完整率' in DB
