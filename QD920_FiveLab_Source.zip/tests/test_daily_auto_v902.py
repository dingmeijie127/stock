"""Automatic daily incremental update: schema, checkpoint SQL, scheduler contracts.
No mocked HTTP response is presented as real market data.
"""
from pathlib import Path
import re,sqlite3

P=Path(__file__).resolve().parents[1]
J=P/'android-app/app/src/main/java/com/quantdesk/download'
DB=(J/'MarketDb.java').read_text()
WORK=(J/'DailyUpdateWorker.java').read_text()
SCH=(J/'DailyUpdateScheduler.java').read_text()
ACT=(J/'MainActivity.java').read_text()


def db():
    connection=sqlite3.connect(':memory:')
    for stmt in re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DB):
        connection.execute(stmt)
    return connection


def test_auto_tables_live_sqlite_and_old_history_retained():
    c=db()
    c.execute('INSERT INTO instruments VALUES(?,?,?,?)',('600519','茅台','SH','real'))
    c.execute('INSERT INTO instruments VALUES(?,?,?,?)',('00700','腾讯','HK','real'))
    old=('600519','2026-10-23',1,2,.5,1.5,100,'LOTS',None,'eastmoney','old bar')
    c.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',old)
    c.execute('INSERT INTO auto_daily_attempts VALUES(?,?,?,?,?,?)',('600519','2026-10-26','saved',1,None,1))
    c.execute('INSERT OR REPLACE INTO auto_daily_attempts VALUES(?,?,?,?,?,?)',('600519','2026-10-26','saved',1,None,2))
    assert c.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==1
    assert c.execute('SELECT count(*) FROM auto_daily_attempts').fetchone()[0]==1
    assert 'DROP TABLE' not in DB
    assert 'super(context,NAME,null,5)' in DB


def test_auto_checkpoint_excludes_completed_but_not_other_market():
    c=db()
    for code,exchange in [('600519','SH'),('000001','SZ'),('00700','HK'),('00005','HK')]:
        c.execute('INSERT INTO instruments VALUES(?,?,?,?)',(code,code,exchange,'fixture'))
    c.execute('INSERT INTO auto_daily_attempts VALUES(?,?,?,?,?,?)',('600519','2026-10-26','saved',1,None,1))
    c.execute('INSERT INTO auto_daily_block VALUES(?,?,?)',('2026-10-26','HK','outage'))
    sql='''SELECT s.code FROM instruments s WHERE s.exchange != 'HK' AND
     NOT EXISTS (SELECT 1 FROM auto_daily_attempts a WHERE a.code=s.code AND a.target_day=?) AND
     NOT EXISTS (SELECT 1 FROM auto_daily_block b WHERE b.target_day=? AND b.market=?)'''
    assert c.execute(sql,('2026-10-26','2026-10-26','A')).fetchall()==[('000001',)]
    # Other trading day is a fresh incremental attempt; the old bar remains untouched.
    assert len(c.execute(sql,('2026-10-27','2026-10-27','A')).fetchall())==2
    assert 'INSERT OR IGNORE INTO daily_bars' in DB


def test_fast_worker_reads_all_symbols_once_and_uses_real_quotes():
    for token in ['RangePlanner.safeEndDay','db.planFastDaily(day)',
                  'TencentBatchQuotes.fetch','db.saveFastQuoteBatch','DailySources.downloadFast',
                  'db.saveFastTail','db.autoAttempt','db.autoRemaining','db.autoBlock','isStopped()']:
        assert token in WORK,token
    assert 'Result.success()' in WORK and 'Result.retry()' in WORK
    assert 'MAX_RUN_MS=4L*60*1000+20_000' in WORK
    assert 'Universe.install' in WORK


def test_periodic_work_persists_and_needs_network_and_can_disable():
    for token in ['PeriodicWorkRequest.Builder','24,TimeUnit.HOURS',
                  'ExistingPeriodicWorkPolicy.KEEP','NetworkType.CONNECTED',
                  'cancelUniqueWork(PERIODIC)','cancelUniqueWork(CATCHUP)',
                  'ExistingWorkPolicy.APPEND_OR_REPLACE','ScheduleClock.delayToNextHKRun']:
        assert token in SCH,token
    for token in ['开启每天自动日更','关闭每天自动日更','① A股全量补齐｜历史日K缺口 + 财报', '② A股快速增量｜只追加最新缺失日K',
                  'DailyUpdateScheduler.ensureScheduled(getApplicationContext())','db.autoOverview()']:
        assert token in ACT,token


def test_gradle_and_upgrade_are_consistent():
    gradle=(P/'android-app/app/build.gradle').read_text()
    assert 'versionCode 920' in gradle
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in gradle
    assert "androidx.work:work-runtime:2.9.1" in gradle
    assert 'if(old<=3 && updated>=4) createAutoSyncTables(d);' in DB
    workflow=(P/'.github/workflows/QD920_FiveLab_Build.yml').read_text()
    assert "z=Path('QD920_FiveLab_Source.zip')" in workflow
    assert 'versionCode 920' in workflow
    assert 'QD901_Source.zip' not in workflow
