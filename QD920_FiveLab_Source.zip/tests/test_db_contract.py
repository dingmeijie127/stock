"""Offline schema/SQL regression tests; not a substitute for Android runtime tests."""
from pathlib import Path
import re, sqlite3

ROOT=Path(__file__).resolve().parents[1]
DBJAVA=(ROOT/'android-app/app/src/main/java/com/quantdesk/download/MarketDb.java').read_text(encoding='utf-8')
HARVEST=(ROOT/'android-app/app/src/main/java/com/quantdesk/download/HarvestService.java').read_text(encoding='utf-8')
SOURCE=(ROOT/'android-app/app/src/main/java/com/quantdesk/download/DailySources.java').read_text(encoding='utf-8')

def new_db():
    db=sqlite3.connect(':memory:')
    ddl=re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',DBJAVA)
    assert len(ddl)>=10, f'Missing v2 schema declarations: {len(ddl)}'
    for sql in ddl:
        db.execute(sql)
    return db

def test_android_create_table_sql_runs_on_sqlite():
    db=new_db()
    db.execute('INSERT INTO instruments(code,name,exchange,source) VALUES(?,?,?,?)',('600519','贵州茅台','SH','real'))
    assert db.execute('SELECT count(*) FROM instruments').fetchone()[0]==1
    assert set(x[0] for x in db.execute('SELECT name FROM sqlite_master WHERE type="table"'))>=set(
        ['instruments','daily_bars','tasks','state','log'])

def test_unique_daily_bar_key_and_source_record():
    db=new_db()
    row=('600519','2026-10-23',100,103,99,101,420,'LOTS_100_SHARES',400000,'eastmoney','raw-json')
    sql='INSERT INTO daily_bars(code,day,o,h,l,c,vol,vol_unit,amount,provider,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)'
    db.execute(sql,row)
    try: db.execute(sql,row)
    except sqlite3.IntegrityError: pass
    else: assert False,'Duplicate daily bars must be rejected without UPSERT'
    assert db.execute('SELECT provider,vol_unit FROM daily_bars').fetchone()==('eastmoney','LOTS_100_SHARES')

def test_task_success_sql_and_resume_query():
    db=new_db()
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('600519','贵州茅台','SH','roster'))
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('000001','平安银行','SZ','roster'))
    start,end='2024-10-24','2026-10-24'
    sql=re.search(r'db\.execSQL\("(INSERT OR REPLACE INTO tasks[^\"]+)"',DBJAVA).group(1)
    db.execute(sql,('600519',start,end,500,'600519',start,end,12345))
    db.execute(sql,('600519',start,end,500,'600519',start,end,12346))
    attempt=db.execute('SELECT attempts,status FROM tasks WHERE code="600519"').fetchone()
    assert attempt == (2,'complete')
    query="SELECT s.code FROM instruments s WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.code=s.code AND t.start_day=? AND t.end_day=? AND t.status='complete') ORDER BY s.code"
    assert db.execute(query,(start,end)).fetchall()==[('000001',)]

def test_task_failure_sql_and_retry():
    db=new_db()
    sql=next(x for x in re.findall(r'getWritableDatabase\(\)\.execSQL\("(INSERT OR REPLACE INTO tasks[^\"]+)"',DBJAVA) if "'failed'" in x)
    params=('600519','2024-10-24','2026-10-24','600519','2024-10-24','2026-10-24','HTTP_403',1234)
    db.execute(sql,params)
    db.execute(sql,params)
    assert db.execute('SELECT status,attempts,error FROM tasks').fetchone()==('failed',2,'HTTP_403')

def test_downloader_no_realtime_roster_gate_and_keeps_checkpoint():
    assert 'Universe.install' in HARVEST
    assert 'DailySources.downloadBars' in HARVEST
    assert 'db.appendDailyBars(code,span.from.toString(),span.to.toString(),result.bars)' in HARVEST
    assert 'writeFailure(code,from,to,error)' in HARVEST
    assert 'wake.acquire' in HARVEST
    assert 'List<MarketDb.Security> securities' in HARVEST
    assert 'HistoryGapPlanner.plan' in HARVEST
    assert 'stock_zh_a_spot_em' not in HARVEST
    assert '"partial".equals(prior)' in DBJAVA

def test_real_providers_and_no_synthetic_prices():
    assert 'push2his.eastmoney.com' in SOURCE
    assert 'web.ifzq.gtimg.cn' in SOURCE
    assert 'query1.finance.yahoo.com' in SOURCE
    assert 'fqt=0' in SOURCE
    assert 'Tencent no rows' in SOURCE
    assert 'Bar.eastmoney' in SOURCE
    assert 'new Bar(day' in SOURCE
