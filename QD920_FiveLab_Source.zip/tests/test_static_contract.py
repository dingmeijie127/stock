from pathlib import Path

P=Path(__file__).resolve().parents[1]
J=P/'android-app/app/src/main/java/com/quantdesk/download'

def test_no_runtime_universe_network_gate():
    svc=(J/'HarvestService.java').read_text()
    assert 'Universe.install' in svc
    assert 'downloadBars' in svc
    assert 'startForeground' in svc
    assert 'appendDailyBars' in svc and 'markVerifiedHistory' in svc
    assert 'writeFailure' in svc
    assert 'stock_zh_a_spot_em' not in svc

def test_manifest_service_permissions():
    text=(P/'android-app/app/src/main/AndroidManifest.xml').read_text()
    for required in ['android.permission.INTERNET','android.permission.FOREGROUND_SERVICE_DATA_SYNC','foregroundServiceType="dataSync"']:
        assert required in text

def test_build_does_not_use_old_sources():
    # Find the workflow bundled with THIS release, without hard-coding old release names.
    import re
    flows=list((P/'.github/workflows').glob('*.yml'))
    assert len(flows)==1, 'Ship exactly one workflow with the source archive'
    current=flows[0]
    assert current.stem.endswith('_Build')
    expected_zip=current.stem[:-len('_Build')]+'_Source.zip'
    text=current.read_text(encoding='utf-8')
    # The source ZIP this action extracts must match the version of the workflow.
    matches=re.findall(r"z=Path\('([^']+_Source\.zip)'\)",text)
    assert matches==[expected_zip], (matches,expected_zip)
    assert "'.github/workflows/"+current.name+"'" in text
    assert "'"+expected_zip+"'" in text
    assert 'build_universe.py' in text
    assert 'upload-artifact@v4' in text
    assert 'workflow_dispatch:' in text
    assert 'QD872_Source.zip' not in text
    # Mismatched internal vs downloadable workflows must fail validation.
    assert (P/'.github/workflows'/current.name).is_file()

def test_ui_only_collection_controls():
    text=(J/'MainActivity.java').read_text()
    for phrase in ['① A股全量补齐｜历史日K缺口 + 财报','暂停当前任务','导出 SQLite','导出日志']:
        assert phrase in text
    assert 'AnalysisActivity' not in text
