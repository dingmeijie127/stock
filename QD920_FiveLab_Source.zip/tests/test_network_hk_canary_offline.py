"""Validate canary parse logic without pretending to reach the Internet."""
import importlib.util
import json
from pathlib import Path
import pytest
spec=importlib.util.spec_from_file_location('hk_canary',Path(__file__).with_name('network_hk_canary.py'))
canary=importlib.util.module_from_spec(spec)
spec.loader.exec_module(canary)

def test_tencent_plain_json():
    body=json.dumps({'data':{'hk00700':{'day':[['2026-10-23','100','101','103','99','1000']]}}})
    assert canary.parse('tencent_fq',body)==(1,'2026-10-23')

def test_tencent_jsonp_and_reject_adjusted():
    body=json.dumps({'data':{'hk00700':{'qfqday':[['2026-10-23','100','101','103','99','1000']]}}})
    with pytest.raises(ValueError,match='adjusted'):
        canary.parse('tencent_hkfq','jsonp='+body+';')

def test_eastmoney_string_records():
    body=json.dumps({'data':{'klines':['2026-10-22,100,102,103,99,40,1000','2026-10-23,100,101,102,98,30,800']}})
    assert canary.parse('eastmoney_hk',body)==(2,'2026-10-23')
