package com.quantdesk.download;
import java.time.LocalDate;
import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Real pure Java computation tested without Android or network. */
public final class FinanceLocalAuditTest {
    static void yes(boolean b,String reason){if(!b)throw new AssertionError(reason);}
    public static void main(String[] args) throws Exception{
        LocalDate now=LocalDate.of(2026,10,26);
        List<String> due=FinanceLocalAudit.expected(now);
        yes(due.size()==7,"expected 7 overdue periods since 2024-12-31: "+due);
        yes(due.get(0).equals("2024-12-31"),"first in rolling window");
        yes(due.get(due.size()-1).equals("2026-06-30"),"Q3/2026 must NOT be reported as overdue on Oct 26");
        yes(!FinanceLocalAudit.expected(LocalDate.of(2026,10,30)).contains("2026-09-30"),"Q3 not due pre Nov3");
        yes(FinanceLocalAudit.expected(LocalDate.of(2026,11,3)).contains("2026-09-30"),"Q3 now overdue");
        yes(FinanceLocalAudit.deadline(LocalDate.of(2025,12,31)).equals(LocalDate.of(2026,4,30)),"annual deadline");
        yes("2026-03-31".equals(FinanceLocalAudit.validPeriod("20260331")),"8-digit period normalize");
        yes("2026-06-30".equals(FinanceLocalAudit.validPeriod("2026-06-30 00:00:00")),"timestamp period normalize");
        yes(FinanceLocalAudit.validPeriod("2026-04-30")==null,"non-quarterend is anomalous");
        yes(FinanceLocalAudit.validPeriod("2026-02-30")==null,"invalid date is anomalous");
        FinanceLocalAudit.Company full=new FinanceLocalAudit.Company("600000","浦发银行","SH");
        FinanceLocalAudit.Company partial=new FinanceLocalAudit.Company("000001","平安银行","SZ");
        FinanceLocalAudit.Company none=new FinanceLocalAudit.Company("000002","测试股票","SZ");
        for(String p:due)for(String t:FinanceLocalAudit.TYPES)full.add(t,p,1,0);
        for(String p:due){partial.add("income",p,1,0);partial.add("balancesheet",p,1,1);}
        partial.add("cashflow","2026-04-12",1,1);
        partial.add("income","bad_date",2,2);
        Map<String,FinanceLocalAudit.Company> all=new LinkedHashMap<>();
        all.put(full.code,full);all.put(partial.code,partial);all.put(none.code,none);
        StringWriter csv=new StringWriter();
        FinanceLocalAudit.Summary summary=FinanceLocalAudit.compute(all,now,csv);
        yes(summary.companies==3,"three instruments");
        yes(summary.none==1,"no rows 1 company");
        yes(summary.allExpectedComplete==1,"one company complete");
        yes(summary.withGaps==2,"2 companies gaps");
        yes(summary.missingCells[0]==7,"only zero-data company missing income");
        yes(summary.missingCells[1]==7,"only zero-data company missing BS");
        yes(summary.missingCells[2]==14,"both partial and none missing cashflow");
        yes(summary.badPeriodRows==3,"bad period records flagged");
        yes(summary.noAnnouncementRows==10,"announcement dates missing even when report present");
        yes(summary.periodCoverage.get("2026-06-30")[3]==1,"3 statements completeness count");
        yes(summary.render().contains("疑似缺失"),"explicit uncertain classification");
        yes(csv.toString().split("\n").length==10,"1 header + 3x3 statement rows");
        yes(csv.toString().contains("2026-06-30"),"missing dates present in CSV");
        yes(!csv.toString().contains("2026-09-30"),"not-yet-due period not mislabeled");
        System.out.println("FinanceLocalAuditTest PASS");
    }
}
