package com.quantdesk.download;
public final class PaperTradeRulesTest {
    static void check(boolean yes,String msg){if(!yes)throw new AssertionError(msg);}
    public static void main(String[] args){
        check(!PaperTradeRules.validNextOpen("2026-10-23","2026-10-23",null,"BUY",10,11,9,10,100),"same-bar lookahead");
        check(PaperTradeRules.validNextOpen("2026-10-23","2026-10-26",null,"BUY",10,11,9,10,100),"next bar");
        check(!PaperTradeRules.validNextOpen("2026-10-23","2026-10-26","2026-10-26","SELL",10,11,9,10,100),"T+1");
        check(PaperTradeRules.validNextOpen("2026-10-26","2026-10-27","2026-10-26","SELL",10,11,9,10,100),"T+1 next date");
        check(!PaperTradeRules.validNextOpen("2026-10-23","2026-10-26",null,"BUY",10,10,10,10,100),"one-price locked");
        check(!PaperTradeRules.validNextOpen("2026-10-23","2026-10-26",null,"BUY",10,11,9,10,0),"halt/zero volume");
        check(!PaperTradeRules.validNextOpen("2026-10-01","2026-11-01",null,"BUY",10,11,9,10,100),"expired");
        check(Math.abs(PaperTradeRules.fillPrice(10,"BUY")-10.01)<1e-6,"buy slippage");
        check(Math.abs(PaperTradeRules.fillPrice(10,"SELL")-9.99)<1e-6,"sell slippage");
        double buy=PaperTradeRules.cashFlow("BUY",100,10.01);
        double sell=PaperTradeRules.cashFlow("SELL",100,9.99);
        check(buy < -1001 && sell <999,"fees included");
        check(Math.abs(buy+sell)<20,"round-trip fee example");
        System.out.println("PaperTradeRulesTest PASS (11 checks)");
    }
}
