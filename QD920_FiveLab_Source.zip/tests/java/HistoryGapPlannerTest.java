package com.quantdesk.download;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
public class HistoryGapPlannerTest {
    private static LocalDate d(String day){return LocalDate.parse(day);}
    private static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    private static List<String> calendar(){
        java.util.ArrayList<String> out=new java.util.ArrayList<>();
        for(LocalDate d=d("2026-01-01");!d.isAfter(d("2026-06-01"));d=d.plusDays(1))
            if(d.getDayOfWeek().getValue()<6)out.add(d.toString());
        return out;
    }
    public static void main(String[] args){
        List<String> cal=calendar();
        check(HistoryGapPlanner.plan(d("2026-01-01"),d("2026-06-01"),Collections.emptyList(),cal,null,null).size()==1,"empty database: full download");
        List<HistoryGapPlanner.Span> missing=HistoryGapPlanner.plan(d("2026-01-01"),d("2026-06-01"),
            Arrays.asList("2026-01-01","2026-01-02","2026-01-06","2026-05-29"),cal,null,null);
        check(missing.get(0).from.equals(d("2026-01-05")),"interior missing day must not be skipped");
        check(missing.get(missing.size()-1).from.equals(d("2026-05-30")),"missing tail must be appended");
        missing=HistoryGapPlanner.plan(d("2026-01-01"),d("2026-06-01"),
            Arrays.asList("2026-05-29"),cal,null,null);
        check(missing.get(0).from.equals(d("2026-01-01")),"imported late history must repair leading gap");
        missing=HistoryGapPlanner.plan(d("2026-01-01"),d("2026-06-01"),
            Arrays.asList("2026-05-29"),cal,"2026-01-01","2026-05-29");
        check(missing.size()==1&&missing.get(0).from.equals(d("2026-05-30")),"verified history only adds tail");
        check(HistoryGapPlanner.plan(d("2026-01-01"),d("2026-06-01"),
            Arrays.asList("2026-05-29"),cal,"2026-01-01","2026-06-01").isEmpty(),"verified current window skips network");
        check(HistoryGapPlanner.plan(d("2026-01-01"),d("2026-06-01"),
            Arrays.asList("2026-05-29"),Collections.emptyList(),null,null).size()==1,"no trusted calendar forces verification");
        System.out.println("HistoryGapPlannerTest PASS");
    }
}
