package com.quantdesk.download;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
public final class FinanceCoveragePlannerTest {
    private static LocalDate d(String s){return LocalDate.parse(s);}
    private static void check(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    public static void main(String[] args){
        LocalDate baseline=d("2024-10-01"),today=d("2026-10-26");
        check(FinanceCoveragePlanner.neededStart("income",baseline,today,
            Collections.emptyList(),null,false).equals(baseline),"empty income requires full audit");
        check(FinanceCoveragePlanner.neededStart("income",baseline,today,
            Arrays.asList("2024-12-31","2025-03-31","2025-06-30","2025-09-30","2025-12-31","2026-03-31","2026-09-30"),
            "2026-09-30",false).equals(d("2026-06-30")),"latest report cannot hide missing Q2");
        check(FinanceCoveragePlanner.neededStart("hk_indicator",baseline,today,
            Arrays.asList("2025-03-31","2026-03-31"),"2026-03-31",false).equals(baseline),
            "HK missing half-year must be audited");
        check(FinanceCoveragePlanner.neededStart("hk_dividend",baseline,today,
            Arrays.asList("2026-06-01"),"2026-06-01",false).equals(baseline),
            "unverified irregular HK events cannot be declared complete");
        System.out.println("FinanceCoveragePlannerTest PASS");
    }
}
