package com.quantdesk.download;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public final class StrategyValidatorTest{
    static void ok(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    public static void main(String[] args){
        List<StrategyValidator.Sample> sample=new ArrayList<>();
        LocalDate d=LocalDate.of(2024,1,1);
        for(int k=0;k<220;k++){
            List<SwingStrategy.Candle> bars=new ArrayList<>();
            for(int i=0;i<230;i++){
                double price=20+i*.10+.08*Math.sin(i*.4+k*.05);
                bars.add(new SwingStrategy.Candle(d.plusDays(i).toString(),price-.04,price+.11,price-.13,price,1200+i));
            }
            sample.add(new StrategyValidator.Sample(String.format("%06d",k+100000),bars));
        }
        List<StrategyValidator.Report> reports=StrategyValidator.run(sample);
        ok(reports.size()==5,"five replay reports");
        for(StrategyValidator.Report r:reports){
            ok(r.days==StrategyValidator.REPLAY_DAYS+1,"chronological horizon");
            ok(r.sampled==220&&r.usable==220,"report actual coverage");
            ok(r.closed>=0&&r.wins<=r.closed,"empirical win accounting");
            ok(r.equity>0&&Double.isFinite(r.equity),"valid equity");
            ok(r.drawdown>=0,"maximum drawdown nonnegative");
        }
        List<StrategyValidator.Report> sparse=StrategyValidator.run(sample.subList(0,8));
        ok(sparse.get(0).explain().contains("样本不足"),"no win-rate claim from insufficient securities");
        System.out.println("StrategyValidatorTest PASS");
    }
}
