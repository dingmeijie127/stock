package com.quantdesk.download;
import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.io.File;
import java.util.Arrays;
import java.util.List;
/** Parses Android-dependent source without requiring an Android SDK in offline checks.
 * This does NOT perform Android type-checking, Gradle compilation, or device testing.
 */
public final class AndroidSyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostic=new DiagnosticCollector<>();
        List<File> files=Arrays.stream(args).map(File::new).toList();
        try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostic,null,null)){
            JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostic,
                Arrays.asList("-proc:none"),null,manager.getJavaFileObjectsFromFiles(files));
            task.parse();
        }
        int errors=0;
        for(Diagnostic<? extends JavaFileObject> d:diagnostic.getDiagnostics()){
            if(d.getKind()==Diagnostic.Kind.ERROR){System.err.println(d);errors++;}
        }
        if(errors>0)throw new IllegalStateException("Java syntax errors: "+errors);
        System.out.println("Java source syntax parse PASS: "+files.size()+" files (NOT an APK compile)");
    }
}
