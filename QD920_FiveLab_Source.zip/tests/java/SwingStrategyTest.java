package com.quantdesk.download;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
public final class SwingStrategyTest {
    static void ok(boolean b,String why){if(!b)throw new AssertionError(why);}
    static List<SwingStrategy.Candle> pullback(){
        List<SwingStrategy.Candle> out=new ArrayList<>();
        LocalDate d=LocalDate.of(2026,1,1);
        for(int i=0;i<85;i++){
            double close=10+i*0.055;
            if(i>=77&&i<=83)close=14.20-(i-76)*0.10;
            if(i==84)close=13.62;
            double open=i==84?13.54:close-0.02;
            out.add(new SwingStrategy.Candle(d.plusDays(i).toString(),open,
                Math.max(open,close)+0.13,Math.min(open,close)-0.14,close,1200));
        }
        return out;
    }
    public static void main(String[] args){
        List<SwingStrategy.Candle> b=pullback();String day=b.get(b.size()-1).day;
        SwingStrategy.Advice advice=SwingStrategy.evaluate(b,day,false,0,0);
        ok("BUY".equals(advice.action),"oversold RSI recovery in uptrend: "+advice.action+" "+advice.reason);
        ok(SwingStrategy.rsi2(b,84)<18,"RSI2 prior oversold");
        ok(SwingStrategy.rsi2(b,85)>SwingStrategy.rsi2(b,84)+5,"RSI2 recovered");
        ok(SwingStrategy.atr14(b,85)>0,"ATR >0");
        ok("NONE".equals(SwingStrategy.evaluate(b,b.get(83).day,false,0,0).action),"stale day blocked");
        ok("SELL".equals(SwingStrategy.evaluate(b,day,true,18,2).action),"stop loss");
        ok("SELL".equals(SwingStrategy.evaluate(b,day,true,11,2).action),"profit taking");
        ok("SELL".equals(SwingStrategy.evaluate(b,day,true,13.62,9).action),"time exit");
        ok("NONE".equals(SwingStrategy.evaluate(b.subList(0,70),b.get(69).day,false,0,0).action),"minimum bars");
        ok(SwingStrategy.buyLotsRisk(100000,100000,10,0.25)%100==0,"A-share lot size");
        ok(SwingStrategy.buyLotsRisk(100000,100000,10,3)<SwingStrategy.buyLotsRisk(100000,100000,10,0.25),"high ATR risk reduces units");
        ok(SwingStrategy.buyLotsRisk(100000,100000,10,-1)==0,"invalid ATR blocked");
        ok(SwingStrategy.commission(1000)==5,"minimum commission");
        ok(Math.abs(SwingStrategy.sellTax(10000)-5)<0.001,"sell tax");
        System.out.println("SwingStrategyTest PASS (14 checks)");
    }
}
