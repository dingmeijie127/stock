package com.quantdesk.download;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public final class AQuantFactorsTest {
    private static void check(boolean p,String detail){if(!p)throw new AssertionError(detail);}
    private static List<AQuantFactors.Candle> fixture(){
        List<AQuantFactors.Candle> rows=new ArrayList<>();
        LocalDate d=LocalDate.parse("2026-07-01");
        for(int n=0;n<61;n++){
            double c=10+n*0.1;
            rows.add(new AQuantFactors.Candle(d.plusDays(n).toString(),c,c+0.5,c-0.5,c,100+n));
        }
        return rows;
    }
    public static void main(String[] argv){
        List<AQuantFactors.Candle> rows=fixture();
        AQuantFactors.Result s=AQuantFactors.compute(rows,LocalDate.parse("2026-09-01"));
        check(s.eligible(),"good rows should calculate");
        check(Math.abs(s.ret20-(16.0/14.0-1))<0.0000001,"20 day raw return");
        check(Math.abs(s.ret60-0.6)<0.0000001,"60 day raw return");
        check(s.volatility20>=0&&s.drawdown60<=0,"quality metrics");
        check("STALE_15D".equals(AQuantFactors.compute(rows,LocalDate.parse("2026-10-15")).status),"stale excluded");
        check("INSUFFICIENT_61".equals(AQuantFactors.compute(rows.subList(0,20),LocalDate.parse("2026-09-01")).status),"short histories excluded");
        rows.set(40,new AQuantFactors.Candle("2026-08-10",20,10,5,7,200));
        check("INVALID_OHLCV".equals(AQuantFactors.compute(rows,LocalDate.parse("2026-09-01")).status),"broken price excluded");
        System.out.println("AQuantFactorsTest PASS");
    }
}
