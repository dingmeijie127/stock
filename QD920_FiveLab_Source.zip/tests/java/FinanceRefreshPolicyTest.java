package com.quantdesk.download;
import java.time.LocalDate;

public final class FinanceRefreshPolicyTest {
    private static void ok(boolean yes,String reason){if(!yes)throw new AssertionError(reason);}
    public static void main(String[] args){
        long now=1761000000000L,day=86400000L;
        ok(FinanceRefreshPolicy.due(null,0,now,"income"),"new source should run");
        ok(!FinanceRefreshPolicy.due("complete",now-day,now,"income"),"A downloaded yesterday, skip");
        ok(FinanceRefreshPolicy.due("complete",now-7*day,now,"income"),"A 7-day refresh");
        ok(!FinanceRefreshPolicy.due("complete",now-7*day,now,"hk_indicator"),"HK 14d interval");
        ok(FinanceRefreshPolicy.due("complete",now-14*day,now,"hk_indicator"),"HK overdue");
        ok(!FinanceRefreshPolicy.due("failed",now-23*60*60*1000L,now,"cashflow"),"don't hammer failing source");
        ok(FinanceRefreshPolicy.due("failed",now-day,now,"cashflow"),"failed due next day");
        ok(!FinanceRefreshPolicy.due("empty",now-day,now,"hk_dividend"),"empty source backoff");
        ok(FinanceRefreshPolicy.due("empty",now-7*day,now,"hk_dividend"),"empty recheck");
        LocalDate today=LocalDate.of(2026,10,26),baseline=today.minusYears(2);
        ok(FinanceRefreshPolicy.requestStart(baseline,today,null).equals(baseline),"first fetch two years");
        ok(FinanceRefreshPolicy.requestStart(baseline,today,"2026-09-01").equals(today.minusMonths(15)),"incremental report correction overlap");
        ok(FinanceRefreshPolicy.requestStart(baseline,today,"2026-10-25").equals(today.minusMonths(15)),"don't use naive 14-day report overlap");
        // Actual imported financial rows take precedence over old/missing data_jobs.
        ok(!FinanceRefreshPolicy.newReportPeriodMayExist("income","20260930",today),
           "A Q3 already in SQLite: do not re-download merely after 7 days");
        ok(FinanceRefreshPolicy.newReportPeriodMayExist("income","20260630",today),
           "A Q3 missing: check only new report quarter");
        ok(!FinanceRefreshPolicy.newReportPeriodMayExist("hk_indicator","20260630",today),
           "HK interim figures stored: no pointless Q3 request");
        ok(FinanceRefreshPolicy.newReportPeriodMayExist("hk_indicator","20251231",today),
           "HK half-year report genuinely missing");
        ok(FinanceRefreshPolicy.requestMissingStart(baseline,today,null,"20260630","income")
           .equals(LocalDate.of(2026,9,30)),"A fetch starts from missing Q3, not two-year history");
        ok(FinanceRefreshPolicy.requestMissingStart(baseline,today,null,"20260630","hk_indicator")
           .equals(LocalDate.of(2026,12,31)),"HK next interim/full-year boundary");
        ok(FinanceRefreshPolicy.requestMissingStart(baseline,today,null,"20260331","hk_indicator")
           .equals(LocalDate.of(2026,9,30)),"Non-calendar HK fiscal year must be supported");
        ok(FinanceRefreshPolicy.requestMissingStart(baseline,today,null,"20261010","hk_dividend")
           .equals(LocalDate.of(2026,10,11)),"HK dividend skips saved historical events");
        ok(FinanceRefreshPolicy.requestMissingStart(baseline,today,null,null,"income")
           .equals(baseline),"No financial data: fetch baseline as before");
        ok(FinanceRefreshPolicy.newReportPeriodMayExist("income","not-a-period",today),
           "Unknown legacy period: don't assume up to date");
        System.out.println("FinanceRefreshPolicyTest passed");
    }
}
