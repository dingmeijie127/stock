package com.quantdesk.download;

import java.time.LocalDateTime;
import java.util.Map;

public final class PaperLiveQuotesTest {
    private static void ok(boolean success,String reason){if(!success)throw new AssertionError(reason);}
    private static String sample(String prefix,String code,String px,String prev,String time){
        String[] fields=new String[40];java.util.Arrays.fill(fields,"");
        fields[1]="测试证券";fields[2]=code;fields[3]=px;fields[4]=prev;fields[30]=time;
        return "v_"+prefix+code+"=\""+String.join("~",fields)+"\";";
    }
    public static void main(String[] args){
        Map<String,PaperLiveQuotes.Quote> parsed=PaperLiveQuotes.parse(
            sample("sh","600519","1412.50","1400.00","20261027101122")+
            sample("sz","000001","10.24","10.00","20261027101412")+
            sample("sz","000002","0","10.00","20261027101412")+
            sample("sh","600000","9.1","9.0","20269999100000")+
            "v_sz123456=\"corrupt\";");
        ok(parsed.size()==2,"invalid quotes must not enter display");
        PaperLiveQuotes.Quote q=parsed.get("600519");
        ok(q!=null&&Math.abs(q.changePercent-(1412.5/1400-1)*100)<1e-9,"change percent");
        ok("2026-10-27".equals(q.tradingDay())&&"10:11".equals(q.clock()),"exchange source timestamp");
        ok(PaperLiveQuotes.usable(q,"2026-10-26",LocalDateTime.of(2026,10,27,10,15)),"current quote");
        ok(!PaperLiveQuotes.usable(q,"2026-10-28",LocalDateTime.of(2026,10,27,10,15)),"outdated relative to DB");
        ok(!PaperLiveQuotes.usable(q,"2026-10-26",LocalDateTime.of(2026,10,25,10,15)),"future exchange timestamp");
        ok(!PaperLiveQuotes.usable(q,"2026-10-26",LocalDateTime.of(2026,11,10,10,15)),"stale network timestamp");
        ok("sh600519".equals(PaperLiveQuotes.symbol("600519")),"Shanghai symbol");
        ok("sz300750".equals(PaperLiveQuotes.symbol("300750")),"Shenzhen symbol");
        ok("bj830799".equals(PaperLiveQuotes.symbol("830799")),"Beijing symbol");
        try{PaperLiveQuotes.symbol("bad");throw new AssertionError("bad ticker accepted");}catch(IllegalArgumentException expected){}
        System.out.println("PaperLiveQuotesTest PASS");
    }
}
