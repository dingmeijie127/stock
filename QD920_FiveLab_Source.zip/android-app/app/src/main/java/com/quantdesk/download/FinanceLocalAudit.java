package com.quantdesk.download;

import java.io.IOException;
import java.io.Writer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Read-only A-share financial-statement coverage rules. NO network, writes, or success checkpoints.
 * Presence of a row is evidence that something was saved, NOT that its accounting fields are correct.
 * Periods before an issuer's listing date cannot be distinguished reliably from missing local rows:
 * every gap is explicitly labelled "suspected", never "provider definitely missing".
 */
public final class FinanceLocalAudit {
    private FinanceLocalAudit() {}
    public static final String[] TYPES={"income","balancesheet","cashflow"};
    public static final String[] LABELS={"利润表","资产负债表","现金流量表"};

    /** Publication deadlines are indicative *latest statutory deadlines* for ordinary A-share issuers.
     * This audit does not know per-issuer filing exemptions, IPO dates or official exchange notices.
     * Two extra calendar days avoid marking deadline-day ingestion lag as a proven gap.
     */
    public static LocalDate deadline(LocalDate quarterEnd){
        switch(quarterEnd.getMonthValue()){
            case 3: return LocalDate.of(quarterEnd.getYear(),4,30);
            case 6: return LocalDate.of(quarterEnd.getYear(),8,31);
            case 9: return LocalDate.of(quarterEnd.getYear(),10,31);
            case 12:return LocalDate.of(quarterEnd.getYear()+1,4,30);
            default:throw new IllegalArgumentException("Not a standard fiscal quarter-end: "+quarterEnd);
        }
    }
    /** Rolling two-year audit window, including only periods whose publication deadline has passed. */
    public static List<String> expected(LocalDate asOf){
        List<String> periods=new ArrayList<>();
        LocalDate baseline=asOf.minusYears(2);
        LocalDate cursor=LocalDate.of(baseline.getYear(),((baseline.getMonthValue()-1)/3+1)*3,1);
        cursor=cursor.withDayOfMonth(cursor.lengthOfMonth());
        if(cursor.isBefore(baseline))cursor=cursor.plusMonths(3).withDayOfMonth(cursor.plusMonths(3).lengthOfMonth());
        while(!cursor.isAfter(asOf)){
            if(asOf.isAfter(deadline(cursor).plusDays(2)))periods.add(cursor.toString());
            LocalDate next=cursor.plusMonths(3);
            cursor=next.withDayOfMonth(next.lengthOfMonth());
        }
        return periods;
    }
    public static String validPeriod(String value){
        if(value==null)return null;
        String s=value.trim();
        if(s.length()>=10 && s.charAt(4)=='-' && s.charAt(7)=='-')s=s.substring(0,10);
        else if(s.length()>=10 && s.charAt(4)=='/' && s.charAt(7)=='/')s=s.substring(0,10).replace('/','-');
        else if(s.matches("[0-9]{8}"))s=s.substring(0,4)+"-"+s.substring(4,6)+"-"+s.substring(6,8);
        else return null;
        try{
            LocalDate d=LocalDate.parse(s,DateTimeFormatter.ISO_LOCAL_DATE);
            if(d.getMonthValue()%3!=0 || d.getDayOfMonth()!=d.lengthOfMonth())return null;
            return d.toString();
        }catch(DateTimeParseException e){return null;}
    }
    public static final class Company {
        public final String code,name,exchange;
        private final Map<String,Set<String>> periods=new HashMap<>();
        private final Map<String,Integer> savedRows=new HashMap<>(),badRows=new HashMap<>(),noAnnouncement=new HashMap<>();
        public Company(String code,String name,String exchange){this.code=code;this.name=name;this.exchange=exchange;}
        public void add(String type,String period,int rows,int withoutAnnouncement){
            if(!isType(type))return;
            savedRows.put(type,savedRows.getOrDefault(type,0)+rows);
            noAnnouncement.put(type,noAnnouncement.getOrDefault(type,0)+withoutAnnouncement);
            String normal=validPeriod(period);
            if(normal==null)badRows.put(type,badRows.getOrDefault(type,0)+rows);
            else periods.computeIfAbsent(type,k->new HashSet<>()).add(normal);
        }
        public boolean has(String type,String period){return periods.containsKey(type)&&periods.get(type).contains(period);}
        public int rows(String type){return savedRows.getOrDefault(type,0);}
        public int bad(String type){return badRows.getOrDefault(type,0);}
        public int noAnnouncement(String type){return noAnnouncement.getOrDefault(type,0);}
        public String latest(String type){
            Set<String> p=periods.get(type);
            return p==null||p.isEmpty()?"":Collections.max(p);
        }
        public int totalRows(){int n=0;for(String t:TYPES)n+=rows(t);return n;}
        public int totalBad(){int n=0;for(String t:TYPES)n+=bad(t);return n;}
        public int totalNoAnnouncement(){int n=0;for(String t:TYPES)n+=noAnnouncement(t);return n;}
    }
    private static boolean isType(String type){for(String t:TYPES)if(t.equals(type))return true;return false;}
    public static final class Summary {
        public final LocalDate asOf;
        public final List<String> expected;
        public int companies,none,allExpectedComplete,withGaps,rows,badPeriodRows,noAnnouncementRows;
        public final int[] companiesWithType=new int[3],completeByType=new int[3],missingCells=new int[3];
        public final Map<String,int[]> periodCoverage=new LinkedHashMap<>();
        public final List<String> samples=new ArrayList<>();
        Summary(LocalDate asOf,List<String> expected){this.asOf=asOf;this.expected=expected;for(String p:expected)periodCoverage.put(p,new int[4]);}
        public String render(){
            StringBuilder s=new StringBuilder();
            s.append("A股财报只读体检 · ").append(asOf).append('\n')
                .append("统计范围：近两年已过通常披露期限的季度；不联网、不修改SQLite\n")
                .append("股票 ").append(companies).append(" 只；财报原始行 ").append(rows)
                .append("；完全没有三大报表 ").append(none).append(" 只\n")
                .append("三表覆盖所有到期报告期 ").append(allExpectedComplete)
                .append(" 只；存在疑似缺期 ").append(withGaps).append(" 只\n")
                .append("已纳入应披露报告期：").append(expected.isEmpty()?"无":String.join("、",expected)).append('\n');
            for(int i=0;i<3;i++)s.append(LABELS[i]).append("：有数据 ").append(companiesWithType[i])
                .append(" 只；覆盖全部到期季度 ").append(completeByType[i])
                .append(" 只；疑似缺失条目 ").append(missingCells[i]).append('\n');
            s.append("报告期覆盖（利润表 / 资产负债表 / 现金流量表 / 三表齐全）：\n");
            for(Map.Entry<String,int[]> e:periodCoverage.entrySet()){
                int[] n=e.getValue();s.append(e.getKey()).append("：")
                  .append(n[0]).append('/').append(n[1]).append('/').append(n[2]).append('/').append(n[3])
                  .append("，分母 ").append(companies).append('\n');
            }
            s.append("报告期无效的原始行 ").append(badPeriodRows)
                .append("；公告日期为空的行 ").append(noAnnouncementRows).append('\n');
            if(!samples.isEmpty()){
                s.append("疑似缺失示例（最多12只，完整名单请导出CSV）：\n");
                for(String x:samples)s.append(x).append('\n');
            }
            s.append("注意：疑似缺失不等于上市后必然应披露；新股、已退市、特殊报告期需核对正式公告。")
                .append(" 有财报行也不代表财务字段正确；公告日期缺失会影响避免未来函数的回测。")
                .append(" 同一报告期多条记录可能是修订或多来源，不自动视为脏数据。");
            return s.toString();
        }
    }
    /** CSV is one row per company x statement type, ~15k rows, not 100k+ quarter-by-quarter rows. */
    public static Summary compute(Map<String,Company> companies,LocalDate asOf,Writer csv) throws IOException{
        List<String> expected=expected(asOf);
        Summary result=new Summary(asOf,expected);
        if(csv!=null)csv.write("code,exchange,name,statement,raw_rows,expected_period_count,saved_expected_count,suspected_missing_count,missing_periods,latest_saved_period,bad_period_rows,no_announcement_rows,status\n");
        for(Company c:companies.values()){
            result.companies++;
            result.rows+=c.totalRows();result.badPeriodRows+=c.totalBad();result.noAnnouncementRows+=c.totalNoAnnouncement();
            if(c.totalRows()==0)result.none++;
            boolean all=true;
            List<String> preview=new ArrayList<>();
            for(int t=0;t<TYPES.length;t++){
                String type=TYPES[t];
                if(c.rows(type)>0)result.companiesWithType[t]++;
                List<String> missing=new ArrayList<>();
                for(String p:expected){
                    boolean present=c.has(type,p);
                    if(present)result.periodCoverage.get(p)[t]++;
                    else missing.add(p);
                }
                result.missingCells[t]+=missing.size();
                if(missing.isEmpty())result.completeByType[t]++;
                else{
                    all=false;
                    preview.add(LABELS[t]+":"+String.join("/",missing));
                }
                if(csv!=null){
                    String status=c.rows(type)==0?"NO_SAVED_ROWS":missing.isEmpty()?"EXPECTED_PRESENT":"SUSPECTED_MISSING";
                    csv.write(cell(c.code)+","+cell(c.exchange)+","+cell(c.name)+","+cell(LABELS[t])+","+
                        c.rows(type)+","+expected.size()+","+(expected.size()-missing.size())+","+
                        missing.size()+","+cell(String.join(";",missing))+","+cell(c.latest(type))+","+
                        c.bad(type)+","+c.noAnnouncement(type)+","+cell(status)+"\n");
                }
            }
            for(String p:expected){
                if(c.has(TYPES[0],p)&&c.has(TYPES[1],p)&&c.has(TYPES[2],p))result.periodCoverage.get(p)[3]++;
            }
            if(all)result.allExpectedComplete++;
            else{
                result.withGaps++;
                if(result.samples.size()<12){
                    String example=c.code+" "+c.name+"："+String.join("；",preview);
                    if(example.length()>210)example=example.substring(0,210)+"…";
                    result.samples.add(example);
                }
            }
        }
        if(csv!=null)csv.flush();
        return result;
    }
    private static String cell(String value){
        if(value==null)value="";
        if(!value.isEmpty() && "=+-@".indexOf(value.charAt(0))>=0)value="'"+value;
        return "\""+value.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\"";
    }
}
