package com.quantdesk.download;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/** Installs actual build-time captured listings; no mobile listing endpoint needed. */
public final class Universe {
    private Universe() {}
    public static int install(Context context, MarketDb market) throws Exception {
        SQLiteDatabase db=market.getWritableDatabase();
        db.beginTransaction();
        int count=0;
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(
                context.getAssets().open("universe.tsv"),StandardCharsets.UTF_8))){
            String head=reader.readLine();
            if(!"code\tname\texchange\tsource".equals(head))
                throw new IllegalStateException("安装包内股票目录格式错误");
            SQLiteStatement insert=db.compileStatement("INSERT OR IGNORE INTO instruments(code,name,exchange,source) VALUES (?,?,?,?)");
            try {
                String line;
                while((line=reader.readLine())!=null){
                    String[] p=line.split("\\t",-1);
                    if(p.length!=4 || !p[0].matches("[0-9]{6}") || p[1].isEmpty() ||
                       !(p[2].equals("SH")||p[2].equals("SZ")||p[2].equals("BJ")))
                        throw new IllegalStateException("股票清单中有无效记录，第 "+(count+2)+" 行");
                    insert.clearBindings();
                    insert.bindString(1,p[0]);insert.bindString(2,p[1]);
                    insert.bindString(3,p[2]);insert.bindString(4,p[3]);
                    insert.executeInsert();count++;
                }
            }finally{insert.close();}
            if(count<3500)throw new IllegalStateException("安装包股票清单只有 "+count+" 只；构建数据不完整");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        // A-only mode: preserve legacy HK rows in SQLite but never import, update or query them.
        return market.countA();
    }

    private static void installHK(Context context, MarketDb market) throws Exception {
        SQLiteDatabase db=market.getWritableDatabase();
        int count=0;
        db.beginTransaction();
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(
                context.getAssets().open("hk_universe.tsv"),StandardCharsets.UTF_8))){
            if(!"code\tname\texchange\tsource".equals(reader.readLine()))
                throw new IllegalStateException("港股清单格式错误，禁止启动空目录任务");
            SQLiteStatement insert=db.compileStatement(
                "INSERT OR IGNORE INTO instruments(code,name,exchange,source) VALUES (?,?,?,?)");
            try{
                String line;
                while((line=reader.readLine())!=null){
                    String[] p=line.split("\t",-1);
                    if(p.length!=4||!p[0].matches("[0-9]{5}")||p[1].isEmpty()||!"HK".equals(p[2]))
                        throw new IllegalStateException("港股目录不合格，第 "+(count+2)+" 行");
                    insert.clearBindings();insert.bindString(1,p[0]);insert.bindString(2,p[1]);
                    insert.bindString(3,"HK");insert.bindString(4,p[3]);insert.executeInsert();count++;
                }
            }finally{insert.close();}
            if(count<1000)throw new IllegalStateException("港股清单只有 "+count+" 只，禁止把空目录当全市场");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }

}
