package com.quantdesk.download;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** Separate, non-brokerage experimental portfolio. Interactive A-share paper trading dashboard. */
public final class PaperTradeActivity extends Activity {
    private static final int EXPORT=3101,EXPORT_DB=3102;
    private static final int NAVY=Color.rgb(17,32,57),BLUE=Color.rgb(41,96,216);
    private static final int BG=Color.rgb(245,247,251),MUTED=Color.rgb(99,113,137);
    private static final int RED=Color.rgb(204,55,64),GREEN=Color.rgb(23,140,102);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private TextView message,accountInfo,sectionName,marketInfo,overviewInfo,diagnosticInfo,automaticInfo;
    private TextView homeStatus,accountAsset,accountMetrics,quoteInfo;
    private LinearLayout tabRow,listPane,strategyRow,homeScreen,detailScreen,homeCards;
    private ScrollView page;
    private boolean inAccount=false;
    private final AtomicBoolean quoteBusy=new AtomicBoolean(false);
    private long lastQuoteRefresh=0L;
    private Dashboard lastQuotedDashboard;
    private String quotedStrategy="",quoteState="联网行情未刷新；持仓按本地收盘价估值";
    private EditText search;
    private String activeTab="持仓",latestDay="",filter="";
    private int selectedStrategy=0;
    private Button autoSwitch;
    private EquityCurveView equityChart;
    private Dashboard current;
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable surface(int color,int radius){
        GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(dp(radius));return b;
    }
    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private LinearLayout.LayoutParams margins(int width,int height,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,height);p.bottomMargin=dp(bottom);return p;
    }
    private Button button(String label,int color,View.OnClickListener onClick){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(Color.WHITE);
        b.setBackground(surface(color,12));b.setPadding(dp(9),dp(8),dp(9),dp(8));b.setOnClickListener(onClick);return b;
    }
    private LinearLayout card(){
        LinearLayout box=column();box.setBackground(surface(Color.WHITE,16));box.setPadding(dp(15),dp(14),dp(15),dp(14));return box;
    }
    private void addCard(LinearLayout root,LinearLayout card){root.addView(card,margins(-1,-2,12));}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(Color.WHITE);
        page=new ScrollView(this);page.setFillViewport(true);page.setBackgroundColor(BG);
        LinearLayout screen=column();screen.setPadding(dp(14),0,dp(14),dp(26));page.addView(screen);setContentView(page);
        homeScreen=column();detailScreen=column();screen.addView(homeScreen);screen.addView(detailScreen);
        buildHome();detailScreen.setVisibility(View.GONE);
        LinearLayout toolbar=column();toolbar.setBackground(surface(NAVY,0));toolbar.setPadding(dp(16),dp(16),dp(16),dp(16));
        detailScreen.addView(toolbar,margins(-1,-2,12));
        TextView back=text("‹  返回五策略账户",13,Color.rgb(185,204,239),false);back.setOnClickListener(v->openHome());toolbar.addView(back);
        gap(toolbar,13);
        toolbar.addView(text("五策略量化实验室 V9.2.0",22,Color.WHITE,true));
        gap(toolbar,5);
        toolbar.addView(text("独立模拟账户 · 持仓明细 · 网络参考报价 · 交易与绩效",12,Color.rgb(181,201,234),false));
        gap(toolbar,12);
        accountInfo=text("正在载入独立策略仓…",17,Color.WHITE,true);
        accountInfo.setLineSpacing(dp(3),1);toolbar.addView(accountInfo);
        gap(toolbar,8);marketInfo=text("市场广度：尚未完成扫描",12,Color.rgb(185,204,239),false);
        marketInfo.setLineSpacing(dp(3),1);toolbar.addView(marketInfo);
        message=text("准备读取本地日K",12,MUTED,false);detailScreen.addView(message,margins(-1,-2,12));
        LinearLayout assets=card();assets.addView(text("模拟账户总资产 · 当前参考估值",12,MUTED,false));
        accountAsset=text("¥100,000.00",30,NAVY,true);assets.addView(accountAsset);
        gap(assets,7);accountMetrics=text("现金 / 持仓市值 / 浮动盈亏载入中",13,NAVY,false);
        accountMetrics.setLineSpacing(dp(5),1);assets.addView(accountMetrics);
        gap(assets,6);quoteInfo=text("行情价格待加载",12,MUTED,false);assets.addView(quoteInfo);
        gap(assets,9);assets.addView(button("刷新持仓网络参考报价",BLUE,v->refreshNetworkQuotes(true)),margins(-1,dp(43),0));
        addCard(detailScreen,assets);
        LinearLayout accountsCard=card();
        accountsCard.addView(text("切换策略账户",14,NAVY,true));gap(accountsCard,8);
        HorizontalScrollView accountScroll=new HorizontalScrollView(this);accountScroll.setHorizontalScrollBarEnabled(false);
        strategyRow=new LinearLayout(this);strategyRow.setOrientation(LinearLayout.HORIZONTAL);
        accountScroll.addView(strategyRow);accountsCard.addView(accountScroll);
        gap(accountsCard,6);overviewInfo=text("五个账户各有独立的本金、持仓、委托和收益",11,MUTED,false);
        accountsCard.addView(overviewInfo);addCard(detailScreen,accountsCard);
        LinearLayout actions=card();actions.addView(text("策略模拟交易",16,NAVY,true));gap(actions,8);
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);
        Button buy=button("＋ 模拟买入",RED,v->manualDialog("BUY","",100));
        Button sell=button("－ 模拟卖出",GREEN,v->manualDialog("SELL","",100));
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(49),1);half.rightMargin=dp(5);
        a.addView(buy,half);
        LinearLayout.LayoutParams other=new LinearLayout.LayoutParams(0,dp(49),1);other.leftMargin=dp(5);
        a.addView(sell,other);actions.addView(a);gap(actions,8);
        actions.addView(button("① 分析全市场 → 扫描五种算法",BLUE,v->runAction("SCAN")),margins(-1,dp(46),8));
        actions.addView(button("② 按当日风险预算生成五仓模拟委托",BLUE,v->runAction("AUTO")),margins(-1,dp(46),8));
        autoSwitch=button("",NAVY,v->new AlertDialog.Builder(this).setTitle("启用后台自动模拟交易？")
            .setMessage("每12小时尝试读取本地最新有效日K；依次分析市场、给五个模拟账户选股、生成虚拟买卖委托。次日行情入库后才会模拟成交。仅在手机允许后台任务时执行，不保证准点，不发送真实券商订单。")
            .setNegativeButton("取消",null)
            .setPositiveButton("切换开关",(d,w)->{
                boolean now=!PaperAutoWorker.enabled(this);PaperAutoWorker.schedule(this,now);updateAutoSwitch();
            }).show());
        updateAutoSwitch();actions.addView(autoSwitch,margins(-1,dp(44),8));
        actions.addView(button("③ 固定参数历史逐日回放 · 验证五策略",NAVY,v->runAction("VALIDATE")),margins(-1,dp(46),8));
        actions.addView(button("确认候选策略委托",NAVY,v->new AlertDialog.Builder(this).setTitle("确认自动模拟委托")
            .setMessage("仅对今日已扫描的BUY/SELL信号创建模拟委托，五仓按牛/熊/震荡分别限制总仓位、单股仓位及持仓数量，观察池不会买入。下一个有效交易日日K开盘模拟成交并计入滑点和费用。是否继续？")
            .setNegativeButton("返回",null).setPositiveButton("创建模拟委托",(d,w)->runAction("ORDER")).show()),margins(-1,dp(46),8));
        actions.addView(button("下一日K结算五个模拟仓委托",GREEN,v->runAction("SETTLE")),margins(-1,dp(44),0));
        // The trade controls appear AFTER the portfolio / orders, not before them.
        LinearLayout diagnostics=card();
        diagnostics.addView(text("每日交易决策 · 市场仓位预算与信号诊断",16,NAVY,true));gap(diagnostics,7);
        diagnosticInfo=text("请先扫描：各仓将显示股票仓位上限、允许信号、观察池和等待原因。",12,NAVY,false);
        diagnosticInfo.setLineSpacing(dp(4),1);diagnostics.addView(diagnosticInfo);
        gap(diagnostics,9);
        automaticInfo=text("自动运行记录尚无；后台开启不代表已完成成交。",12,MUTED,false);
        diagnostics.addView(automaticInfo);
        // Diagnostic details follow the account table and trade controls.
        LinearLayout table=card();sectionName=text("模拟账户明细",16,NAVY,true);table.addView(sectionName);
        gap(table,10);
        HorizontalScrollView tabsScroll=new HorizontalScrollView(this);tabsScroll.setHorizontalScrollBarEnabled(false);
        tabRow=new LinearLayout(this);tabRow.setOrientation(LinearLayout.HORIZONTAL);tabsScroll.addView(tabRow);table.addView(tabsScroll);
        gap(table,8);
        search=new EditText(this);search.setTextSize(13);search.setSingleLine(true);
        search.setHint("搜索股票代码或名称，例如 600519 / 茅台");search.setBackground(surface(BG,10));
        search.setPadding(dp(12),dp(9),dp(12),dp(9));table.addView(search,margins(-1,dp(46),6));
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filter=s.toString().trim();renderRows();}
            @Override public void afterTextChanged(Editable e){}
        });
        listPane=column();table.addView(listPane);addCard(detailScreen,table);
        addCard(detailScreen,actions);
        LinearLayout curveCard=card();curveCard.addView(text("当前策略账户 · 历史净值",15,NAVY,true));
        gap(curveCard,8);equityChart=new EquityCurveView(this);
        curveCard.addView(equityChart,margins(-1,dp(156),0));addCard(detailScreen,curveCard);
        addCard(detailScreen,diagnostics);
        LinearLayout files=card();files.addView(text("导出及实验说明",16,NAVY,true));gap(files,9);
        files.addView(button("导出当前策略的委托与成交 CSV",BLUE,v->exportFile(EXPORT)),margins(-1,dp(44),7));
        files.addView(button("备份独立模拟账本 SQLite",NAVY,v->exportFile(EXPORT_DB)),margins(-1,dp(44),10));
        files.addView(text("模拟自动交易须手机定期同步行情。信号收盘产生、下一有效日K开盘模拟成交；五仓资金相互隔离，单仓T+1、手数、滑点及手续费均独立。市场数据库只读。",12,MUTED,false));
        gap(files,8);
        files.addView(text("缠论分型为简化模型，不是完整的笔/线段/中枢算法。回放只用当前股票池和未复权日K，存在幸存者偏差、除权缺口和涨跌停排队偏差；必须查看样本数和区间，不保证胜率。",12,MUTED,false));
        addCard(detailScreen,files);
        PaperAutoWorker.schedule(this,PaperAutoWorker.enabled(this));
        refreshTabs();runAction("REFRESH");
    }
    private void buildHome(){
        LinearLayout hero=column();hero.setPadding(dp(18),dp(22),dp(18),dp(20));hero.setBackground(surface(NAVY,0));
        hero.addView(text("五策略量化实验室",23,Color.WHITE,true));gap(hero,5);
        hero.addView(text("V9.2.0 · A股模拟交易 · 五个独立账户",12,Color.rgb(186,207,236),false));
        gap(hero,12);hero.addView(text("选择一个策略，查看真实模拟持仓、成本、参考现价、委托和交易明细。",13,Color.WHITE,false));
        homeScreen.addView(hero,margins(-1,-2,14));
        LinearLayout status=card();status.addView(text("市场与账户状态",15,NAVY,true));gap(status,7);
        homeStatus=text("读取行情和五仓资产中…",12,MUTED,false);homeStatus.setLineSpacing(dp(4),1);status.addView(homeStatus);
        gap(status,9);status.addView(button("刷新五个模拟账户",BLUE,v->runAction("REFRESH")),margins(-1,dp(43),0));
        addCard(homeScreen,status);
        homeScreen.addView(text("五个独立策略账户 · 选择进入",18,NAVY,true),margins(-1,-2,11));
        homeCards=column();homeScreen.addView(homeCards);
        LinearLayout help=card();help.addView(text("价格和成交说明",15,NAVY,true));gap(help,8);
        help.addView(text("模拟成交：按信号日之后的有效交易日日K开盘价推算，并计入滑点与手续费。",12,MUTED,false));
        gap(help,6);help.addView(text("持仓参考价：优先显示你手动/自动刷新获得的联网报价及原始时间；网络不可用则使用本地最近收盘价。联网价格不写入行情数据库、不参与模拟成交或回测。",12,MUTED,false));
        addCard(homeScreen,help);
    }
    private void openHome(){
        inAccount=false;detailScreen.setVisibility(View.GONE);homeScreen.setVisibility(View.VISIBLE);
        if(page!=null)page.scrollTo(0,0);
    }
    private void openAccount(int position){
        if(busy.get()){Toast.makeText(this,"正在计算，请完成后进入账户",Toast.LENGTH_SHORT).show();return;}
        selectedStrategy=position;activeTab="持仓";inAccount=true;
        homeScreen.setVisibility(View.GONE);detailScreen.setVisibility(View.VISIBLE);
        if(page!=null)page.scrollTo(0,0);
        runAction("REFRESH");
    }
    @Override public void onBackPressed(){if(inAccount)openHome();else super.onBackPressed();}
    private static final class Holding {
        String code,name,boughtDay,quoteDay,quoteTime="",quoteSource="本地日K收盘";
        int qty;double basis,price,dayChange=Double.NaN;boolean online=false;
        Holding(String code,String name,int qty,double basis,double price,String boughtDay,String quoteDay){
            this.code=code;this.name=name;this.qty=qty;this.basis=basis;this.price=price;
            this.boughtDay=boughtDay;this.quoteDay=quoteDay;
        }
    }
    private static final class Dashboard {
        String day,summary,performance,ledger,message,marketSummary,validation,automatic;
        String[] overview=new String[StrategySuite.IDS.length];
        List<Double> curve=Collections.emptyList();
        double cash;
        int pending;
        AccountTile[] accounts=new AccountTile[StrategySuite.IDS.length];
        List<Holding> holdings=new ArrayList<>();
        Map<String,String> names=new HashMap<>();
        List<PaperTradingStore.FillView> fills=Collections.emptyList();
        List<PaperTradingStore.Signal> signals=Collections.emptyList();
        List<PaperTradingStore.OrderView> orders=Collections.emptyList();
    }
    private static final class AccountTile {
        String title;double cash,equity;int holdings,pending;
        AccountTile(String title,double cash,double equity,int holdings,int pending){
            this.title=title;this.cash=cash;this.equity=equity;this.holdings=holdings;this.pending=pending;
        }
    }
    private void updateAutoSwitch(){
        if(autoSwitch!=null)autoSwitch.setText(PaperAutoWorker.enabled(this)?"后台模拟自动交易：已开启（12小时尝试）":"后台模拟自动交易：关闭 · 点击开启");
    }
    private String selectedId(){return StrategySuite.IDS[selectedStrategy];}
    private void runAction(String action){
        if(!busy.compareAndSet(false,true)){message.setText("后台操作中，请完成后再试");return;}
        message.setText("正在处理 "+action+" · 使用本地历史日K与隔离模拟账本");
        final String sid=selectedId();
        new Thread(()->{
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore paper=new PaperTradingStore(getApplicationContext())){
                String day=PaperTradingStore.asOf(market),note="";
                long[] ids=paper.accounts();
                if(day.isEmpty())note="行情数据库无有效完成日K，不能选股或成交";
                else if("SCAN".equals(action)||"AUTO".equals(action)){
                    for(long id:ids)paper.settle(market,id,day);
                    note=paper.scanAll(market,day,(now,total)->{
                        if(now%400==0||now==total)ui.post(()->message.setText("大盘+股票策略进度 " +now+"/"+total));
                    });
                    PaperAutoWorker.prefs(this).edit().putString("market_summary",note)
                        .putString("scan_day",day).apply();
                    if("AUTO".equals(action))for(int i=0;i<ids.length;i++)
                        note+="\n"+StrategySuite.title(StrategySuite.IDS[i])+"："+paper.placeSuggestedOrders(market,ids[i],day);
                }else if("ORDER".equals(action)){
                    StringBuilder notes=new StringBuilder();
                    for(int i=0;i<ids.length;i++)notes.append(StrategySuite.title(StrategySuite.IDS[i]))
                        .append("：").append(paper.placeSuggestedOrders(market,ids[i],day)).append("\n");
                    note=notes.toString();
                }else if("SETTLE".equals(action)){
                    StringBuilder notes=new StringBuilder();for(int i=0;i<ids.length;i++)
                        notes.append(StrategySuite.title(StrategySuite.IDS[i])).append("：")
                            .append(paper.settle(market,ids[i],day)).append("\n");
                    note=notes.toString();
                }else if("VALIDATE".equals(action)){
                    note=runValidation(market,day);
                }
                Dashboard next=readDashboard(market,paper,paper.account(sid),day);
                next.message=note.isEmpty()?"五个策略模拟账户已载入；未发送任何真实交易委托":note;
                ui.post(()->show(next));
            }catch(Exception ex){
                android.util.Log.e("QDFiveLab","模拟仓异常",ex);
                ui.post(()->message.setText("模拟仓操作失败："+ex.getClass().getSimpleName()+"  "+ex.getMessage()));
            }finally{busy.set(false);}
        },"qd-five-"+action).start();
    }
    private String runValidation(MarketDb market,String asOf){
        List<PaperTradingStore.Security> all=PaperTradingStore.universe(market);
        // Stable, deterministic sample independent of returns or strategy selections.
        all.sort((x,y)->Integer.compare(x.code.hashCode()^0x5b71,y.code.hashCode()^0x5b71));
        List<StrategyValidator.Sample> sample=new ArrayList<>();
        int limit=Math.min(StrategyValidator.MAX_SYMBOLS,all.size());
        for(int i=0;i<limit;i++){
            String code=all.get(i).code;
            List<SwingStrategy.Candle> bars=PaperTradingStore.historyForValidation(market,code,asOf);
            sample.add(new StrategyValidator.Sample(code,bars));
            if(i%60==0){int progress=i;ui.post(()->message.setText("回放样本数据载入 "+progress+"/"+limit));}
        }
        List<StrategyValidator.Report> reports=StrategyValidator.run(sample);
        StringBuilder result=new StringBuilder("固定参数逐日历史回放（当前股票池抽样；不是独立样本验证）");
        for(StrategyValidator.Report report:reports)result.append("\n\n").append(report.explain());
        result.append("\n\n局限：当前股票池的幸存者偏差、未复权行情、部分涨跌停无法成交、缺少真实指数和退市股票、未进行参数调优/独立样本验证；未用未来数据产生信号。");
        String value=result.toString();
        PaperAutoWorker.prefs(this).edit().putString("validation",value).putString("validation_day",asOf).apply();
        return "历史回放已执行：见【战绩】页。";
    }
    private Dashboard readDashboard(MarketDb market,PaperTradingStore paper,long account,String day){
        Dashboard d=new Dashboard();d.day=day;
        d.marketSummary=PaperAutoWorker.prefs(this).getString("market_summary","市场广度尚未计算，点击分析全市场");
        d.validation=PaperAutoWorker.prefs(this).getString("validation","尚未执行固定参数历史回放，暂不能报告历史回放胜率。");
        d.automatic=PaperAutoWorker.prefs(this).getString("last_auto_run","尚未运行后台自动交易；请先更新日K或手动点击扫描。");
        for(int i=0;i<StrategySuite.IDS.length;i++){
            long id=paper.account(StrategySuite.IDS[i]);
            d.overview[i]=paper.summary(market,id,day).split("\n持仓 ")[0];
            d.accounts[i]=new AccountTile(StrategySuite.title(StrategySuite.IDS[i]),paper.cash(id),
                day.isEmpty()?paper.cash(id):paper.equity(market,id,day),paper.positions(id).size(),paper.pendingCount(id));
        }
        d.curve=paper.equityCurve(account);
        d.summary=paper.summary(market,account,day);
        d.cash=paper.cash(account);d.pending=paper.pendingCount(account);
        d.performance=paper.performance(account);d.ledger=paper.recentLedger(account);
        d.signals=paper.signals(account,day);d.orders=paper.orders(account,100);
        d.fills=paper.fills(account,100);
        for(PaperTradingStore.OrderView o:d.orders)if(!d.names.containsKey(o.code))d.names.put(o.code,PaperTradingStore.securityName(market,o.code));
        for(PaperTradingStore.Signal v:d.signals)if(!d.names.containsKey(v.code))d.names.put(v.code,PaperTradingStore.securityName(market,v.code));
        for(PaperTradingStore.FillView v:d.fills)if(!d.names.containsKey(v.code))d.names.put(v.code,PaperTradingStore.securityName(market,v.code));
        for(Map.Entry<String,PaperTradingStore.Position> e:paper.positions(account).entrySet()){
            PaperTradingStore.Position p=e.getValue();
            List<SwingStrategy.Candle> bars=PaperTradingStore.history(market,p.code,day);
            SwingStrategy.Candle last=bars.isEmpty()?null:bars.get(bars.size()-1);
            Holding h=new Holding(p.code,PaperTradingStore.securityName(market,p.code),p.qty,p.basis,
                last==null?p.basis:last.close,p.boughtDay,last==null?"无":last.day);
            if(last!=null&&bars.size()>=2){
                double prev=bars.get(bars.size()-2).close;
                if(Double.isFinite(prev)&&prev>0)h.dayChange=(last.close/prev-1)*100;
            }
            d.holdings.add(h);d.names.put(h.code,h.name);
        }
        Collections.sort(d.holdings,(a,b)->a.code.compareTo(b.code));
        return d;
    }
    private void show(Dashboard d){
        current=d;latestDay=d.day;
        accountInfo.setText(StrategySuite.title(selectedId())+" · 独立模拟账户");
        String firstLine=d.marketSummary.split("\n",2)[0];
        marketInfo.setText(firstLine);
        String selectedLine="尚无该策略最新诊断，点击【分析全市场】。";
        for(String line:d.marketSummary.split("\n"))
            if(line.startsWith(StrategySuite.title(selectedId())+"：")){selectedLine=line;break;}
        diagnosticInfo.setText("策略规则："+StrategySuite.formula(selectedId())+"\n"+selectedLine+
            "\n观察池 ≠ 买点；每日会给出仓位计划和等待原因，交易信号必须达到触发条件。弱市轻仓≠保证每天成交。");
        automaticInfo.setText("自动任务："+(PaperAutoWorker.enabled(this)?"已开启（每12小时尝试）":"已关闭")+
            "\n"+(d.automatic.length()>200?d.automatic.substring(0,200)+"…":d.automatic));
        equityChart.setValues(d.curve);
        refreshStrategyRow(d);
        overviewInfo.setText("每仓独立记账 · 持仓 "+d.holdings.size()+" 只 · 待成交 "+d.pending+" 笔");
        message.setText(d.message==null?"模拟账户已更新":d.message);
        renderHome(d);renderAssets(d);
        refreshTabs();renderRows();
        if(inAccount&&!d.holdings.isEmpty())refreshNetworkQuotes(false);
    }
    private void refreshStrategyRow(Dashboard d){
        strategyRow.removeAllViews();
        for(int i=0;i<StrategySuite.IDS.length;i++){
            final int idx=i;
            String label=new String[]{"① RSI2","② 缠论旗形","③ 突破","④ 布林","⑤ 动量"}[i];
            TextView t=text(label,13,i==selectedStrategy?BLUE:NAVY,true);
            t.setGravity(Gravity.CENTER);t.setPadding(dp(13),dp(12),dp(13),dp(12));
            t.setBackground(surface(i==selectedStrategy?Color.rgb(228,237,255):BG,11));
            t.setOnClickListener(v->openAccount(idx));
            LinearLayout.LayoutParams lp=margins(-2,-2,0);lp.rightMargin=dp(7);strategyRow.addView(t,lp);
        }
    }
    private void renderHome(Dashboard d){
        homeStatus.setText("已存本地日K至 "+(d.day.isEmpty()?"无":d.day)+"\n"+
            d.marketSummary.split("\n",2)[0]+"\n"+
            "模拟交易不发送券商订单；五仓独立核算。");
        homeCards.removeAllViews();
        for(int i=0;i<d.accounts.length;i++){
            AccountTile t=d.accounts[i];if(t==null)continue;final int idx=i;
            LinearLayout tile=card();tile.setPadding(dp(15),dp(15),dp(15),dp(15));
            LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);
            TextView name=text(t.title,16,NAVY,true);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            line.addView(text("进入账户 ›",13,BLUE,true));tile.addView(line);gap(tile,8);
            tile.addView(text("总资产  ¥"+money(t.equity),21,NAVY,true));gap(tile,5);
            double ret=(t.equity/100000.0-1)*100;
            tile.addView(text(String.format(Locale.CHINA,"累计收益 %+.2f%%   持仓 %d 只   待成交 %d 笔",ret,t.holdings,t.pending),
                12,ret>=0?RED:GREEN,false));
            gap(tile,5);tile.addView(text("可用现金 ¥"+money(t.cash)+"   ·   初始本金 ¥100,000",12,MUTED,false));
            tile.setOnClickListener(v->openAccount(idx));addCard(homeCards,tile);
        }
    }
    private double holdingsValue(Dashboard d){double total=0;for(Holding h:d.holdings)total+=h.qty*h.price;return total;}
    private void renderAssets(Dashboard d){
        double invested=0,basis=0;int online=0;
        for(Holding p:d.holdings){invested+=p.qty*p.price;basis+=p.qty*p.basis;if(p.online)online++;}
        double asset=d.cash+invested,profit=invested-basis,totalReturn=(asset/100000-1)*100;
        accountAsset.setText("¥"+money(asset));
        accountMetrics.setText("累计收益  "+String.format(Locale.CHINA,"%+.2f%%",totalReturn)+
            "    持仓浮盈亏  "+String.format(Locale.CHINA,"%+.2f",profit)+" 元\n"+
            "可用现金  ¥"+money(d.cash)+"     持仓市值  ¥"+money(invested)+"\n"+
            "持仓 "+d.holdings.size()+" 只  ·  待成交 "+d.pending+" 笔  ·  本金 ¥100,000");
        accountMetrics.setTextColor(profit>=0?RED:GREEN);
        quoteInfo.setText((d.holdings.isEmpty()?"无持仓；仍可在【委托】查看待成交股票。":
            (online>0?"已更新网络参考报价 "+online+"/"+d.holdings.size()+" 只（可能延迟）":"持仓估值按本地最近收盘价"))+
            "\n"+quoteState+"\n参考估值不写回账本，不作为自动成交价格。" );
    }
    private void refreshNetworkQuotes(boolean force){
        Dashboard d=current;
        if(!inAccount||d==null)return;
        if(d.holdings.isEmpty()){
            quoteState="当前账户无持仓；无须请求网络报价";renderAssets(d);return;
        }
        long now=System.currentTimeMillis();String sid=selectedId();
        if(!force&&sid.equals(quotedStrategy)&&d==lastQuotedDashboard&&now-lastQuoteRefresh<90000)return;
        if(!quoteBusy.compareAndSet(false,true))return;
        lastQuoteRefresh=now;quotedStrategy=sid;lastQuotedDashboard=d;
        List<String> codes=new ArrayList<>();for(Holding p:d.holdings)codes.add(p.code);
        quoteState="正在通过网络读取持仓报价…";renderAssets(d);
        new Thread(()->{
            try{
                Map<String,PaperLiveQuotes.Quote> quotes=PaperLiveQuotes.fetch(codes);
                java.time.LocalDateTime stamp=PaperLiveQuotes.nowInShanghai();
                ui.post(()->{
                    if(!sid.equals(selectedId())||current!=d){quoteBusy.set(false);return;}
                    int updated=0;
                    for(Holding h:d.holdings){
                        PaperLiveQuotes.Quote q=quotes.get(h.code);
                        if(PaperLiveQuotes.usable(q,h.quoteDay,stamp)){
                            h.price=q.price;h.quoteDay=q.tradingDay();h.quoteTime=q.clock();
                            h.dayChange=q.changePercent;h.online=true;h.quoteSource="腾讯网络参考报价";updated++;
                        }
                    }
                    quoteState=updated==0?"网络无可用的新报价；已回退本地收盘价":
                        "来源："+PaperLiveQuotes.PROVIDER+" · "+updated+"只有效，未更新的沿用本地收盘";
                    d.accounts[selectedStrategy].equity=d.cash+holdingsValue(d);
                    renderHome(d);renderAssets(d);renderRows();quoteBusy.set(false);
                });
            }catch(Exception ex){
                ui.post(()->{
                    if(sid.equals(selectedId())&&current==d){
                        quoteState="联网报价失败（"+ex.getClass().getSimpleName()+"），保留本地收盘价";
                        renderAssets(d);renderRows();
                    }
                    quoteBusy.set(false);
                });
            }
        },"qd-paper-live-quotes").start();
    }
    private void refreshTabs(){
        if(tabRow==null)return;tabRow.removeAllViews();
        for(String name:new String[]{"持仓","委托","成交","信号","战绩","诊断","流水"}){
            boolean selected=name.equals(activeTab);
            TextView t=text(name,13,selected?BLUE:MUTED,selected);
            t.setGravity(Gravity.CENTER);t.setPadding(dp(15),dp(10),dp(15),dp(10));
            t.setBackground(surface(selected?Color.rgb(228,237,255):BG,10));
            t.setOnClickListener(v->{activeTab=name;refreshTabs();renderRows();});
            LinearLayout.LayoutParams layout=margins(-2,dp(42),0);layout.rightMargin=dp(6);
            tabRow.addView(t,layout);
        }
    }
    private boolean match(String code){
        if(filter.isEmpty()||code.contains(filter))return true;
        if(current==null)return false;
        String name=current.names.get(code);
        if(name==null)for(Holding h:current.holdings)if(h.code.equals(code)){name=h.name;break;}
        return name!=null&&name.contains(filter);
    }
    private void detail(String header,String sub,int color,View.OnClickListener action,String label){
        LinearLayout box=column();box.setPadding(dp(11),dp(12),dp(11),dp(12));
        box.setBackground(surface(BG,12));
        box.addView(text(header,15,color,true));gap(box,4);
        TextView explanation=text(sub,12,MUTED,false);explanation.setLineSpacing(dp(3),1);box.addView(explanation);
        if(action!=null){gap(box,8);box.addView(button(label,BLUE,action),margins(-1,dp(40),0));}
        listPane.addView(box,margins(-1,-2,8));
    }
    private void priceField(LinearLayout root,String label,String value,int color){
        LinearLayout item=column();item.addView(text(label,11,MUTED,false));gap(item,2);
        item.addView(text(value,15,color,true));root.addView(item,new LinearLayout.LayoutParams(0,-2,1));
    }
    private void positionCard(Holding p){
        double pnl=(p.price-p.basis)*p.qty,pnlPct=(p.price/p.basis-1)*100;
        LinearLayout box=column();box.setPadding(dp(13),dp(14),dp(13),dp(14));box.setBackground(surface(BG,13));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout name=column();name.addView(text(p.name.isEmpty()?p.code:p.name,16,NAVY,true));
        name.addView(text(p.code+" · 持仓"+p.qty+"股",12,MUTED,false));
        top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout roi=column();roi.setGravity(Gravity.RIGHT);
        TextView profit=text(String.format(Locale.CHINA,"%+.2f%%",pnlPct),20,pnl>=0?RED:GREEN,true);profit.setGravity(Gravity.RIGHT);roi.addView(profit);
        TextView profitYuan=text(String.format(Locale.CHINA,"%+.2f 元",pnl),12,pnl>=0?RED:GREEN,false);
        profitYuan.setGravity(Gravity.RIGHT);roi.addView(profitYuan);top.addView(roi);
        box.addView(top);gap(box,13);
        LinearLayout prices=new LinearLayout(this);prices.setOrientation(LinearLayout.HORIZONTAL);
        priceField(prices,"参考现价", "¥"+fmt(p.price),p.dayChange>=0?RED:GREEN);
        priceField(prices,"持仓成本","¥"+fmt(p.basis),NAVY);
        priceField(prices,"持仓市值","¥"+money(p.price*p.qty),NAVY);
        box.addView(prices);gap(box,9);
        box.addView(text("涨跌幅 " +(Double.isNaN(p.dayChange)?"—（本地日K未计算）":String.format(Locale.CHINA,"%+.2f%%",p.dayChange))+
            "  ·  买入日期 "+p.boughtDay,12,MUTED,false));gap(box,3);
        box.addView(text("报价 " + p.quoteDay+(p.quoteTime.isEmpty()?"":" "+p.quoteTime)+" · "+p.quoteSource,11,MUTED,false));
        gap(box,11);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button sell=button("卖出持仓",GREEN,v->manualDialog("SELL",p.code,p.qty));
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(0,dp(40),1);b.rightMargin=dp(5);actions.addView(sell,b);
        Button buy=button("查看选股信号",BLUE,v->{activeTab="信号";refreshTabs();renderRows();});
        LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(0,dp(40),1);c.leftMargin=dp(5);actions.addView(buy,c);
        box.addView(actions);listPane.addView(box,margins(-1,-2,9));
    }
    private static String money(double n){return String.format(Locale.CHINA,"%,.2f",n);}
    private void renderRows(){
        if(listPane==null)return;
        listPane.removeAllViews();if(current==null){listPane.addView(text("本地模拟账户读取中…",13,MUTED,false));return;}
        int count=0;
        if("持仓".equals(activeTab)){
            sectionName.setText("持仓明细 · "+current.holdings.size()+"只 / 待成交"+current.pending+"笔");
            for(Holding p:current.holdings){if(!match(p.code))continue;count++;positionCard(p);}
            if(current.holdings.isEmpty() && current.pending>0){
                detail("尚未持仓，但有 "+current.pending+" 笔未成交委托",
                    "模拟买入不是立刻显示持仓：信号日下单，下一有效交易日有合格日K才结算。点击【委托】查看股票、股数、原因和状态。",
                    NAVY,v->{activeTab="委托";refreshTabs();renderRows();},"查看未成交委托");count++;
            }
        }else if("信号".equals(activeTab)){
            sectionName.setText(StrategySuite.title(selectedId())+" · 候选信号 "+current.day);
            for(PaperTradingStore.Signal s:current.signals){if(!match(s.code))continue;count++;
                int color="BUY".equals(s.action)?RED:"SELL".equals(s.action)?GREEN:NAVY;
                detail(("BUY".equals(s.action)?"允许候选买入":"SELL".equals(s.action)?"候选卖出":"HOLD".equals(s.action)?"持仓观察":"WATCH".equals(s.action)?"观察池（不可自动买入）":"BLOCKED".equals(s.action)?"仅供研究·市场风控禁止买入":"数据警告")+
                    "  "+current.names.getOrDefault(s.code,"")+" "+s.code+"  ¥"+fmt(s.price),
                    "分数 "+fmt(s.score)+" | "+s.reason,color,
                    "BUY".equals(s.action)?v->manualDialog("BUY",s.code,100):null,"按此股票手动下单");
            }
        }else if("诊断".equals(activeTab)){
            sectionName.setText("策略诊断 · 技术触发与风控过滤原因");
            String part="尚未完成当日市场扫描";
            for(String line:current.marketSummary.split("\n"))
                if(line.startsWith(StrategySuite.title(selectedId())+"：")){part=line;break;}
            detail("当前大盘状态",current.marketSummary.split("\n",2)[0],NAVY,null,"");
            detail("当前策略筛选计数",part,NAVY,null,"");
            detail("本策略选股逻辑",StrategySuite.formula(selectedId()),NAVY,null,"");
            detail("为何仍然空仓？","系统每天计算强/弱/震荡并分别给五个账户设置仓位预算；技术形态不达标时进入观察池，绝不把观察当成交。可买信号也可能因仓位、现金、100股手数或下一日无法成交而继续空仓；诊断计数仅反映最近一次扫描。",MUTED,null,"");
            count=4;
        }else if("委托".equals(activeTab)){
            sectionName.setText("委托订单 · 最近100笔（待成交 "+current.pending+"）");
            for(PaperTradingStore.OrderView o:current.orders){if(!match(o.code))continue;count++;
                String status="PENDING".equals(o.status)?"待下一交易日结算":"FILLED".equals(o.status)?"已成交":"已撤销/未成交";
                String caption="信号日 "+o.day+" · "+o.qty+"股 · "+status;
                caption+="\n"+("FILLED".equals(o.status)?"成交 "+o.fillDay+" · 成交价 ¥"+fmt(o.fillPrice):
                    "未成交，无买入成本价 · 等待下一有效交易日日K");
                caption+="\n"+("PENDING".equals(o.status)?(o.referencePrice>0?"信号日收盘参考 ¥"+fmt(o.referencePrice)+" · 非委托成交价":"尚无委托参考价；成交后显示真实模拟开盘成交价"):
                    "")+"\n原因："+o.reason;
                detail("#"+o.id+"  "+current.names.getOrDefault(o.code,"")+" "+o.code+"  "+("BUY".equals(o.side)?"买入":"卖出"),
                    caption,"BUY".equals(o.side)?RED:GREEN,
                    "PENDING".equals(o.status)?v->confirmCancel(o.id):null,"撤销未成交委托");
            }
        }else if("成交".equals(activeTab)){
            sectionName.setText("真实模拟成交 · 最近100笔");
            for(PaperTradingStore.FillView f:current.fills){if(!match(f.code))continue;count++;
                detail(current.names.getOrDefault(f.code,"")+" "+f.code+"  "+("BUY".equals(f.side)?"模拟买入":"模拟卖出")+" · ¥"+fmt(f.price),
                    "成交日 "+f.day+"  ·  "+f.qty+"股  ·  成交金额 ¥"+money(f.price*f.qty)+
                        "\n手续费 ¥"+fmt(f.fee)+"  ·  印花税 ¥"+fmt(f.tax)+
                        "  ·  现金变动 "+String.format(Locale.CHINA,"%+.2f",f.cashChange),
                    "BUY".equals(f.side)?RED:GREEN,null,"");
            }
        }else if("战绩".equals(activeTab)){
            sectionName.setText("收益风险分析");
            detail("策略交易记录统计（非历史回放）",current.performance,NAVY,null,"");
            detail("时间顺序历史回放 · 5种策略",current.validation,NAVY,null,"");count++;
        }else{
            sectionName.setText("最近交易流水");detail("模拟成交与委托",current.ledger,NAVY,null,"");count++;
        }
        if(count==0)detail("当前没有"+activeTab+"记录",
            "这表示该策略账户目前没有对应数据，不代表已经买入。委托和成交单独记录；未成交股票只在【委托】显示。先分析行情、查看信号和风险预算，再决定是否开启自动模拟交易。",MUTED,null,"");
    }
    private static String fmt(double n){return String.format(Locale.CHINA,"%.2f",n);}
    private void manualDialog(String side,String presetCode,int defaultQty){
        if(latestDay.isEmpty()){Toast.makeText(this,"请先载入有效行情",Toast.LENGTH_SHORT).show();return;}
        LinearLayout form=column();form.setPadding(dp(22),dp(10),dp(22),dp(3));
        form.addView(text("股票代码（A股6位）",13,NAVY,true));
        EditText code=new EditText(this);code.setSingleLine(true);code.setInputType(2);
        code.setHint("600519");code.setText(presetCode);form.addView(code);
        form.addView(text("股数（100股整数倍）",13,NAVY,true));
        EditText qty=new EditText(this);qty.setSingleLine(true);qty.setInputType(2);
        qty.setText(""+defaultQty);form.addView(qty);
        form.addView(text("最新信号日："+latestDay+"。这是次交易日开盘的模拟委托，不会发送真实订单。",12,MUTED,false));
        new AlertDialog.Builder(this).setTitle("BUY".equals(side)?"模拟买入":"模拟卖出").setView(form)
            .setNegativeButton("取消",null).setPositiveButton("确认委托",(dlg,which)->{
                int shares;
                try{shares=Integer.parseInt(qty.getText().toString().trim());}catch(Exception ex){message.setText("请输入有效股数");return;}
                manualOrder(side,code.getText().toString().trim(),shares);
            }).show();
    }
    private void manualOrder(String side,String code,int qty){
        if(!busy.compareAndSet(false,true)){message.setText("后台任务运行中，请完成后操作");return;}
        message.setText("正在校验模拟委托与持仓…");
        final String sid=selectedId();
        new Thread(()->{
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore p=new PaperTradingStore(getApplicationContext())){
                long a=p.account(sid);String day=PaperTradingStore.asOf(market);
                String result=p.manualOrder(market,a,day,code,side,qty);
                Dashboard d=readDashboard(market,p,a,day);d.message=result;
                ui.post(()->{activeTab="委托";show(d);});
            }catch(Exception ex){ui.post(()->message.setText("下单失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-manual-order").start();
    }
    private void confirmCancel(long id){
        new AlertDialog.Builder(this).setTitle("撤销委托 #"+id)
            .setMessage("只能撤销还未模拟成交的委托；已成交无法撤销。")
            .setNegativeButton("返回",null).setPositiveButton("确认撤销",(dlg,which)->cancel(id)).show();
    }
    private void cancel(long id){
        if(!busy.compareAndSet(false,true)){message.setText("后台任务运行中，暂不能撤单");return;}
        final String sid=selectedId();
        new Thread(()->{
            try(MarketDb m=new MarketDb(getApplicationContext());PaperTradingStore p=new PaperTradingStore(getApplicationContext())){
                long a=p.account(sid);String msg=p.cancelPending(a,id);String day=PaperTradingStore.asOf(m);
                Dashboard d=readDashboard(m,p,a,day);d.message=msg;ui.post(()->show(d));
            }catch(Exception ex){ui.post(()->message.setText("撤单失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-cancel").start();
    }
    private void exportFile(int kind){
        if(busy.get()){message.setText("模拟任务运行中，请完成后导出");return;}
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(kind==EXPORT?"text/csv":"application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE,kind==EXPORT?"QD-FiveLab-当前策略模拟交易.csv":"QD-FiveLab-五策略模拟账本.sqlite3");
        try{startActivityForResult(intent,kind);}catch(Exception ex){message.setText("无法打开文件保存窗口："+ex.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if((request!=EXPORT&&request!=EXPORT_DB)||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri target=data.getData();
        if(!busy.compareAndSet(false,true)){message.setText("模拟任务仍在运行，暂不能导出");return;}
        message.setText("正在导出模拟账户…");
        final String sid=selectedId();
        new Thread(()->{
            try(PaperTradingStore p=new PaperTradingStore(getApplicationContext());
                OutputStream stream=getContentResolver().openOutputStream(target,"w")){
                if(stream==null)throw new IllegalStateException("保存地址不可写");
                if(request==EXPORT){
                    OutputStreamWriter writer=new OutputStreamWriter(stream,StandardCharsets.UTF_8);
                    p.exportLedger(p.account(sid),writer);writer.flush();
                }else{
                    p.accounts();p.checkpoint();
                    File source=getDatabasePath(PaperTradingStore.NAME);
                    try(FileInputStream input=new FileInputStream(source)){
                        byte[] buffer=new byte[65536];int n;
                        while((n=input.read(buffer))!=-1)stream.write(buffer,0,n);
                    }stream.flush();
                }
                ui.post(()->{message.setText("模拟账户导出完成");Toast.makeText(this,"文件已保存",Toast.LENGTH_LONG).show();});
            }catch(Exception ex){ui.post(()->message.setText("导出失败："+ex.getMessage()));}
            finally{busy.set(false);}
        },"qd-lab-export").start();
    }
}
