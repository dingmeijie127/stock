package com.quantdesk.download;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Small, self-contained visual of ACTUALLY recorded paper-account equity snapshots. */
public final class EquityCurveView extends View{
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Double> values=new ArrayList<>();
    public EquityCurveView(Context context){super(context);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setValues(List<Double> v){values=v==null?new ArrayList<>():new ArrayList<>(v);invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        int w=getWidth(),h=getHeight();if(w<80||h<60)return;
        float left=14,top=21,right=w-14,bottom=h-21;
        paint.setTextSize(11*getResources().getDisplayMetrics().scaledDensity);
        if(values.size()<2){paint.setColor(Color.rgb(107,119,140));paint.setStyle(Paint.Style.FILL);
            c.drawText("净值曲线：至少需要两个不同收盘日的记录",left,h/2f,paint);return;}
        double low=Double.POSITIVE_INFINITY,high=Double.NEGATIVE_INFINITY;
        for(double x:values)if(Double.isFinite(x)){low=Math.min(low,x);high=Math.max(high,x);}
        if(!Double.isFinite(low)||!Double.isFinite(high))return;
        double span=Math.max(1,high-low);low-=span*.1;high+=span*.1;
        paint.setStrokeWidth(1);paint.setColor(Color.rgb(218,226,236));
        c.drawLine(left,top,right,top,paint);c.drawLine(left,(top+bottom)/2,right,(top+bottom)/2,paint);
        c.drawLine(left,bottom,right,bottom,paint);
        Path line=new Path();boolean start=false;
        for(int i=0;i<values.size();i++){
            double equity=values.get(i);if(!Double.isFinite(equity))continue;
            float x=left+(right-left)*i/(values.size()-1f);
            float y=(float)(bottom-(bottom-top)*(equity-low)/(high-low));
            if(!start){line.moveTo(x,y);start=true;}else line.lineTo(x,y);
        }
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3.1f);
        paint.setColor(values.get(values.size()-1)>=values.get(0)?Color.rgb(201,63,74):Color.rgb(27,148,105));
        c.drawPath(line,paint);paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(83,102,125));
        c.drawText(String.format(Locale.CHINA,"起始 ¥%,.0f",values.get(0)),left,12*getResources().getDisplayMetrics().scaledDensity,paint);
        String last=String.format(Locale.CHINA,"当前 ¥%,.0f",values.get(values.size()-1));
        c.drawText(last,right-paint.measureText(last),h-2,paint);
    }
}
