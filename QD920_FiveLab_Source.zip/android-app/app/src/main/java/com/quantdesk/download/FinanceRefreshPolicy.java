package com.quantdesk.download;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** Financial providers are report-period sources, not live tick feeds.
 *  Database row de-duplication alone is NOT request de-duplication.
 */
public final class FinanceRefreshPolicy {
    private static final long DAY_MS=86400000L;
    private FinanceRefreshPolicy(){}
    /** Back off unsuccessful sources; don't retry failed/empty requests on every tap.
     *  Reporting season still gets a weekly successful-data refresh.
     */
    public static long retryAfterMillis(String status,String dataset){
        if ("failed".equals(status)) return DAY_MS;
        if ("empty".equals(status)) return 7L*DAY_MS;
        if ("complete".equals(status)) return dataset.startsWith("hk_") ? 14L*DAY_MS : 7L*DAY_MS;
        return 0;
    }
    public static boolean due(String status,long checkedAt,long now,String dataset){
        return status==null || checkedAt<=0 || now<checkedAt ||
            now-checkedAt>=retryAfterMillis(status,dataset);
    }
    /** First successful scan gets two years. Subsequent scheduled scans need only
     *  a rolling 15-month report-period window (late publications/revisions).
     *  Older restatements need a separate, deliberate full audit, not every tap.
     */
    public static LocalDate requestStart(LocalDate baseline,LocalDate today,String lastSuccessfulEnd){
        if(lastSuccessfulEnd==null||lastSuccessfulEnd.isEmpty())return baseline;
        LocalDate overlap=today.minusMonths(15);
        return overlap.isAfter(baseline)?overlap:baseline;
    }
    /** A saved fiscal period does not expire just because seven calendar days passed.
     *  A/H indicator periods are not daily quotes; dividends are event based.
     *  We open a new quarter/half-year only after a modest publication grace period.
     */
    public static boolean newReportPeriodMayExist(String dataset,String savedPeriod,LocalDate today){
        if("hk_dividend".equals(dataset))return true; // Irregular event; poll for NEW events only.
        LocalDate latest=parsePeriod(savedPeriod);
        if(latest==null)return true; // Unknown old format: never claim the cache is complete.
        return !today.isBefore(nextReportPeriod(dataset,latest).plusDays(7));
    }
    /** With saved rows, HTTP starts AFTER the latest stored fiscal period/event.
     *  Full historical audits must be explicitly requested separately, not forced
     *  during every daily K-line run.
     */
    public static LocalDate requestMissingStart(LocalDate baseline,LocalDate today,
        String lastSuccessfulEnd,String lastSavedPeriod,String dataset){
        LocalDate latest=parsePeriod(lastSavedPeriod);
        if(latest!=null){
            LocalDate next="hk_dividend".equals(dataset)?latest.plusDays(1):nextReportPeriod(dataset,latest);
            return next.isAfter(baseline)?next:baseline;
        }
        return requestStart(baseline,today,lastSuccessfulEnd);
    }
    static LocalDate parsePeriod(String raw){
        if(raw==null)return null;
        String text=raw.trim();
        try{
            if(text.matches("[0-9]{8}"))return LocalDate.parse(text,DateTimeFormatter.BASIC_ISO_DATE);
            if(text.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))return LocalDate.parse(text);
        }catch(DateTimeParseException ignored){}
        return null;
    }
    private static LocalDate nextReportPeriod(String dataset,LocalDate latest){
        int year=latest.getYear(),month=latest.getMonthValue();
        if("hk_indicator".equals(dataset)){
            // HK issuers have non-December financial year ends (e.g. March).
            // Move one half-year from THEIR saved report date, not Jun/Dec globally.
            LocalDate next=latest.plusMonths(6);
            return latest.getDayOfMonth()==latest.lengthOfMonth()
                ?next.withDayOfMonth(next.lengthOfMonth()):next;
        }
        int quarterEnd=((month-1)/3+1)*3;
        return LocalDate.of(year,quarterEnd,1).plusMonths(4).minusDays(1);
    }

}
