package com.quantdesk.download;

import java.util.Locale;

/** Fixed, testable exposure rules for the FIVE independent paper experiments.
 * A regime is a *budget*, not a prediction or a promise to trade every day.
 * UNKNOWN always means no new risk. All fractions are of account equity.
 */
public final class RiskPolicy {
    private RiskPolicy() {}
    public static final class Plan {
        public final double exposure, perName;
        public final int maxPositions;
        public Plan(double exposure,double perName,int maxPositions){
            if(exposure<0||exposure>1||perName<0||perName>exposure||maxPositions<0||maxPositions>5)
                throw new IllegalArgumentException("invalid paper risk budget");
            this.exposure=exposure;this.perName=perName;this.maxPositions=maxPositions;
        }
        public boolean mayBuy(){return exposure>0&&perName>0&&maxPositions>0;}
        public String description(){return String.format(Locale.CHINA,"总股票仓位上限 %.0f%%，单股 %.0f%%，最多 %d 只",100*exposure,100*perName,maxPositions);}
        /** Existing positions + waiting buys count against the limit. */
        public double newCapital(double equity,double invested,double cash){
            if(!mayBuy()||!Double.isFinite(equity)||!Double.isFinite(invested)||!Double.isFinite(cash)||equity<=0)return 0;
            return Math.max(0,Math.min(Math.max(0,cash),Math.min(equity*perName,equity*exposure-Math.max(0,invested))));
        }
    }
    public static Plan forMode(String strategy,String mode){
        if(MarketRegime.UNKNOWN.equals(mode)||mode==null)return new Plan(0,0,0);
        if(MarketRegime.BEAR.equals(mode)){
            if(StrategySuite.RSI.equals(strategy))return new Plan(.12,.12,1);
            if(StrategySuite.CHAN.equals(strategy))return new Plan(.12,.12,1);
            if(StrategySuite.BREAKOUT.equals(strategy))return new Plan(.15,.15,1);
            if(StrategySuite.BOLL.equals(strategy))return new Plan(.12,.08,1);
            if(StrategySuite.MOMENTUM.equals(strategy))return new Plan(.15,.15,1);
        }else if(MarketRegime.RANGE.equals(mode)){
            if(StrategySuite.RSI.equals(strategy))return new Plan(.35,.18,2);
            if(StrategySuite.CHAN.equals(strategy))return new Plan(.30,.15,2);
            if(StrategySuite.BREAKOUT.equals(strategy))return new Plan(.25,.13,2);
            if(StrategySuite.BOLL.equals(strategy))return new Plan(.45,.15,3);
            if(StrategySuite.MOMENTUM.equals(strategy))return new Plan(.30,.15,2);
        }else if(MarketRegime.BULL.equals(mode)){
            if(StrategySuite.RSI.equals(strategy))return new Plan(.55,.19,3);
            if(StrategySuite.CHAN.equals(strategy))return new Plan(.60,.20,3);
            if(StrategySuite.BREAKOUT.equals(strategy))return new Plan(.65,.17,4);
            if(StrategySuite.BOLL.equals(strategy))return new Plan(.20,.10,2);
            if(StrategySuite.MOMENTUM.equals(strategy))return new Plan(.60,.16,4);
        }
        return new Plan(0,0,0);
    }
    /** Some pending orders come from an older APK and had no scan plan. Do not silently increase their budget. */
    public static Plan legacy(){return new Plan(.20,.20,1);}
}
