package com.quantdesk.download;

import java.util.List;
import java.util.Locale;

/** Five distinct, fixed-parameter, no-forward-data A-share strategy experiments.
 * Chan: simplified confirmed 3-bar fractal + downward consolidation flag, NOT complete Chan theory.
 */
public final class StrategySuite {
    private StrategySuite(){}
    public static final String RSI=SwingStrategy.VERSION;
    public static final String CHAN="CHAN_FRACTAL_FLAG_V1";
    public static final String BREAKOUT="DONCHIAN_ATR_V1";
    public static final String BOLL="BOLLINGER_REVERSAL_V1";
    public static final String MOMENTUM="MOMENTUM_LOWVOL_V1";
    public static final String[] IDS={RSI,CHAN,BREAKOUT,BOLL,MOMENTUM};
    public static String title(String id){
        if(RSI.equals(id))return "① RSI2 趋势回调";
        if(CHAN.equals(id))return "② 缠论分型 + 旗形";
        if(BREAKOUT.equals(id))return "③ Donchian 突破";
        if(BOLL.equals(id))return "④ 布林均值回归";
        if(MOMENTUM.equals(id))return "⑤ 动量 + 低波动";
        return id;
    }
    public static String formula(String id){
        if(RSI.equals(id))return "牛市趋势回调 / 震荡与熊市缩仓反弹 + RSI(2) + ATR";
        if(CHAN.equals(id))return "底分型+旗形突破；弱市短整理确认（仅简化分型，不等于完整缠论笔/线段/中枢）";
        if(BREAKOUT.equals(id))return "牛市55日/震荡与弱市20日唐奇安突破 + ATR及成交量";
        if(BOLL.equals(id))return "布林带回归+RSI14；弱市轻仓反抽，不保证触发；仓位由市场状态限制";
        if(MOMENTUM.equals(id))return "牛市60日强势动量 / 弱市抗跌领涨 + ATR低波动";
        return "未知实验";
    }
    private static SwingStrategy.Advice out(String type,String text,SwingStrategy.Candle b,double score){
        return new SwingStrategy.Advice(type,text,b.day,b.close,score);
    }
    static double highest(List<SwingStrategy.Candle> b,int end,int count){double max=Double.NEGATIVE_INFINITY;for(int i=end-count;i<end;i++)max=Math.max(max,b.get(i).high);return max;}
    static double lowest(List<SwingStrategy.Candle> b,int end,int count){double min=Double.POSITIVE_INFINITY;for(int i=end-count;i<end;i++)min=Math.min(min,b.get(i).low);return min;}
    static double rsi14(List<SwingStrategy.Candle> b,int n){
        double up=0,down=0;for(int i=n-14;i<n;i++){
            double d=b.get(i).close-b.get(i-1).close;up+=Math.max(0,d);down+=Math.max(0,-d);
        }
        if(down==0)return up==0?50:100;
        return 100-100/(1+up/down);
    }
    private static boolean bottomFractal(List<SwingStrategy.Candle> b,int i){
        return i>0&&i<b.size()-1&&b.get(i).low<b.get(i-1).low&&b.get(i).low<b.get(i+1).low;
    }
    /** Separate genuine raw technical triggers from the market risk gate.
     * A blocked technical BUY is NEVER converted to an executable BUY/order.
     */
    public static final class Assessment {
        public final SwingStrategy.Advice advice,raw;
        public final String category;
        Assessment(SwingStrategy.Advice advice,SwingStrategy.Advice raw,String category){
            this.advice=advice;this.raw=raw;this.category=category;
        }
    }
    public static Assessment assess(String id,List<SwingStrategy.Candle> bars,String day,
                                    MarketRegime.Result market,boolean held,double basis,int heldDays){
        if(held){
            SwingStrategy.Advice advice=evaluate(id,bars,day,market,true,basis,heldDays);
            return new Assessment(advice,advice,"HELD");
        }
        if(market==null){
            SwingStrategy.Advice none=new SwingStrategy.Advice("NONE","没有市场广度判断",day,0,0);
            return new Assessment(none,none,"QUALITY");
        }
        // A research-only permissive regime for the strategy's OWN entry conditions;
        // use the real market for the final execution permission.
        String researchMode=MarketRegime.UNKNOWN.equals(market.mode)?
            (BOLL.equals(id)?MarketRegime.RANGE:MarketRegime.BULL):market.mode;
        MarketRegime.Result research=new MarketRegime.Result(day,researchMode,market.observed,
            market.universe,market.breadth20,market.breadth60,market.advancing,market.return20,market.description);
        SwingStrategy.Advice raw=evaluate(id,bars,day,research,false,0,0);
        if(!"BUY".equals(raw.action)){
            boolean quality=raw.reason.contains("K线")||raw.reason.contains("日K")||raw.reason.contains("目标日")||raw.reason.contains("行情");
            return new Assessment(raw,raw,quality?"QUALITY":"NO_SETUP");
        }
        if(!market.allowed(id)){
            String reason="技术触发，但"+market.label()+"不允许自动开仓；原始原因："+raw.reason;
            SwingStrategy.Advice blocked=new SwingStrategy.Advice("BLOCKED",reason,day,raw.price,raw.score);
            return new Assessment(blocked,raw,"BLOCKED");
        }
        return new Assessment(raw,raw,"READY");
    }
    public static SwingStrategy.Advice evaluate(String id,List<SwingStrategy.Candle> b,String day,
                                                 MarketRegime.Result regime,boolean held,double basis,int heldDays){
        if(regime==null)return new SwingStrategy.Advice("NONE","未完成大盘广度分析",day,0,0);
        if(b==null||b.size()<105)return new SwingStrategy.Advice("NONE","有效日K不足105根",day,0,0);
        int n=b.size();SwingStrategy.Candle last=b.get(n-1),prev=b.get(n-2);
        if(!day.equals(last.day))return out("NONE","该股票没有目标日行情",last,0);
        for(int i=n-105;i<n;i++)if(!b.get(i).valid()||(i>n-105&&b.get(i-1).day.compareTo(b.get(i).day)>=0))
            return out("NONE","K线质量或顺序异常",last,0);
        double ma20=SwingStrategy.sma(b,n,20),ma60=SwingStrategy.sma(b,n,60),
            ma100=SwingStrategy.sma(b,n,100),atr=SwingStrategy.atr14(b,n),atrRate=atr/last.close;
        if(held){
            if(basis<=0||!Double.isFinite(basis))return out("NONE","异常成本，暂停执行",last,0);
            double r=last.close/basis-1;
            if(MarketRegime.BEAR.equals(regime.mode)){
                // One small high-conviction defensive position may survive while it remains strong.
                // Paper orders are still subject to T+1 and next available session opening prices.
                if(BOLL.equals(id)){
                    if(r<=-.035||r>=.055||heldDays>=3||last.close<prev.low)
                        return out("SELL","熊市布林反抽：止损/止盈/3日到期退出",last,99);
                    return out("HOLD","熊市布林反抽：小额仓位，最长3日",last,0);
                }
                if(r<=-.04||r>=.085||heldDays>=7||(heldDays>=2&&last.close<ma20*.96))
                    return out("SELL","弱市风控：4%止损/8.5%止盈/7日到期或跌离MA20",last,98);
                return out("HOLD","弱市强势股试验：小额持仓/短周期复核",last,0);
            }
            if(r<=-Math.max(.04,Math.min(.085,2.2*atr/basis)))return out("SELL","ATR风险止损",last,96);
            if(r>=.14)return out("SELL","获利达到14%，锁定模拟收益",last,92);
            if(heldDays>=4&&last.close<ma20*.975)return out("SELL","失守20日均线，趋势保护",last,88);
            if(heldDays>=20)return out("SELL","持有20交易日，到期再平衡",last,80);
            return out("HOLD","持仓跟踪；"+regime.label(),last,0);
        }
        if(!regime.allowed(id))return out("NONE","市场状态"+regime.label()+"不适合当前策略新开仓",last,0);
        double daily=last.close/prev.close-1;
        if(last.close<3||Math.abs(daily)>.095||atrRate<.008||atrRate>.07)
            return out("NONE","流动性/涨跌幅/波动率过滤",last,0);
        boolean bear=MarketRegime.BEAR.equals(regime.mode),range=MarketRegime.RANGE.equals(regime.mode);
        if(RSI.equals(id)){
            if(bear||range){
                double r0=SwingStrategy.rsi2(b,n-1),r1=SwingStrategy.rsi2(b,n);
                boolean confirmed=r0<=(bear?25:28)&&r1>=r0+5&&last.close>prev.close&&last.close>=last.open;
                boolean location=last.close>ma20*(bear?.93:.91)&&last.close<ma20*1.025;
                boolean trend=ma20>SwingStrategy.sma(b,n-5,20)*(bear?.975:.985);
                if(confirmed&&location&&trend&&atrRate<(bear?.052:.063))
                    return out("BUY",String.format(Locale.CHINA,"%s RSI(2) %.1f→%.1f，MA20附近反弹；按大盘仓位预算执行",bear?"熊市轻仓":"震荡回调",r0,r1),last,78+Math.min(12,r1-r0));
            }else return SwingStrategy.evaluate(b,day,false,0,0);
        }else if(CHAN.equals(id)){
            int bottoms=0;double lastBottom=0;
            for(int i=n-20;i<n-2;i++)if(bottomFractal(b,i)){bottoms++;lastBottom=b.get(i).low;}
            double flagHigh=highest(b,n-1,11),earlyHigh=highest(b,n-12,11);
            boolean flag=earlyHigh>flagHigh*1.02&&last.close>flagHigh&&last.close>prev.close;
            double avgVol=0;for(int i=n-21;i<n-1;i++)avgVol+=b.get(i).volume/20;
            if(bear||range){
                double localTop=highest(b,n-1,bear?5:8);
                if(bottoms>=1&&lastBottom>0&&last.close>localTop&&
                   last.close>ma20*(bear?.96:.94)&&last.volume>avgVol*(bear?1.04:.96)&&atrRate<.055)
                    return out("BUY",String.format(Locale.CHINA,"%s：确认底分型%d处，突破%d日整理区 %.2f，量比 %.1f",
                        bear?"弱市轻仓分型突破":"震荡简化旗形",bottoms,bear?5:8,localTop,last.volume/avgVol),last,73+Math.min(18,(last.close/localTop-1)*1000));
            }else if(bottoms>=2&&lastBottom>0&&last.close>ma60&&flag&&last.volume>avgVol*1.20)
                return out("BUY",String.format(Locale.CHINA,"已确认%d处底分型；下倾整理旗形向上突破 %.2f；放量 %.1f倍",bottoms,flagHigh,last.volume/avgVol),last,77+Math.min(18,(last.close/flagHigh-1)*1000));
        }else if(BREAKOUT.equals(id)){
            int lookback=bear||range?20:55;
            double top=highest(b,n-1,lookback);
            double v=0;for(int i=n-21;i<n-1;i++)v+=b.get(i).volume/20;
            boolean trend=bear?last.close>ma60*.98&&ma20>SwingStrategy.sma(b,n-5,20):
                          range?last.close>ma20&&ma20>SwingStrategy.sma(b,n-5,20):
                                ma60>SwingStrategy.sma(b,n-5,60)&&last.close>ma20;
            if(last.close>top&&trend&&atrRate<(bear?.04:.055)&&last.volume>v*(bear?1.10:.90))
                return out("BUY",String.format(Locale.CHINA,"%s：突破前%d日高点 %.2f，ATR %.1f%%",bear?"弱市强势股轻仓":range?"震荡短突破":"牛市趋势",lookback,top,100*atrRate),last,74+Math.min(20,(last.close/top-1)*1000));
        }else if(BOLL.equals(id)){
            double mean=ma20,var=0,priorMean=SwingStrategy.sma(b,n-1,20),priorVar=0;
            for(int i=n-20;i<n;i++)var+=Math.pow(b.get(i).close-mean,2)/20;
            for(int i=n-21;i<n-1;i++)priorVar+=Math.pow(b.get(i).close-priorMean,2)/20;
            double lower=mean-2*Math.sqrt(var),prevLower=priorMean-2*Math.sqrt(priorVar);
            if(bear){
                double avgVol=0;for(int i=n-21;i<n-1;i++)avgVol+=b.get(i).volume/20.;
                if((prev.close<prevLower||prev.low<prevLower)&&last.close>lower&&
                   last.close>prev.close&&last.close>last.open&&last.volume>avgVol*.9&&
                   rsi14(b,n)>=25&&rsi14(b,n)<=58&&atrRate<.055)
                    return out("BUY",String.format(Locale.CHINA,"熊市防御反弹：重新站回布林下轨 %.2f，RSI14 %.1f；仓位上限8%%",lower,rsi14(b,n)),last,78);
            }else if((prev.close<prevLower||prev.low<prevLower)&&last.close>lower&&last.close>prev.close&&rsi14(b,n)<55)
                return out("BUY",String.format(Locale.CHINA,"布林下轨回归 %.2f；RSI14 %.1f",lower,rsi14(b,n)),last,75);
        }else if(MOMENTUM.equals(id)){
            double mom60=last.close/b.get(n-61).close-1,mom20=last.close/b.get(n-21).close-1;
            boolean ok=bear?last.close>ma60&&last.close>ma20&&mom20>.028&&mom60>0&&atrRate<.035:
                range?last.close>ma60&&ma20>SwingStrategy.sma(b,n-5,20)&&mom20>.027&&mom60>.035&&atrRate<.04:
                      last.close>ma100&&ma20>ma60&&mom60>.08&&mom60<.35&&mom20>.02&&mom20<.16&&atrRate<.034;
            if(ok)return out("BUY",String.format(Locale.CHINA,"%s：60日动量 %.1f%%，20日动量 %.1f%%，低ATR %.1f%%",
                bear?"弱市抗跌强势":range?"震荡相对强势":"牛市动量",mom60*100,mom20*100,atrRate*100),last,68+Math.min(25,mom60*70));
        }
        return out("NONE","不满足"+title(id)+"的完整入场条件",last,0);
    }
    /** Research watchlist only: proximity to a setup is NOT a BUY order and never counted as a win. */
    public static SwingStrategy.Advice watch(String id,List<SwingStrategy.Candle> b,String day){
        if(b==null||b.size()<105||!day.equals(b.get(b.size()-1).day))return null;
        int n=b.size();for(int i=n-105;i<n;i++)if(!b.get(i).valid())return null;
        SwingStrategy.Candle last=b.get(n-1);
        if(last.close<3||Math.abs(last.close/b.get(n-2).close-1)>.095)return null;
        double ma20=SwingStrategy.sma(b,n,20),ma60=SwingStrategy.sma(b,n,60),
            a=SwingStrategy.atr14(b,n)/last.close;
        if(a<.008||a>.075)return null;
        double score=0;String reason="";
        if(RSI.equals(id)){
            double r=SwingStrategy.rsi2(b,n);
            if(r<42&&last.close>ma20*.90&&last.close<ma20*1.06){score=55-r*.38;reason="RSI2偏低，等待收盘确认反弹";}
        }else if(CHAN.equals(id)){
            int fractals=0;for(int i=n-18;i<n-2;i++)if(bottomFractal(b,i))fractals++;
            double top=highest(b,n-1,8);
            if(fractals>0&&last.close>ma20*.94&&last.close>top*.95){score=35+Math.min(15,(last.close/top)*10);reason="已出现确认底分型，观察整理区上沿";}
        }else if(BREAKOUT.equals(id)){
            double top=highest(b,n-1,20);
            if(last.close>top*.94&&last.close>ma20){score=40+Math.min(12,(last.close/top)*11);reason="接近20日突破位，等待放量有效突破";}
        }else if(BOLL.equals(id)){
            double v=0;for(int i=n-20;i<n;i++)v+=Math.pow(b.get(i).close-ma20,2)/20;
            if(last.close<ma20-.45*Math.sqrt(v)){score=45+Math.min(12,(ma20-last.close)/ma20*150);reason="接近布林下沿，等待反转确认";}
        }else if(MOMENTUM.equals(id)){
            double mom20=last.close/b.get(n-21).close-1;
            if(last.close>ma60*.97&&mom20>0&&a<.045){score=45+Math.min(12,mom20*45);reason="抗跌动量观察，等待触发入场规则";}
        }
        return score>0?out("WATCH",reason+"（观察池，不可自动买入）",last,score):null;
    }

}
