package com.quantdesk.download;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Pure planning logic; missing exchange sessions are evidence, not a proof of trading.
 * Stock suspensions, IPOs and holidays are checked through the provider, never fabricated.
 */
public final class HistoryGapPlanner {
    private HistoryGapPlanner() {}
    public static final class Span {
        public final LocalDate from,to;
        public Span(LocalDate from,LocalDate to){this.from=from;this.to=to;}
        @Override public String toString(){return from+".."+to;}
    }
    /** The verified range MUST be created by this version's full-coverage pass, not a legacy task. */
    public static List<Span> plan(LocalDate start,LocalDate end,List<String> existing,
                                  List<String> reference,String verifiedFrom,String verifiedTo){
        List<Span> result=new ArrayList<>();
        if(start.isAfter(end))return result;
        LocalDate coveredTo=null;
        if(verifiedFrom!=null&&verifiedTo!=null){
            try{
                if(!LocalDate.parse(verifiedFrom).isAfter(start))coveredTo=LocalDate.parse(verifiedTo);
            }catch(Exception ignored){}
        }
        if(coveredTo!=null){
            if(!coveredTo.isBefore(end))return result;
            LocalDate next=coveredTo.plusDays(1);
            result.add(new Span(next.isBefore(start)?start:next,end));
            return result;
        }
        if(existing.isEmpty()||reference.size()<80){
            result.add(new Span(start,end));return result;
        }
        LocalDate first=LocalDate.parse(existing.get(0));
        LocalDate last=LocalDate.parse(existing.get(existing.size()-1));
        if(first.isAfter(start)){
            boolean missedSession=false;
            for(String date:reference){
                LocalDate session=LocalDate.parse(date);
                if(!session.isBefore(start)&&session.isBefore(first)){missedSession=true;break;}
            }
            // Avoid reporting a weekend/short holiday before the first bar as a gap.
            if(missedSession||java.time.temporal.ChronoUnit.DAYS.between(start,first)>7)
                result.add(new Span(start,first.minusDays(1)));
        }
        Set<String> present=new HashSet<>(existing);
        LocalDate open=null,close=null;
        for(String day:reference){
            LocalDate d=LocalDate.parse(day);
            if(d.isBefore(first)||d.isAfter(last)||d.isBefore(start)||d.isAfter(end))continue;
            if(!present.contains(day)){
                if(open==null)open=d;
                close=d;
            }else if(open!=null){
                result.add(new Span(open,close));open=null;close=null;
            }
        }
        if(open!=null)result.add(new Span(open,close));
        if(last.isBefore(end))result.add(new Span(last.plusDays(1),end));
        return result;
    }
}
