package com.quantdesk.download;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/** Read-only descriptive factors from STORED unadjusted daily closes.
 * Not an adjusted-return or backtesting engine. Does not fabricate missing days.
 */
public final class AQuantFactors {
    private AQuantFactors() {}
    public static final class Candle {
        public final LocalDate day;
        public final double open, high, low, close, volume;
        public Candle(String date,double o,double h,double l,double c,double v){
            day=LocalDate.parse(date);open=o;high=h;low=l;close=c;volume=v;
        }
        boolean valid(){
            return Double.isFinite(open)&&Double.isFinite(high)&&Double.isFinite(low)&&
                Double.isFinite(close)&&Double.isFinite(volume)&&low>0&&high>=low&&
                open>=low-0.00001&&open<=high+0.00001&&close>=low-0.00001&&
                close<=high+0.00001&&volume>=0;
        }
    }
    public static final class Result {
        public final String status,day;
        public final int observations;
        public final double close,ret20,ret60,ma20,ma60,volatility20,drawdown60;
        Result(String status,String day,int n,double close,double ret20,double ret60,
               double ma20,double ma60,double vol20,double drawdown60){
            this.status=status;this.day=day;observations=n;this.close=close;
            this.ret20=ret20;this.ret60=ret60;this.ma20=ma20;this.ma60=ma60;
            volatility20=vol20;this.drawdown60=drawdown60;
        }
        public boolean eligible(){return "OK_RAW_UNADJUSTED".equals(status);}
    }
    private static Result blocked(String status,List<Candle> rows){
        int n=rows.size();Candle last=n==0?null:rows.get(n-1);
        return new Result(status,last==null?"":last.day.toString(),n,
            last==null?Double.NaN:last.close,Double.NaN,Double.NaN,Double.NaN,
            Double.NaN,Double.NaN,Double.NaN);
    }
    /** Input ordered oldest to newest, <= as-of date, max 61 most recent stored days. */
    public static Result compute(List<Candle> rows,LocalDate asOf){
        if(rows.size()<61)return blocked("INSUFFICIENT_61",rows);
        Candle last=rows.get(rows.size()-1);
        if(last.day.isAfter(asOf))return blocked("FUTURE_BAR",rows);
        if(ChronoUnit.DAYS.between(last.day,asOf)>15)return blocked("STALE_15D",rows);
        LocalDate previous=null;
        for(Candle row:rows){
            if(!row.valid())return blocked("INVALID_OHLCV",rows);
            if(previous!=null){
                if(!row.day.isAfter(previous))return blocked("DUPLICATE_OR_UNSORTED",rows);
                if(ChronoUnit.DAYS.between(previous,row.day)>20)
                    return blocked("GAP_OVER_20D",rows);
            }
            previous=row.day;
        }
        int n=rows.size();
        double lastClose=last.close;
        double sum20=0,sum60=0;
        for(int i=n-20;i<n;i++)sum20+=rows.get(i).close;
        for(int i=n-60;i<n;i++)sum60+=rows.get(i).close;
        double sumLogs=0,sumSquares=0;
        for(int i=n-20;i<n;i++){
            double lr=Math.log(rows.get(i).close/rows.get(i-1).close);
            sumLogs+=lr;sumSquares+=lr*lr;
        }
        double mean=sumLogs/20;
        double var=Math.max(0,sumSquares/20-mean*mean);
        double peak=0,maxDrawdown=0;
        for(int i=n-60;i<n;i++){
            double c=rows.get(i).close;
            peak=Math.max(peak,c);
            maxDrawdown=Math.min(maxDrawdown,c/peak-1);
        }
        return new Result("OK_RAW_UNADJUSTED",last.day.toString(),n,lastClose,
            lastClose/rows.get(n-21).close-1,lastClose/rows.get(n-61).close-1,
            sum20/20,sum60/60,Math.sqrt(var*252),maxDrawdown);
    }
}
