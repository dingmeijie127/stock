package com.quantdesk.download;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Display-only Tencent quotes. NEVER used to settle orders, write MarketDb or certify live trading. */
public final class PaperLiveQuotes {
    public static final String PROVIDER="腾讯公开行情·参考报价";
    public static final int MAX_CODES=30;
    private static final DateTimeFormatter STAMP=DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    public static final class Quote {
        public final String code,name,exchangeTime;
        public final double price,previousClose,changePercent;
        public Quote(String code,String name,double price,double previousClose,String exchangeTime){
            this.code=code;this.name=name;this.price=price;this.previousClose=previousClose;
            this.changePercent=(price/previousClose-1)*100;
            this.exchangeTime=exchangeTime;
        }
        public String tradingDay(){return exchangeTime.substring(0,4)+"-"+exchangeTime.substring(4,6)+"-"+exchangeTime.substring(6,8);}
        public String clock(){return exchangeTime.substring(8,10)+":"+exchangeTime.substring(10,12);}
    }
    private PaperLiveQuotes(){}
    public static String symbol(String code){
        if(code==null||!code.matches("[0-9]{6}"))throw new IllegalArgumentException("股票代码格式错误");
        if(code.startsWith("6"))return "sh"+code;
        if(code.startsWith("0")||code.startsWith("3"))return "sz"+code;
        if(code.startsWith("4")||code.startsWith("8")||code.startsWith("9"))return "bj"+code;
        throw new IllegalArgumentException("不支持的交易所代码");
    }
    public static Map<String,Quote> parse(String payload){
        Map<String,Quote> result=new HashMap<>();
        if(payload==null)return result;
        for(String record:payload.split(";")){
            try{
                int eq=record.indexOf('=');if(eq<0)continue;
                String key=record.substring(0,eq).trim();
                if(!key.matches("v_(sh|sz|bj)[0-9]{6}"))continue;
                int a=record.indexOf('"',eq),b=record.lastIndexOf('"');if(a<0||b<=a)continue;
                String[] f=record.substring(a+1,b).split("~",-1);
                if(f.length<35)continue;
                String code=key.substring(4);
                if(!code.equals(f[2]))continue;
                double px=Double.parseDouble(f[3]),prev=Double.parseDouble(f[4]);
                if(!Double.isFinite(px)||!Double.isFinite(prev)||px<=0||prev<=0)continue;
                String time=f[30].replaceAll("[^0-9]","");
                if(time.length()<14)continue;
                time=time.substring(0,14);
                LocalDateTime.parse(time,STAMP); // reject impossible exchange timestamps
                result.put(code,new Quote(code,f[1],px,prev,time));
            }catch(RuntimeException malformed){/* bad entry does not poison remaining positions */}
        }
        return result;
    }
    /** Reject future or stale server timestamps; client clock is only a plausibility test. */
    public static boolean usable(Quote quote,String savedDay,LocalDateTime shanghaiNow){
        if(quote==null||savedDay==null||savedDay.isEmpty())return false;
        LocalDateTime at;
        try{at=LocalDateTime.parse(quote.exchangeTime,STAMP);}catch(RuntimeException ex){return false;}
        if(quote.tradingDay().compareTo(savedDay)<0)return false;
        return !at.isAfter(shanghaiNow.plusMinutes(5)) && !at.isBefore(shanghaiNow.minusDays(5));
    }
    public static Map<String,Quote> fetch(List<String> holdingCodes) throws IOException {
        if(holdingCodes==null||holdingCodes.isEmpty())return Collections.emptyMap();
        if(holdingCodes.size()>MAX_CODES)throw new IOException("一次只允许刷新最多30只持仓股票");
        List<String> names=new ArrayList<>();
        for(String code:holdingCodes)names.add(symbol(code));
        URL url=new URL("https://qt.gtimg.cn/q="+String.join(",",names));
        HttpURLConnection conn=(HttpURLConnection)url.openConnection();
        conn.setConnectTimeout(4000);conn.setReadTimeout(6000);conn.setUseCaches(false);
        conn.setRequestProperty("User-Agent","Mozilla/5.0");
        conn.setRequestProperty("Referer","https://gu.qq.com/");
        try{
            if(conn.getResponseCode()!=200)throw new IOException("网络报价 HTTP "+conn.getResponseCode());
            try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] bytes=new byte[8192];int len;
                while((len=in.read(bytes))!=-1){
                    if(out.size()+len>200000)throw new IOException("报价响应过大");
                    out.write(bytes,0,len);
                }
                return parse(new String(out.toByteArray(),Charset.forName("GBK")));
            }
        }finally{conn.disconnect();}
    }
    public static LocalDateTime nowInShanghai(){return ZonedDateTime.now(ZoneId.of("Asia/Shanghai")).toLocalDateTime();}
}
