package com.quantdesk.download;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/** Fixed-parameter chronological historical replay; all signals close[t], fills open[t+1].
 * NO fitted parameters, no forward bars in signal calculation; incomplete coverage yields NO victory claims.
 * Historical universe is subject to survivorship bias and unadjusted prices (clearly disclosed).
 */
public final class StrategyValidator {
    private StrategyValidator(){}
    public static final int MAX_SYMBOLS=450,REPLAY_DAYS=85,MIN_HISTORY=110;
    public static final class Sample {
        public final String code;public final List<SwingStrategy.Candle> candles;
        public Sample(String code,List<SwingStrategy.Candle> candles){this.code=code;this.candles=candles;}
    }
    static final class Position {
        int qty;double basis;String buyDay;
        Position(int qty,double basis,String buyDay){this.qty=qty;this.basis=basis;this.buyDay=buyDay;}
    }
    static final class Pending {
        String code,side;int qty;RiskPolicy.Plan plan;
        Pending(String c,String s,int n){this(c,s,n,RiskPolicy.legacy());}
        Pending(String c,String s,int n,RiskPolicy.Plan p){code=c;side=s;qty=n;plan=p;}
    }
    public static final class Report {
        public final String strategy,first,last;
        public final int days,sampled,usable,closed,wins;
        public final double equity,drawdown,profitFactor,netPnl;
        public Report(String strategy,String first,String last,int days,int sampled,int usable,
                      int closed,int wins,double equity,double drawdown,double profitFactor,double netPnl){
            this.strategy=strategy;this.first=first;this.last=last;this.days=days;
            this.sampled=sampled;this.usable=usable;this.closed=closed;this.wins=wins;
            this.equity=equity;this.drawdown=drawdown;this.profitFactor=profitFactor;this.netPnl=netPnl;
        }
        /** Wilson binomial score interval; uncertainty MUST accompany small win-rate samples. */
        private String confidence(){
            if(closed==0)return "未定义";
            double z=1.96,p=wins/(double)closed,z2=z*z;
            double denominator=1+z2/closed;
            double centre=(p+z2/(2*closed))/denominator;
            double half=(z*Math.sqrt((p*(1-p)+z2/(4.*closed))/closed))/denominator;
            return String.format(Locale.CHINA,"%.1f%%~%.1f%%",100*Math.max(0,centre-half),100*Math.min(1,centre+half));
        }
        public String explain(){
            if(days<30||usable<200)return StrategySuite.title(strategy)+"：样本不足，不能计算可靠胜率（有效"+usable+"/"+sampled+"只；交易日"+days+"）";
            return String.format(Locale.CHINA,"%s  |  %s~%s (%d天)\\n样本 %d只、合格 %d只；平仓 %d笔，胜 %d笔；样本胜率 %s\\n模拟期末权益 ¥%,.2f；期间收益 %+.2f%%；最大回撤 %.2f%%；盈亏因子 %s",
                StrategySuite.title(strategy),first,last,days,sampled,usable,closed,wins,
                closed==0?"无交易":String.format(Locale.CHINA,"%.1f%%（95%% Wilson区间 %s）",
                    100.*wins/closed,confidence()),
                equity,100*(equity/100000-1),drawdown*100,
                netPnl==0&&closed==0?"无交易":Double.isFinite(profitFactor)?String.format(Locale.CHINA,"%.2f",profitFactor):"无亏损/无从估算")
                +(closed>0&&closed<30?"\n【警告】只有"+closed+"笔平仓，胜率统计极不稳定，不能当成专业验证结论":"");
        }
    }
    public static List<Report> run(List<Sample> raw){
        // Fixed deterministic code ordering; NEVER filter/select securities by performance.
        List<Sample> samples=new ArrayList<>();
        for(Sample s:raw)if(s!=null&&s.candles!=null&&s.candles.size()>=MIN_HISTORY)samples.add(s);
        Collections.sort(samples,Comparator.comparing(a->a.code));
        TreeSet<String> timeline=new TreeSet<>();
        for(Sample s:samples)for(SwingStrategy.Candle c:s.candles)if(c.valid())timeline.add(c.day);
        List<String> days=new ArrayList<>(timeline);
        if(days.size()>REPLAY_DAYS+1)days=days.subList(days.size()-REPLAY_DAYS-1,days.size());
        Map<String,Map<String,Integer>> indexes=new HashMap<>();
        for(Sample s:samples){Map<String,Integer> byDay=new HashMap<>();
            for(int i=0;i<s.candles.size();i++)byDay.put(s.candles.get(i).day,i);
            indexes.put(s.code,byDay);
        }
        List<Report> reports=new ArrayList<>();
        for(String id:StrategySuite.IDS)reports.add(replay(id,samples,indexes,days,raw.size()));
        return reports;
    }
    private static Report replay(String id,List<Sample> securities,Map<String,Map<String,Integer>> ix,List<String> timeline,int sampled){
        double cash=100000,peak=100000,dd=0,gp=0,gl=0,pnl=0;
        int wins=0,closed=0,activeDays=0,usable=0;
        Map<String,Position> holdings=new HashMap<>();
        List<Pending> pending=new ArrayList<>();
        Map<String,Sample> byCode=new HashMap<>();for(Sample s:securities)byCode.put(s.code,s);
        for(Sample s:securities)if(s.candles.size()>=MIN_HISTORY)usable++;
        if(timeline.size()<2)return new Report(id,"","",0,sampled,usable,0,0,100000,0,Double.NaN,0);
        for(int k=0;k<timeline.size();k++){
            String day=timeline.get(k);activeDays++;
            // Settle last-close instructions at this day's open; skipped if no eligible daily bar.
            List<Pending> sells=new ArrayList<>(),buys=new ArrayList<>();
            for(Pending x:pending){if("SELL".equals(x.side))sells.add(x);else buys.add(x);}pending.clear();
            for(Pending o:sells){
                Sample s=byCode.get(o.code);Integer j=ix.get(o.code).get(day);Position p=holdings.get(o.code);
                if(j==null||p==null||!validFill(s.candles.get(j))||day.compareTo(p.buyDay)<=0)continue;
                double price=PaperTradeRules.fillPrice(s.candles.get(j).open,"SELL");
                double received=PaperTradeRules.cashFlow("SELL",p.qty,price);
                double tradePnl=received-p.qty*p.basis;
                cash+=received;pnl+=tradePnl;closed++;if(tradePnl>0){wins++;gp+=tradePnl;}else gl-=tradePnl;
                holdings.remove(o.code);
            }
            for(Pending o:buys){
                Sample s=byCode.get(o.code);Integer j=ix.get(o.code).get(day);
                if(j==null||holdings.containsKey(o.code)||holdings.size()>=o.plan.maxPositions||
                    !o.plan.mayBuy()||!validFill(s.candles.get(j)))continue;
                double price=PaperTradeRules.fillPrice(s.candles.get(j).open,"BUY");
                double equity=currentEquity(cash,holdings,byCode,ix,day);
                double budget=o.plan.newCapital(equity,equity-cash,cash);
                int qty=Math.min(o.qty,SwingStrategy.buyLots(budget,price,1));
                while(qty>=100&&-PaperTradeRules.cashFlow("BUY",qty,price)>cash)qty-=100;
                if(qty<100)continue;
                double paid=-PaperTradeRules.cashFlow("BUY",qty,price);
                cash-=paid;holdings.put(o.code,new Position(qty,paid/qty,day));
            }
            double equity=currentEquity(cash,holdings,byCode,ix,day);
            peak=Math.max(peak,equity);dd=Math.max(dd,1-equity/peak);
            if(k==timeline.size()-1)break;
            MarketRegime.Tally tally=new MarketRegime.Tally();
            for(Sample s:securities){Integer j=ix.get(s.code).get(day);
                tally.observe(j==null?Collections.emptyList():s.candles.subList(0,j+1),day);
            }
            MarketRegime.Result regime=tally.finish(day);
            Set<String> selling=new HashSet<>();
            RiskPolicy.Plan plan=regime.plan(id);
            List<Recommendation> recs=new ArrayList<>();
            for(Sample s:securities){Integer j=ix.get(s.code).get(day);
                if(j==null||j<104)continue;
                Position p=holdings.get(s.code);
                List<SwingStrategy.Candle> history=s.candles.subList(0,j+1);
                int heldDays=p==null?0:tradeDaysSince(s.candles,j,p.buyDay);
                SwingStrategy.Advice advice=StrategySuite.evaluate(id,history,day,regime,p!=null,p==null?0:p.basis,heldDays);
                if("SELL".equals(advice.action)&&p!=null){selling.add(s.code);pending.add(new Pending(s.code,"SELL",p.qty));}
                else if("BUY".equals(advice.action)&&p==null)
                    recs.add(new Recommendation(s.code,advice.score,history,plan));
            }
            recs.sort((a,b)->Double.compare(b.score,a.score));
            int buysThisDay=0;double planned=cash,plannedInvested=equity-cash;
            for(Recommendation r:recs){
                if(holdings.size()+buysThisDay>=plan.maxPositions||buysThisDay>=3)break;
                double price=r.bars.get(r.bars.size()-1).close;
                int qty=SwingStrategy.buyLotsRisk(planned,equity,price,SwingStrategy.atr14(r.bars,r.bars.size()));
                qty=Math.min(qty,SwingStrategy.buyLots(plan.newCapital(equity,plannedInvested,planned),price,1));
                if(qty<100)continue;
                pending.add(new Pending(r.code,"BUY",qty,plan));buysThisDay++;
                plannedInvested+=qty*price;
                planned-=qty*price+SwingStrategy.commission(qty*price);
            }
        }
        double total=currentEquity(cash,holdings,byCode,ix,timeline.get(timeline.size()-1));
        return new Report(id,timeline.get(0),timeline.get(timeline.size()-1),activeDays,sampled,usable,
            closed,wins,total,dd,gl<=0?(gp>0?Double.POSITIVE_INFINITY:Double.NaN):gp/gl,pnl);
    }
    static int tradeDaysSince(List<SwingStrategy.Candle> b,int idx,String from){int count=0;
        for(int i=idx;i>=0&&b.get(i).day.compareTo(from)>=0;i--)count++;return count;}
    static boolean validFill(SwingStrategy.Candle c){return c.valid()&&c.high-c.low>1e-7;}
    static final class Recommendation{String code;double score;List<SwingStrategy.Candle> bars;RiskPolicy.Plan plan;
        Recommendation(String c,double s,List<SwingStrategy.Candle> b,RiskPolicy.Plan p){code=c;score=s;bars=b;plan=p;}}
    static double currentEquity(double cash,Map<String,Position> positions,Map<String,Sample> byCode,
                                Map<String,Map<String,Integer>> ix,String day){
        double value=cash;
        for(Map.Entry<String,Position> e:positions.entrySet()){
            Sample s=byCode.get(e.getKey());Integer j=ix.get(e.getKey()).get(day);
            // On suspended days value last KNOWN close; never uses a future quote.
            if(j==null){for(int i=s.candles.size()-1;i>=0;i--)if(s.candles.get(i).day.compareTo(day)<=0){j=i;break;}}
            value+=e.getValue().qty*(j==null?e.getValue().basis:s.candles.get(j).close);
        }
        return value;
    }
}
