package com.quantdesk.download;

import java.util.List;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/** Experimental, deterministic end-of-day RSI(2) pullback engine; no look-ahead. */
public final class SwingStrategy {
    private SwingStrategy() {}
    public static final String VERSION="TREND_RSI2_ATR_LAB_V1";
    public static final class Candle {
        public final String day;
        public final double open,high,low,close,volume;
        public Candle(String day,double open,double high,double low,double close,double volume){
            this.day=day;this.open=open;this.high=high;this.low=low;this.close=close;this.volume=volume;
        }
        boolean valid(){return day!=null&&day.length()==10&&Double.isFinite(open)&&Double.isFinite(high)&&
            Double.isFinite(low)&&Double.isFinite(close)&&Double.isFinite(volume)&&low>0&&high>=low&&
            open>=low-1e-5&&open<=high+1e-5&&close>=low-1e-5&&close<=high+1e-5&&volume>0;}
    }
    public static final class Advice {
        public final String action,reason,asOf;
        public final double price,score;
        public Advice(String action,String reason,String asOf,double price,double score){
            this.action=action;this.reason=reason;this.asOf=asOf;this.price=price;this.score=score;
        }
    }
    static double sma(List<Candle> b,int end,int period){
        if(end<period)throw new IllegalArgumentException("insufficient bars");
        double sum=0;for(int i=end-period;i<end;i++)sum+=b.get(i).close;
        return sum/period;
    }
    /** Wilder RSI: early historic bars may influence the indicator; only bars before end are used. */
    public static double rsi2(List<Candle> b,int end){
        if(end<4)throw new IllegalArgumentException("insufficient RSI bars");
        double up=0,down=0;
        for(int i=1;i<=2;i++){
            double delta=b.get(i).close-b.get(i-1).close;
            up+=Math.max(0,delta);down+=Math.max(0,-delta);
        }
        up/=2;down/=2;
        for(int i=3;i<end;i++){
            double delta=b.get(i).close-b.get(i-1).close;
            up=(up+Math.max(0,delta))/2;down=(down+Math.max(0,-delta))/2;
        }
        if(up==0&&down==0)return 50;
        if(down==0)return 100;
        return 100-100/(1+up/down);
    }
    /** True range uses yesterday's close; end is exclusive. */
    public static double atr14(List<Candle> b,int end){
        if(end<15)throw new IllegalArgumentException("insufficient ATR bars");
        double sum=0;
        for(int i=end-14;i<end;i++){
            Candle curr=b.get(i);
            double prev=b.get(i-1).close;
            sum+=Math.max(curr.high-curr.low,Math.max(Math.abs(curr.high-prev),Math.abs(curr.low-prev)));
        }
        return sum/14;
    }
    /** bars sorted oldest to newest, strictly point-in-time close data. */
    public static Advice evaluate(List<Candle> bars,String targetDay,boolean held,double costBasis,int tradingDaysHeld){
        if(bars==null||bars.isEmpty())return new Advice("NONE","缺少历史数据","",0,0);
        Candle last=bars.get(bars.size()-1);
        if(!last.day.equals(targetDay))return new Advice("NONE","不是目标日最新收盘数据",last.day,last.close,0);
        if(bars.size()<75)return new Advice("NONE","趋势与动量指标至少需要75根日K",last.day,last.close,0);
        for(int i=0;i<bars.size();i++){
            if(!bars.get(i).valid())return new Advice("NONE","K线异常或停牌数据无效",last.day,last.close,0);
            if(i>0){
                if(bars.get(i).day.compareTo(bars.get(i-1).day)<=0)
                    return new Advice("NONE","K线日期未按升序",last.day,last.close,0);
                try{
                    if(ChronoUnit.DAYS.between(LocalDate.parse(bars.get(i-1).day),LocalDate.parse(bars.get(i).day))>20)
                        return new Advice("NONE","历史K线存在超过20自然日缺口",last.day,last.close,0);
                }catch(Exception ex){return new Advice("NONE","K线日期格式错误",last.day,last.close,0);}
            }
        }
        int n=bars.size();
        double ma20=sma(bars,n,20),prev20=sma(bars,n-5,20);
        double ma60=sma(bars,n,60),prev60=sma(bars,n-5,60);
        double atr=atr14(bars,n),volatility=atr/last.close;
        double rsiPrior=rsi2(bars,n-1),rsiNow=rsi2(bars,n);
        double dayMove=last.close/bars.get(n-2).close-1;
        if(held){
            if(!Double.isFinite(costBasis)||costBasis<=0)return new Advice("NONE","持仓成本无效",last.day,last.close,0);
            double ret=last.close/costBasis-1;
            double stopPct=Math.max(0.04,Math.min(0.08,2.2*atr/costBasis));
            if(ret<=-stopPct)return new Advice("SELL",String.format(Locale.CHINA,"波动率止损触发：亏损%.1f%% ≥ 风险线%.1f%%；下个交易日模拟卖出",-ret*100,stopPct*100),last.day,last.close,100);
            if(ret>=0.10)return new Advice("SELL","盈利达到10%，锁定模拟收益",last.day,last.close,95);
            if(tradingDaysHeld>=3&&last.close<ma20*0.975)return new Advice("SELL","收盘跌破20日均线2.5%，趋势保护离场",last.day,last.close,90);
            if(tradingDaysHeld>=9)return new Advice("SELL","持仓9个交易日，到期控制敞口",last.day,last.close,80);
            return new Advice("HOLD",String.format(Locale.CHINA,"趋势跟踪：浮盈%.1f%% / ATR14波动%.1f%%",ret*100,volatility*100),last.day,last.close,0);
        }
        if(last.close<3||last.close>1000||Math.abs(dayMove)>0.095)
            return new Advice("NONE","价格或单日波动触及策略过滤条件",last.day,last.close,0);
        if(volatility<0.012||volatility>0.075)return new Advice("NONE","ATR波动率不在1.2%～7.5%范围",last.day,last.close,0);
        boolean trend=ma60>prev60&&ma20>=prev20&&last.close>ma60;
        boolean location=last.close>=ma20*0.94&&last.close<=ma20*1.02;
        boolean reversal=rsiPrior<=18&&rsiNow>=rsiPrior+5&&last.close>bars.get(n-2).close&&last.close>=last.open;
        if(trend&&location&&reversal){
            double score=30+(18-rsiPrior)*1.4+Math.min(15,(rsiNow-rsiPrior)*0.5)+
                Math.min(10,(ma20/prev20-1)*2500);
            return new Advice("BUY",String.format(Locale.CHINA,
                "MA60上行 + MA20回调；RSI(2) %.1f→%.1f 超卖反弹；ATR14 %.1f%%；下个有效交易日模拟开盘买入",
                rsiPrior,rsiNow,volatility*100),last.day,last.close,score);
        }
        return new Advice("NONE","未同时满足趋势、回调位置和RSI(2)反转条件",last.day,last.close,0);
    }
    /** At most 0.75% initial-equity risk per idea and 20% capital allocation, rounded to A-share lots. */
    public static int buyLotsRisk(double cash,double equity,double price,double atr){
        if(!Double.isFinite(cash)||!Double.isFinite(equity)||!Double.isFinite(price)||!Double.isFinite(atr)||
            cash<=0||equity<=0||price<=0||atr<=0)return 0;
        double stopDistance=Math.max(price*0.04,Math.min(price*0.08,atr*2.2));
        double qtyByRisk=Math.floor((equity*0.0075)/stopDistance);
        double qtyByBudget=Math.floor((Math.min(cash,equity*0.20)-6)/(price*1.003));
        return (int)(Math.max(0,Math.floor(Math.min(qtyByRisk,qtyByBudget)/100))*100);
    }
    public static int buyLots(double available,double price,double percent){
        if(!Double.isFinite(available)||!Double.isFinite(price)||!Double.isFinite(percent)||price<=0||available<=0||percent<=0)return 0;
        return Math.max(0,(int)Math.floor((available*Math.min(percent,1)-6)/(price*1.003)/100)*100);
    }
    public static double commission(double gross){return Math.max(5,Math.round(gross*0.0003*100.0)/100.0);}
    public static double sellTax(double gross){return Math.round(gross*0.0005*100.0)/100.0;}
}
