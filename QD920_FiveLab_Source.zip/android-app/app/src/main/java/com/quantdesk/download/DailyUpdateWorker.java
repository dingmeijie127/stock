package com.quantdesk.download;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Fast daily update. 5 minutes is a run-time BUDGET, never a fabricated completeness guarantee.
 *  Network rate limits, holidays and backfill needs remain visible as pending work.
 */
public final class DailyUpdateWorker extends Worker {
    private static final long MAX_RUN_MS=4L*60*1000+20_000; // reserve 40 sec for late network calls and shutdown
    private static final long QUOTE_STAGE_MS=120_000;
    private static final long TAIL_STAGE_MS=65_000;
    private static final int MAX_TAIL_REQUESTS=48;
    private static final int PARALLEL=4;
    private static final int MAX_INFLIGHT=8;
    private static final int MAX_STALE_DAYS=10;
    public DailyUpdateWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    private static final class QuotePage {
        final List<String> symbols;final Map<String,Bar> bars;final String error;
        QuotePage(List<String> symbols,Map<String,Bar> bars,String error){
            this.symbols=symbols;this.bars=bars;this.error=error;
        }
    }
    private static final class QuoteStats {
        int inserted;
        final Map<String,String> checkedWithoutBar=new HashMap<>();
    }
    private static final class TailResult {
        final MarketDb.FastCandidate stock;final LocalDate start;
        final DailySources.Result data;final String error;
        TailResult(MarketDb.FastCandidate s,LocalDate start,DailySources.Result data,String error){
            stock=s;this.start=start;this.data=data;this.error=error;
        }
    }
    private boolean active(Context context,long deadline){
        return !isStopped() && DailyUpdateScheduler.enabled(context) &&
                !MarketDb.IMPORT_IN_PROGRESS.get() && System.currentTimeMillis()<deadline;
    }
    private void stage(MarketDb db,String day,String message){db.autoState(day,"running","",message);}
    private QuoteStats quoteStage(Context context,MarketDb db,String day,LocalDate target,
                           List<MarketDb.FastCandidate> list,long runDeadline) throws Exception {
        QuoteStats stats=new QuoteStats();
        List<String> symbols=new ArrayList<>();
        // One quote page covers 40 instruments whether or not their *history* is complete.
        // Today's candle is independent of missing 2024/2025 rows or recent listings.
        for(MarketDb.FastCandidate c:list){
            if("SH".equals(c.exchange)||"SZ".equals(c.exchange)||"HK".equals(c.exchange))
                symbols.add(TencentBatchQuotes.symbol(c.code,c.exchange));
        }
        if(symbols.isEmpty())return stats;
        List<List<String>> pages=TencentBatchQuotes.pages(symbols);
        ExecutorService pool=Executors.newFixedThreadPool(PARALLEL);
        CompletionService<QuotePage> completion=new ExecutorCompletionService<>(pool);
        List<Future<QuotePage>> pending=new ArrayList<>();
        long deadline=Math.min(runDeadline,System.currentTimeMillis()+QUOTE_STAGE_MS);
        int next=0,finished=0,inserted=0,errors=0;
        try{
            while(next<pages.size() && pending.size()<MAX_INFLIGHT){
                List<String> p=pages.get(next++);
                pending.add(completion.submit(()->{
                    try{return new QuotePage(p,TencentBatchQuotes.fetch(p,target),null);}
                    catch(Exception e){return new QuotePage(p,new HashMap<>(),e.getClass().getSimpleName()+": "+e.getMessage());}
                }));
            }
            while(!pending.isEmpty() && active(context,deadline)){
                Future<QuotePage> f=completion.poll(1000,TimeUnit.MILLISECONDS);
                if(f==null)continue;
                pending.remove(f);finished++;
                QuotePage result=f.get();
                if(result.error!=null){
                    errors++;
                    if(errors<=3)db.log("FAST_SOURCE_ERROR","腾讯A股批量行情："+result.error);
                }
                // Only accept symbols actually requested by this completed HTTP page.
                // A no-bar (stale/suspended/invalid) response must be checkpointed
                // after the limited backup stage so the next tap does not retry it.
                java.util.Set<String> requestedCodes=new HashSet<>();
                for(String symbol:result.symbols)
                    requestedCodes.add(symbol.substring(2));
                result.bars.keySet().retainAll(requestedCodes);
                if(!result.bars.isEmpty())inserted+=db.saveFastQuoteBatch(result.bars,day);
                for(String symbol:result.symbols){
                    String code=symbol.substring(2);
                    if(!result.bars.containsKey(code))
                        stats.checkedWithoutBar.put(code,result.error==null?"stale":"failed");
                }
                if(finished%5==0||finished==pages.size())
                    stage(db,day,"批量A股收盘快照 "+finished+"/"+pages.size()+" 批；新增 "+inserted+
                          " 根；请求错误 "+errors+"；只存日期为 "+day+" 的有效收盘行情");
                if(next<pages.size()){
                    List<String> p=pages.get(next++);
                    pending.add(completion.submit(()->{
                        try{return new QuotePage(p,TencentBatchQuotes.fetch(p,target),null);}
                        catch(Exception e){return new QuotePage(p,new HashMap<>(),e.getClass().getSimpleName()+": "+e.getMessage());}
                    }));
                }
            }
        }finally{
            for(Future<QuotePage> f:pending)f.cancel(true);
            pool.shutdownNow();
        }
        db.log("AUTO_FAST","A股批量收盘快照：候选 "+symbols.size()+"，已处理批次 "+finished+
               "/"+pages.size()+"，新增 "+inserted+"，接口错误批次 "+errors);
        stats.inserted=inserted;
        return stats;
    }
    private int tailStage(Context context,MarketDb db,String day,LocalDate target,
                          long deadline) throws Exception {
        // Re-plan with ONE indexed SQLite query to exclude anything committed by batch quotes.
        MarketDb.FastPlan plan=db.planFastDaily(day);
        List<MarketDb.FastCandidate> due=new ArrayList<>();
        LocalDate oldest=target.minusDays(MAX_STALE_DAYS);
        int deferred=0;
        for(MarketDb.FastCandidate candidate:plan.pending){
            String market="HK".equals(candidate.exchange)?"HK":"A";
            if(db.fastMarketBlocked(day,market))continue;
            if(candidate.latest==null || candidate.latest.compareTo(oldest.toString())<0){
                // Do not accidentally spend the five-minute daily budget redownloading 2 years.
                db.autoAttempt(candidate.code,day,"backfill",0,"历史缺口太大，需使用'历史补缺'功能");
                deferred++;continue;
            }
            due.add(candidate);
        }
        if(deferred>0)db.log("AUTO_FAST","需另外历史补缺："+deferred+" 只；不会把它们标成今日完成");
        if(due.isEmpty())return 0;
        // Fair share between markets: A-share outages must not starve HK jobs.
        List<MarketDb.FastCandidate> a=new ArrayList<>(),hk=new ArrayList<>();
        for(MarketDb.FastCandidate stock:due){
            if("HK".equals(stock.exchange))hk.add(stock);else a.add(stock);
        }
        due.clear();
        for(int i=0;i<Math.max(a.size(),hk.size());i++){
            if(i<a.size())due.add(a.get(i));
            if(i<hk.size())due.add(hk.get(i));
        }
        // A/H quote batches already handled most securities. Historical-provider fallbacks
        // are a LIMITED diagnostic/recovery lane, never another full-market sweep.
        int queued=due.size();
        if(due.size()>MAX_TAIL_REQUESTS){
            due=new ArrayList<>(due.subList(0,MAX_TAIL_REQUESTS));
            db.log("AUTO_FAST","逐只备源限额 "+MAX_TAIL_REQUESTS+"；其余 "+
                    (queued-due.size())+" 只不发网络请求，保留待补记录");
        }
        ExecutorService pool=Executors.newFixedThreadPool(PARALLEL);
        CompletionService<TailResult> completion=new ExecutorCompletionService<>(pool);
        List<Future<TailResult>> pending=new ArrayList<>();
        int next=0,done=0,added=0,failedA=0,failedHK=0;
        final Set<String> blocked=new HashSet<>();
        try{
            while(next<due.size() && pending.size()<MAX_INFLIGHT)
                pending.add(submit(completion,due.get(next++),target));
            while(!pending.isEmpty() && active(context,deadline)){
                Future<TailResult> f=completion.poll(1000,TimeUnit.MILLISECONDS);
                if(f==null)continue;
                pending.remove(f);
                TailResult result=f.get();
                MarketDb.FastCandidate stock=result.stock;
                String market="HK".equals(stock.exchange)?"HK":"A";
                if(result.error!=null){
                    db.autoAttempt(stock.code,day,"failed",0,result.error);
                    if("HK".equals(market))failedHK++;else failedA++;
                    if(("HK".equals(market)?failedHK:failedA)==8){
                        blocked.add(market);
                        db.autoBlock(day,market,"连续8只失败，保留未下载股票；可手动重试");
                        db.log("AUTO_ERROR",market+"接口连续失败，暂停该市场，原数据保留");
                    }
                    if(done%25==0)db.log("AUTO_ERROR",market+":"+stock.code+" "+result.error);
                }else{
                    boolean targetBar=false;
                    for(Bar b:result.data.bars)if(day.equals(b.date)){targetBar=true;break;}
                    String status=result.data.skippedBars>0?"partial":targetBar?"saved":"stale";
                    String reason=result.data.skippedBars>0?"异常行情根数："+result.data.skippedBars:
                           targetBar?null:"行情源尚未提供目标交易日收盘K线；保留检查点";
                    added+=db.saveFastTail(stock.code,result.start.toString(),day,result.data.bars,status,reason);
                    if("HK".equals(market))failedHK=0;else failedA=0;
                }
                done++;
                if(done%25==0){
                    stage(db,day,"逐只补尾："+done+"/"+due.size()+"；新增 "+added+
                        " 根；A股连续失败 "+failedA+"，港股连续失败 "+failedHK);
                }
                while(next<due.size()&&pending.size()<MAX_INFLIGHT){
                    MarketDb.FastCandidate candidate=due.get(next++);
                    String mk="HK".equals(candidate.exchange)?"HK":"A";
                    if(blocked.contains(mk))continue;
                    pending.add(submit(completion,candidate,target));
                }
            }
        }finally{
            for(Future<TailResult> f:pending)f.cancel(true);
            pool.shutdownNow();
        }
        db.log("AUTO_FAST","逐只补尾完成 "+done+"/"+due.size()+"；新增 "+added+" 条；其余按检查点续传");
        return added;
    }
    private Future<TailResult> submit(CompletionService<TailResult> completion,
                                       MarketDb.FastCandidate stock,LocalDate target){
        return completion.submit(()->{
            LocalDate latest=LocalDate.parse(stock.latest);
            LocalDate start=latest.plusDays(1);
            // A small tail only: archive repairs use the separate historical task.
            try{
                DailySources.Result data=DailySources.downloadFast(stock.code,stock.exchange,start,target);
                return new TailResult(stock,start,data,null);
            }catch(Exception e){
                String error=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
                if(error.length()>350)error=error.substring(0,350);
                return new TailResult(stock,start,null,error);
            }
        });
    }
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();
        if(!DailyUpdateScheduler.enabled(c))return Result.success();
        if(MarketDb.IMPORT_IN_PROGRESS.get())return Result.retry();
        if(!HarvestService.RUNNING.compareAndSet(false,true))return Result.retry();
        long started=System.currentTimeMillis(),deadline=started+MAX_RUN_MS;
        try(MarketDb db=new MarketDb(c)){
            Universe.install(c,db); // Add newly listed A-share symbols from the bundled audited roster
            LocalDate target=RangePlanner.safeEndDay(ZonedDateTime.now(ZoneId.of("Asia/Hong_Kong")));
            String day=target.toString();
            MarketDb.FastPlan plan=db.planFastDaily(day);
            db.autoState(day,"running","","快速增量批量检查：今日待处理 "+plan.pending.size()+
                "，已有当天K线 "+plan.alreadyCurrent+"，已检查 "+plan.alreadyAttempted);
            db.log("AUTO_FAST","单次批量查库：待处理 "+plan.pending.size()+"，已是最新 "+plan.alreadyCurrent+
                "，已尝试 "+plan.alreadyAttempted);
            if(plan.pending.isEmpty()){
                int missing=db.autoMissingBars(day),unresolved=db.autoUnresolved(day),blocked=db.autoBlocked(day);
                String msg="本轮无可请求股票；仍缺目标收盘日K线 "+missing+" 只，已检查但未解决 "+unresolved+
                    " 只，暂停市场 "+blocked+"；失败项需点强制重试，历史缺口需单独补缺";
                db.autoState(day,missing==0&&unresolved==0&&blocked==0?"done":"partial","",msg);
                db.log("AUTO_FAST",msg);
                try{
                    FastFinanceSync.Result finance=FastFinanceSync.run(c,db,deadline,()->active(c,deadline));
                    db.log("FINANCE_FAST","今日K线无需请求；财报联网 "+finance.attempted+
                        " 项，新增 "+finance.saved+" 行，仍到期 "+finance.pending+" 项");
                }catch(Exception financeError){db.log("FINANCE_ERROR",financeError.toString());}
                return Result.success();
            }
            QuoteStats quote=quoteStage(c,db,day,target,plan.pending,deadline);
            int added=quote.inserted;
            if(active(c,deadline))added+=tailStage(c,db,day,target,
                Math.min(deadline,System.currentTimeMillis()+TAIL_STAGE_MS));
            // Mark *only completed* quote pages; unfinished pages remain available
            // for the next bounded batch. Never overwrite a just-saved tail bar.
            db.markFastQuoteChecks(day,quote.checkedWithoutBar);
            long financeStart=System.currentTimeMillis();
            if(active(c,deadline)){
                try{
                    FastFinanceSync.Result finance=FastFinanceSync.run(c,db,deadline,()->active(c,deadline));
                    db.log("FINANCE_FAST","财报增量：联网 "+finance.attempted+
                        " 项，新增 "+finance.saved+" 行，失败 "+finance.failed+
                        " 项，剩余到期 "+finance.pending+" 项；用时 "+
                        ((System.currentTimeMillis()-financeStart)/1000)+" 秒");
                }catch(Exception financeError){
                    db.log("FINANCE_ERROR","财报增量独立失败，不影响K线："+financeError.getMessage());
                }
            }
            int remaining=db.autoRemaining(day),failures=db.autoFailures(day),blocked=db.autoBlocked(day),unresolved=db.autoUnresolved(day);
            int missing=db.autoMissingBars(day);
            long elapsed=System.currentTimeMillis()-started;
            String detail="仅A股日K+财报增量总耗时 "+(elapsed/1000)+" 秒；本次新增日K "+added+
                " 根；累计目标日成功/部分 "+db.autoProcessed(day)+"；失败 "+failures+
                "，可继续处理 "+remaining+"，目标日仍缺K线 "+missing+
                "，缺口/待补全 "+unresolved+"，暂停市场 "+blocked;
            boolean unfinished=missing>0||blocked>0||unresolved>0;
            if(isStopped()||!DailyUpdateScheduler.enabled(c)){
                db.autoState(day,"paused","",detail);
            }else{
                db.autoState(day,unfinished?"partial":"done","",detail);
                if(remaining>0)DailyUpdateScheduler.enqueueNext(c,90_000L);
            }
            db.log("AUTO_FAST",detail);
            return Result.success();
        }catch(InterruptedException e){
            Thread.currentThread().interrupt();return Result.retry();
        }catch(Exception e){
            try(MarketDb db=new MarketDb(c)){
                String reason=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
                db.log("AUTO_ERROR","快速增量失败："+reason);
                db.autoState("","error","",reason);
            }catch(Exception ignored){}
            return Result.retry();
        }finally{HarvestService.RUNNING.set(false);}
    }
}
