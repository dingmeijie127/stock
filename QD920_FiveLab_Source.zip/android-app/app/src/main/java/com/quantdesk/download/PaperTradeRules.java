package com.quantdesk.download;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Conservative next-session fill assumptions used ONLY for fictional portfolio validation. */
public final class PaperTradeRules {
    private PaperTradeRules() {}
    public static boolean validNextOpen(String signalDay,String fillDay,String buyDay,
                                        String side,double open,double high,double low,double close,double volume){
        if(signalDay==null||fillDay==null||fillDay.compareTo(signalDay)<=0)return false;
        if(buyDay!=null&&"SELL".equals(side)&&fillDay.compareTo(buyDay)<=0)return false;
        if(ChronoUnit.DAYS.between(LocalDate.parse(signalDay),LocalDate.parse(fillDay))>15)return false;
        return Double.isFinite(open)&&Double.isFinite(high)&&Double.isFinite(low)&&Double.isFinite(close)&&
            Double.isFinite(volume)&&volume>0&&low>0&&high>=low&&high-low>0.0000001&&
            open>=low-0.00001&&open<=high+0.00001&&close>=low-0.00001&&close<=high+0.00001;
    }
    public static double fillPrice(double open,String side){
        if(open<=0||!Double.isFinite(open))throw new IllegalArgumentException("invalid open");
        return Math.round(open*("BUY".equals(side)?1.001:0.999)*100)/100.0;
    }
    public static double cashFlow(String side,int qty,double fillPrice){
        if(qty<=0||fillPrice<=0)throw new IllegalArgumentException("invalid fill");
        double gross=qty*fillPrice;
        return "BUY".equals(side)?-gross-SwingStrategy.commission(gross):
            gross-SwingStrategy.commission(gross)-SwingStrategy.sellTax(gross);
    }
}
