package com.quantdesk.download;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Full finance audit uses periods actually stored in dataset_rows, not a completed data_jobs flag. */
public final class FinanceCoveragePlanner {
    private FinanceCoveragePlanner(){}
    private static LocalDate quarterEndOnOrAfter(LocalDate date){
        int m=((date.getMonthValue()-1)/3+1)*3;
        LocalDate q=LocalDate.of(date.getYear(),m,1).with(TemporalAdjusters.lastDayOfMonth());
        return q.isBefore(date)?q.plusMonths(3).with(TemporalAdjusters.lastDayOfMonth()):q;
    }
    /** Null: no known missing historical fiscal period, and no new period is due.
     *  HK dividends are events, so absence cannot be inferred from the calendar.
     */
    public static LocalDate neededStart(String dataset,LocalDate baseline,LocalDate today,
                                         List<String> saved,String lastSavedPeriod,boolean verified){
        if(saved.isEmpty())return baseline;
        if("hk_dividend".equals(dataset)){
            return verified?FinanceRefreshPolicy.requestMissingStart(baseline,today,null,lastSavedPeriod,dataset):baseline;
        }
        Set<LocalDate> have=new HashSet<>();
        for(String period:saved){
            LocalDate d=FinanceRefreshPolicy.parsePeriod(period);
            if(d!=null)have.add(d);
        }
        if(have.isEmpty())return baseline;
        if(!verified){
            if("hk_indicator".equals(dataset)){
                LocalDate latest=FinanceRefreshPolicy.parsePeriod(lastSavedPeriod);
                if(latest==null)return baseline;
                LocalDate cursor=latest;
                while(!cursor.minusMonths(6).isBefore(baseline)){
                    LocalDate prev=cursor.minusMonths(6);
                    if(cursor.getDayOfMonth()==cursor.lengthOfMonth())
                        prev=prev.withDayOfMonth(prev.lengthOfMonth());
                    if(!have.contains(prev))return baseline; // provider can return whole 2-year period range
                    cursor=prev;
                }
            }else{
                LocalDate quarter=quarterEndOnOrAfter(baseline);
                // Only treat periods >90 days old as overdue; do not claim an unreleased report missing.
                while(!quarter.plusDays(90).isAfter(today)){
                    if(!have.contains(quarter))return quarter;
                    quarter=quarter.plusMonths(3).with(TemporalAdjusters.lastDayOfMonth());
                }
            }
        }
        if(FinanceRefreshPolicy.newReportPeriodMayExist(dataset,lastSavedPeriod,today))
            return FinanceRefreshPolicy.requestMissingStart(baseline,today,null,lastSavedPeriod,dataset);
        return null;
    }
}
