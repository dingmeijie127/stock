package com.quantdesk.download;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
public final class SwingStrategyTest {
    static void ok(boolean b,String why){if(!b)throw new AssertionError(why);}
    static List<SwingStrategy.Candle> trend(){
        List<SwingStrategy.Candle> out=new ArrayList<>();
        LocalDate d=LocalDate.of(2026,1,1);
        for(int i=0;i<80;i++){
            double c=10+i*0.08;
            double hi=c+0.02;
            if(i==79){c=17.10;hi=17.20;}
            out.add(new SwingStrategy.Candle(d.plusDays(i).toString(),c-0.02,hi,c-0.07,c,i==79?4000:1000));
        }
        return out;
    }
    public static void main(String[] args){
        List<SwingStrategy.Candle> a=trend();
        String day=a.get(a.size()-1).day;
        SwingStrategy.Advice buy=SwingStrategy.evaluate(a,day,false,0,0);
        ok("BUY".equals(buy.action),"breakout with volume -> BUY: "+buy.action+" "+buy.reason);
        ok("NONE".equals(SwingStrategy.evaluate(a,a.get(78).day,false,0,0).action),"stale asof blocked");
        ok("SELL".equals(SwingStrategy.evaluate(a,day,true,20.0,2).action),"stoploss");
        ok("SELL".equals(SwingStrategy.evaluate(a,day,true,15.0,2).action),"takeprofit");
        ok("SELL".equals(SwingStrategy.evaluate(a,day,true,17.0,10).action),"time exit");
        ok("NONE".equals(SwingStrategy.evaluate(a.subList(0,60),a.get(59).day,false,0,0).action),"min history");
        ok(SwingStrategy.buyLots(100000,10,0.20)%100==0,"lots");
        ok(SwingStrategy.commission(1000)==5,"commission minimum");
        ok(Math.abs(SwingStrategy.sellTax(10000)-5)<0.001,"sell tax");
        System.out.println("SwingStrategyTest PASS (9 checks)");
    }
}
