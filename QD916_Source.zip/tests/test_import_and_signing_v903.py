"""Regression checks: database import and APK signing guards (offline contracts)."""
from pathlib import Path
import sqlite3,re,random
import yaml

ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'android-app/app/src/main/java/com/quantdesk/download'


def test_safe_import_controls_and_status():
    activity=(JAVA/'MainActivity.java').read_text()
    database=(JAVA/'MarketDb.java').read_text()
    worker=(JAVA/'DailyUpdateWorker.java').read_text()
    service=(JAVA/'HarvestService.java').read_text()
    assert 'IMPORT_IN_PROGRESS' in database
    assert 'IMPORTING.compareAndSet(false,true)' in activity
    assert 'if(!IMPORTING.get())refreshUI()' in activity
    assert 'SqliteBackupFormat.requireValidFile(temp)' in activity
    assert 'importStatus=text(' in activity
    assert 'File(getFilesDir(),"imports")' in activity
    assert 'catch(Throwable e)' in activity
    assert 'MarketDb.IMPORT_IN_PROGRESS.get()' in service
    assert 'MarketDb.IMPORT_IN_PROGRESS.get()' in worker
    assert 'if(st.executeInsert()!=-1)merged++' in database
    assert 'DROP TABLE' not in database


def test_signing_configuration_and_version():
    flow=ROOT/'.github/workflows/QD916_Build.yml'
    obj=yaml.safe_load(flow.read_text())
    text=flow.read_text()
    assert obj['jobs']['build-apk']['timeout-minutes']>=30
    assert 'QD916_Source.zip' in text
    assert 'if [[ $present -ne 0 && $present -ne 4 ]]' in text
    assert 'apksigner" verify --print-certs' in text
    assert all(secret in text for secret in ['QD_KEYSTORE_B64','QD_SIGNING_ALIAS','QD_SIGNING_STORE_PASSWORD','QD_SIGNING_KEY_PASSWORD'])
    gradle=(ROOT/'android-app/app/build.gradle').read_text()
    assert 'versionCode 916' in gradle
    assert "applicationId 'com.quantdesk.asharecollector88'" in gradle
    assert "versionName '9.1.6'" in gradle


def test_import_is_idempotent_with_large_legacy_dataset(tmp_path):
    # Execute actual SQLite 3 upsert constraints; Android thread/SAF behavior needs device testing.
    source=sqlite3.connect(tmp_path/'v881.sqlite3')
    target=sqlite3.connect(tmp_path/'v903.sqlite3')
    schema='''CREATE TABLE daily_bars(code TEXT NOT NULL,day TEXT NOT NULL,o REAL,h REAL,l REAL,c REAL,vol REAL,vol_unit TEXT,amount REAL,provider TEXT,raw TEXT,PRIMARY KEY(code,day))'''
    for d in (source,target):d.execute(schema)
    rows=[]
    import datetime
    baseline=datetime.date(2024,1,1)
    for i in range(10000):
        date=(baseline+datetime.timedelta(days=i%365)).isoformat()
        code=f'{i//365:06d}'
        rows.append((code,date,1.,2.,.5,1.2,300.,'SHARES',100.,'sample','sample'))
    source.executemany('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',rows)
    target.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',rows[0])
    for run in range(2):
        with target:
            target.executemany('INSERT OR IGNORE INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',source.execute('SELECT * FROM daily_bars'))
        assert target.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==10000
    assert target.execute('SELECT c FROM daily_bars WHERE code=? AND day=?',(rows[0][0],rows[0][1])).fetchone()[0]==1.2
    source.close();target.close()
