"""V9.1.0 regression: short current-candle fetch independent from old history/finance audits."""
from pathlib import Path
import subprocess, tempfile
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'
W=(J/'DailyUpdateWorker.java').read_text()
DB=(J/'MarketDb.java').read_text()
FIN=(J/'FastFinanceSync.java').read_text()
QUOTE=(J/'TencentBatchQuotes.java').read_text()

def test_hk_batch_reads_timestamp_and_native_share_unit():
    for token in ['hk[0-9]{5}', 'v_(?:r_)?hk', 'SHARES', 'time.substring(0,8)', 'hour<(hk?16:15)', 'requestedCodes']:
        assert token in QUOTE or token in W
    assert 'MAX_TAIL_REQUESTS=48' in W
    assert 'TAIL_STAGE_MS=65_000' in W
    assert 'stats.checkedWithoutBar.put' in W

def test_failures_checkpointed_only_after_attempt():
    assert 'db.markFastQuoteChecks(day,quote.checkedWithoutBar)' in W
    assert W.index('tailStage(c,db')<W.index('db.markFastQuoteChecks(day,quote.checkedWithoutBar)')
    assert 'INSERT OR IGNORE INTO auto_daily_attempts' in DB
    assert 'WHERE NOT EXISTS' in DB
    assert 'INSERT OR IGNORE INTO daily_bars' in DB
    assert 'return stats;' in W

def test_finance_bounded_and_existing_schema_unchanged():
    assert 'MAX_REQUESTS=100' in FIN and 'PARALLEL=4' in FIN
    assert 'db.financeCheckpoints()' in FIN
    assert 'FinanceRefreshPolicy.due' in FIN
    assert 'db.saveData' in FIN and 'db.saveEmptyDataJob' in FIN
    assert 'result.pending+=due.size()-result.attempted' in FIN
    assert 'NAME="quantdesk-a-share-2y.sqlite3"' in DB
    assert 'super(context,NAME,null,5)' in DB
    assert "versionCode 916" in (R/'android-app/app/build.gradle').read_text()

def test_actual_hk_parser_java():
    with tempfile.TemporaryDirectory() as temp:
        sources=[J/'Bar.java',J/'TencentBatchQuotes.java',R/'tests/java/TencentBatchQuotesTest.java']
        subprocess.run(['javac','-encoding','UTF-8','-d',temp,*map(str,sources)],check=True,capture_output=True)
        out=subprocess.run(['java','-cp',temp,'com.quantdesk.download.TencentBatchQuotesTest'],
                           check=True,capture_output=True,text=True)
        assert 'OK' in out.stdout
