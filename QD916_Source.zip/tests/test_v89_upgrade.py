"""Real SQLite v1->v2 schema upgrade tests and regression checks; no stock network."""
from pathlib import Path
import sqlite3, re, json
R=Path(__file__).resolve().parents[1]
M=(R/'android-app/app/src/main/java/com/quantdesk/download/MarketDb.java').read_text()
B=(R/'android-app/app/build.gradle').read_text()
S=(R/'android-app/app/src/main/java/com/quantdesk/download/HarvestService.java').read_text()
F=(R/'android-app/app/src/main/java/com/quantdesk/download/FinancialSources.java').read_text()


def statements():
    return re.findall(r'd\.execSQL\("(CREATE (?:TABLE|INDEX) [^\"]+)"\);',M)


def create_legacy(db):
    for statement in statements()[:6]: db.execute(statement)
    db.execute('PRAGMA user_version=1')


def upgrade(db):
    for statement in statements()[6:]: db.execute(statement)
    db.execute('PRAGMA user_version=3')


def test_v881_tables_retained_and_financial_data_additive():
    db=sqlite3.connect(':memory:')
    create_legacy(db)
    db.execute('INSERT INTO instruments VALUES(?,?,?,?)',('600519','贵州茅台','SH','real'))
    db.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',('600519','2026-10-23',1,2,0.5,1.5,100,'LOTS',2000,'eastmoney','raw'))
    db.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?)',('600519','2024-10-24','2026-10-24','complete',1,1,None,1))
    upgrade(db)
    assert db.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==1
    assert db.execute('SELECT status FROM tasks').fetchone()[0]=='complete'
    assert {'dataset_rows','data_jobs','finance_state'}.issubset({x[0] for x in db.execute('SELECT name FROM sqlite_master')})
    # Repeat migration safely (IF NOT EXISTS); no wipe.
    upgrade(db)
    assert db.execute('SELECT count(*) FROM daily_bars').fetchone()[0]==1
    db.close()


def test_report_raw_rows_and_revision_dedupe():
    db=sqlite3.connect(':memory:'); create_legacy(db); upgrade(db)
    raw=json.dumps({'ts_code':'600519.SH','end_date':'20260930','ann_date':'20261020','revenue':1000.},ensure_ascii=False)
    values=('600519','income','uniquehash','20260930','20261020','', 'tushare',raw,1234)
    db.execute('INSERT OR IGNORE INTO dataset_rows VALUES(?,?,?,?,?,?,?,?,?)',values)
    db.execute('INSERT OR IGNORE INTO dataset_rows VALUES(?,?,?,?,?,?,?,?,?)',values)
    assert db.execute('SELECT count(*) FROM dataset_rows').fetchone()[0]==1
    assert json.loads(db.execute('SELECT raw_json FROM dataset_rows').fetchone()[0])['revenue']==1000.
    assert 'PRIMARY KEY(code,dataset,record_id)' in M
    db.close()


def test_same_app_identity_and_no_destructive_migrations():
    assert "applicationId 'com.quantdesk.asharecollector88'" in B
    assert 'versionCode 916' in B
    assert 'super(context,NAME,null,5)' in M
    assert 'No destructive migrations permitted' not in M
    assert 'DROP TABLE' not in M
    assert 'CREATE TABLE IF NOT EXISTS data_jobs' in M
    assert 'new TokenVault' not in S


def test_kline_reuses_old_saved_maximum_and_finance_separate():
    assert 'HistoryGapPlanner.plan' in S
    assert 'db.barDays(code,from,to)' in S
    assert 'db.markVerifiedHistory(code,from,to)' in S
    assert 'START_FINANCE' in S
    assert 'FinancialSources.fetch' in S
    assert 'db.saveData' in S
    assert 'db.dataFailure' in S
    assert all(k in F for k in ['income','balancesheet','cashflow','hk_indicator','hk_dividend'])
    assert 'https://api.tushare.pro' not in F
    assert 'Eastmoney' in F


def test_database_import_export_in_android_source():
    a=(R/'android-app/app/src/main/java/com/quantdesk/download/MainActivity.java').read_text()
    assert 'mergeBackup(temp' in a
    assert 'ACTION_OPEN_DOCUMENT' in a and 'ACTION_CREATE_DOCUMENT' in a
    assert '已下载行情不会删除' in M
    assert 'INSERT OR IGNORE INTO daily_bars' in M
    assert not (R/'android-app/app/src/main/java/com/quantdesk/download/TokenVault.java').exists()
