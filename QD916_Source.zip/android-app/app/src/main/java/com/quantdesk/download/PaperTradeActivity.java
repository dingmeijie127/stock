package com.quantdesk.download;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Second independent strategy page; all money is fictional and strictly offline. */
public final class PaperTradeActivity extends Activity {
    private static final int EXPORT=3101,EXPORT_DB=3102;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private TextView message,accountInfo,signals,ledger;
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String t,int size){TextView x=new TextView(this);x.setText(t);x.setTextSize(size);x.setPadding(dp(4),dp(8),dp(4),dp(8));x.setTextIsSelectable(true);return x;}
    private void button(LinearLayout root,String label,View.OnClickListener callback){
        Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setOnClickListener(callback);root.addView(b);
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(15),dp(12),dp(15),dp(20));
        ScrollView scroll=new ScrollView(this);scroll.addView(panel);setContentView(scroll);
        panel.addView(text("QuantDesk · 页面② 短线波段模拟账户",21));
        panel.addView(text("账户01 · 策略 SWING_BREAKOUT_V1 · 完全模拟，不连接真实券商，不使用真实资金。以后新策略使用独立账户。",13));
        button(panel,"← 返回A股数据库主页",v->finish());
        message=text("正在加载本地K线、模拟账本……",15);panel.addView(message);
        accountInfo=text("模拟权益读取中……",16);panel.addView(accountInfo);
        panel.addView(text("今日/最新收盘日建议（信号产生于收盘后，计划在下一交易日执行）",17));
        button(panel,"① 重新扫描本地A股｜生成买卖持仓建议",v->runAction("SCAN"));
        signals=text("尚未生成策略建议",14);panel.addView(signals);
        button(panel,"② 确认建议｜创建待成交模拟委托",v->runAction("ORDER"));
        button(panel,"③ 用新入库的下一交易日日K模拟结算",v->runAction("SETTLE"));
        panel.addView(text("模拟账本（最近35条，记录持久保存）",17));
        ledger=text("账本读取中……",13);panel.addView(ledger);
        button(panel,"导出模拟账户账本CSV",v->exportFile(EXPORT));
        button(panel,"单独备份模拟账户SQLite（与市场数据库分开）",v->exportFile(EXPORT_DB));
        panel.addView(text("策略：收盘价突破过去20日最高价，MA5>MA20、MA20上行且放量才考虑买；跌破10日均线、-6%止损、+12%止盈或10个交易日离场。每个信号都注明日期，非实时交易指令。",13));
        panel.addView(text("关键限制：未复权日K可能受分红送转干扰；日K无法还原真实盘口、滑点和涨跌停成交排队。模拟按下一有效日开盘价±0.1%滑点，佣金模拟万分之三最低5元，卖出印花税万分之五。复权、历史退市股、停牌、成交量和回测偏差仍须单独验证。模拟账户存独立SQLite，备份市场数据库时请同时备份本账户。",13));
        runAction("SCAN");
    }
    private void runAction(String action){
        if(!busy.compareAndSet(false,true)){message.setText("当前扫描/结算正在进行，请勿重复点击");return;}
        message.setText("正在处理："+action+"……（只读市场K线，独立写模拟账本）");
        new Thread(()->{
            String note="";
            try(MarketDb market=new MarketDb(getApplicationContext());PaperTradingStore paper=new PaperTradingStore(getApplicationContext())){
                long a=paper.account();String day=PaperTradingStore.asOf(market);
                if(day.isEmpty()){note="数据库没有有效A股日K，不能生成信号或成交";}
                else if("SCAN".equals(action)){
                    String settlement=paper.settle(market,a,day);
                    note=settlement+"\n"+paper.scan(market,a,day,(scanned,total)->
                        ui.post(()->message.setText("正在扫描已存A股日K："+scanned+"/"+total+" 只；模拟账户不联网")));
                }else if("ORDER".equals(action)){
                    // Only act on saved signals for the current latest trading day.
                    if(paper.signals(a,day).isEmpty())note="没有当前收盘日信号，请先点击『重新扫描』";
                    else note=paper.placeSuggestedOrders(a,day);
                }else note=paper.settle(market,a,day);
                String summary=paper.summary(market,a,day);
                StringBuilder recommended=new StringBuilder();
                List<PaperTradingStore.Signal> daySignals=paper.signals(a,day);
                int buys=0,sells=0,holds=0;
                for(PaperTradingStore.Signal s:daySignals){
                    if("BUY".equals(s.action))buys++;
                    if("SELL".equals(s.action))sells++;
                    if("HOLD".equals(s.action))holds++;
                }
                recommended.append("日期 ").append(day).append(" · 买入候选 ").append(buys)
                    .append(" / 待卖出 ").append(sells).append(" / 继续持有 ").append(holds).append("\n");
                for(PaperTradingStore.Signal s:daySignals){
                    recommended.append(s.action).append(" ").append(s.code).append(" ").append(PaperTradingStore.securityName(market,s.code)).append(" 收盘¥")
                        .append(String.format(Locale.CHINA,"%.2f",s.price)).append("\n  ").append(s.reason).append("\n");
                }
                if(daySignals.isEmpty())recommended.append("今天没有符合条件的有效信号；不会为了交易而强行选股。\n");
                String log=paper.recentLedger(a);
                String msg=note;
                ui.post(()->{message.setText(msg);accountInfo.setText(summary);signals.setText(recommended.toString());ledger.setText(log);});
            }catch(Exception ex){
                android.util.Log.e("QDPaper","纸上交易失败",ex);
                String fail="模拟账户操作失败："+ex.getClass().getSimpleName()+" "+ex.getMessage();
                ui.post(()->message.setText(fail));
            }finally{busy.set(false);}
        },"qd-paper-"+action).start();
    }
    private void exportFile(int kind){
        if(busy.get()){message.setText("模拟账本正在写入，请完成后再导出");return;}
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(kind==EXPORT?"text/csv":"application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE,kind==EXPORT?"QuantDesk-模拟账户01-交易账本.csv":"QuantDesk-模拟账户01-备份.sqlite3");
        try{startActivityForResult(intent,kind);}catch(Exception ex){message.setText("无法打开CSV保存窗口："+ex.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if((request!=EXPORT&&request!=EXPORT_DB)||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri target=data.getData();
        if(!busy.compareAndSet(false,true)){message.setText("模拟任务仍在运行，暂不能导出");return;}
        message.setText("正在导出模拟账户文件……");
        new Thread(()->{
            try(PaperTradingStore paper=new PaperTradingStore(getApplicationContext());
                OutputStream stream=getContentResolver().openOutputStream(target,"w")){
                if(stream==null)throw new IllegalStateException("保存文件不可写");
                if(request==EXPORT){
                    OutputStreamWriter writer=new OutputStreamWriter(stream,StandardCharsets.UTF_8);
                    paper.exportLedger(paper.account(),writer);writer.flush();
                }else{
                    paper.account();paper.checkpoint();
                    File source=getDatabasePath(PaperTradingStore.NAME);
                    try(FileInputStream input=new FileInputStream(source)){
                        byte[] buffer=new byte[65536];int n;
                        while((n=input.read(buffer))!=-1)stream.write(buffer,0,n);
                    }
                    stream.flush();
                }
                ui.post(()->Toast.makeText(this,"模拟账户文件已保存",Toast.LENGTH_LONG).show());
            }catch(Exception e){ui.post(()->message.setText("导出失败："+e.getMessage()));}
            finally{busy.set(false);}
        },"qd-paper-export").start();
    }
}
