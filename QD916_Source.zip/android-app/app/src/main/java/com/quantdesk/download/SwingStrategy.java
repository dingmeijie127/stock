package com.quantdesk.download;

import java.util.List;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** V9.1.6: pure, deterministic, close-of-day signal engine; never uses future bars. */
public final class SwingStrategy {
    private SwingStrategy() {}
    public static final String VERSION="SWING_BREAKOUT_V1";
    public static final class Candle {
        public final String day;
        public final double open,high,low,close,volume;
        public Candle(String day,double open,double high,double low,double close,double volume){
            this.day=day;this.open=open;this.high=high;this.low=low;this.close=close;this.volume=volume;
        }
        boolean valid(){return day!=null&&day.length()==10&&Double.isFinite(open)&&Double.isFinite(high)&&
            Double.isFinite(low)&&Double.isFinite(close)&&Double.isFinite(volume)&&low>0&&high>=low&&
            open>=low-1e-5&&open<=high+1e-5&&close>=low-1e-5&&close<=high+1e-5&&volume>0;}
    }
    public static final class Advice {
        public final String action,reason,asOf;
        public final double price,score;
        public Advice(String action,String reason,String asOf,double price,double score){
            this.action=action;this.reason=reason;this.asOf=asOf;this.price=price;this.score=score;
        }
    }
    private static double mean(List<Candle> b,int endExclusive,int period,boolean volume){
        double sum=0;
        for(int i=endExclusive-period;i<endExclusive;i++)sum+=volume?b.get(i).volume:b.get(i).close;
        return sum/period;
    }
    /** bars oldest -> newest, point-in-time holdings and basis supplied by caller. */
    public static Advice evaluate(List<Candle> bars,String targetDay,boolean held,double costBasis,int tradingDaysHeld){
        if(bars.isEmpty())return new Advice("NONE","没有历史数据","",0,0);
        Candle last=bars.get(bars.size()-1);
        if(!last.day.equals(targetDay))return new Advice("NONE","当前股票没有目标交易日收盘K线",last.day,last.close,0);
        if(bars.size()<65)return new Advice("NONE","不足65根日K",last.day,last.close,0);
        for(int i=1;i<bars.size();i++){
            if(!bars.get(i).valid()||bars.get(i).day.compareTo(bars.get(i-1).day)<=0)
                return new Advice("NONE","K线非法或日期未升序",last.day,last.close,0);
            if(ChronoUnit.DAYS.between(LocalDate.parse(bars.get(i-1).day),LocalDate.parse(bars.get(i).day))>20)
                return new Advice("NONE","历史K线存在超过20天间隔",last.day,last.close,0);
        }
        if(!bars.get(0).valid())return new Advice("NONE","K线异常",last.day,last.close,0);
        int n=bars.size();
        double ma5=mean(bars,n,5,false),ma10=mean(bars,n,10,false),ma20=mean(bars,n,20,false);
        double priorMa20=mean(bars,n-1,20,false);
        double prev20High=0;
        for(int i=n-21;i<n-1;i++)prev20High=Math.max(prev20High,bars.get(i).high);
        double volumeRatio=last.volume/Math.max(1,mean(bars,n-1,20,true));
        double dayChange=last.close/bars.get(n-2).close-1;
        if(held){
            if(costBasis<=0)return new Advice("NONE","持仓成本错误",last.day,last.close,0);
            double ret=last.close/costBasis-1;
            if(ret<=-0.06)return new Advice("SELL","收盘价跌破买入成本6%止损",last.day,last.close,100);
            if(ret>=0.12)return new Advice("SELL","收盘价达到12%止盈",last.day,last.close,100);
            if(last.close<ma10)return new Advice("SELL","收盘价跌破10日均线",last.day,last.close,90);
            if(tradingDaysHeld>=10)return new Advice("SELL","持仓达到10个交易日",last.day,last.close,80);
            return new Advice("HOLD","持仓仍在趋势内；检查止损与10日均线",last.day,last.close,0);
        }
        if(dayChange>0.12||dayChange< -0.12)return new Advice("NONE","单日剧烈波动，可能含除权异常",last.day,last.close,0);
        if(last.close>prev20High&&ma5>ma20&&ma20>priorMa20&&last.close>ma20&&volumeRatio>=1.2){
            double score=(last.close/prev20High-1)*100+Math.min(volumeRatio,3)*2+
                (ma5/ma20-1)*100;
            return new Advice("BUY",String.format(java.util.Locale.CHINA,
                "突破前20日高点；MA5>MA20；量比%.2f；次交易日模拟买入",volumeRatio),last.day,last.close,score);
        }
        return new Advice("NONE","未满足突破、均线与放量的共同条件",last.day,last.close,0);
    }
    public static int buyLots(double available,double price,double percent){
        if(!Double.isFinite(available)||!Double.isFinite(price)||price<=0||available<=0)return 0;
        double budget=Math.min(available,available*percent);
        return Math.max(0, (int)(Math.floor((budget-5)/(price*1.003)/100))*100);
    }
    public static double commission(double gross){return Math.max(5,Math.round(gross*0.0003*100.0)/100.0);}
    public static double sellTax(double gross){return Math.round(gross*0.0005*100.0)/100.0;}
}
