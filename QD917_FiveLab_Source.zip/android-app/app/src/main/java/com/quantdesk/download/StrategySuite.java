package com.quantdesk.download;

import java.util.List;
import java.util.Locale;

/** Five distinct, fixed-parameter, no-forward-data A-share strategy experiments.
 * Chan: simplified confirmed 3-bar fractal + downward consolidation flag, NOT complete Chan theory.
 */
public final class StrategySuite {
    private StrategySuite(){}
    public static final String RSI=SwingStrategy.VERSION;
    public static final String CHAN="CHAN_FRACTAL_FLAG_V1";
    public static final String BREAKOUT="DONCHIAN_ATR_V1";
    public static final String BOLL="BOLLINGER_REVERSAL_V1";
    public static final String MOMENTUM="MOMENTUM_LOWVOL_V1";
    public static final String[] IDS={RSI,CHAN,BREAKOUT,BOLL,MOMENTUM};
    public static String title(String id){
        if(RSI.equals(id))return "① RSI2 趋势回调";
        if(CHAN.equals(id))return "② 缠论分型 + 旗形";
        if(BREAKOUT.equals(id))return "③ Donchian 突破";
        if(BOLL.equals(id))return "④ 布林带震荡反转";
        if(MOMENTUM.equals(id))return "⑤ 动量 + 低波动";
        return id;
    }
    public static String formula(String id){
        if(RSI.equals(id))return "MA60向上 + RSI(2)超卖反弹 + ATR仓位";
        if(CHAN.equals(id))return "确认底分型+简化下倾旗形突破+量能过滤（不等于完整缠论中枢/笔/线段）";
        if(BREAKOUT.equals(id))return "55日唐奇安通道突破 + MA60 + ATR";
        if(BOLL.equals(id))return "20日布林带下轨回归 + RSI14 + 震荡环境";
        if(MOMENTUM.equals(id))return "60日相对自身动量 + MA100 + ATR波动过滤";
        return "未知实验";
    }
    private static SwingStrategy.Advice out(String type,String text,SwingStrategy.Candle b,double score){
        return new SwingStrategy.Advice(type,text,b.day,b.close,score);
    }
    static double highest(List<SwingStrategy.Candle> b,int end,int count){double max=Double.NEGATIVE_INFINITY;for(int i=end-count;i<end;i++)max=Math.max(max,b.get(i).high);return max;}
    static double lowest(List<SwingStrategy.Candle> b,int end,int count){double min=Double.POSITIVE_INFINITY;for(int i=end-count;i<end;i++)min=Math.min(min,b.get(i).low);return min;}
    static double rsi14(List<SwingStrategy.Candle> b,int n){
        double up=0,down=0;for(int i=n-14;i<n;i++){
            double d=b.get(i).close-b.get(i-1).close;up+=Math.max(0,d);down+=Math.max(0,-d);
        }
        if(down==0)return up==0?50:100;
        return 100-100/(1+up/down);
    }
    private static boolean bottomFractal(List<SwingStrategy.Candle> b,int i){
        return i>0&&i<b.size()-1&&b.get(i).low<b.get(i-1).low&&b.get(i).low<b.get(i+1).low;
    }
    public static SwingStrategy.Advice evaluate(String id,List<SwingStrategy.Candle> b,String day,
                                                 MarketRegime.Result regime,boolean held,double basis,int heldDays){
        if(regime==null)return new SwingStrategy.Advice("NONE","未完成大盘广度分析",day,0,0);
        if(b==null||b.size()<105)return new SwingStrategy.Advice("NONE","有效日K不足105根",day,0,0);
        int n=b.size();SwingStrategy.Candle last=b.get(n-1),prev=b.get(n-2);
        if(!day.equals(last.day))return out("NONE","该股票没有目标日行情",last,0);
        for(int i=n-105;i<n;i++)if(!b.get(i).valid()||(i>n-105&&b.get(i-1).day.compareTo(b.get(i).day)>=0))
            return out("NONE","K线质量或顺序异常",last,0);
        double ma20=SwingStrategy.sma(b,n,20),ma60=SwingStrategy.sma(b,n,60),
            ma100=SwingStrategy.sma(b,n,100),atr=SwingStrategy.atr14(b,n),atrRate=atr/last.close;
        if(held){
            if(basis<=0||!Double.isFinite(basis))return out("NONE","异常成本，暂停执行",last,0);
            double r=last.close/basis-1;
            if(MarketRegime.BEAR.equals(regime.mode))return out("SELL","大盘转入熊市：所有账户风险优先，下一交易日模拟退出",last,99);
            if(r<=-Math.max(.04,Math.min(.085,2.2*atr/basis)))return out("SELL","ATR风险止损",last,96);
            if(r>=.14)return out("SELL","获利达到14%，锁定模拟收益",last,92);
            if(heldDays>=4&&last.close<ma20*.975)return out("SELL","失守20日均线，趋势保护",last,88);
            if(heldDays>=20)return out("SELL","持有20交易日，到期再平衡",last,80);
            return out("HOLD","持仓跟踪；"+regime.label(),last,0);
        }
        if(!regime.allowed(id))return out("NONE","市场状态"+regime.label()+"不适合当前策略新开仓",last,0);
        double daily=last.close/prev.close-1;
        if(last.close<3||Math.abs(daily)>.095||atrRate<.008||atrRate>.07)
            return out("NONE","流动性/涨跌幅/波动率过滤",last,0);
        if(RSI.equals(id)){
            SwingStrategy.Advice a=SwingStrategy.evaluate(b,day,false,0,0);
            return a;
        }
        if(CHAN.equals(id)){
            // Confirmed swing low must be at least one day old; no repainting with future candles.
            int bottoms=0;double lastBottom=0;for(int i=n-19;i<n-3;i++)if(bottomFractal(b,i)){
                bottoms++;lastBottom=b.get(i).low;
            }
            double flagHigh=highest(b,n-1,11),earlyHigh=highest(b,n-12,11);
            boolean flag=earlyHigh>flagHigh*1.02&&last.close>flagHigh&&last.close>prev.close;
            double avgVol=0;for(int i=n-21;i<n-1;i++)avgVol+=b.get(i).volume/20;
            if(bottoms>=2&&lastBottom>0&&last.close>ma60&&flag&&last.volume>avgVol*1.20)
                return out("BUY",String.format(Locale.CHINA,"已确认%d处底分型；下倾整理旗形向上突破 %.2f；放量 %.1f倍",bottoms,flagHigh,last.volume/avgVol),last,77+Math.min(18,(last.close/flagHigh-1)*1000));
        }else if(BREAKOUT.equals(id)){
            double top=highest(b,n-1,55);
            if(last.close>top&&ma60>SwingStrategy.sma(b,n-5,60)&&last.close>ma20&&atrRate<.055)
                return out("BUY",String.format(Locale.CHINA,"突破前55日最高 %.2f；MA60上行；ATR %.1f%%",top,atrRate*100),last,74+Math.min(20,(last.close/top-1)*1000));
        }else if(BOLL.equals(id)){
            double mean=ma20,var=0,priorMean=SwingStrategy.sma(b,n-1,20),priorVar=0;
            for(int i=n-20;i<n;i++)var+=Math.pow(b.get(i).close-mean,2)/20;
            for(int i=n-21;i<n-1;i++)priorVar+=Math.pow(b.get(i).close-priorMean,2)/20;
            double lower=mean-2*Math.sqrt(var),prevLower=priorMean-2*Math.sqrt(priorVar);
            if(prev.close<prevLower&&last.close>lower&&last.close>prev.close&&rsi14(b,n)<48)
                return out("BUY",String.format(Locale.CHINA,"布林下轨回归 %.2f；RSI14 %.1f",lower,rsi14(b,n)),last,75);
        }else if(MOMENTUM.equals(id)){
            double mom60=last.close/b.get(n-61).close-1,mom20=last.close/b.get(n-21).close-1;
            if(last.close>ma100&&ma20>ma60&&mom60>.08&&mom60<.35&&mom20>.02&&mom20<.16&&atrRate<.034)
                return out("BUY",String.format(Locale.CHINA,"60日动量 %.1f%%，20日动量 %.1f%%，低ATR %.1f%%",mom60*100,mom20*100,atrRate*100),last,65+Math.min(25,mom60*70));
        }
        return out("NONE","不满足"+title(id)+"的完整入场条件",last,0);
    }
}
