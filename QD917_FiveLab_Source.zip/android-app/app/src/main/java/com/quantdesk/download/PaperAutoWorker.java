package com.quantdesk.download;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.concurrent.TimeUnit;

/** Opt-in: only fictional transactions. Requires refreshed local daily bars; never talks to a broker. */
public final class PaperAutoWorker extends Worker {
    public static final String NAME="qd-multi-five-paper-daily";
    private static final String PREF="five_strategy_lab";
    public PaperAutoWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    public static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public static boolean enabled(Context c){return prefs(c).getBoolean("auto_paper",false);}
    public static void schedule(Context c,boolean enabled){
        prefs(c).edit().putBoolean("auto_paper",enabled).apply();
        if(!enabled){WorkManager.getInstance(c).cancelUniqueWork(NAME);return;}
        PeriodicWorkRequest work=new PeriodicWorkRequest.Builder(PaperAutoWorker.class,12,TimeUnit.HOURS)
            .setConstraints(new Constraints.Builder().setRequiresBatteryNotLow(true).build())
            .build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(NAME,ExistingPeriodicWorkPolicy.KEEP,work);
    }
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();if(!enabled(c))return Result.success();
        if(MarketDb.IMPORT_IN_PROGRESS.get()||HarvestService.RUNNING.get())return Result.retry();
        try(MarketDb market=new MarketDb(c);PaperTradingStore paper=new PaperTradingStore(c)){
            String day=PaperTradingStore.asOf(market);
            if(day.isEmpty())return Result.success();
            String prev=prefs(c).getString("last_cycle_day","");
            // One cycle per actual saved-market day. Settlement idempotent, orders unique per day.
            if(day.equals(prev))return Result.success();
            for(long id:paper.accounts())paper.settle(market,id,day);
            String marketSummary=paper.scanAll(market,day,null);
            StringBuilder result=new StringBuilder(marketSummary);
            for(long id:paper.accounts())result.append("\n").append(paper.placeSuggestedOrders(market,id,day));
            prefs(c).edit().putString("last_cycle_day",day).putString("market_summary",marketSummary)
                .putString("last_auto_run",result.toString()).apply();
            return Result.success();
        }catch(Exception ex){android.util.Log.e("QDFiveLab","自动模拟任务出错",ex);return Result.retry();}
    }
}
