package com.quantdesk.download;

import java.util.List;
import java.util.Locale;

/** Cross-sectional market regime based ONLY on stored A-share bars up to evaluation date.
 *  Uses market breadth rather than pretending the database includes a verified index feed.
 */
public final class MarketRegime {
    private MarketRegime(){}
    public static final String BULL="BULL",BEAR="BEAR",RANGE="RANGE",UNKNOWN="UNKNOWN";
    public static final class Tally {
        public int universe,observed,above20,above60,advancing;
        public double return20Sum;
        public void observe(List<SwingStrategy.Candle> b,String day){
            universe++;
            if(b==null||b.size()<65)return;
            int n=b.size();SwingStrategy.Candle end=b.get(n-1);
            if(!day.equals(end.day)||!end.valid())return;
            for(int i=n-65;i<n;i++)if(!b.get(i).valid())return;
            double m20=SwingStrategy.sma(b,n,20),m60=SwingStrategy.sma(b,n,60);
            double m20prev=SwingStrategy.sma(b,n-5,20);
            observed++;
            if(end.close>m20)above20++;
            if(end.close>m60)above60++;
            if(m20>m20prev)advancing++;
            return20Sum+=end.close/b.get(n-21).close-1;
        }
        public Result finish(String day){
            double coverage=universe==0?0:observed/(double)universe;
            if(observed<200||coverage<0.55)return new Result(day,UNKNOWN,observed,universe,0,0,0,0,
                "历史日K覆盖不足（至少200只且覆盖率55%）；暂停新买入");
            double b20=above20/(double)observed,b60=above60/(double)observed;
            double adv=advancing/(double)observed,ret=return20Sum/observed;
            String mode;
            if(b60>=0.57&&b20>=0.55&&adv>=0.52&&ret>=0.01)mode=BULL;
            else if(b60<=0.42&&b20<=0.45&&adv<=0.46&&ret<=-0.01)mode=BEAR;
            else mode=RANGE;
            String info=String.format(Locale.CHINA,"全市场广度：MA20上方 %.1f%%、MA60上方 %.1f%%、均线向上 %.1f%%、20日等权平均涨跌 %.2f%%；有效 %d/%d只",
                100*b20,100*b60,100*adv,100*ret,observed,universe);
            return new Result(day,mode,observed,universe,b20,b60,adv,ret,info);
        }
    }
    public static final class Result{
        public final String day,mode,description;public final int observed,universe;
        public final double breadth20,breadth60,advancing,return20;
        public Result(String day,String mode,int observed,int universe,double b20,double b60,double adv,double r,String description){
            this.day=day;this.mode=mode;this.observed=observed;this.universe=universe;
            this.breadth20=b20;this.breadth60=b60;this.advancing=adv;this.return20=r;this.description=description;
        }
        public String label(){return BULL.equals(mode)?"牛市（广度偏强）":BEAR.equals(mode)?"熊市（广度偏弱）":RANGE.equals(mode)?"震荡/猴市":"无法可靠判定";}
        public boolean allowed(String id){
            if(UNKNOWN.equals(mode)||BEAR.equals(mode))return false;
            if(StrategySuite.CHAN.equals(id)||StrategySuite.BREAKOUT.equals(id))return BULL.equals(mode);
            if(StrategySuite.BOLL.equals(id))return RANGE.equals(mode);
            return true;
        }
    }
}
