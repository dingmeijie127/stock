"""V9.1.5 financial coverage feature and no destructive DB changes source contracts."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'android-app/app/src/main/java/com/quantdesk/download'


def test_button_audit_and_export_use_same_read_only_db_path():
    ui=(SRC/'MainActivity.java').read_text()
    db=(SRC/'MarketDb.java').read_text()
    assert '扫描本地财报｜覆盖率 + 缺期明细' in ui
    assert '导出A股财报缺口CSV｜逐股票逐报表' in ui
    assert 'new Thread(' in ui and 'qd-finance-local-audit' in ui
    assert 'db.auditAFinance(' in ui
    audit=db[db.index('public FinanceLocalAudit.Summary auditAFinance'):db.index('public int countDataRows()')]
    assert 'getReadableDatabase()' in audit
    assert 'getWritableDatabase()' not in audit
    assert 'r.dataset IN (\'income\',\'balancesheet\',\'cashflow\')' in audit
    assert "i.exchange IN ('SH','SZ','BJ')" in audit
    assert 'GROUP BY' in audit
    assert 'SELECT r.raw_json' not in audit


def test_build_package_and_original_schema_preserved():
    wf=(ROOT/'.github/workflows/QD917_FiveLab_Build.yml').read_text()
    gradle=(ROOT/'android-app/app/build.gradle').read_text()
    db=(SRC/'MarketDb.java').read_text()
    assert "z=Path('QD917_FiveLab_Source.zip')" in wf
    assert 'FinanceLocalAuditTest.java' in wf
    assert 'versionCode 917' in gradle
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in gradle
    assert 'quantdesk-a-share-2y.sqlite3' in db
    assert 'PRIMARY KEY(code,dataset,record_id)' in db
    assert 'DROP TABLE' not in db
