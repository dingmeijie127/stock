"""Release-package consistency guard: expected V9.1.5 tree and workflow."""
from pathlib import Path
import ast
import re

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / '.github/workflows/QD917_FiveLab_Build.yml'

def test_workflow_required_sources_are_present():
    content = WORKFLOW.read_text(encoding='utf-8')
    m = re.search(r'          required=(\[.*?\])\n', content, re.S)
    assert m, 'Missing required-file declaration in the GitHub workflow'
    for path in ast.literal_eval(m.group(1)):
        assert (ROOT/path).is_file(), f'Workflow checks for missing source: {path}'

def test_app_version_matches_workflow():
    text = (ROOT/'android-app/app/build.gradle').read_text(encoding='utf-8')
    assert 'versionCode 917' in text
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in text
    assert 'QD917_FiveLab_Source.zip' in WORKFLOW.read_text(encoding='utf-8')
