"""RSI2 lab identity and independently configurable signing; market schema unchanged."""
from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'
W=(R/'.github/workflows/QD917_FiveLab_Build.yml').read_text()

def test_independent_apk_identity_and_signing():
    gradle=(R/'android-app/app/build.gradle').read_text()
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in gradle
    assert 'secrets.QD_FIVELAB01_KEYSTORE_B64' in W
    for item in ('SIGNING_ALIAS','SIGNING_STORE_PASSWORD','SIGNING_KEY_PASSWORD'):
        assert f'secrets.QD_FIVELAB01_{item}' in W
    assert "QD917_FiveLab_Source.zip" in W
    assert "QD917_FiveLab_Build.yml" in W
    assert ':app:assembleRelease' in W and ':app:assembleDebug' in W
    assert 'FIVELAB_SIGNING_MODE=debug' in W
    assert 'FIVELAB_SIGNING_MODE=release' in W
    assert 'if [[ $present -ne 0 && $present -ne 4 ]]' in W

def test_strategy_is_mean_reversion_not_breakout():
    engine=(J/'SwingStrategy.java').read_text()
    assert 'TREND_RSI2_ATR_LAB_V1' in engine
    assert 'rsiPrior<=18' in engine
    assert 'rsiNow>=rsiPrior+5' in engine
    assert 'atr14(' in engine and 'buyLotsRisk(' in engine
    assert 'SWING_BREAKOUT_V1' not in engine

def test_realistic_manual_workflow_and_ui():
    store=(J/'PaperTradingStore.java').read_text()
    page=(J/'PaperTradeActivity.java').read_text()
    for contract in ('manualOrder(', 'cancelPending(', 'orders(', 'performance('):
        assert contract in store
    for feature in ('模拟买入','模拟卖出','撤销未成交委托','持仓','委托','战绩','流水','AlertDialog'):
        assert feature in page
    assert 'day=?' in store and "status='PENDING'" in store
    assert 'DROP TABLE' not in store

def test_marketdb_no_schema_migration_in_paper_layer():
    assert 'getReadableDatabase()' in (J/'PaperTradingStore.java').read_text()
    assert 'quantdesk-paper-accounts.sqlite3' in (J/'PaperTradingStore.java').read_text()
