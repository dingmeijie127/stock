# TideQuant V0.3.1：GitHub SDK 安装修复

## 原因

你上传的截图显示：`Android SDK` 步骤通过 `android-actions/setup-android@v3` 调用 `sdkmanager` 安装已废弃的 `tools` 包，出现 `Failed to find package 'tools'`。构建在安装SDK期间就中止，后续的 Gradle 编译并未执行。

## 修复

1. 两个 job（debug/release）均升级为 `android-actions/setup-android@v4`。
2. 显式配置 `packages: ''`，不再安装默认附加 SDK 包。
3. 仅显式安装工程需要的 `platforms;android-35`、`build-tools;35.0.0`、`platform-tools`。
4. 保留 JDK 17、Gradle 8.9、原来独立包名 `cn.tidelab.quantpilot`、本地 SQLite 适配代码以及 Debug APK Artifacts 上传。

## 操作

**只修改 YML 的最短路径：** 在GitHub打开 `.github/workflows/build-apk.yml`，用提供的 `build-apk_修复版.yml` 的完整内容覆盖，Commit changes，然后去 Actions → Build TideQuant Android APK → Run workflow。

**覆盖整个工程：** 解压 `TideQuant_v0.3.1_GitHub_SDK修复完整版.zip`，上传其中的文件到原仓库根目录（确保 `.github/workflows/build-apk.yml` 也上传），提交后在 Actions 运行。**不要把 ZIP 原文件当成仓库源代码上传。**

成功后在运行记录底部的 Artifacts 下载 `TideQuant-v0.3-debug-apk`，解压得到 `app-debug.apk`。

注意：本次修复通过YAML语法和静态检查；我们没有接入用户GitHub Runner，因此不能宣称已在GitHub上编译成功。如发生下一步 Gradle 编译报错，请提供新的报错**第一个 `What went wrong` 或 `error:`** 片段。
