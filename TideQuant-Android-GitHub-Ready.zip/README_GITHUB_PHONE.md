# 潮汐量化 v0.3.2 | 手机 GitHub Actions 编译

## 交付文件
- TideQuant-Android-GitHub-Ready.zip：完整 Android 工程。解压后**所有文件必须处于仓库根目录**；根目录应能看到 `app/`、`settings.gradle` 和 `.github/workflows/build-apk.yml`。
- build-apk.yml：与 ZIP 内 `.github/workflows/build-apk.yml` **完全相同**。无需改名、无需再次上传，只做备用。

## 在 GitHub Actions 构建
1. 创建一个空白仓库（建议 Private），把 ZIP **解压后的全部内容**上传到仓库根目录，**不要只把 ZIP 文件上传进去**。
2. 确认 `app/build.gradle`、`settings.gradle`、`.github/workflows/build-apk.yml` 路径正确，没有多套一个外层文件夹。
3. 点仓库 Actions -> TideQuant - Build Android APK -> Run workflow。首次上传后 push 也可自动构建。
4. 构建完成在该次 Actions 运行的 Artifacts 下载 `TideQuant-Android-Debug-APK`，解压得到 `app-debug.apk`，安装。

## 不覆盖旧 App
新包名 `cn.tidelab.quantpilot`，不会覆盖早先的 QuantDesk。GitHub 每次新运行默认可能产生不同的 Debug 签名证书，因此新 Debug APK 可能无法直接覆盖安装旧的潮汐量化 Debug APK。要稳定升级，请配置四个仓库 Secrets：`TIDE_KEYSTORE_BASE64`、`TIDE_STORE_PASSWORD`、`TIDE_KEY_ALIAS`、`TIDE_KEY_PASSWORD`；工作流会额外生成一个签名 Release APK（妥善保存同一个密钥）。不要把密钥放进源码或 ZIP。

## 当前边界
- 旧 APK 并未打包用户手机上的 SQLite 行情库。这个 App 支持选择用户自己的 SQLite 文件、检查表结构并兼容 `daily_bars` + `instruments`；不能假称已经验证了真实两年股票回测。
- 已测试 Python 研究引擎 9 项测试和 JavaScript 语法/模拟烟测；当前运行环境缺少 Android SDK 与 Gradle，**没有在 GitHub 上实际完成APK编译**。如果新工作流进入 Gradle 后出现编译异常，请提交完整步骤日志继续排查。
- 内置模拟数据只用于功能演示，不是可保证的收益率或胜率。
