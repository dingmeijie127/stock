# 潮汐量化 v0.3.5 · 大型SQLite导入修复

- 删除硬编码 `MAX_FILE_BYTES=1_500_000_000L`：支持超过1.5GB的未加密SQLite文件。
- 按1MiB块读取输入流，每64MiB显示复制进度，期间持续检查手机可用空间，预留256MiB。
- 导入过程使用临时文件，只有通过SQLite文件头、quick_check和表结构检查后才替换上一次的库。
- SAF文件选择器只能直接提供InputStream；这版**需要将数据库完整复制到App私有空间**。若数据库为3GB，手机至少要有3GB以上剩余空间另加256MB（仍要考虑旧库占用）。
- 旧QuantDesk自动识别 `daily_bars` + `instruments`；`dataset_rows.raw_json` 的财报转换仍未实测，不应宣称已完成。
- 移除1.5GB文件大小限制**不等于**一次加载全部历史行情到WebView；手机近期探索窗口依然限制最多18万条，完整版两年回测需研究引擎。
- 若原数据库采用WAL，请在旧App导出已checkpoint的完整数据库，单独复制.db可能缺最近数据。
- 本版尚未在GitHub Actions编译APK或在真实多GB数据库上真机验收；请按实际结果反馈。

---

# 手机端 GitHub 编译说明 · 潮汐量化 V0.3.4

## 两个文件

- `TideQuant-v0.3.4-Android-Project.zip`：完整独立 Android 工程，内部也包含工作流。
- `build-apk.yml`：要放在仓库路径 `.github/workflows/build-apk.yml` 的独立工作流。

## 手机上最少操作

1. 上传 ZIP 到 `dingmeijie127/stock` 仓库根目录，文件名保持 `TideQuant-v0.3.4-Android-Project.zip`。
2. 打开仓库的 `.github/workflows/build-apk.yml`。如果已有文件，点 Edit，把它替换为本版 `build-apk.yml` 内容并 Commit。若没有该路径，需要先在 GitHub 网页创建 `.github/workflows/` 目录和文件。
3. 进入 **Actions → TideQuant Android APK → Run workflow**。
4. 等运行完成，在 Artifacts 下载 `TideQuant-v0.3.4-Debug-APK`，解压安装 `TideQuant-v0.3.4-debug.apk`。

**重要：** GitHub只运行仓库里的 `.github/workflows/*.yml`，不会自动运行压缩包内部的工作流。ZIP可直接上传，但独立YML必须在仓库的正确路径存在。

如果失败，请打开Actions里红色步骤，截取从第一个 `Error` 开始到结尾的日志。不要只截顶部summary。
