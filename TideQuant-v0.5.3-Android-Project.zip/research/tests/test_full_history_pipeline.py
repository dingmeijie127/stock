"""Creates an explicitly synthetic QuantDesk-shaped SQLite, then feeds a day-ordered
JOIN export into the same pure-Java core used by the Android on-device runner.
Never a proof of real returns; this is a reproducible pipeline test.
"""
from pathlib import Path
import csv, sqlite3, subprocess, shutil
import pytest

ROOT=Path(__file__).resolve().parents[2]
SAMPLE=ROOT/'research/sample/DEMO_SYNTHETIC_576_bars.csv'
MAIN=ROOT/'app/src/main/java/cn/tidelab/quantpilot/QuantCore.java'
JAVA=ROOT/'research/tests/java/CoreCsvSmoke.java'


def test_sqlite_join_to_backtest_core(tmp_path):
    if not shutil.which('javac') or not shutil.which('java'):
        pytest.skip('Java JDK unavailable')
    # Only 70 different symbols to keep CI fast. The signal strategy is not optimized here.
    path=tmp_path/'SYNTHETIC_ONLY_old_quantdesk.db'
    con=sqlite3.connect(path)
    con.executescript('''
        CREATE TABLE instruments (code TEXT PRIMARY KEY, name TEXT, exchange TEXT);
        CREATE TABLE daily_bars (code TEXT, day TEXT, o REAL, h REAL, l REAL,
                                 c REAL, vol REAL, vol_unit TEXT, amount REAL,
                                 PRIMARY KEY(code,day));
        CREATE TABLE dataset_rows(code TEXT, dataset TEXT, raw_json TEXT, announcement_day TEXT);
    ''')
    rows=[];codes=set()
    with SAMPLE.open(encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            if len(codes)>=70 and item['code'] not in codes:continue
            codes.add(item['code'])
            rows.append((item['code'],item['date'],*[float(item[k]) for k in ['open','high','low','close','volume']], 'SHARES',float(item['amount'])))
    con.executemany('INSERT INTO instruments VALUES(?,?,?)',[(x,f'合成演示{x}','SH') for x in sorted(codes)])
    con.executemany('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?)',rows)
    con.commit()
    out=tmp_path/'from_old_db.csv'
    with out.open('w',newline='',encoding='utf8') as f:
        w=csv.writer(f);w.writerow(['code','date','open','high','low','close','volume','amount','sector','name'])
        for r in con.execute('''SELECT b.code,b.day,b.o,b.h,b.l,b.c,b.vol,b.amount,i.name
                                FROM daily_bars b JOIN instruments i ON b.code=i.code
                                WHERE i.exchange IN ('SH','SZ','BJ') ORDER BY b.day,b.code'''):
            w.writerow([r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],'未分类',r[8]])
    con.close()
    compile=subprocess.run(['javac','-encoding','UTF-8','-d',str(tmp_path),str(MAIN),str(JAVA)],capture_output=True,text=True)
    assert compile.returncode==0,compile.stderr
    result=subprocess.run(['java','-cp',str(tmp_path),'cn.tidelab.quantpilot.CoreCsvSmoke',str(out)],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    assert 'CASH trades=0' in result.stdout
    assert 'STOCKS=70' in result.stdout
    assert 'ROWS=8050' in result.stdout
