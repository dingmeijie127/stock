"""No-sector-data must disable theme account; no pre-disclosure usage.
All input prices are SYNTHETIC, not A-share investment performance.
"""
from pathlib import Path
import csv, shutil, subprocess
import pytest
ROOT=Path(__file__).resolve().parents[2]


def test_no_future_membership_or_earnings(tmp_path):
    if not shutil.which('javac') or not shutil.which('java'):
        pytest.skip('JDK is needed to exercise Android-shared Java core')
    source=ROOT/'research/sample/DEMO_SYNTHETIC_576_bars.csv'
    target=tmp_path/'sorted.csv'
    with source.open(encoding='utf-8-sig') as f:
        items=list(csv.reader(f))
    with target.open('w',encoding='utf8',newline='') as f:
        w=csv.writer(f);w.writerow(items[0]);w.writerows(sorted(items[1:],key=lambda r:(r[1],r[0])))
    out=tmp_path/'classes';out.mkdir()
    files=[ROOT/'app/src/main/java/cn/tidelab/quantpilot/QuantCore.java',ROOT/'research/tests/java/PointInTimeSmoke.java']
    c=subprocess.run(['javac','-encoding','UTF-8','-d',str(out),*[str(x) for x in files]],capture_output=True,text=True)
    assert c.returncode==0,c.stderr
    r=subprocess.run(['java','-cp',str(out),'cn.tidelab.quantpilot.PointInTimeSmoke',str(target)],capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    assert 'POINT_IN_TIME_OK' in r.stdout
    assert 'baselineRotationFills=0' in r.stdout
