package cn.tidelab.quantpilot;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Checks that the rotation mode cannot access facts before their effective date. */
public final class PointInTimeSmoke {
  static final String DISCLOSURE="2026-08-01";
  static final class MockContext implements QuantCore.Context {
    @Override public boolean hasSector(){return true;}
    @Override public boolean hasFinance(){return true;}
    @Override public String sector(String code,String day){return day.compareTo(DISCLOSURE)<0?null:(Integer.parseInt(code.substring(code.length()-1))%3==0?"半导体":Integer.parseInt(code.substring(code.length()-1))%3==1?"机器人":"光通信");}
    @Override public QuantCore.Finance finance(String code,String day){return day.compareTo(DISCLOSURE)<0?null:new QuantCore.Finance(.22,10000000,5000000);}
  }
  public static void main(String[] args)throws Exception {
    QuantCore a=new QuantCore(new MockContext());
    QuantCore baseline=new QuantCore();
    try(BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream(args[0]),StandardCharsets.UTF_8))){
      String line=in.readLine();
      while((line=in.readLine())!=null){String[] r=line.split(",",-1);if(r.length<10)continue;
        QuantCore.Bar bar=new QuantCore.Bar(r[0],r[9],r[1],Double.parseDouble(r[2]),Double.parseDouble(r[3]),Double.parseDouble(r[4]),Double.parseDouble(r[5]),Double.parseDouble(r[7]));
        a.accept(bar);baseline.accept(bar);
      }
    }
    a.finish();baseline.finish();
    if(baseline.accounts().get("ROTATION").filled!=0)throw new AssertionError("rotation traded with no sector or finance data");
    for(QuantCore.Trade t:a.accounts().get("ROTATION").trades)if(t.buyDay.compareTo(DISCLOSURE)<0)throw new AssertionError("future finance/sector leakage");
    if(a.days()<80)throw new AssertionError("too few days");
    System.out.println("POINT_IN_TIME_OK bars="+a.valid+" rotationSignals="+a.rotationSignals+" baselineRotationFills="+baseline.accounts().get("ROTATION").filled);
  }
}
