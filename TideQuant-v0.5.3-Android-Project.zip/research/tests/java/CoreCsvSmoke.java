package cn.tidelab.quantpilot;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Standalone Java core test; consumes canonical historical bars SORTED BY day,code. */
public class CoreCsvSmoke {
  public static void main(String[] a)throws Exception{
    if(a.length<1)throw new IllegalArgumentException("usage: CoreCsvSmoke sorted-bars.csv");
    QuantCore core=new QuantCore();
    try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(a[0]),StandardCharsets.UTF_8))){
      String line=r.readLine();int n=0;
      while((line=r.readLine())!=null){String[] p=line.split(",",-1);if(p.length<8)continue;
        // code,date,open,high,low,close,volume,amount,sector,name
        core.accept(new QuantCore.Bar(p[0],p.length>=10?p[9]:p[0],p[1],Double.parseDouble(p[2]),Double.parseDouble(p[3]),Double.parseDouble(p[4]),Double.parseDouble(p[5]),Double.parseDouble(p[7])));
        n++;
      }
    }
    core.finish();
    if(core.days()<40||core.stocks()<40)throw new AssertionError("bad coverage "+core.days()+" "+core.stocks());
    for(Map.Entry<String,QuantCore.Account> it:core.accounts().entrySet()){
      QuantCore.Account ac=it.getValue();
      for(QuantCore.Trade t:ac.trades){if(t.sellDay.compareTo(t.buyDay)<=0)throw new AssertionError("T+1 violation");if(t.qty%100!=0)throw new AssertionError("invalid lot");}
      System.out.printf(java.util.Locale.ROOT,"%s trades=%d total=%.5f maxDD=%.5f win=%s train=%.5f test=%.5f%n",it.getKey(),ac.trades.size(),ac.total(),ac.maxDD,ac.winRate(),ac.trainReturn(),ac.testReturn());
      if(it.getKey().equals("CASH")&&(ac.trades.size()!=0||Math.abs(ac.total())>1e-12))throw new AssertionError("cash not stable");
    }
    System.out.printf("ROWS=%d VALID=%d INVALID=%d STOCKS=%d DAYS=%d ELIGIBLE_DAYS=%d%n",core.scanned,core.valid,core.invalid,core.stocks(),core.days(),core.eligibleDays);
  }
}
