# 手机端 GitHub 编译说明 · 潮汐量化 V0.3.4

## 两个文件

- `TideQuant-v0.3.4-Android-Project.zip`：完整独立 Android 工程，内部也包含工作流。
- `build-apk.yml`：要放在仓库路径 `.github/workflows/build-apk.yml` 的独立工作流。

## 手机上最少操作

1. 上传 ZIP 到 `dingmeijie127/stock` 仓库根目录，文件名保持 `TideQuant-v0.3.4-Android-Project.zip`。
2. 打开仓库的 `.github/workflows/build-apk.yml`。如果已有文件，点 Edit，把它替换为本版 `build-apk.yml` 内容并 Commit。若没有该路径，需要先在 GitHub 网页创建 `.github/workflows/` 目录和文件。
3. 进入 **Actions → TideQuant Android APK → Run workflow**。
4. 等运行完成，在 Artifacts 下载 `TideQuant-v0.3.4-Debug-APK`，解压安装 `TideQuant-v0.3.4-debug.apk`。

**重要：** GitHub只运行仓库里的 `.github/workflows/*.yml`，不会自动运行压缩包内部的工作流。ZIP可直接上传，但独立YML必须在仓库的正确路径存在。

如果失败，请打开Actions里红色步骤，截取从第一个 `Error` 开始到结尾的日志。不要只截顶部summary。
