潮汐量化 V0.5.3 — 手机端 GitHub 使用指南

本次唯一下载：TideQuant-v0.5.3-OneDownload.zip
解压一次，得到：
  TideQuant-v0.5.3-Android-Project.zip
  .github/workflows/build-apk.yml
  README_PHONE.txt

1. 只把内部 TideQuant-v0.5.3-Android-Project.zip 上传到 GitHub 仓库根目录（不要上传总ZIP，也不要解压内部源码ZIP）。
2. 把 .github/workflows/build-apk.yml 覆盖仓库同名文件；如果缺目录，创建 .github/workflows。
3. 提交新文件到 main（或 master）分支。不要点击旧运行记录的 Re-run jobs。
4. 到 Actions，选择 TideQuant V0.5.3 | Build APK，再点 Run workflow。
5. 查看 BUILD-APK-v053 任务，成功后在 Artifacts 下载 TideQuant-v0.5.3-Debug-APK。

如果 GitHub 页面还是出现步骤“Python offline research regression tests”，那就不是 V0.5.3 工作流。
新工作流是双任务：BUILD-APK-v053 和 RESEARCH-TESTS-v053，研究测试不会拦截 APK 构建。
注：尚未在 GitHub Runner 实际验证 Android 编译；Android APK 是否能编译，以这次 Actions 日志为准。
