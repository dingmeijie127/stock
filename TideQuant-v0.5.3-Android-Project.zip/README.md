## CI hotfix 0.5.1
Fixes GitHub Actions Python test path after extracting archived Android source. See README_GITHUB_PHONE.txt. This is a CI hotfix, not a claim of live-trading validation.

# 潮汐量化 v0.5.0 · 历史数据研究版（独立Android App）

**研究软件，不自动连接券商，不承诺胜率或收益。**

## 这次实际实现（相对v0.4）

- 按`daily_bars` JOIN `instruments`全库读取A股日线，首次回测在App私有数据库**副本**建立`(day,code)`索引，避免昂贵的全表排序；原手机来源库不被改动。创建索引可能较慢，且需额外空间。
- 不再限制SQLite文件1.5GB；按1MB分片复制、校验后才替换App内副本。保护真实数据不遭覆盖。
- 历史行业/概念CSV按`effective_date`生效，旧时点不可读取未来归属；没有历史映射，则主线账户不下单。
- 财报CSV按`announcement_date`生效：强制验证`revenue_yoy`、`net_profit_ttm`和`ocf_ttm`；严格要求**TTM**口径。或者识别`dataset_rows.raw_json`中明确为TTM的顶层键；不识别时允许导入用户核实过的键映射JSON。
- 主线账户以市场广度判断环境、5日板块相对强度/广度和资金活跃度选择标的，标的日K趋势、换手成交额和基本面过滤；热点转冷、风险环境变化、跌破均线、持仓超期时提示退出。
- 三个策略账户（主线+财报、突破价量、回踩价量）加空仓基准，各自有独立权益、交易、收益、回撤；入场信号t收盘生成，t+1开盘模拟买，A股整手、费用、保守涨跌停限制；单笔风险预算200元（滑点和跳空可能超过）。
- 本机回测JSON导出：交易全清单、权益曲线、样本前后段、胜率和Wilson 95%区间、利润因子、风险期数、行业阶段、财报和板块覆盖统计。缺数据明确警告。
- GitHub Actions自动解压根目录源码ZIP，运行Python+Java测试，构建独立包名`cn.tidelab.quantpilot`的Debug APK；可选Release签名。

## Android手机操作

1. 安装新App（GitHub Actions artifact）。原App继续存在。
2. 数据中心→选择SQLite（从你原App**完整导出**的.db/.sqlite文件；若源库WAL模式，务必先checkpoint/导出快照）。
3. 导入成功自动整库回测。未提供行业或财报时，看到的是突破/回踩价量基线，**不是完整热点策略**。
4. 若要完整主线回测，导入历史行业CSV和公告日财报CSV，或上传经核对的raw_json字段映射JSON；再点击重新运行整库回测。
5. 在收益验证页查看收益、胜率、风险指标和近期成交，点击导出整库JSON报告。

## 数据格式与严肃限制

`examples`目录中所有示例带有SYNTHETIC字样，**均不是真实市场数据**。

- 行业CSV列：`code,sector,effective_date`。每个代码可有多个不同时点的记录；不可用2026年今日行业分类倒灌2024年的回测。
- 财报CSV列：`code,announcement_date,revenue_yoy,net_profit_ttm,ocf_ttm`。同比用小数：15%=`0.15`，净利润和经营现金流TTM以人民币元计。**不能用某一季度净利当TTM**。
- 若`dataset_rows.raw_json`字段未能严格匹配TTM语义，报告显示`RAW_JSON_UNMAPPED`，请核对报告中的`coverage.fieldSamples`后生成字段映射JSON。字段映射需要用户确认语义，软件不应自动编造。
- 历史停牌、复权除权、退市股、涨跌停可成交性、实际数据供应商以及日K触价是否一定成交，都尚未得到你真实数据库的验证；日K无法实现盘中快速避开主力砸盘，需分钟级数据。
- 两年历史最多也只有约500个交易日，某个策略若只有个位数或十几笔交易，胜率统计极不稳定。收益验证必须包含隔离的样本外和真实前向模拟。
- 本项目未收到用户真实多GB数据库，**没有任何可信的真实历史回测收益或盈利保证**。不应将此版本直接当做实盘自动交易系统。

## 本地验收命令

`PYTHONPATH=research python -m pytest research/tests -q`

纯Java测试通过，Android项目Java在最小API签名桩中完成源码类型检查；**没有**Android SDK的本环境无法完成真实APK打包和真机大库性能验收。GitHub Actions是否成功以实际Run日志为准。
