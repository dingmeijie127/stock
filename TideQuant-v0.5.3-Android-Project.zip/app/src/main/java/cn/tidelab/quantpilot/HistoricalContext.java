package cn.tidelab.quantpilot;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Point-in-time research metadata. Unknown is NEVER silently treated as positive. */
final class HistoricalContext implements QuantCore.Context {
    final HashMap<String,TreeMap<String,String>> sectorTimeline = new HashMap<>();
    final HashMap<String,TreeMap<String,QuantCore.Finance>> financeTimeline = new HashMap<>();
    long sectorRows=0, financeRows=0, rejectedFinance=0, skippedUndated=0;
    String financeMethod="UNAVAILABLE", sectorMethod="UNAVAILABLE";
    final LinkedHashMap<String,Integer> jsonDatasets=new LinkedHashMap<>();
    final LinkedHashMap<String,Integer> rejectedByReason=new LinkedHashMap<>();
    String keymapDataset="",keyRevenue="",keyProfit="",keyCash="",growthUnit="fraction";

    static String date(String d){
        if(d==null)return "";
        d=d.trim(); if(d.matches("\\d{8}"))return d.substring(0,4)+"-"+d.substring(4,6)+"-"+d.substring(6);
        return d.length()>=10&&d.charAt(4)=='-'&&d.charAt(7)=='-'?d.substring(0,10):"";
    }
    static String code(String c){
        if(c==null)return "";c=c.trim().toUpperCase(Locale.ROOT);
        if(c.startsWith("SH")||c.startsWith("SZ")||c.startsWith("BJ"))c=c.substring(2);
        if(c.matches("[0-9]{6}\\.(SH|SZ|BJ)"))c=c.substring(0,6);
        return c;
    }
    static Double number(Object raw){
        if(raw==null||raw==JSONObject.NULL)return null;
        try {String s=raw.toString().replace(",","").trim(); if(s.isEmpty()||s.equals("--"))return null;
            boolean percent=s.endsWith("%");if(percent)s=s.substring(0,s.length()-1);
            double n=Double.parseDouble(s);if(!Double.isFinite(n))return null;
            return percent?n/100:n;
        } catch(Exception e){return null;}
    }
    static String[] splitCSV(String line){
        ArrayList<String> v=new ArrayList<>();StringBuilder b=new StringBuilder();boolean quoted=false;
        for(int i=0;i<line.length();i++){
            char c=line.charAt(i);if(c=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){b.append('"');i++;}else quoted=!quoted;}
            else if(c==','&&!quoted){v.add(b.toString().trim());b.setLength(0);}else b.append(c);
        }
        v.add(b.toString().trim());return v.toArray(new String[0]);
    }
    static int field(String[] head,String... names){for(String name:names)for(int i=0;i<head.length;i++)if(head[i].trim().equalsIgnoreCase(name))return i;return -1;}
    static String at(String[] row,int idx){return idx>=0&&idx<row.length?row[idx]:"";}
    static void validateDate(String d){if(!d.matches("\\d{4}-\\d{2}-\\d{2}"))throw new IllegalArgumentException("必须提供历史生效日期，格式YYYY-MM-DD");}

    void loadSectorCSV(File file) throws Exception{
        try(BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8),65536)){
            String header=in.readLine();if(header==null)throw new IllegalArgumentException("板块CSV为空");
            String[] h=splitCSV(header.replace("\uFEFF",""));int c=field(h,"code"),s=field(h,"sector"),d=field(h,"effective_date","asof_date","date");
            if(c<0||s<0||d<0)throw new IllegalArgumentException("板块CSV必须包含 code,sector,effective_date。只给今天的板块归属不能用于两年历史回测");
            String line;long count=0;while((line=in.readLine())!=null){if(line.trim().isEmpty())continue;
                String[] row=splitCSV(line);String stock=code(at(row,c)),sec=at(row,s),when=date(at(row,d));
                if(!stock.matches("\\d{6}")||sec.isEmpty()||when.isEmpty()){skippedUndated++;continue;}
                sectorTimeline.computeIfAbsent(stock,k->new TreeMap<>()).put(when,sec);count++;
                if(count>2_000_000)throw new IllegalArgumentException("板块历史CSV行数过多，请先清洗去重");
            }
            if(count==0)throw new IllegalArgumentException("没有有效的历史行业归属记录");
            sectorRows=count;sectorMethod="DATED_CSV";
        }
    }
    void loadFinanceCSV(File file) throws Exception{
        try(BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8),65536)){
            String header=in.readLine();if(header==null)throw new IllegalArgumentException("财报CSV为空");
            String[] h=splitCSV(header.replace("\uFEFF",""));int c=field(h,"code"),d=field(h,"announcement_date","announcement_day"),r=field(h,"revenue_yoy"),p=field(h,"net_profit_ttm"),o=field(h,"ocf_ttm");
            if(c<0||d<0||r<0||p<0||o<0)throw new IllegalArgumentException("财报CSV必须包含 code,announcement_date,revenue_yoy,net_profit_ttm,ocf_ttm；不能拿单季净利冒充TTM");
            String line;long count=0;while((line=in.readLine())!=null){if(line.trim().isEmpty())continue;
                String[] row=splitCSV(line);String stock=code(at(row,c)),when=date(at(row,d));
                Double revenue=number(at(row,r)),profit=number(at(row,p)),cash=number(at(row,o));
                if(!stock.matches("\\d{6}")||when.isEmpty()||revenue==null||profit==null||cash==null){rejectedFinance++;continue;}
                // Ratios in CSV are decimal fractions, not percentages.
                addFinance(stock,when,revenue,profit,cash);count++;
                if(count>2_000_000)throw new IllegalArgumentException("财报CSV行数过多，请检查是否重复导出");
            }
            if(count==0)throw new IllegalArgumentException("未发现合格财报：必须有已披露公告日及完整TTM字段");
            financeMethod="STRICT_CSV";
        }
    }
    private void addFinance(String code,String date,double revenue,double profit,double cash){
        if(revenue < -10 || revenue > 100 || !Double.isFinite(profit)||!Double.isFinite(cash)){rejectedFinance++;return;}
        financeTimeline.computeIfAbsent(code,k->new TreeMap<>()).put(date,new QuantCore.Finance(revenue,profit,cash));financeRows++;
    }
    /** User supplied explicit JSON key mapping. Never infer TTM semantics from a vague key. */
    void loadKeyMapping(File file) throws Exception{
        StringBuilder text=new StringBuilder();
        try(BufferedReader in=new BufferedReader(new InputStreamReader(new FileInputStream(file),StandardCharsets.UTF_8))){
            String line;while((line=in.readLine())!=null){text.append(line);if(text.length()>10000)throw new IllegalArgumentException("JSON键映射超过10KB");}
        }
        JSONObject j=new JSONObject(text.toString());
        keymapDataset=j.optString("dataset","").trim();
        keyRevenue=j.optString("revenue_yoy_key","").trim();
        keyProfit=j.optString("net_profit_ttm_key","").trim();
        keyCash=j.optString("ocf_ttm_key","").trim();
        growthUnit=j.optString("revenue_yoy_unit","fraction").trim();
        if(keyRevenue.isEmpty()||keyProfit.isEmpty()||keyCash.isEmpty()||!(growthUnit.equals("fraction")||growthUnit.equals("percent")))
            throw new IllegalArgumentException("JSON映射必须明确三个TTM及同比字段，单位只能fraction或percent");
        if(keyRevenue.contains(".")||keyProfit.contains(".")||keyCash.contains("."))
            throw new IllegalArgumentException("当前仅支持raw_json顶层键；嵌套结构请先规范化成财报CSV");
    }
    /**
     * Audit vendor raw_json. Only keys EXPLICITLY stating TTM are accepted. For non-standard
     * vendor schemas, user must supply standard finance CSV from a verified schema mapping.
     * The announcement_day in dataset_rows must exist; report periods are never substituted.
     */
    void inspectAndImportRawJson(SQLiteDatabase db) {
        try(Cursor columns=db.rawQuery("PRAGMA table_info(dataset_rows)",null)){
            Set<String> have=new HashSet<>();while(columns.moveToNext())have.add(columns.getString(1));
            if(!have.containsAll(Arrays.asList("code","announcement_day","raw_json","dataset"))){financeMethod="JSON_SCHEMA_INCOMPLETE";return;}
        } catch(Exception e){financeMethod="JSON_SCHEMA_UNREADABLE";return;}
        long seen=0;
        try(Cursor cur=db.rawQuery("SELECT code,announcement_day,dataset,raw_json FROM dataset_rows WHERE announcement_day IS NOT NULL AND raw_json IS NOT NULL ORDER BY announcement_day",null)){
            while(cur.moveToNext()){
                seen++;String stock=code(cur.getString(0)),d=date(cur.getString(1)),dataset=cur.getString(2);
                jsonDatasets.put(dataset,jsonDatasets.getOrDefault(dataset,0)+1);
                if(!keymapDataset.isEmpty()&&!keymapDataset.equals(dataset))continue;
                if(d.isEmpty()||!stock.matches("\\d{6}")){rejectedFinance++;continue;}
                try {
                    JSONObject obj=new JSONObject(cur.getString(3));
                    Double r=keyRevenue.isEmpty()?firstNumber(obj,"revenue_yoy","revenue_yoy_ratio","rev_yoy"):number(obj.opt(keyRevenue));
                    Double p=keyProfit.isEmpty()?firstNumber(obj,"net_profit_ttm","profit_ttm","netprofit_ttm"):number(obj.opt(keyProfit));
                    Double o=keyCash.isEmpty()?firstNumber(obj,"ocf_ttm","operating_cashflow_ttm","operating_cash_flow_ttm"):number(obj.opt(keyCash));
                    if(r!=null && !keyRevenue.isEmpty() && growthUnit.equals("percent"))r/=100.0;
                    if(r==null||p==null||o==null){rejectedFinance++;continue;}
                    addFinance(stock,d,r,p,o);
                } catch(Exception e){rejectedFinance++;}
            }
            financeMethod=financeRows>0?(keyRevenue.isEmpty()?"RAW_JSON_EXACT_TTM_KEYS":"USER_MAPPED_RAW_JSON_TTM_KEYS"):"RAW_JSON_UNMAPPED";
        }catch(Exception e){financeMethod="RAW_JSON_READ_ERROR:"+e.getClass().getSimpleName();}
    }
    static Double firstNumber(JSONObject obj,String... keys){for(String k:keys)if(obj.has(k))return number(obj.opt(k));return null;}
    @Override public String sector(String stock,String day){TreeMap<String,String> m=sectorTimeline.get(code(stock));if(m==null)return null;Map.Entry<String,String> e=m.floorEntry(day);return e==null?null:e.getValue();}
    @Override public QuantCore.Finance finance(String stock,String day){TreeMap<String,QuantCore.Finance> m=financeTimeline.get(code(stock));if(m==null)return null;Map.Entry<String,QuantCore.Finance> e=m.floorEntry(day);return e==null?null:e.getValue();}
    @Override public boolean hasSector(){return sectorRows>0;}
    @Override public boolean hasFinance(){return financeRows>0;}
    JSONObject coverage() throws Exception {
        JSONObject obj=new JSONObject();obj.put("sectorRows",sectorRows);obj.put("sectorSymbols",sectorTimeline.size());obj.put("sectorMethod",sectorMethod);
        obj.put("financeRows",financeRows);obj.put("financeSymbols",financeTimeline.size());obj.put("financeMethod",financeMethod);
        obj.put("financeRejected",rejectedFinance);obj.put("sectorRejected",skippedUndated);
        JSONObject ds=new JSONObject();for(Map.Entry<String,Integer> e:jsonDatasets.entrySet())ds.put(e.getKey(),e.getValue());obj.put("jsonDatasets",ds);
        obj.put("sourceValidation","财报TTM单位、同比比例、复权及历史板块归属仍需根据真实数据来源审计");
        return obj;
    }
}
