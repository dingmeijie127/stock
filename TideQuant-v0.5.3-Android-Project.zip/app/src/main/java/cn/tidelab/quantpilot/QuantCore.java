package cn.tidelab.quantpilot;

import java.util.*;

/** Dependency-free streaming research baseline. Receives bars in ascending (day,code) order.
 * No sector/fundamental inference. Signals from close t; new buys at open t+1.
 * NOT a claim of real execution: daily bars cannot reveal queue position, intraday order or slippage.
 */
public final class QuantCore {
    public static final double CAPITAL=100000, RISK=200, MAX_TICKET=8000;
    public interface Context { String sector(String code,String day); Finance finance(String code,String day); boolean hasSector(); boolean hasFinance(); }
    public static final class Finance {public final double revenueYoy,profitTtm,cashflowTtm;
        public Finance(double r,double p,double c){revenueYoy=r;profitTtm=p;cashflowTtm=c;}}
    static final class SectorDaily {int n=0,up=0;double ret=0,volumeRatio=0;
        void add(Indicator x){n++;ret+=x.ret1;volumeRatio+=Double.isFinite(x.amountRatio)?Math.min(x.amountRatio,10):1;if(x.ret1>0)up++;}
        double breadth(){return n==0?0:up/(double)n;}double averageReturn(){return n==0?0:ret/n;}
    }
    static final class SectorSeries {final ArrayDeque<Double> relative=new ArrayDeque<>();
        double strength=0,adv=0,turnover=0;String phase="未建立";
        void append(double rel,double breadth,double flow){relative.addLast(rel);if(relative.size()>10)relative.removeFirst();
            strength=relative.stream().skip(Math.max(0,relative.size()-5)).mapToDouble(Double::doubleValue).sum();
            adv=breadth;turnover=flow;
            phase=relative.size()<5?"预热":strength<-.012&&breadth<.42?"退潮":strength>.08&&flow>1.8?"拥挤":strength>.02&&breadth>.55?"加速":strength>.01?"启动":"震荡";
        }
    }
    static final class Seed {final String mode;final Signal signal;
        Seed(String mode,Signal sig){this.mode=mode;this.signal=sig;}}

    public static final class Bar {
        public final String code, name, day;
        public final double o,h,l,c,amount;
        public Bar(String code,String name,String day,double o,double h,double l,double c,double amount){
            this.code=code;this.name=name;this.day=day;this.o=o;this.h=h;this.l=l;this.c=c;this.amount=amount;
        }
    }
    static final class State {
        final ArrayDeque<Double> closes=new ArrayDeque<>(),highs=new ArrayDeque<>(),amounts=new ArrayDeque<>(),trs=new ArrayDeque<>();
        double prevClose=Double.NaN,prevMa5=Double.NaN,lastClose=Double.NaN;
        int total=0;
        double mean(ArrayDeque<Double> q,int n){if(q.size()<n)return Double.NaN;double s=0;int i=0;for(Iterator<Double> it=q.descendingIterator();it.hasNext()&&i<n;i++)s+=it.next();return s/n;}
        static void push(ArrayDeque<Double> q,double v,int n){q.addLast(v);if(q.size()>n)q.removeFirst();}
        Indicator update(Bar x){
            double former=prevClose;
            double prior5=mean(closes,5);
            double prior20High=Double.NaN;
            if(highs.size()>=20){prior20High=highs.stream().mapToDouble(Double::doubleValue).max().orElse(Double.NaN);}
            double prev5close=closes.size()>=5?closes.stream().skip(closes.size()-5).findFirst().orElse(Double.NaN):Double.NaN;
            double tr=Math.max(x.h-x.l,Double.isNaN(former)?0:Math.max(Math.abs(x.h-former),Math.abs(x.l-former)));
            double amtBase=mean(amounts,20);
            push(closes,x.c,25);push(highs,x.h,20);push(amounts,x.amount,20);push(trs,tr,14);
            total++;
            double ma5=mean(closes,5),ma20=mean(closes,20),atr=mean(trs,14);
            double ret1=Double.isFinite(former)&&former>0?x.c/former-1:Double.NaN;
            double ret5=Double.isFinite(prev5close)&&prev5close>0?x.c/prev5close-1:Double.NaN;
            double ratio=Double.isFinite(amtBase)&&amtBase>0?x.amount/amtBase:Double.NaN;
            double loc=x.h==x.l?0.5:(x.c-x.l)/(x.h-x.l);
            prevClose=x.c;prevMa5=ma5;lastClose=x.c;
            return new Indicator(x,ma5,ma20,atr,ret1,ret5,ratio,prior20High,former,prior5,loc,amtBase);
        }
    }
    static final class Indicator {
        final Bar bar;final double ma5,ma20,atr,ret1,ret5,amountRatio,prior20High,prevClose,prevMa5,closeLoc,amountMa20;
        Indicator(Bar b,double a,double bb,double c,double d,double e,double f,double g,double h,double i,double j,double k){bar=b;ma5=a;ma20=bb;atr=c;ret1=d;ret5=e;amountRatio=f;prior20High=g;prevClose=h;prevMa5=i;closeLoc=j;amountMa20=k;}
    }
    public static final class Trade {
        public String code,buyDay,sellDay,reason;
        public int qty;public double entry,exit,pnl;
    }
    static final class Signal {String code,day;double close,stopPct,score;Signal(String c,String d,double p,double s,double rank){code=c;day=d;close=p;stopPct=s;score=rank;}}
    static final class Position {String code,day;int qty;double entry,paid,stop,target;int held=0;}
    public static final class Account {
        final String mode;int filled=0;double cash=CAPITAL,peak=CAPITAL,maxDD=0,lastEquity=CAPITAL;Position position=null;Signal pending=null;
        String pendingSell=null;List<Trade> trades=new ArrayList<>();List<Double> equity=new ArrayList<>();List<String> equityDays=new ArrayList<>();
        Account(String m){mode=m;}
        static double fee(double value,boolean sell){return Math.max(5,value*.00025)+value*.00001+(sell?value*.0005:0);}
        void sell(double price,String day,String reason){
            if(position==null)return;double revenue=price*position.qty;double profit=revenue-fee(revenue,true)-position.paid;
            Trade t=new Trade();t.code=position.code;t.buyDay=position.day;t.sellDay=day;t.qty=position.qty;t.entry=position.entry;t.exit=price;t.pnl=profit;t.reason=reason;
            trades.add(t);cash+=revenue-fee(revenue,true);position=null;pendingSell=null;
        }
        void handleOpen(Indicator x){
            Bar b=x.bar;
            if(position!=null&&position.code.equals(b.code)){
                if(!position.day.equals(b.day)){
                    boolean atSealedDown=Double.isFinite(x.prevClose) && b.o<=x.prevClose*.903; // Can only observe opening quote at this decision time
                    if(!atSealedDown){
                        if(pendingSell!=null) sell(b.o*.999,b.day,pendingSell);
                        else if(b.o<=position.stop) sell(b.o*.999,b.day,"GAP_STOP");
                        else if(b.l<=position.stop) sell(position.stop*.999,b.day,"STOP_FIRST");
                        else if(b.o>=position.target) sell(b.o*.999,b.day,"GAP_TARGET");
                        else if(b.h>=position.target) sell(position.target*.999,b.day,"TARGET");
                    }
                }
            }
            if(position==null&&pending!=null&&pending.code.equals(b.code)&&!pending.day.equals(b.day)){
                double gap=b.o/pending.close-1;
                if(gap>=-.04&&gap<=.02 && !(Double.isFinite(x.prevClose)&&b.o>=x.prevClose*1.098)){
                    double price=b.o*1.001;
                    int lots=(int)Math.floor(Math.min(RISK/(price*100*pending.stopPct), Math.min(MAX_TICKET,cash-8)/(price*100)));
                    if(lots>=1){int qty=lots*100;double cost=qty*price+fee(qty*price,false);
                        if(cost<=cash){Position p=new Position();p.code=b.code;p.day=b.day;p.entry=price;p.qty=qty;p.paid=cost;p.stop=price*(1-pending.stopPct);p.target=price*(1+pending.stopPct*(mode.equals("BREAKOUT")?2.3:mode.equals("PULLBACK")?1.8:2.0));position=p;cash-=cost;filled++;}}
                }
                pending=null;
            }
        }
        void endDay(String day,String regime,Signal signal,Map<String,State> all,Context context,Map<String,SectorSeries> sectorSeries){
            // A prior-day order expires after the next market session even if that symbol was suspended.
            if(pending!=null&&!pending.day.equals(day))pending=null;
            if(position!=null){
                position.held++;
                State s=all.get(position.code);
                if(s!=null&&s.total>0){double c=s.lastClose;
                    if(regime.equals("RISK_OFF")||c<s.mean(s.closes,20) || position.held>=8)pendingSell="REGIME_OR_TIME";
                    if(mode.equals("ROTATION")&&context!=null){
                        String sector=context.sector(position.code,day);
                        SectorSeries pulse=sector==null?null:sectorSeries.get(sector);
                        if(pulse==null||pulse.phase.equals("退潮")||pulse.strength<-.01)pendingSell="THEME_COOLING";
                        Finance fin=context.finance(position.code,day);
                        if(fin!=null&&(fin.profitTtm<=0||fin.cashflowTtm<=0))pendingSell="FUNDAMENTAL_RISK";
                    }
                }
            }else if(!mode.equals("CASH") && pending==null && signal!=null && !regime.equals("RISK_OFF") && !regime.equals("INSUFFICIENT"))pending=signal;
            double eq=cash;
            if(position!=null){State s=all.get(position.code);eq+=position.qty*(s==null?position.entry:s.lastClose);}
            lastEquity=eq;peak=Math.max(peak,eq);maxDD=Math.min(maxDD,eq/peak-1);equity.add(eq);equityDays.add(day);
        }
        public double total(){return lastEquity/CAPITAL-1;}
        public double trainReturn(){if(equity.isEmpty())return 0;int cut=Math.max(0,((int)(equity.size()*.6))-1);return equity.get(cut)/CAPITAL-1;}
        public double testReturn(){if(equity.isEmpty())return 0;int cut=Math.max(0,((int)(equity.size()*.6))-1);return lastEquity/equity.get(cut)-1;}
        public Double winRate(){return trades.isEmpty()?null:trades.stream().filter(t->t.pnl>0).count()/(double)trades.size();}
        public Double payoff(){double w=0,l=0;int wn=0,ln=0;for(Trade t:trades){if(t.pnl>0){w+=t.pnl;wn++;}else if(t.pnl<0){l-=t.pnl;ln++;}}return wn>0&&ln>0?(w/wn)/(l/ln):null;}
    }
    private final HashMap<String,State> symbols=new HashMap<>();
    private final LinkedHashMap<String,Account> accounts=new LinkedHashMap<>();
    private final HashMap<String,Signal> candidates=new HashMap<>();
    private final ArrayList<Seed> candidateSeeds=new ArrayList<>();
    private final HashMap<String,SectorDaily> todaySector=new HashMap<>();
    private final HashMap<String,SectorSeries> sectorSeries=new HashMap<>();
    private final Context context;
    public long eligibleFinanceSignals=0,missingFinanceSignals=0,missingSectorSignals=0,rotationSignals=0;
    public final Map<String,Integer> marketStates=new TreeMap<>();
    public Map<String,String> sectorPhases(){Map<String,String> m=new LinkedHashMap<>();sectorSeries.entrySet().stream().sorted((a,b)->Double.compare(b.getValue().strength,a.getValue().strength)).limit(12).forEach(e->m.put(e.getKey(),e.getValue().phase));return m;}

    private String currentDay=null;private int dayUp=0,dayAbove=0,dayValid=0,days=0;
    private final ArrayDeque<Double> advances=new ArrayDeque<>();
    public long scanned=0,valid=0,invalid=0,qualifiedPriceVolumeSignals=0;public String firstDay="",lastDay="";public int eligibleDays=0,riskOffDays=0;
    public QuantCore(){this(null);}
    public QuantCore(Context ctx){context=ctx;for(String mode:new String[]{"ROTATION","BREAKOUT","PULLBACK","CASH"})accounts.put(mode,new Account(mode));}
    public void accept(Bar b){
        scanned++;
        if(!valid(b)){invalid++;return;}
        if(currentDay!=null&&!currentDay.equals(b.day))finishDay();
        if(currentDay==null){currentDay=b.day;if(firstDay.isEmpty())firstDay=b.day;}
        lastDay=b.day;valid++;
        State st=symbols.computeIfAbsent(b.code,k->new State());
        // IMPORTANT: trade at today's open using yesterday's indicators before updating state with today's close.
        double last=st.prevClose;
        Indicator indicator=new Indicator(b,Double.NaN,Double.NaN,Double.NaN,Double.NaN,Double.NaN,Double.NaN,Double.NaN,last,Double.NaN,Double.NaN,Double.NaN);
        for(Account account:accounts.values())account.handleOpen(indicator);
        Indicator x=st.update(b);
        if(Double.isFinite(x.ma20)&&Double.isFinite(x.ret1)){
            dayValid++;if(b.c>x.ma20)dayAbove++;if(x.ret1>0)dayUp++;
            if(context!=null && context.hasSector()){
                String sector=context.sector(b.code,b.day);
                if(sector!=null&&!sector.isEmpty())todaySector.computeIfAbsent(sector,k->new SectorDaily()).add(x);
            }
            if(isSignal(x)){
                boolean breakout=b.c>x.prior20High && b.c<=x.prior20High*1.055;
                boolean reclaim=Double.isFinite(x.prevMa5) && x.prevClose<=x.prevMa5 && b.c>x.ma5;
                if(breakout||reclaim){qualifiedPriceVolumeSignals++;double atrpct=x.atr/b.c,stop=Math.max(.028,atrpct*1.25),risk100=b.c*100*stop;
                    if(risk100<=RISK){double rank=.50*Math.min(.2,x.ret5)/.2+.35*Math.min(3,x.amountRatio)/3+.15*x.closeLoc;
                        for(String m:accounts.keySet())if((m.equals("BREAKOUT")&&breakout)||(m.equals("PULLBACK")&&reclaim)||(m.equals("ROTATION")&&(breakout||reclaim))){
                            candidateSeeds.add(new Seed(m,new Signal(b.code,b.day,b.c,stop,rank)));
                        }
                    }
                }
            }
        }
    }
    private boolean valid(Bar b){return b!=null&&b.code!=null&&b.day!=null&&b.day.length()>=10 && b.o>0&&b.c>0&&b.l>0 && b.h>=Math.max(b.o,b.c)&&b.l<=Math.min(b.o,b.c)&&Double.isFinite(b.amount)&&b.amount>0;}
    private boolean isSignal(Indicator x){
        Bar b=x.bar;if(!b.code.matches("(600|601|603|605|000|001|002|003)\\d{3}")||b.name.toUpperCase(Locale.ROOT).contains("ST"))return false;
        double p=b.c;return p>=3&&p<=80&&x.amountMa20>=8e7&&x.amountRatio>=1.1&&x.amountRatio<=3.8 && Double.isFinite(x.atr)&&x.atr/p>=.015&&x.atr/p<=.085 &&x.ret5>.01&&x.ret5<.15 &&x.ret1<.094 && b.c>x.ma5&&x.ma5>x.ma20&&x.closeLoc>.6&&Double.isFinite(x.prior20High);
    }
    private void finishDay(){
        double adv=dayValid==0?0:dayUp/(double)dayValid;double breadth=dayValid==0?0:dayAbove/(double)dayValid;
        advances.addLast(adv);if(advances.size()>3)advances.removeFirst();
        double meanAdv=advances.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        String regime=dayValid<40||advances.size()<3?"INSUFFICIENT":(breadth<.35||(meanAdv<.32&&breadth<.48))?"RISK_OFF":(breadth>.52&&meanAdv>.50)?"RISK_ON":"NEUTRAL";
        if(!regime.equals("INSUFFICIENT"))eligibleDays++;if(regime.equals("RISK_OFF"))riskOffDays++;
        marketStates.put(regime,marketStates.getOrDefault(regime,0)+1);
        double marketDailyReturn=0;int marketCount=0;
        for(SectorDaily v:todaySector.values()){marketDailyReturn+=v.ret;marketCount+=v.n;}
        marketDailyReturn=marketCount==0?0:marketDailyReturn/marketCount;
        for(Map.Entry<String,SectorDaily> e:todaySector.entrySet()){
            SectorDaily v=e.getValue();
            if(v.n>=3)sectorSeries.computeIfAbsent(e.getKey(),k->new SectorSeries())
                .append(v.averageReturn()-marketDailyReturn,v.breadth(),v.volumeRatio/v.n);
        }
        for(Seed item:candidateSeeds){
            Signal signal=item.signal;
            double rank=signal.score;
            if(item.mode.equals("ROTATION")){
                if(context==null||!context.hasSector()){missingSectorSignals++;continue;}
                String sector=context.sector(signal.code,currentDay);
                SectorSeries history=sector==null?null:sectorSeries.get(sector);
                if(history==null||history.relative.size()<5||history.strength<.01||history.adv<.5||history.phase.equals("退潮")||history.phase.equals("拥挤")){missingSectorSignals++;continue;}
                if(!context.hasFinance()){missingFinanceSignals++;continue;}
                Finance fin=context.finance(signal.code,currentDay);
                if(fin==null){missingFinanceSignals++;continue;}
                if(fin.revenueYoy<0||fin.profitTtm<=0||fin.cashflowTtm<=0)continue;
                eligibleFinanceSignals++;
                rank+=Math.min(.20,history.strength)*2;
                rotationSignals++;
            }
            Signal selected=candidates.get(item.mode);
            if(selected==null||rank>selected.score)candidates.put(item.mode,new Signal(signal.code,signal.day,signal.close,signal.stopPct,rank));
        }
        for(Account a:accounts.values())a.endDay(currentDay,regime,candidates.get(a.mode),symbols,context,sectorSeries);
        days++;dayUp=0;dayAbove=0;dayValid=0;candidates.clear();candidateSeeds.clear();todaySector.clear();currentDay=null;
    }
    public void finish(){if(currentDay!=null)finishDay();}
    public Map<String,Account> accounts(){return Collections.unmodifiableMap(accounts);}
    public int days(){return days;}
    public int stocks(){return symbols.size();}
}
