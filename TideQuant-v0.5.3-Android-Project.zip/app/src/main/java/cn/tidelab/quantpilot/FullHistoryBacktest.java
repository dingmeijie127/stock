package cn.tidelab.quantpilot;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.Map;

/** Full-history, streaming on-device BASELINE, not a sector-rotation strategy.
 * Does not load the 1.5GB SQLite into the WebView or into a 180k row array.
 * It requires the original QuantDesk daily_bars + instruments tables.
 */
final class FullHistoryBacktest {
    interface Reporter {void report(String type,JSONObject json);}
    private static JSONObject status(String s){JSONObject x=new JSONObject();try{x.put("message",s);}catch(Exception ignored){}return x;}
    private static Double finite(Double x){return x!=null&&Double.isFinite(x)?x:null;}
    static void run(File file,File sectorFile,File financeFile,File keymapFile,Reporter reporter) throws Exception {
        reporter.report("fullProgress",status("开始扫描全部历史日K线，逐行计算，不使用18万行近期样本。大数据库可能需要较长时间。"));
        long start=System.currentTimeMillis();
        // Source SAF file was first copied into app-private storage. Indexing only this
        // private copy does NOT modify the user's original SQLite database.
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(file.getAbsolutePath(),null,SQLiteDatabase.OPEN_READWRITE)){
            reporter.report("fullProgress",status("优化历史查询：正在为私有数据库副本建立(day,code)索引；首次运行可能较慢、需要额外磁盘空间…"));
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_tide_bars_day_code ON daily_bars(day,code)");
            db.execSQL("PRAGMA query_only=ON");
            HistoricalContext context=new HistoricalContext();
            if(sectorFile!=null&&sectorFile.isFile()){
                reporter.report("fullProgress",status("读取历史行业归属（按生效日期，不用今日行业倒推过去）…"));
                context.loadSectorCSV(sectorFile);
            }
            if(financeFile!=null&&financeFile.isFile()){
                reporter.report("fullProgress",status("读取已标准化财报（公告日可用）…"));
                context.loadFinanceCSV(financeFile);
            } else if(tableExists(db,"dataset_rows")){
                if(keymapFile!=null&&keymapFile.isFile())context.loadKeyMapping(keymapFile);
                reporter.report("fullProgress",status("审计原版财报JSON；仅接受明确标记TTM的字段…"));
                context.inspectAndImportRawJson(db);
            }
            QuantCore engine=new QuantCore(context);
            // Selection is by exchange, not by today's top-volume names: avoids the old winner-only universe.
            // If daily_bars(day,code) is indexed, this query streams without loading the whole DB into memory.
            String sql="SELECT b.code,COALESCE(i.name,b.code),b.day,b.o,b.h,b.l,b.c,b.amount " +
                    "FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                    "WHERE i.exchange IN ('SH','SZ','BJ') " +
                    "ORDER BY b.day,b.code";
            try(Cursor cur=db.rawQuery(sql,null)){
                while(cur.moveToNext()){
                    QuantCore.Bar bar=new QuantCore.Bar(cur.getString(0),cur.getString(1),normalize(cur.getString(2)),
                         cur.getDouble(3),cur.getDouble(4),cur.getDouble(5),cur.getDouble(6),cur.isNull(7)?Double.NaN:cur.getDouble(7));
                    engine.accept(bar);
                    if(engine.scanned%50000==0){
                        reporter.report("fullProgress",status("已扫描"+engine.scanned+"条；有效"+engine.valid+"条；历史范围"+engine.firstDay+"～"+engine.lastDay+"；请保持App运行"));
                    }
                }
            }
            engine.finish();
            JSONObject result=new JSONObject();
            result.put("kind","BASELINE_PRICE_VOLUME");result.put("source","本机SQLite全部可读取历史；未经行情供应商真实性审计");
            result.put("warning","只有sectorReady和financeReady都为真才启用带历史行业与财报过滤的主线账户。其他账户是价量基线。真实数据来源、停复牌、送转复权、历史上市退市池和日K无法验证的实际成交仍可能影响收益；严禁将回测当成收益保证。" );
            result.put("scanned",engine.scanned);result.put("valid",engine.valid);result.put("invalid",engine.invalid);
            result.put("symbols",engine.stocks());result.put("days",engine.days());
            result.put("first",engine.firstDay);result.put("last",engine.lastDay);
            result.put("eligibleDays",engine.eligibleDays);result.put("riskOffDays",engine.riskOffDays);result.put("qualifiedPriceVolumeSignals",engine.qualifiedPriceVolumeSignals);
            result.put("elapsedMs",System.currentTimeMillis()-start);
            result.put("financeReady",context.hasFinance());result.put("sectorReady",context.hasSector());
            result.put("mode",context.hasFinance()&&context.hasSector()?"ROTATION_WITH_PIT_FILTER":"BASELINE_ONLY");
            result.put("pitCoverage",context.coverage());
            result.put("eligibleFinanceSignals",engine.eligibleFinanceSignals);
            result.put("missingFinanceSignals",engine.missingFinanceSignals);
            result.put("missingSectorSignals",engine.missingSectorSignals);
            result.put("qualifiedRotationSignals",engine.rotationSignals);
            JSONObject phases=new JSONObject();for(Map.Entry<String,String> pair:engine.sectorPhases().entrySet())phases.put(pair.getKey(),pair.getValue());result.put("sectorPhases",phases);
            result.put("marketStates",new JSONObject(engine.marketStates));
            JSONObject coverage=new JSONObject();
            if(tableExists(db,"dataset_rows")){
                try(Cursor c=db.rawQuery("SELECT COUNT(*),COUNT(DISTINCT dataset),COUNT(DISTINCT code) FROM dataset_rows",null)){
                    if(c.moveToFirst()){coverage.put("financeJsonRows",c.getLong(0));coverage.put("financeDatasets",c.getInt(1));coverage.put("financeSymbols",c.getInt(2));}
                }catch(Exception e){coverage.put("financeInfo","财报仅检测到表；未识别字段："+e.getMessage());}
            }
            // Only inspect raw JSON keys; do NOT guess revenue or profit meanings from unknown vendor fields.
            if(tableExists(db,"dataset_rows")){
                JSONArray keys=new JSONArray();
                try(Cursor c=db.rawQuery("SELECT dataset,raw_json FROM dataset_rows WHERE raw_json IS NOT NULL LIMIT 5",null)){
                    while(c.moveToNext()){
                        JSONObject sample=new JSONObject();sample.put("dataset",c.getString(0));
                        try{JSONObject obj=new JSONObject(c.getString(1));JSONArray k=new JSONArray();java.util.Iterator<String> it=obj.keys();int n=0;while(it.hasNext()&&n++<16)k.put(it.next());sample.put("fields",k);}catch(Exception ignored){sample.put("fields","非JSON对象或无法解码");}
                        keys.put(sample);
                    }
                }catch(Exception e){coverage.put("sampleInfo","未读取到供应商字段样本");}
                coverage.put("fieldSamples",keys);
            }
            result.put("coverage",coverage);
            JSONArray models=new JSONArray();
            for(Map.Entry<String,QuantCore.Account> entry:engine.accounts().entrySet()){
                QuantCore.Account a=entry.getValue();JSONObject m=new JSONObject();
                m.put("id",entry.getKey());m.put("capital",QuantCore.CAPITAL);m.put("equity",a.lastEquity);
                m.put("return",a.total());m.put("maxDrawdown",a.maxDD);m.put("winRate",finite(a.winRate()));m.put("payoff",finite(a.payoff()));
                m.put("trades",a.trades.size());m.put("fills",a.filled);
                m.put("tradeMode",entry.getKey().equals("ROTATION")?(context.hasFinance()&&context.hasSector()?"行业轮动+财报（有覆盖条件）":"缺行业或财报：无信号"):"价量对照基线");m.put("trainReturn",a.trainReturn());m.put("testReturn",a.testReturn());
                m.put("openPosition",a.position!=null);
                JSONArray recent=new JSONArray();
                int begin=Math.max(0,a.trades.size()-12);
                for(int j=begin;j<a.trades.size();j++){
                    QuantCore.Trade t=a.trades.get(j);JSONObject tr=new JSONObject();tr.put("code",t.code);tr.put("buyDay",t.buyDay);tr.put("sellDay",t.sellDay);
                    tr.put("qty",t.qty);tr.put("buy",t.entry);tr.put("sell",t.exit);tr.put("pnl",t.pnl);tr.put("reason",t.reason);recent.put(tr);
                }
                m.put("recentTrades",recent);
                JSONArray allTrades=new JSONArray();int winCount=0;
                for(QuantCore.Trade t:a.trades){
                    if(t.pnl>0)winCount++;
                    JSONObject tr=new JSONObject();tr.put("code",t.code);tr.put("buyDate",t.buyDay);tr.put("sellDate",t.sellDay);
                    tr.put("qty",t.qty);tr.put("buyPrice",t.entry);tr.put("sellPrice",t.exit);
                    tr.put("netPnl",t.pnl);tr.put("exitReason",t.reason);allTrades.put(tr);
                }
                m.put("allTrades",allTrades);
                if(a.trades.size()>0){
                    // 95% Wilson interval: far more meaningful than an unqualified percentage.
                    int n=a.trades.size();double z=1.96,pHat=winCount/(double)n,denom=1+z*z/n;
                    double center=(pHat+z*z/(2*n))/denom;
                    double half=z*Math.sqrt(pHat*(1-pHat)/n+z*z/(4.0*n*n))/denom;
                    JSONArray interval=new JSONArray();interval.put(Math.max(0,center-half));interval.put(Math.min(1,center+half));m.put("winRateWilson95",interval);
                }else m.put("winRateWilson95",JSONObject.NULL);
                JSONArray curve=new JSONArray();for(int k=0;k<a.equity.size();k++){
                    JSONObject point=new JSONObject();point.put("date",a.equityDays.get(k));point.put("equity",a.equity.get(k));curve.put(point);
                }
                m.put("equityCurve",curve);
                double wins=0,losses=0;for(QuantCore.Trade t:a.trades){if(t.pnl>=0)wins+=t.pnl;else losses-=t.pnl;}
                m.put("profitFactor",losses>0?wins/losses:JSONObject.NULL);
                m.put("realizedPnL",wins-losses);
                m.put("sampleAdequacy",a.trades.size()>=100?"100+交易（仍需样本外检验）":a.trades.size()>=30?"30-99交易（不稳定）":"<30笔，无法可靠估计胜率");
                models.put(m);
            }
            result.put("models",models);
            reporter.report("fullResult",result);
        }
    }
    static boolean tableExists(SQLiteDatabase db,String table){
        try(Cursor c=db.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",new String[]{table})){return c.moveToFirst();}
    }
    static String normalize(String day){if(day==null)return "";String x=day.trim();if(x.matches("\\d{8}"))return x.substring(0,4)+"-"+x.substring(4,6)+"-"+x.substring(6);return x.length()>=10?x.substring(0,10):x;}
}
