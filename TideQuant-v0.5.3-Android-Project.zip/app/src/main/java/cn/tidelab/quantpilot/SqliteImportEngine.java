package cn.tidelab.quantpilot;

import android.app.Activity;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Read-only SQLite data adapter. No network, broker actions, or SQL from WebView is executed verbatim. */
final class SqliteImportEngine {
    private final Activity activity;
    private final WebView web;
    private final ExecutorService jobs=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final File dbFile;
    private volatile boolean busy=false;
    private Map<String,Set<String>> schema=new HashMap<>();
    private String originalName="";
    private volatile boolean walHeaderDetected=false;
    // No arbitrary database size limit: SQLite files can be multi-gigabyte.
    // Keep a free-space reserve so copying never fills the system partition.
    private static final long MIN_FREE_SPACE_BYTES = 256L * 1024L * 1024L;
    private static final long PROGRESS_STEP_BYTES = 64L * 1024L * 1024L;
    private static final long FREE_SPACE_CHECK_STEP_BYTES = 8L * 1024L * 1024L;
    private static final int MAX_ROWS=180000;

    SqliteImportEngine(Activity a,WebView w) {
        activity=a;web=w;dbFile=new File(a.getFilesDir(),"readonly_market_import.sqlite");
    }
    private void event(String type,JSONObject payload) {
        JSONObject message=new JSONObject();
        try{message.put("type",type);message.put("payload",payload);}catch(Exception ignored){}
        String script="window.tideDbReceive&&window.tideDbReceive("+message.toString()+")";
        main.post(()->web.evaluateJavascript(script,null));
    }
    private JSONObject error(String explanation) {
        JSONObject x=new JSONObject();try{x.put("message",explanation);}catch(Exception ignored){}return x;
    }
    private static String quoted(String s){return "\""+s.replace("\"","\"\"")+"\"";}
    private String validated(String table,String field) {
        Set<String> cols=schema.get(table);
        if(cols==null||field==null||!cols.contains(field))throw new IllegalArgumentException("字段不属于已检查的表: "+field);
        return quoted(field);
    }
    private String table(String raw) {
        if(!schema.containsKey(raw))throw new IllegalArgumentException("未检查的SQLite表: "+raw);
        return quoted(raw);
    }
    private static String str(JSONObject map,String key) {return map.optString(key,"").trim();}
    private String optional(JSONObject map,String tbl,String key,String fallback) {
        String v=str(map,key);return v.isEmpty()?fallback:validated(tbl,v);
    }
    /** Provider sizes are only estimates: some SAF providers do not report size at all. */
    private long reportedLength(Uri uri) {
        try(Cursor c=activity.getContentResolver().query(uri,
                new String[]{OpenableColumns.SIZE},null,null,null)) {
            if(c!=null && c.moveToFirst() && !c.isNull(0))return c.getLong(0);
        }catch(Exception ignored){}
        return -1L;
    }
    private void requireFreeSpace(File targetDir, long remainingBytes) {
        long free=targetDir.getUsableSpace();
        if(free<=MIN_FREE_SPACE_BYTES)
            throw new IllegalArgumentException("手机存储空间不足：须预留至少256MB，当前可用" + humanBytes(free));
        if(remainingBytes>=0 && free-remainingBytes<MIN_FREE_SPACE_BYTES)
            throw new IllegalArgumentException("手机空间不够复制数据库：预计还需" + humanBytes(remainingBytes)
                + "，可用" + humanBytes(free) + "（另预留256MB）。请清理手机空间或导出较小数据库。");
    }
    private static String humanBytes(long bytes) {
        if(bytes<0)return "未知";
        if(bytes>=1024L*1024L*1024L)
            return String.format(Locale.ROOT,"%.2fGB",bytes/(1024.0*1024.0*1024.0));
        return String.format(Locale.ROOT,"%.0fMB",bytes/(1024.0*1024.0));
    }
    void copyAndInspect(Uri uri,String displayName) {
        if(busy){event("error",error("已有数据库操作正在执行"));return;}
        busy=true;
        final String incomingName=displayName==null?"SQLite文件":displayName;
        event("progress",status("准备导入大型SQLite文件：采用1MB缓冲流式复制，原文件不会被修改…"));
        jobs.execute(()->{
            File temp=new File(dbFile.getAbsolutePath()+".tmp");
            try {
                if(temp.exists() && !temp.delete())
                    throw new IllegalArgumentException("无法清理上次未完成的数据库临时文件");
                final long expected=reportedLength(uri);
                requireFreeSpace(dbFile.getParentFile(),expected);
                long size=0L, lastProgress=0L, lastSpaceCheck=0L;
                byte[] buf=new byte[1024*1024];
                try(InputStream in=activity.getContentResolver().openInputStream(uri);
                    FileOutputStream out=new FileOutputStream(temp)) {
                    if(in==null)throw new IllegalArgumentException("未能读取所选文件");
                    int n;
                    while((n=in.read(buf))!=-1){
                        if(n==0)continue;
                        out.write(buf,0,n);
                        size+=n;
                        if(size-lastSpaceCheck>=FREE_SPACE_CHECK_STEP_BYTES){
                            // Source size may be unknown: recheck actual free space throughout copy.
                            requireFreeSpace(dbFile.getParentFile(),expected<0?-1:Math.max(0,expected-size));
                            lastSpaceCheck=size;
                        }
                        if(size-lastProgress>=PROGRESS_STEP_BYTES){
                            event("progress",status("已复制" + humanBytes(size) +
                                (expected>=0?" / "+humanBytes(expected):"") +
                                "；仍在流式读取，请勿退出App"));
                            lastProgress=size;
                        }
                    }
                    out.getFD().sync();
                }
                if(size==0)throw new IllegalArgumentException("文件为空");
                event("progress",status("已复制"+humanBytes(size)+"；正在核验SQLite文件头和数据库完整性…"));
                byte[] h=new byte[100];int headerBytes=0;
                try(FileInputStream in=new FileInputStream(temp)){
                    while(headerBytes<h.length){int n=in.read(h,headerBytes,h.length-headerBytes);if(n<0)break;headerBytes+=n;}
                }
                if(headerBytes<16||!Arrays.equals(Arrays.copyOf(h,16),"SQLite format 3\000".getBytes("UTF-8")))
                    throw new IllegalArgumentException("文件不是标准未加密SQLite3数据库");
                boolean newWalFlag=headerBytes>=20&&(h[18]==2||h[19]==2);
                // Validate BEFORE replacing the previously-imported database.
                verifyQuickCheck(temp);
                Map<String,Set<String>> inspected=inspectSchema(temp);
                Files.move(temp.toPath(),dbFile.toPath(),StandardCopyOption.REPLACE_EXISTING);
                schema=inspected;
                originalName=incomingName;
                walHeaderDetected=newWalFlag;
                JSONObject p=schemaPayload();p.put("sizeBytes",size);p.put("fileName",originalName);p.put("freshImport",true);event("schema",p);
            } catch(Exception e){
                event("error",error(e.getMessage()==null?"数据库导入失败":e.getMessage()));
            } finally {
                try{if(temp.exists())temp.delete();}catch(Exception ignored){}
                busy=false;
            }
        });
    }
    void runFullHistoryBacktest(){
        if(busy){event("error",error("还有数据库操作进行中，请稍后再运行完整回测"));return;}
        busy=true;
        jobs.execute(()->{
            try{
                if(!dbFile.exists())throw new IllegalArgumentException("尚未导入SQLite数据库");
                if(schema.isEmpty())inspectInternal();
                if(!isLegacyQuantDesk())throw new IllegalArgumentException("整库回测目前只支持旧QuantDesk的daily_bars/instruments，请检查数据库结构");
                FullHistoryBacktest.run(dbFile,new File(activity.getFilesDir(),"tide_historical_sector.csv"),new File(activity.getFilesDir(),"tide_finance_standard.csv"),new File(activity.getFilesDir(),"tide_finance_keymap.json"),(type,data)->event(type,data));
            }catch(Exception ex){event("fullError",error("完整历史分析失败："+(ex.getMessage()==null?ex.toString():ex.getMessage())));}
            finally{busy=false;}
        });
    }
    void importFinanceKeyMap(Uri uri){
        if(busy){event("error",error("数据库操作正在进行"));return;}
        busy=true;jobs.execute(()->{
            File dst=new File(activity.getFilesDir(),"tide_finance_keymap.json"),tmp=new File(dst.getAbsolutePath()+".tmp");
            try(InputStream input=activity.getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(tmp)){
                if(input==null)throw new IllegalArgumentException("映射文件无法读取");byte[] buf=new byte[4096];int n,total=0;
                while((n=input.read(buf))!=-1){total+=n;if(total>10000)throw new IllegalArgumentException("映射文件不应超过10KB");out.write(buf,0,n);}out.getFD().sync();
                HistoricalContext tester=new HistoricalContext();tester.loadKeyMapping(tmp);
                Files.move(tmp.toPath(),dst.toPath(),StandardCopyOption.REPLACE_EXISTING);
                JSONObject done=new JSONObject();done.put("message","财报JSON字段映射已保存，请重新运行整库回测");done.put("kind","keymap");done.put("rows",1);event("researchCsvLoaded",done);
            }catch(Exception e){event("error",error(e.getMessage()));}
            finally{if(tmp.exists())tmp.delete();busy=false;}
        });
    }
    void importResearchCsv(Uri uri,boolean finance){
        if(busy){event("error",error("数据库或文件操作进行中"));return;}
        busy=true;
        jobs.execute(()->{
            File destination=new File(activity.getFilesDir(),finance?"tide_finance_standard.csv":"tide_historical_sector.csv");
            File tmp=new File(destination.getAbsolutePath()+".tmp");
            try{
                long bytes=0;byte[] buffer=new byte[1024*256];
                try(InputStream input=activity.getContentResolver().openInputStream(uri);FileOutputStream output=new FileOutputStream(tmp)){
                    if(input==null)throw new IllegalArgumentException("无法打开CSV");int count;
                    while((count=input.read(buffer))!=-1){output.write(buffer,0,count);bytes+=count;
                        if(bytes>150_000_000)throw new IllegalArgumentException("行业或财报映射文件超过150MB，请拆分（主SQLite文件不受此限制）");}
                    output.getFD().sync();
                }
                HistoricalContext checker=new HistoricalContext();
                if(finance)checker.loadFinanceCSV(tmp);else checker.loadSectorCSV(tmp);
                Files.move(tmp.toPath(),destination.toPath(),StandardCopyOption.REPLACE_EXISTING);
                JSONObject success=new JSONObject();success.put("message",(finance?"财报":"历史行业")+"CSV校验并保存成功；运行整库回测将启用已验证字段");
                success.put("kind",finance?"finance":"sector");success.put("rows",finance?checker.financeRows:checker.sectorRows);
                event("researchCsvLoaded",success);
            }catch(Exception e){event("error",error("CSV导入失败："+e.getMessage()));}
            finally{if(tmp.exists())tmp.delete();busy=false;}
        });
    }
    void restoreMetadata(){jobs.execute(()->{try{if(dbFile.exists()){inspectInternal();JSONObject p=schemaPayload();p.put("fileName",originalName.isEmpty()?"已导入SQLite":originalName);p.put("sizeBytes",dbFile.length());event("schema",p);}}catch(Exception e){event("error",error("已保存数据库不能读取："+e.getMessage()));}});}
    private void verifyQuickCheck(File file) throws Exception {
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(file.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
            Cursor c=db.rawQuery("PRAGMA quick_check(1)",null)){
            if(!c.moveToFirst()||!"ok".equalsIgnoreCase(c.getString(0)))
                throw new IllegalArgumentException("SQLite完整性检查未通过；原数据库未被替换");
        }
    }
    private Map<String,Set<String>> inspectSchema(File source) throws Exception {
        Map<String,Set<String>> map=new HashMap<>();
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(source.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
            try(Cursor tables=db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null)){
                while(tables.moveToNext()){
                    String t=tables.getString(0);Set<String> fields=new HashSet<>();
                    try(Cursor columns=db.rawQuery("PRAGMA table_info("+quoted(t)+")",null)){
                        int index=columns.getColumnIndexOrThrow("name");while(columns.moveToNext())fields.add(columns.getString(index));
                    }
                    if(!fields.isEmpty())map.put(t,fields);
                }
            }
        }
        if(map.isEmpty())throw new IllegalArgumentException("数据库没有可读取的数据表");
        return map;
    }
    private void inspectInternal() throws Exception {
        schema=inspectSchema(dbFile);
        try(FileInputStream in=new FileInputStream(dbFile)){
            byte[] h=new byte[20];int n=0;while(n<h.length){int r=in.read(h,n,h.length-n);if(r<0)break;n+=r;}
            walHeaderDetected=n>=20&&(h[18]==2||h[19]==2);
        }
    }
    private JSONObject schemaPayload() throws Exception {
        JSONObject p=new JSONObject();JSONArray tables=new JSONArray();
        ArrayList<String> names=new ArrayList<>(schema.keySet());java.util.Collections.sort(names);
        for(String name:names){JSONObject o=new JSONObject();o.put("name",name);
            JSONArray cols=new JSONArray();ArrayList<String> items=new ArrayList<>(schema.get(name));java.util.Collections.sort(items);
            for(String c:items)cols.put(c);o.put("columns",cols);tables.put(o);
        }
        p.put("tables",tables);
        p.put("walWarning",walHeaderDetected);
        p.put("legacyQuantDesk",isLegacyQuantDesk());
        if(isLegacyQuantDesk()) p.put("legacyNote","旧版daily_bars/instruments可直接联表读取；dataset_rows财报JSON与行业标签需要单独转换验证");
        return p;
    }
    /** Exact original QuantDesk schema recovered from the supplied APK's DEX strings.
     * The original SQLite database file was NOT included in that APK.
     * NO finance/sector values are invented; unknown sector stays unknown.
     */
    private boolean isLegacyQuantDesk() {
        Set<String> bars=schema.get("daily_bars"), instruments=schema.get("instruments");
        return bars!=null && instruments!=null &&
            bars.containsAll(Arrays.asList("code","day","o","h","l","c","vol","vol_unit","amount")) &&
            instruments.containsAll(Arrays.asList("code","name","exchange"));
    }
    void loadLegacySnapshot(String json) {
        if(busy){event("error",error("数据库任务正运行"));return;}
        busy=true;
        jobs.execute(()->{
            try {
                if(!isLegacyQuantDesk())throw new IllegalArgumentException("数据库不属于旧QuantDesk架构，请改用标准字段映射");
                JSONObject opts=new JSONObject(json);
                int days=Math.max(70,Math.min(240,opts.optInt("days",120)));
                int symbols=Math.max(100,Math.min(750,opts.optInt("symbols",500)));
                if(days*symbols>MAX_ROWS) throw new IllegalArgumentException("近期样本超出180000行限制");
                String firstDay=null,lastDay=null;
                ArrayList<String> codes=new ArrayList<>();
                int missingAmount=0, unknownVolumeUnit=0, omittedRows=0,count=0;
                try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
                    // Strictly A shares. Old APK also tracked HK shares; do not mix them with A-share limit rules.
                    try(Cursor c=db.rawQuery(
                        "SELECT DISTINCT b.day FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                        "WHERE i.exchange IN ('SH','SZ','BJ') ORDER BY b.day DESC LIMIT " + days,null)) {
                        while(c.moveToNext()){
                            if(lastDay==null) lastDay=c.getString(0);
                            firstDay=c.getString(0);
                        }
                    }
                    if(firstDay==null||lastDay==null) throw new IllegalArgumentException("旧数据库里没有A股日线");
                    try(Cursor c=db.rawQuery(
                        "SELECT b.code FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                        "WHERE b.day=? AND i.exchange IN ('SH','SZ','BJ') " +
                        "GROUP BY b.code ORDER BY COALESCE(MAX(b.amount),0) DESC LIMIT " + symbols,
                        new String[]{lastDay})){
                        while(c.moveToNext())codes.add(c.getString(0));
                    }
                    if(codes.isEmpty())throw new IllegalArgumentException("旧数据库最近交易日没有A股记录");
                    StringBuilder marks=new StringBuilder();for(int k=0;k<codes.size();k++){if(k>0)marks.append(',');marks.append('?');}
                    String sql="SELECT b.code,b.day,b.o,b.h,b.l,b.c,b.amount,b.vol,b.vol_unit,i.name " +
                        "FROM daily_bars b JOIN instruments i ON b.code=i.code " +
                        "WHERE b.day>=? AND i.exchange IN ('SH','SZ','BJ') " +
                        "AND b.code IN ("+marks+") ORDER BY b.day,b.code";
                    ArrayList<String> args=new ArrayList<>();args.add(firstDay);args.addAll(codes);
                    event("start",status("识别旧QuantDesk：读取A股日线并联表名称；无行业标签不生成真实热点排名"));
                    JSONArray batch=new JSONArray();
                    try(Cursor c=db.rawQuery(sql,args.toArray(new String[0]))){
                        while(c.moveToNext()){
                            String volUnit=c.getString(8);
                            if(volUnit!=null && !("SHARES".equalsIgnoreCase(volUnit) || "SHARE".equalsIgnoreCase(volUnit))) {unknownVolumeUnit++;}
                            // Require actual exchange-reported amount, NEVER silently fabricate amount from c*volume.
                            if(c.isNull(6)||c.getDouble(6)<=0){missingAmount++;omittedRows++;continue;}
                            JSONObject row=new JSONObject();
                            row.put("code",c.getString(0));row.put("date",normalDate(c.getString(1)));
                            row.put("open",c.getDouble(2));row.put("high",c.getDouble(3));row.put("low",c.getDouble(4));row.put("close",c.getDouble(5));
                            row.put("amount",c.getDouble(6));row.put("volume",c.getDouble(7));
                            row.put("name",c.getString(9));row.put("sector","未分类");
                            batch.put(row);count++;
                            if(batch.length()>=500){sendBatch("bars",batch,count);batch=new JSONArray();}
                        }
                    }
                    if(batch.length()>0)sendBatch("bars",batch,count);
                }
                JSONObject done=new JSONObject();done.put("count",count);done.put("symbols",codes.size());
                done.put("start",normalDate(firstDay));done.put("end",normalDate(lastDay));done.put("source",originalName);
                done.put("missingAmount",missingAmount);done.put("omittedRows",omittedRows);
                done.put("unknownVolumeUnit",unknownVolumeUnit);done.put("legacy",true);
                event("barsDone",done);
            } catch(Exception ex){event("error",error("旧QuantDesk解析失败："+ex.getMessage()));}
            finally{busy=false;}
        });
    }

    private JSONObject status(String msg){JSONObject x=new JSONObject();try{x.put("message",msg);}catch(Exception ignored){}return x;}
    private void sendBatch(String mode,JSONArray data,int done){
        try{JSONObject p=new JSONObject();p.put("mode",mode);p.put("rows",data);p.put("done",done);event("batch",p);}catch(Exception ignored){}
    }
    void loadSnapshot(String json) {
        if(busy){event("error",error("已有数据库任务在运行"));return;}
        busy=true;
        jobs.execute(()->{
            try{
                JSONObject map=new JSONObject(json);String t=str(map,"table");String tab=table(t);
                String date=validated(t,str(map,"date"));String code=validated(t,str(map,"code"));
                String open=validated(t,str(map,"open")),high=validated(t,str(map,"high")),low=validated(t,str(map,"low")),close=validated(t,str(map,"close")),amount=validated(t,str(map,"amount"));
                String volume=optional(map,t,"volume","0"),name=optional(map,t,"name",code),sector=optional(map,t,"sector","'未分类'");
                int days=Math.max(70,Math.min(240,map.optInt("days",150)));int symbols=Math.max(100,Math.min(750,map.optInt("symbols",600)));
                if(days*symbols>MAX_ROWS)throw new IllegalArgumentException("时间窗口×股票数量不能超过180000，避免手机内存不足");
                String lastDay=null,firstDay=null;ArrayList<String> symbolList=new ArrayList<>();
                try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
                    try(Cursor d=db.rawQuery("SELECT DISTINCT "+date+" FROM "+tab+" WHERE "+date+" IS NOT NULL ORDER BY "+date+" DESC LIMIT "+days,null)) {
                        int n=0;while(d.moveToNext()){if(n==0)lastDay=d.getString(0);firstDay=d.getString(0);n++;}
                        if(n<60)throw new IllegalArgumentException("数据库不足60个交易日，无法计算中期指标");
                    }
                    try(Cursor symbolsCur=db.rawQuery("SELECT "+code+" FROM "+tab+" WHERE "+date+"=? GROUP BY "+code+" ORDER BY SUM(CAST("+amount+" AS REAL)) DESC LIMIT "+symbols,new String[]{lastDay})){
                        while(symbolsCur.moveToNext())if(symbolsCur.getString(0)!=null)symbolList.add(symbolsCur.getString(0));
                    }
                    if(symbolList.isEmpty())throw new IllegalArgumentException("最新交易日无股票可用");
                    StringBuilder ph=new StringBuilder();for(int i=0;i<symbolList.size();i++){if(i>0)ph.append(',');ph.append('?');}
                    String sql="SELECT "+code+" AS qcode,"+date+" AS qdate,"+open+" AS qo,"+high+" AS qh,"+low+" AS ql,"+close+" AS qc,"+amount+" AS qa,"+volume+" AS qv,"+name+" AS qn,"+sector+" AS qs FROM "+tab+" WHERE "+date+">=? AND "+code+" IN ("+ph+") ORDER BY "+date+","+code;
                    ArrayList<String> args=new ArrayList<>();args.add(firstDay);args.addAll(symbolList);
                    event("start",status("已选取最近"+days+"日、成交活跃的"+symbolList.size()+"只股票；这是探索子集，不是全市场回测"));
                    int count=0;JSONArray batch=new JSONArray();
                    try(Cursor cursor=db.rawQuery(sql,args.toArray(new String[0]))){
                        while(cursor.moveToNext()){
                            JSONObject row=new JSONObject();row.put("code",cursor.getString(0));row.put("date",normalDate(cursor.getString(1)));
                            row.put("open",cursor.getDouble(2));row.put("high",cursor.getDouble(3));row.put("low",cursor.getDouble(4));row.put("close",cursor.getDouble(5));
                            row.put("amount",cursor.getDouble(6));row.put("volume",cursor.getDouble(7));row.put("name",cursor.getString(8));row.put("sector",cursor.getString(9));
                            batch.put(row);count++;
                            if(batch.length()>=500){sendBatch("bars",batch,count);batch=new JSONArray();}
                            if(count>=MAX_ROWS)break;
                        }
                    }
                    if(batch.length()>0)sendBatch("bars",batch,count);
                    JSONObject complete=new JSONObject();complete.put("count",count);complete.put("symbols",symbolList.size());complete.put("start",normalDate(firstDay));complete.put("end",normalDate(lastDay));complete.put("source",originalName);event("barsDone",complete);
                }
            }catch(Exception e){event("error",error("行情导入失败："+e.getMessage()));}
            finally{busy=false;}
        });
    }
    void loadFinance(String json) {
        if(busy){event("error",error("已有数据库任务在运行"));return;}busy=true;
        jobs.execute(()->{
            try{
                JSONObject map=new JSONObject(json);String t=str(map,"table"),tab=table(t),code=validated(t,str(map,"code")),date=validated(t,str(map,"announcement_date"));
                String revenue=validated(t,str(map,"revenue_yoy")),profit=validated(t,str(map,"net_profit_ttm")),ocf=validated(t,str(map,"ocf_ttm"));
                String sql="SELECT "+code+","+date+","+revenue+","+profit+","+ocf+" FROM "+tab+" ORDER BY "+date;
                int count=0;JSONArray batch=new JSONArray();event("start",status("正在读取按公告日可得的财务指标…"));
                try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
                    Cursor cur=db.rawQuery(sql,null)){
                    while(cur.moveToNext()){
                        JSONObject row=new JSONObject();row.put("code",cur.getString(0));row.put("announcement_date",normalDate(cur.getString(1)));
                        row.put("revenue_yoy",cur.getDouble(2));row.put("net_profit_ttm",cur.getDouble(3));row.put("ocf_ttm",cur.getDouble(4));batch.put(row);count++;
                        if(batch.length()>=500){sendBatch("finance",batch,count);batch=new JSONArray();}
                        if(count>=300000)throw new IllegalArgumentException("财报行数超过30万，请先在电脑上按公告日整理");
                    }
                }
                if(batch.length()>0)sendBatch("finance",batch,count);
                JSONObject p=new JSONObject();p.put("count",count);event("financeDone",p);
            }catch(Exception e){event("error",error("财报导入失败："+e.getMessage()));}finally{busy=false;}
        });
    }
    private static String normalDate(String text){
        if(text==null)return "";
        String x=text.trim();if(x.matches("\\d{8}"))return x.substring(0,4)+"-"+x.substring(4,6)+"-"+x.substring(6,8);
        return x.length()>=10?x.substring(0,10):x;
    }
    void close(){jobs.shutdownNow();}
}
