package cn.tidelab.quantpilot;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.webkit.ValueCallback;

/** Isolated offline research UI. No brokerage permissions, credentials or order APIs. */
public final class MainActivity extends Activity {
    private WebView webView;
    private SqliteImportEngine sqliteEngine;
    private ValueCallback<Uri[]> pendingChooser;
    private String exportPayload;
    private static final int REQ_CSV = 9022;
    private static final int REQ_SQLITE = 9024;
    private static final int REQ_EXPORT = 9023;
    private static final int REQ_SECTOR_HISTORY = 9025;
    private static final int REQ_FINANCE_HISTORY = 9026;
    private static final int REQ_FINANCE_KEYMAP = 9027;

    private final class SafeLocalBridge {
        @JavascriptInterface public void chooseSqlite() {
            runOnUiThread(() -> {
                try {
                    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    startActivityForResult(intent,REQ_SQLITE);
                } catch(Exception e) {Toast.makeText(MainActivity.this,"无法打开文件选择器",Toast.LENGTH_SHORT).show();}
            });
        }
        @JavascriptInterface public void chooseHistoricalSectors() {pickResearchCsv(REQ_SECTOR_HISTORY);}
        @JavascriptInterface public void chooseHistoricalFinance() {pickResearchCsv(REQ_FINANCE_HISTORY);}
        @JavascriptInterface public void chooseFinanceKeymap(){pickResearchCsv(REQ_FINANCE_KEYMAP);}
        @JavascriptInterface public void readLegacySqliteSnapshot(String optionsJson) {
            if (optionsJson!=null && optionsJson.length()<2000) sqliteEngine.loadLegacySnapshot(optionsJson);
        }
        @JavascriptInterface public void readSqliteSnapshot(String mapJson) {
            if(mapJson!=null&&mapJson.length()<8000)sqliteEngine.loadSnapshot(mapJson);
        }
        @JavascriptInterface public void readSqliteFinance(String mapJson) {
            if(mapJson!=null&&mapJson.length()<8000)sqliteEngine.loadFinance(mapJson);
        }
        @JavascriptInterface public void restoreSqlite() {sqliteEngine.restoreMetadata();}
        @JavascriptInterface public void runFullHistoryBacktest() {sqliteEngine.runFullHistoryBacktest();}

        @JavascriptInterface public void exportJson(final String filename,final String json) {
            if (json == null || json.length() > 8_000_000) return;
            runOnUiThread(() -> {
                exportPayload=json;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                String safe=filename == null ? "tidequant_report.json" : filename.replaceAll("[^\\p{L}\\p{N}_.-]","_");
                intent.putExtra(Intent.EXTRA_TITLE,safe);
                try {startActivityForResult(intent,REQ_EXPORT);} catch(Exception e) {exportPayload=null;Toast.makeText(MainActivity.this,"无法打开文件保存器",Toast.LENGTH_LONG).show();}
            });
        }
    }

    private void pickResearchCsv(int requestCode){
        runOnUiThread(()->{
            try {Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");startActivityForResult(intent,requestCode);
            }catch(Exception e){Toast.makeText(this,"无法打开文件选择器："+e.getMessage(),Toast.LENGTH_LONG).show();}
        });
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        sqliteEngine=new SqliteImportEngine(this,webView);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new SafeLocalBridge(),"TideBridge");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,android.webkit.WebResourceRequest request){
                Uri u=request.getUrl();
                return !"appassets.androidplatform.net".equals(u.getHost());
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(
                WebView v,android.webkit.WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if (pendingChooser!=null) pendingChooser.onReceiveValue(null);
                pendingChooser=callback;
                try {
                    Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/plain","application/csv","application/vnd.ms-excel","application/json","application/octet-stream"});
                    startActivityForResult(Intent.createChooser(intent,"选择历史数据 CSV"),REQ_CSV);
                } catch (Exception e) {pendingChooser.onReceiveValue(null);pendingChooser=null;}
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_SQLITE){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null) {
                Uri file=data.getData();String name=file.getLastPathSegment();
                try(android.database.Cursor c=getContentResolver().query(file,null,null,null,null)){
                    if(c!=null&&c.moveToFirst()){
                        int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                        if(i>=0)name=c.getString(i);
                    }
                } catch(Exception ignored){}
                sqliteEngine.copyAndInspect(file,name);
            }
            return;
        }
        if(requestCode==REQ_SECTOR_HISTORY||requestCode==REQ_FINANCE_HISTORY||requestCode==REQ_FINANCE_KEYMAP){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)
                if(requestCode==REQ_FINANCE_KEYMAP)sqliteEngine.importFinanceKeyMap(data.getData());
                else sqliteEngine.importResearchCsv(data.getData(),requestCode==REQ_FINANCE_HISTORY);
            return;
        }
        if(requestCode==REQ_CSV && pendingChooser!=null){
            Uri[] result=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;
            pendingChooser.onReceiveValue(result);
            pendingChooser=null;
        }
        if(requestCode==REQ_EXPORT){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&exportPayload!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new IllegalStateException("no output stream");
                    out.write(exportPayload.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"模拟研究报告已保存",Toast.LENGTH_SHORT).show();
                } catch(Exception e){Toast.makeText(this,"保存失败："+e.getMessage(),Toast.LENGTH_LONG).show();}
            }
            exportPayload=null;
        }
    }
    @Override public void onBackPressed(){
        if(webView.canGoBack())webView.goBack();else super.onBackPressed();
    }
    @Override public void onDestroy(){
        if(pendingChooser!=null){pendingChooser.onReceiveValue(null);pendingChooser=null;}
        sqliteEngine.close();webView.destroy();super.onDestroy();
    }
}
