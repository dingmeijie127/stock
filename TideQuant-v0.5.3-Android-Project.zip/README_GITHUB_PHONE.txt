TideQuant v0.5.1 · GitHub Actions fix

This version fixes the GitHub error: pytest: file or directory not found: research/tests.
The old workflow was running pytest in the repository root instead of the unzipped source project.

On mobile:
1. Download TideQuant-v0.5.1-OneDownload.zip and extract it ONCE.
2. Upload TideQuant-v0.5.1-Android-Project.zip to the repository root, without extracting that inner ZIP.
3. In GitHub, open .github/workflows/ and replace build-apk.yml with the bundled one (same path/name).
4. Commit both changes, then Actions > TideQuant Android APK > Run workflow.
5. Download TideQuant-v0.5.1-Debug-APK from the successful run's Artifacts section.

IMPORTANT: The old workflow file MUST be replaced. Uploading just the new source ZIP will not correct the old workflow.
This ZIP does not contain your private >1.5GB SQLite DB; live market/financial performance is NOT verified.
Android build has NOT been executed on GitHub by this package's creator; please use run log as source of truth.
