package com.quantdesk.download;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A-share CLOSE-OF-DAY quotes in bounded batches; never invent a trading date. */
public final class TencentBatchQuotes {
    public static final int BATCH_SIZE=40;
    private TencentBatchQuotes(){}
    /** Pure parser for Tencent's GBK quote records, independent from Android and transport. */
    public static Map<String,Bar> parse(String payload,LocalDate requested){
        Map<String,Bar> result=new HashMap<>();
        String target=requested.toString().replace("-","");
        for(String record:payload.split(";")){
            try{
                int equal=record.indexOf('=');
                if(equal<0)continue;
                String key=record.substring(0,equal).trim();
                if(!key.matches("v_(sh|sz)[0-9]{6}"))continue; // HK/BJ have different semantics
                String code=key.substring(key.length()-6);
                int left=record.indexOf('"',equal),right=record.lastIndexOf('"');
                if(left<0||right<=left)continue;
                String[] f=record.substring(left+1,right).split("~",-1);
                if(f.length<38||!code.equals(f[2]))continue;
                // f30 is exchange-provided YYYYMMDDHHmmss. Local device clock cannot be used.
                if(f[30].length()<14 || !f[30].substring(0,8).equals(target))continue;
                double close=Double.parseDouble(f[3]),open=Double.parseDouble(f[5]);
                double high=Double.parseDouble(f[33]),low=Double.parseDouble(f[34]);
                double volume=Double.parseDouble(f[6]); // A-share quote volume in 100-share lots
                if(volume<=0)continue; // suspension/empty quote is not a completed daily candle
                String raw=record.substring(left+1,right);
                Bar bar=new Bar(requested.toString(),open,high,low,close,volume,null,
                    "tencent_eod_batch","LOTS_100_SHARES",raw);
                result.put(code,bar);
            }catch(RuntimeException invalid){
                // A single bad/missing quote must not discard the other valid names in a batch.
            }
        }
        return result;
    }
    public static String symbol(String code,String exchange){
        if(code==null||!code.matches("[0-9]{6}")||!("SH".equals(exchange)||"SZ".equals(exchange)))
            throw new IllegalArgumentException("Batch quotes support SH/SZ equity only");
        return ("SH".equals(exchange)?"sh":"sz")+code;
    }
    public static Map<String,Bar> fetch(List<String> symbols,LocalDate target) throws IOException {
        if(symbols.isEmpty()||symbols.size()>BATCH_SIZE)throw new IllegalArgumentException("Batch size 1..40");
        for(String s:symbols)if(!s.matches("(sh|sz)[0-9]{6}"))throw new IllegalArgumentException("Bad quote symbol");
        String url="https://qt.gtimg.cn/q="+String.join(",",symbols);
        HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(4000);conn.setReadTimeout(6000);
        conn.setUseCaches(false);conn.setRequestProperty("User-Agent","Mozilla/5.0");
        conn.setRequestProperty("Referer","https://gu.qq.com/");
        try{
            int status=conn.getResponseCode();
            if(status!=200)throw new IOException("Tencent batch HTTP "+status);
            try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=in.read(buffer))!=-1){
                    if(out.size()+n>200000)throw new IOException("Tencent response too big");
                    out.write(buffer,0,n);
                }
                return parse(new String(out.toByteArray(),Charset.forName("GBK")),target);
            }
        }finally{conn.disconnect();}
    }
    public static List<List<String>> pages(List<String> symbols){
        List<List<String>> pages=new ArrayList<>();
        for(int i=0;i<symbols.size();i+=BATCH_SIZE)
            pages.add(new ArrayList<>(symbols.subList(i,Math.min(symbols.size(),i+BATCH_SIZE))));
        return pages;
    }
}
