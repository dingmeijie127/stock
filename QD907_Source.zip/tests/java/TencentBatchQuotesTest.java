package com.quantdesk.download;
import java.time.LocalDate;
import java.util.Map;
public final class TencentBatchQuotesTest {
    private static void check(boolean v,String message){if(!v)throw new AssertionError(message);}
    private static String row(String symbol,String code,String date,String close){
        String[] f=new String[52];java.util.Arrays.fill(f,"");
        f[2]=code;f[3]=close;f[5]="101";f[6]="300";f[30]=date;
        f[33]="103";f[34]="100";
        return "v_"+symbol+"=\""+String.join("~",f)+"\";";
    }
    public static void main(String[] a){
        LocalDate target=LocalDate.of(2026,10,26);
        String valid=row("sh600519","600519","20261026150700","102");
        String yesterday=row("sz000001","000001","20261023150700","102");
        String broken=row("sz000002","000002","20261026150700","95"); // close below low
        Map<String,Bar> parsed=TencentBatchQuotes.parse(valid+yesterday+broken,target);
        check(parsed.size()==1,"only target-day valid OHLCV may be saved: "+parsed.size());
        Bar b=parsed.get("600519");check(b!=null && b.close==102,"wrong stock value");
        check(b.source.equals("tencent_eod_batch"),"provider provenance");
        check(b.volumeUnit.equals("LOTS_100_SHARES"),"volume unit explicit");
        check(TencentBatchQuotes.parse(valid,LocalDate.of(2026,10,27)).isEmpty(),"wrong day rejected");
        check(TencentBatchQuotes.symbol("600519","SH").equals("sh600519"),"Shanghai");
        check(TencentBatchQuotes.symbol("000001","SZ").equals("sz000001"),"Shenzhen");
        boolean rejected=false;
        try{TencentBatchQuotes.symbol("00700","HK");}catch(IllegalArgumentException expected){rejected=true;}
        check(rejected,"HK quote schema must never be treated as A equity");
        check(TencentBatchQuotes.pages(java.util.Collections.nCopies(97,"sh600519")).size()==3,"bounded batches");
        System.out.println("TencentBatchQuotesTest OK");
    }
}
