# QuantDesk V8.6 · 全市场数据库采集版（Android 原生版 + 可选 Python 采集器）

这是对前一版“APK 没有真正全量下载模块”的修复：**APP 启动后，首页即是原生数据采集控制台，不需要在手机先安装 Python，也不需要远程电脑服务器。** 保留「打开原版行情与技术分析界面」按钮。由于输入材料只有旧 APK，没有原始 Android 工程和签名，原分析资源从用户提供的 V8.4 APK 恢复，Android Java 容器另行编写，无法保证与旧版二进制兼容。

## 一、数据库先行（本地 SQLite）

启动 → **① 创建 / 打开本地 SQLite 数据库**。持久化 DB：`quantdesk-market-v86.sqlite3`，手机内置私有存储，不会上传到 GitHub。结构：

| 表名 | 说明 |
|---|---|
| `instruments` | A 股、港股股票代码、名称、当前公开目录原始记录、采集时间 |
| `candles` | 日、周、月、1/5/15/30/60 分钟 K 线，OHLCV、复权属性、原数据、来源 |
| `financial_statements` | 利润表、资产负债表、现金流量表（报告期 + 来源 + 原始科目） |
| `auxiliary_data` | 财务指标、复权因子、分红、审计、股东户数等可授权扩展数据 |
| `fetch_tasks` | 按市场/证券/数据集/时间段记录 `observed / partial / failed / permission_required` 和已保存数量 |
| `fetch_errors` | 每次采集错误日志（HTTP、解析错误、权限不足） |
| `data_gaps` | 数据质量缺口：历史短缺、三表未在相同报告期对齐等 |
| `catalog_checks` | 目录覆盖审计：不假装已有完整交易所官方目录 |
| `ingest_runs` | 每次采集任务的开始/停止、完成状态和原因 |

**保留原始响应与来源；不生成假 K 线和财报；不把请求成功标为交易所认证的完整。** 周/月 K 线标为 `derived_daily_<上游源>`，表示根据同来源日线 OHLCV 聚合，而非声称拿到了交易所原始周/月数据。不同复权序列不混存；不同来源成交量的单位不能擅自转换，保留原提供者和 `volume_unit`。

## 二、手机上怎么全市场采集

1. 连接**非计费 Wi-Fi**，留足存储空间、电量；全市场历史任务可能持续很久，Android/厂商系统可能停止服务，服务会持久化分段检查点，重新打开再次按「②」继续。
2. 如有 **Tushare Token**，在 UI 的选填框输入。它仅在这次手机任务运行时保存在内存，不写进 APK、ZIP、SQLite、GitHub，也不写进日志。按开始按钮后立即清空输入框。
3. 点击「① 创建数据库」，再点击「② 下载 A 股 + 港股全市场」。APP 显示股票、K 线记录、三表、辅助数据和失败/未授权计数。
4. 想暂停时点「③」；任务会在当前网络请求结束后暂停。再次按「②」会根据 SQLite 中的 `fetch_tasks` 跳过已完成的历史时间段，继续失败和未完成段。
5. 暂停服务后点击「④ 导出全部数据库 .sqlite3」，选择 Android 文件夹，把数据库完整导出。点击页面下方「查询本地 K 线 / 财报 / 采集状态」可按股票检查实际保存的记录。

原生 Android 数据源：

- **公开股票目录 + K 线**：东方财富（HK/A）；有故障时 Tushare（需授权）或 Yahoo Finance 历史数据备用；分段回填日线，获取可用的历史 1/5/15/30/60 分钟线。
- **三大财报**：Tushare `income / balancesheet / cashflow`（A）和 `hk_income / hk_balancesheet / hk_cashflow`（HK），按时间段保存全部**实际可获取**的报告期与原始指标；HK 原始接口是一项财务科目一行，程序按报告期归组保存。
- **可选扩展**：A 股 `fina_indicator / dividend / adj_factor / fina_audit / stk_holdernumber`；港股 `hk_fina_indicator`（具体可用性受权限影响）。
- **Python 采集器仍在 `collector/`**：可在电脑/服务器安装 AKShare、Tushare、yfinance 做更大规模采集、独立核对和加速，**不是 APK 启动下载的必要条件**。电脑数据库与手机 SQLite 是不同数据库结构，当前**尚无跨设备自动合并**，可手动导出手机 DB。

## 三、最重要的事实（避免“显示完成但是没有数据”）

- 这不是预装了全市场历史数据的 APK。下载安装后需要**实际联网**、点击下载、给予足够时间及数据商访问权限，数据库才会增长。
- 公开源无法保证**所有上市/退市证券**和交易所每一天的完整历史；仅靠公开接口不能保证全部 Tick、逐笔委托、历史所有分钟线、港交所公告附件原文、财报修订版与所有行业数据库。
- Tushare A 股财报一般有积分门槛，**港股三大财报与港股日线通常需要单独授权**；无 Token 或权限时任务明确标记 `permission_required`，不会伪造成功。港股会计币种、单位、财政年度以原始字段为准（未知就写 `UNKNOWN`，不是强行默认为 HKD）。
- 一个时间段采集到数据，只能称 `observed`，**不是经交易日历、上市状态、退市完整清单复核的 certified 全量**。目录 `advertised=-1` 表示官方总数未认证；`data_gaps` 和 `fetch_errors` 用于进一步审计。
- GitHub Actions **只负责编译 APK，不会自动把 A/HK 全量数据库下载到你的手机**。手机端的采集须在安装 APK 后由本人发起。
- 由于 Android、数据源限流及网络/电量限制，全市场采集适合反复增量、分批持续回填。长期无人值守的海量历史数据库，应部署获授权的数据源到电脑/服务器；仅手机采集无法承诺“一次运行全部拿齐”。

## 四、GitHub 新仓库：**只上传两个文件**

下载：

1. `QuantDesk86_DataVault_Source.zip` → **原样**上传到新仓库根目录，不用解压。
2. `QuantDesk86_DataVault_Build.yml` → **文件名不需要改**，进入 GitHub 仓库的 `.github/workflows/` 文件夹，点击 `Add file → Upload files`，选择这个 YML 直接上传，**无须打开或复制内容**。

GitHub Actions 识别 `.github/workflows/` 下面任何 `.yml` 文件名，因此路径可以是 `.github/workflows/QuantDesk86_DataVault_Build.yml`。源码 ZIP 中也自带相同工作流（文件名 `android-build.yml`），但直接上传 ZIP 时，GitHub 不会自动识别 ZIP 内的 YAML；单独的 YML 必须放在工作流文件夹下。

GitHub → Actions → `QuantDesk V8.6 - DataVault Full Market APK` → Run workflow。
构建成功后下载 Artifacts → `QuantDesk-V8.6-DataVault-APK` → 解压 → 安装 `QuantDesk-V8.6-DataVault-debug.apk`。

新 YAML：从根目录自动展开上述源码 ZIP、验证原生采集文件、测试 Java 市场规则、Python/JS 测试、安装 Android SDK 35、用 Gradle 8.9/AGP 8.7.3 + Java 17 编译 Debug APK。源码 ZIP 也包含 Android 工程、前端恢复资源、测试与 YAML。不要上传 API Token 到 GitHub；Debug APK 不是正式签名发布版。

## 五、开发者离线自测及限制

```bash
python -m pytest -q tests
node --test tests/*.test.cjs
javac -d build/testclasses android-app/app/src/main/java/com/quantdesk/v85/MarketRules.java tests/MarketRulesTest.java
java -cp build/testclasses MarketRulesTest
```

新增 Python 测试将从 Android Java 源码里提取数据库建表 SQL，使用真正的 Python SQLite 内核执行，再测试唯一性约束、复权隔离、财报来源、任务表与故障记录；原 V8.5 Python/JS 测试保留。

当前执行环境没有 Android SDK/Gradle，也不允许直接连接证券商公网端点。**这些离线检查不等价于 GitHub 上已编译出 APK，更不等于全市场真实下载已成功**。请用实际 Actions 构建日志验证 APK 编译，并在手机上启动小批量采集后核对 SQLite 行数与记录。

参考：
- https://tushare.pro/document/1?doc_id=108
- https://tushare.pro/document/2?doc_id=389
- https://tushare.pro/document/2?doc_id=390
- https://tushare.pro/document/2?doc_id=391
- https://developer.android.com/develop/background-work/services/fgs/service-types
