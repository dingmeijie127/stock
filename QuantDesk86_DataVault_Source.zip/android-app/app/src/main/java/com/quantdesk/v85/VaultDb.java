package com.quantdesk.v85;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;
import java.util.Locale;

/** Persistent on-phone SQL data warehouse. Every observation retains source and original payload. */
public final class VaultDb extends SQLiteOpenHelper {
    public static final String NAME = "quantdesk-market-v86.sqlite3";
    public VaultDb(Context context) { super(context, NAME, null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE instruments (market TEXT NOT NULL, code TEXT NOT NULL, name TEXT NOT NULL, exchange TEXT, status TEXT, source TEXT NOT NULL, catalog_at INTEGER NOT NULL, raw_json TEXT NOT NULL, PRIMARY KEY(market,code))");
        db.execSQL("CREATE TABLE candles (market TEXT NOT NULL, code TEXT NOT NULL, interval TEXT NOT NULL, adjustment TEXT NOT NULL, timestamp TEXT NOT NULL, o REAL NOT NULL, h REAL NOT NULL, l REAL NOT NULL, c REAL NOT NULL, volume REAL NOT NULL, volume_unit TEXT NOT NULL, amount REAL, source TEXT NOT NULL, fetched_at INTEGER NOT NULL, raw_json TEXT NOT NULL, PRIMARY KEY(market,code,interval,adjustment,timestamp))");
        db.execSQL("CREATE INDEX candles_lookup ON candles(market,code,interval,timestamp)");
        db.execSQL("CREATE TABLE financial_statements (market TEXT NOT NULL,code TEXT NOT NULL,kind TEXT NOT NULL,period TEXT NOT NULL,source TEXT NOT NULL,currency TEXT,unit TEXT,ann_date TEXT,raw_json TEXT NOT NULL,fetched_at INTEGER NOT NULL,PRIMARY KEY(market,code,kind,period,source))");
        db.execSQL("CREATE INDEX statement_lookup ON financial_statements(market,code,period)");
        db.execSQL("CREATE TABLE auxiliary_data (market TEXT NOT NULL,code TEXT NOT NULL,dataset TEXT NOT NULL,observation_key TEXT NOT NULL,source TEXT NOT NULL,raw_json TEXT NOT NULL,fetched_at INTEGER NOT NULL,PRIMARY KEY(market,code,dataset,observation_key,source))");
        db.execSQL("CREATE INDEX auxiliary_lookup ON auxiliary_data(market,code,dataset)");
        db.execSQL("CREATE TABLE fetch_tasks (task_key TEXT PRIMARY KEY, market TEXT, code TEXT, kind TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, rows_saved INTEGER NOT NULL DEFAULT 0, provider TEXT, error TEXT, updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX task_status ON fetch_tasks(status,market,kind)");
        db.execSQL("CREATE TABLE ingest_runs (id INTEGER PRIMARY KEY AUTOINCREMENT,started_at INTEGER NOT NULL,finished_at INTEGER, status TEXT NOT NULL, message TEXT)");
        db.execSQL("CREATE TABLE catalog_checks (market TEXT PRIMARY KEY, provider TEXT NOT NULL, advertised INTEGER, received INTEGER NOT NULL, fetched_at INTEGER NOT NULL, status TEXT NOT NULL)");
        db.execSQL("CREATE TABLE fetch_errors (id INTEGER PRIMARY KEY AUTOINCREMENT, task_key TEXT NOT NULL, provider TEXT, reason TEXT, occurred_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE data_gaps (market TEXT NOT NULL, code TEXT NOT NULL, category TEXT NOT NULL, details TEXT NOT NULL,checked_at INTEGER NOT NULL,PRIMARY KEY(market,code,category))");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { throw new IllegalStateException("explicit schema migration required"); }
    public void saveInstrument(String market,String code,String name,String source,String raw) {
        if (!MarketRules.validCode(market,code) || name.trim().isEmpty()) throw new IllegalArgumentException("invalid instrument");
        ContentValues v=new ContentValues(); v.put("market",market);v.put("code",code);v.put("name",name);
        v.put("source",source);v.put("catalog_at",System.currentTimeMillis());v.put("raw_json",raw);
        getWritableDatabase().insertWithOnConflict("instruments",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void saveCandle(String market,String code,String interval,String adjustment,String timestamp,
           double o,double h,double l,double c,double volume,Double amount,String provider,String raw) {
        MarketRules.validateBar(o,h,l,c,volume);
        if (!MarketRules.validCode(market,code) || !timestamp.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}([ T][0-9]{2}:[0-9]{2}(:[0-9]{2})?)?") ||
                !(adjustment.equals("none")||adjustment.equals("qfq")||adjustment.equals("hfq"))) throw new IllegalArgumentException("invalid candle identity");
        ContentValues v=new ContentValues();v.put("market",market);v.put("code",code);v.put("interval",interval);
        v.put("adjustment",adjustment);v.put("timestamp",timestamp);v.put("o",o);v.put("h",h);
        v.put("l",l);v.put("c",c);v.put("volume",volume);
        v.put("volume_unit",provider.equals("yahoo")?"SHARES":"SOURCE_NATIVE_UNVERIFIED");
        if(amount!=null)v.put("amount",amount);
        v.put("source",provider);v.put("fetched_at",System.currentTimeMillis());v.put("raw_json",raw);
        getWritableDatabase().insertWithOnConflict("candles",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void saveFinancial(String market,String code,String kind,String period,String provider,String raw,String currency,String unit,String annDate) {
        if (!MarketRules.validCode(market,code)||!period.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}") ||
                !(kind.equals("income")||kind.equals("balance")||kind.equals("cashflow"))) throw new IllegalArgumentException("invalid financial statement");
        ContentValues v=new ContentValues();v.put("market",market);v.put("code",code);v.put("kind",kind);
        v.put("period",period);v.put("source",provider);v.put("currency",currency);v.put("unit",unit);
        v.put("ann_date",annDate);v.put("raw_json",raw);v.put("fetched_at",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("financial_statements",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void saveAuxiliary(String market,String code,String dataset,String key,String provider,String raw) {
        if(!MarketRules.validCode(market,code)||!dataset.matches("[a-z_]{3,40}")||key.isEmpty())throw new IllegalArgumentException("invalid auxiliary record");
        ContentValues v=new ContentValues();v.put("market",market);v.put("code",code);v.put("dataset",dataset);
        v.put("observation_key",key);v.put("source",provider);v.put("raw_json",raw);
        v.put("fetched_at",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("auxiliary_data",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void catalogCheck(String market,String source,int advertised,int received,String status) {
        ContentValues v=new ContentValues();v.put("market",market);v.put("provider",source);v.put("advertised",advertised);
        v.put("received",received);v.put("status",status);v.put("fetched_at",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("catalog_checks",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public boolean done(String key) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM fetch_tasks WHERE task_key=? AND status='observed'",new String[]{key})) {return c.moveToFirst();}
    }
    public boolean doneWithin(String key,long maxAgeMillis) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT status,updated_at FROM fetch_tasks WHERE task_key=?",new String[]{key})) {
            return c.moveToFirst() && c.getString(0).equals("observed") &&
                    System.currentTimeMillis()-c.getLong(1)<maxAgeMillis;
        }
    }
    public void recordTask(String key,String market,String code,String kind,String state,int rows,String provider,String error) {
        SQLiteDatabase db=getWritableDatabase();
        int attempts=0;
        try(Cursor cur=db.rawQuery("SELECT attempts FROM fetch_tasks WHERE task_key=?",new String[]{key})) {if(cur.moveToFirst())attempts=cur.getInt(0);}
        ContentValues v=new ContentValues();v.put("task_key",key);v.put("market",market);v.put("code",code);
        v.put("kind",kind);v.put("status",state);v.put("rows_saved",rows);v.put("attempts",attempts+1);
        v.put("provider",provider);v.put("error",error);v.put("updated_at",System.currentTimeMillis());
        db.insertWithOnConflict("fetch_tasks",null,v,SQLiteDatabase.CONFLICT_REPLACE);
        if (error!=null && !error.isEmpty()) {
            ContentValues err=new ContentValues();err.put("task_key",key);err.put("provider",provider);
            err.put("reason",error.length()>1000?error.substring(0,1000):error);err.put("occurred_at",System.currentTimeMillis());
            db.insert("fetch_errors",null,err);
        }
    }
    public void startRun() {
        ContentValues v=new ContentValues();v.put("started_at",System.currentTimeMillis());v.put("status","running");
        getWritableDatabase().insert("ingest_runs",null,v);
    }
    public void finishRun(String status,String message) {
        getWritableDatabase().execSQL("UPDATE ingest_runs SET finished_at=?,status=?,message=? WHERE id=(SELECT max(id) FROM ingest_runs)",
            new Object[]{System.currentTimeMillis(),status,message});
    }
    public JSONObject stockStatus(String market,String code) {
        if(!MarketRules.validCode(market,code))throw new IllegalArgumentException("请输入完整的6位A股或5位港股代码");
        JSONObject j=new JSONObject();SQLiteDatabase db=getReadableDatabase();
        try{
            j.put("symbol",market+":"+code);
            try(Cursor c=db.rawQuery("SELECT name,source FROM instruments WHERE market=? AND code=?",new String[]{market,code})) {
                if(c.moveToFirst()){j.put("name",c.getString(0));j.put("catalog_source",c.getString(1));}
            }
            try(Cursor c=db.rawQuery("SELECT interval,count(*),min(timestamp),max(timestamp),count(DISTINCT source) FROM candles WHERE market=? AND code=? GROUP BY interval ORDER BY interval",new String[]{market,code})) {
                while(c.moveToNext())j.put("kline_"+c.getString(0),c.getLong(1)+"条 | "+c.getString(2)+"～"+c.getString(3)+" | 来源数量"+c.getInt(4));
            }
            try(Cursor c=db.rawQuery("SELECT kind,count(*),max(period) FROM financial_statements WHERE market=? AND code=? GROUP BY kind",new String[]{market,code})){
                while(c.moveToNext())j.put("report_"+c.getString(0),c.getInt(1)+"期，最新 "+c.getString(2));
            }
            try(Cursor c=db.rawQuery("SELECT dataset,count(*) FROM auxiliary_data WHERE market=? AND code=? GROUP BY dataset",new String[]{market,code})){
                while(c.moveToNext())j.put("additional_"+c.getString(0),c.getLong(1));
            }
            try(Cursor c=db.rawQuery("SELECT status,count(*) FROM fetch_tasks WHERE market=? AND code=? GROUP BY status",new String[]{market,code})){
                while(c.moveToNext())j.put("tasks_"+c.getString(0),c.getLong(1));
            }
        }catch(Exception e){try{j.put("error",e.getMessage());}catch(Exception ignored){}}
        return j;
    }
    public JSONObject stats() {
        JSONObject j=new JSONObject();SQLiteDatabase db=getReadableDatabase();
        try {
            for(String t:new String[]{"instruments","candles","financial_statements","auxiliary_data","fetch_tasks","fetch_errors","data_gaps"}){
                try(Cursor c=db.rawQuery("SELECT count(*) FROM "+t,null)){ c.moveToFirst();j.put(t,c.getLong(0)); }
            }
            try(Cursor c=db.rawQuery("SELECT market,count(*) FROM instruments GROUP BY market",null)){
                while(c.moveToNext())j.put("symbols_"+c.getString(0),c.getLong(1));
            }
            try(Cursor c=db.rawQuery("SELECT interval,count(*) FROM candles GROUP BY interval",null)) {
                long minute=0;while(c.moveToNext()){
                    if(c.getString(0).equals("day"))j.put("candles_day",c.getLong(1));else minute+=c.getLong(1);
                }j.put("candles_minute",minute);
            }
            try(Cursor c=db.rawQuery("SELECT status,count(*) FROM fetch_tasks GROUP BY status",null)) {
                while(c.moveToNext())j.put("tasks_"+c.getString(0),c.getLong(1));
            }
            try(Cursor c=db.rawQuery("SELECT market,advertised,received,status FROM catalog_checks",null)) {
                while(c.moveToNext())j.put("catalog_"+c.getString(0),c.getString(3)+" ("+c.getInt(2)+" / "+(c.getInt(1)<0?"官方总数未核验":c.getInt(1))+")");
            }
            try(Cursor c=db.rawQuery("SELECT status,coalesce(message,'') FROM ingest_runs ORDER BY id DESC LIMIT 1",null)) {
                if(c.moveToNext()){j.put("last_run",c.getString(0));j.put("last_message",c.getString(1));}
            }
        } catch(Exception e) { try{j.put("db_error",e.getMessage());}catch(Exception ignored){} }
        return j;
    }
}
