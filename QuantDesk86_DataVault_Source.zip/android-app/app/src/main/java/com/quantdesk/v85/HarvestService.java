package com.quantdesk.v85;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.util.concurrent.atomic.AtomicBoolean;

/** User-started Android foreground ingestion. Pauses cleanly, resume uses SQLite checkpoints. */
public final class HarvestService extends Service {
    public static final String START="com.quantdesk.v85.START_HARVEST";
    public static final String PAUSE="com.quantdesk.v85.PAUSE_HARVEST";
    public static final String CHANNEL="quantdesk_v86_ingestion";
    public static final AtomicBoolean RUNNING=new AtomicBoolean(false);
    private final AtomicBoolean shouldStop=new AtomicBoolean(false);
    private Thread job;
    public static volatile String PROGRESS="尚未开始";
    private volatile String progress="准备数据库";
    private long lastNotificationMs=0;
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();
        if(PAUSE.equals(action)){
            shouldStop.set(true);
            progress="已请求暂停，等待当前请求结束";PROGRESS=progress;
            show(progress);
            return START_NOT_STICKY;
        }
        if(!START.equals(action)||!RUNNING.compareAndSet(false,true))return START_NOT_STICKY;
        shouldStop.set(false);show("初始化全市场采集数据库…");
        final String token=intent.getStringExtra("tushare_token");
        final int startYear=intent.getIntExtra("start_year",1990);
        job=new Thread(()->{
            VaultDb vault=new VaultDb(getApplicationContext());
            try{
                NativeCollector collector=new NativeCollector(getApplicationContext(),vault,new NativeCollector.Feedback(){
                    @Override public void onUpdate(String message){ progress=message;PROGRESS=message;
                        if(System.currentTimeMillis()-lastNotificationMs>5000){lastNotificationMs=System.currentTimeMillis();show(message);} }
                    @Override public boolean isPaused(){return shouldStop.get();}
                },token,startYear,900);
                collector.runAll();
            }catch(Exception e){
                progress="采集发生错误: "+e.getClass().getSimpleName()+" / "+e.getMessage();
                PROGRESS=progress;show(progress);
            }finally{
                vault.close();RUNNING.set(false);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
            }
        },"market-harvest-worker");
        job.start();return START_NOT_STICKY;
    }
    private void show(String message){
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(manager==null)return;
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"QuantDesk 数据采集",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,CHANNEL)
           .setContentTitle("QuantDesk · A 股 / 港股数据库采集")
           .setContentText(message.length()>90?message.substring(0,90):message)
           .setSmallIcon(android.R.drawable.stat_sys_download)
           .setOngoing(true).setContentIntent(pending).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(1024,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(1024,n);
    }
    @Override public void onDestroy(){shouldStop.set(true);super.onDestroy();}
}
