package com.quantdesk.v85;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.Context;
import android.Manifest;
import android.content.pm.PackageManager;
import android.view.View;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import java.io.*;
import java.util.Locale;
import org.json.JSONObject;

/** Primary screen: fully native downloader, persistent market database first, analysis second. */
public final class MainActivity extends Activity {
    private static final int EXPORT_SQLITE=203;
    private TextView status,details;
    private EditText token,year,lookup;
    private Spinner searchMarket;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean screenLive;
    private static final int DARK=Color.rgb(19,30,45),BLUE=Color.rgb(24,92,175),MUTED=Color.rgb(75,87,105);
    @Override public void onCreate(Bundle state){super.onCreate(state);build();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},300);
    }
    private GradientDrawable background(int color,int radius){GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(radius);return b;}
    private TextView text(String value,int size,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(DARK);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void add(LinearLayout col,View widget,int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(top);col.addView(widget,lp);}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private Button button(String caption,int color){Button b=new Button(this);b.setText(caption);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setBackground(background(color,dp(12)));b.setPadding(dp(12),dp(14),dp(12),dp(14));return b;}
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(244,247,251));
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(dp(20),dp(28),dp(20),dp(40));
        scroll.addView(col);setContentView(scroll);
        add(col,text("QuantDesk · 全市场数据库",24,true),1);
        TextView sub=text("先建库 → 下载 A 股 / 港股股票清单 → 逐段存储 K 线与财报 → 查看缺口 → 导出 SQLite",13,false);
        sub.setTextColor(MUTED);add(col,sub,10);
        TextView warning=text("真实数据采集（不是演示数据）。港股完整三大财报通常需要 Tushare 单独授权；必须使用不计费 Wi‑Fi，任务可暂停再继续。",13,false);
        warning.setBackground(background(Color.rgb(255,246,224),dp(10)));warning.setPadding(dp(12),dp(12),dp(12),dp(12));add(col,warning,14);
        add(col,text("Tushare Token（选填；财报全量建议配置）",14,true),18);
        token=new EditText(this);token.setHint("粘贴你自己的 Token；仅本次采集在内存使用");
        token.setSingleLine(true);token.setTextSize(14);token.setInputType(129);add(col,token,4);
        add(col,text("历史采集起始年份",14,true),12);
        year=new EditText(this);year.setText("1990");year.setInputType(2);year.setSingleLine(true);add(col,year,2);
        Button create=button("① 创建 / 打开本地 SQLite 数据库",BLUE);add(col,create,16);
        create.setOnClickListener(v->{VaultDb db=new VaultDb(this);db.getWritableDatabase();db.close();refresh();toast("本地数据库已建立");});
        Button start=button("② 下载 A 股 + 港股全市场（支持断点续传）",Color.rgb(11,110,80));add(col,start,10);
        start.setOnClickListener(v->{
            try {
                int y=Integer.parseInt(year.getText().toString());if(y<1990||y>java.time.LocalDate.now().getYear())throw new NumberFormatException();
                VaultDb db=new VaultDb(this);db.getWritableDatabase();db.close();
                Intent job=new Intent(this,HarvestService.class);job.setAction(HarvestService.START);
                job.putExtra("start_year",y);job.putExtra("tushare_token",token.getText().toString().trim());
                if(Build.VERSION.SDK_INT>=26)startForegroundService(job);else startService(job);
                token.setText("");toast("采集任务已发出：按年分段写入数据库");
            }catch(NumberFormatException e){toast("起始年份请输入 1990—当前年份");}catch(Exception e){toast("无法启动："+e.getMessage());}
        });
        Button pause=button("③ 暂停采集（记录保存在 SQLite）",Color.rgb(166,93,34));add(col,pause,10);
        pause.setOnClickListener(v->{Intent job=new Intent(this,HarvestService.class);job.setAction(HarvestService.PAUSE);
            try{startService(job);toast("已请求暂停，当前网络请求结束后生效");}catch(Exception e){toast("暂停失败："+e.getMessage());}});
        Button export=button("④ 导出全部数据库 .sqlite3",BLUE);add(col,export,10);
        export.setOnClickListener(v->{if(HarvestService.RUNNING.get()){toast("请先暂停并等待采集服务停止，再导出数据库");return;}
            Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.setType("application/octet-stream");
            save.addCategory(Intent.CATEGORY_OPENABLE);save.putExtra(Intent.EXTRA_TITLE,VaultDb.NAME);startActivityForResult(save,EXPORT_SQLITE);
        });
        Button analysis=button("⑤ 打开原版行情与技术分析界面",DARK);add(col,analysis,10);
        analysis.setOnClickListener(v->startActivity(new Intent(this,AnalysisActivity.class)));
        add(col,text("数据库实时状态",18,true),24);
        status=text("正在读取统计…",14,false);status.setTextIsSelectable(true);
        status.setBackground(background(Color.WHITE,dp(12)));status.setPadding(dp(14),dp(14),dp(14),dp(14));add(col,status,8);
        details=text("提示：已取得数据 ≠ 全市场历史已完整核验。失败、未授权、IPO 前无交易数据必须分别检查。",12,false);
        details.setTextColor(MUTED);add(col,details,10);
        Button reload=button("刷新采集状态",Color.rgb(83,99,115));add(col,reload,12);reload.setOnClickListener(v->refresh());
        add(col,text("查询已下载的单只股票",18,true),20);
        searchMarket=new Spinner(this);
        ArrayAdapter<String> option=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,new String[]{"A","HK"});
        option.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        searchMarket.setAdapter(option);add(col,searchMarket,5);
        lookup=new EditText(this);lookup.setSingleLine(true);lookup.setHint("例如 600519 或 00700");
        lookup.setInputType(2);add(col,lookup,5);
        Button inspect=button("查询本地 K 线 / 财报 / 采集状态",BLUE);add(col,inspect,8);
        inspect.setOnClickListener(v->{
            VaultDb db=new VaultDb(this);
            try{
                String market=searchMarket.getSelectedItem().toString();String code=lookup.getText().toString().trim();
                JSONObject j=db.stockStatus(market,code);
                new android.app.AlertDialog.Builder(this).setTitle("本地数据库 · "+market+" "+code)
                        .setMessage(j.toString(2)).setPositiveButton("关闭",(d,w)->{}).show();
            }catch(Exception e){toast("查询失败："+e.getMessage());}finally{db.close();}
        });
        refresh();
    }
    private void refresh(){
        VaultDb db=new VaultDb(this);
        try{
            JSONObject o=db.stats();
            String s="采集服务："+(HarvestService.RUNNING.get()?"运行中":"未运行 / 已停止")+"\n"+
                "A 股："+o.optLong("symbols_A")+" 只   港股："+o.optLong("symbols_HK")+" 只\n"+
                "K 线行数："+o.optLong("candles")+"（日线 "+o.optLong("candles_day")+"，分钟线 "+o.optLong("candles_minute")+"）\n"+
                "财报记录："+o.optLong("financial_statements")+"  扩展指标/事件："+o.optLong("auxiliary_data")+"\n"+
                "已观测任务："+o.optLong("tasks_observed")+"  部分："+o.optLong("tasks_partial")+"\n"+
                "失败："+o.optLong("tasks_failed")+"  未授权："+o.optLong("tasks_permission_required")+"\n"+
                "历史失败日志："+o.optLong("fetch_errors")+"\n"+
                "最近任务："+o.optString("last_run","未开始")+"\n"+
                "A 股目录："+o.optString("catalog_A","待建")+"\n港股目录："+o.optString("catalog_HK","待建")+"\n";
            status.setText(s);
        }catch(Exception e){status.setText("数据库检查失败："+e.getMessage());}
        finally{db.close();}
    }
    @Override protected void onResume(){super.onResume();screenLive=true;handler.post(tick);}
    @Override protected void onPause(){screenLive=false;handler.removeCallbacks(tick);super.onPause();}
    private final Runnable tick=new Runnable(){@Override public void run(){if(screenLive){refresh();handler.postDelayed(this,3000);}}};
    private void toast(String str){Toast.makeText(this,str,Toast.LENGTH_LONG).show();}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
        if(req!=EXPORT_SQLITE||result!=RESULT_OK||data==null||data.getData()==null)return;
        if(HarvestService.RUNNING.get()){toast("仍在采集，必须先暂停，不能直接复制写入中的数据库");return;}
        try{
            VaultDb db=new VaultDb(this);SQLiteDatabase sql=db.getWritableDatabase();
            try(Cursor cur=sql.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)",null)){while(cur.moveToNext()){} }
            db.close();File input=getDatabasePath(VaultDb.NAME);
            Uri output=data.getData();
            try(InputStream in=new FileInputStream(input);OutputStream out=getContentResolver().openOutputStream(output)) {
                if(out==null)throw new IOException("NO_OUTPUT_STREAM");
                byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                out.flush();
            }
            toast("SQLite 已导出到你选择的文件夹");
        }catch(Exception e){toast("数据库导出失败："+e.getMessage());}
    }
}
