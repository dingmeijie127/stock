package com.quantdesk.download;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
public final class RecentGapPlannerTest {
    private static void eq(Object x,Object y){if(!x.equals(y))throw new AssertionError(x+" != "+y);}
    public static void main(String[] args){
        String target="2026-10-27";
        var sessions=Arrays.asList("2026-10-23","2026-10-26","2026-10-27");
        eq(RecentGapPlanner.firstFetchDay("2026-10-23",target,sessions,
            new HashSet<>(Arrays.asList("2026-10-23"))),LocalDate.parse("2026-10-24"));
        // Newest bar already fetched, previous session still missing: detect on next tap.
        eq(RecentGapPlanner.firstFetchDay(target,target,sessions,
            new HashSet<>(Arrays.asList("2026-10-23","2026-10-27"))),LocalDate.parse("2026-10-26"));
        if(RecentGapPlanner.firstFetchDay(target,target,sessions,new HashSet<>(sessions))!=null)
            throw new AssertionError("complete recent tail should not request more history");
        if(RecentGapPlanner.firstFetchDay(null,target,sessions,new HashSet<>())!=null)
            throw new AssertionError("unknown first bar should be deferred to full history");
        System.out.println("RecentGapPlannerTest PASS");
    }
}
