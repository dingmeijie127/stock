package com.quantdesk.download;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public final class StrategySuiteTest{
    static void ok(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    static List<SwingStrategy.Candle> bars(double step,int n){
        List<SwingStrategy.Candle> out=new ArrayList<>();
        LocalDate d=LocalDate.of(2025,1,1);
        for(int i=0;i<n;i++){
            double c=30+step*i+Math.sin(i*.4)*.17;
            out.add(new SwingStrategy.Candle(d.plusDays(i).toString(),c-.05,c+.18,c-.19,c,2000+i));
        }
        return out;
    }
    public static void main(String[] args){
        ok(StrategySuite.IDS.length==5,"exactly five independent experiments");
        for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)ok(!StrategySuite.IDS[i].equals(StrategySuite.IDS[j]),"unique account keys");
        List<SwingStrategy.Candle> up=bars(.065,115),down=bars(-.065,115);
        MarketRegime.Tally upTally=new MarketRegime.Tally(),downTally=new MarketRegime.Tally();
        for(int i=0;i<240;i++){
            upTally.observe(up,up.get(up.size()-1).day);
            downTally.observe(down,down.get(down.size()-1).day);
        }
        MarketRegime.Result bull=upTally.finish(up.get(up.size()-1).day),bear=downTally.finish(down.get(down.size()-1).day);
        ok(MarketRegime.BULL.equals(bull.mode),"bull should be based on breadth and momentum");
        ok(MarketRegime.BEAR.equals(bear.mode),"bear should be based on breadth and momentum");
        ok(MarketRegime.UNKNOWN.equals(new MarketRegime.Tally().finish("2025-03-01").mode),"unknown insufficient data");
        ok(bull.allowed(StrategySuite.BREAKOUT),"bull breakout allowed");
        ok(bear.allowed(StrategySuite.BREAKOUT)&&bear.allowed(StrategySuite.RSI),"bear uses small budgets, does not globally disable strategies");
        ok(bull.allowed(StrategySuite.BOLL),"Bollinger may trade with small bull-market risk budget");
        ok(bear.allowed(StrategySuite.BOLL),"bear allows conditional countertrend opportunities only");
        ok(!new MarketRegime.Tally().finish("2025-03-01").allowed(StrategySuite.BOLL),"unknown always blocks buys");
        for(String id:StrategySuite.IDS){
            SwingStrategy.Advice stopped=StrategySuite.evaluate(id,up,up.get(up.size()-1).day,bear,true,200,4);
            ok("SELL".equals(stopped.action),"bear risk exit: "+id);
            SwingStrategy.Advice noBuy=StrategySuite.evaluate(id,up,up.get(up.size()-1).day,bear,false,0,0);
            ok(!"BUY".equals(noBuy.action)||bear.plan(id).exposure<=.15,"bear can buy only within small budgets: "+id);
            SwingStrategy.Advice stale=StrategySuite.evaluate(id,up,up.get(up.size()-2).day,bull,false,0,0);
            ok(!"BUY".equals(stale.action),"no stale day entry");
        }
        StrategySuite.Assessment momentumRaw=StrategySuite.assess(StrategySuite.MOMENTUM,up,
            up.get(up.size()-1).day,bear,false,0,0);
        ok("BUY".equals(momentumRaw.raw.action),"synthetic rising bars trigger raw momentum");
        ok("READY".equals(momentumRaw.category)&&"BUY".equals(momentumRaw.advice.action),
            "strong low-volatility stocks can produce bear-market paper ideas within small budgets");
        StrategySuite.Assessment momentumBull=StrategySuite.assess(StrategySuite.MOMENTUM,up,
            up.get(up.size()-1).day,bull,false,0,0);
        ok("READY".equals(momentumBull.category)&&"BUY".equals(momentumBull.advice.action),
            "same technical signal is actionable in bull regime");
        StrategySuite.Assessment sparse=StrategySuite.assess(StrategySuite.RSI,
            up.subList(0,70),up.get(69).day,bear,false,0,0);
        ok("QUALITY".equals(sparse.category),"insufficient daily bars must be differentiated");
        RiskPolicy.Plan weak=RiskPolicy.forMode(StrategySuite.MOMENTUM,MarketRegime.BEAR);
        ok(weak.maxPositions==5&&weak.perName<=.05&&weak.exposure<=.15,"weak market can diversify up to five tiny positions without adding leverage");
        ok(weak.newCapital(100000,15000,85000)==0,"no extra stock purchases beyond weak market exposure");
        ok(weak.newCapital(100000,0,100000)>0,"qualified small bear trade remains possible");
        RiskPolicy.Plan unknown=RiskPolicy.forMode(StrategySuite.RSI,MarketRegime.UNKNOWN);
        ok(unknown.newCapital(100000,0,100000)==0,"no new risk on unknown data");
        SwingStrategy.Advice watch=StrategySuite.watch(StrategySuite.BREAKOUT,up,up.get(up.size()-1).day);
        ok(watch==null||"WATCH".equals(watch.action),"watchlists never become buy orders");
        ok(StrategySuite.title(StrategySuite.CHAN).contains("缠论"),"chinese label");
        ok(StrategySuite.formula(StrategySuite.CHAN).contains("不等于完整"),"honest Chan disclaimer");
        System.out.println("StrategySuiteTest PASS");
    }
}
