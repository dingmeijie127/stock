package com.quantdesk.download;
/** Offline rules for quick study mode; never imply a live/causal fill. */
public final class QuickPaperRulesTest {
    static void ok(boolean value,String msg){if(!value)throw new AssertionError(msg);}
    public static void main(String[] args){
        for(String id:StrategySuite.IDS){
            for(String mode:new String[]{MarketRegime.BEAR,MarketRegime.RANGE,MarketRegime.BULL}){
                RiskPolicy.Plan p=RiskPolicy.forMode(id,mode);
                ok(p.maxPositions==5,"can split any eligible exposure into five positions: "+id+" "+mode);
                ok(p.perName<=p.exposure,"single stock budget never exceeds account stock exposure");
                ok(p.newCapital(100000,100000*p.exposure,100000)==0,"no leverage at regime cap");
                ok(p.newCapital(100000,0,100000)<=100000*p.perName,"individual budget bounded");
            }
        }
        ok(!RiskPolicy.forMode(StrategySuite.RSI,MarketRegime.UNKNOWN).mayBuy(),"unknown market disables new risk");
        ok(PaperTradeRules.validQuickClose(10,11,9,10.2,1000),"complete healthy daily bar");
        ok(!PaperTradeRules.validQuickClose(10,10,10,10,1000),"one price limit cannot be filled");
        ok(!PaperTradeRules.validQuickClose(10,11,9,10,0),"halt/untradeable volume");
        ok(!PaperTradeRules.validNextOpen("2026-10-27","2026-10-27",null,"BUY",10,11,9,10,1000),
            "causal strict mode must still refuse same-day fill");
        ok(PaperTradeRules.cashFlow("BUY",100,10)<-1000,"quick assumed fill still includes costs");
        System.out.println("QuickPaperRulesTest PASS");
    }
}
