"""Static segregation invariants. Android-run database functionality still needs emulator verification."""
from pathlib import Path
P=Path(__file__).resolve().parents[1]
J=P/'android-app/app/src/main/java/com/quantdesk/download'

def test_fast_and_strict_ledgers_are_distinct_and_schema_unchanged():
    s=(J/'PaperTradingStore.java').read_text()
    assert 'QUICK_SUFFIX="_QUICK"' in s
    assert 'quickAccount(String strategy)' in s and 'quickAccounts()' in s
    assert 'isQuickAccount(account)' in s
    assert 'if(isQuickAccount(account))throw' in s
    assert 'if(!isQuickAccount(account))throw' in s
    assert 'settleInternal(market,account,through,false)' in s
    assert 'settleInternal(market,account,through,true)' in s
    assert 'barOnDay(market,code,through)' in s
    assert 'candle.close:candle.open' in s
    assert 'quick&&!signal.equals(through)' in s
    assert 'signal_day<=?' in s and 'signal_day<?' in s
    assert 'quickCloseReady(through)' in s
    assert 'maxPositions' in s and 'SwingStrategy.buyLots' in s
    assert 'p.boughtDay.compareTo(candle.day)>=0' in s
    assert 'closed_trades' in s and 'account_id' in s
    # Paper account database version and table names have not changed.
    assert 'super(context,NAME,null,1)' in s
    assert 'CREATE TABLE positions(' in s and 'CREATE TABLE fills(' in s


def test_fast_one_tap_scan_then_fill_and_clear_mode_in_ui():
    u=(J/'PaperTradeActivity.java').read_text()
    assert 'quickMode=true' in u
    assert '"QUICK".equals(action)' in u
    assert 'scanQuickAll' in u
    assert 'placeSuggestedOrders' in u and 'settleQuick(market,ids[i],day)' in u
    assert 'quickAccount(sid)' in u and 'paper.account(sid)' in u
    assert '立即快测' in u and '严格次日仓' in u
    assert 'quick_auto_enabled' in u and 'last_quick_day' in u
    assert 'paper.scanQuickAll(market,day,null)' in u
    assert '当前：快测假设仓' in u and '不可验证' in u
    assert '"成交"' in u and '"战绩"' in u and '"持仓"' in u


def test_untouched_market_collector_and_signing_id():
    """Check collector identity without depending on the prior release ZIP.

    GitHub Actions extracts only QD922_FiveLab_Source.zip into RUNNER_TEMP;
    older release archives do not exist next to the extracted source.
    These SHA-256 hashes were recorded from the unchanged V9.2.1 sources.
    """
    import hashlib
    reference_sha256 = {
        'MarketDb.java': '324a3fef877acfa4bb0d413c46cc8f221546378b472505fbc4ad42e5681a6460',
        'ManualFastSync.java': '9764e0d6d725b8bc228c44d673e445bea692e95ac7417f4f0a7390e0bbab331b',
        'HarvestService.java': '23bd65ffc82c7e3e07a0d9d882ec78a9032a0ab478f49bdae39a8e1d870fcc06',
        'DailySources.java': '67921643588fb8f51114d3b4ad58b4d903ab5c1013e482ae29ae351574a7073e',
    }
    for filename, expected in reference_sha256.items():
        actual = hashlib.sha256((J / filename).read_bytes()).hexdigest()
        assert actual == expected, f'{filename} differs from the V9.2.1 collector baseline'
    gradle=(P/'android-app/app/build.gradle').read_text()
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in gradle
    assert 'versionCode 922' in gradle
