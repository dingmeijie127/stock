"""Paper account v9.1.6 contract; no modifications to user's market SQLite."""
from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
JAVA=R/'android-app/app/src/main/java/com/quantdesk/download'

def test_second_screen_registered_and_accessible():
    manifest=(R/'android-app/app/src/main/AndroidManifest.xml').read_text()
    main=(JAVA/'MainActivity.java').read_text()
    screen=(JAVA/'PaperTradeActivity.java').read_text()
    assert 'PaperTradeActivity' in main and 'PaperTradeActivity' in manifest
    assert 'setContentView' in screen and 'current.signals' in screen and 'renderRows' in screen
    assert '正在' in screen and '模拟账户' in screen

def test_paper_ledger_separate_and_persistent():
    p=(JAVA/'PaperTradingStore.java').read_text()
    assert 'quantdesk-paper-accounts.sqlite3' in p
    for table in ('accounts','orders','positions','fills','closed_trades','equity_snapshots','signals'):
        assert 'CREATE TABLE '+table in p
    assert 'UNIQUE(account_id,code,side,signal_day)' in p
    assert 'PENDING' in p and 'FILLED' in p and 'CANCELLED' in p
    assert 'MarketDb.NAME' not in p and 'DROP TABLE' not in p

def test_only_a_and_not_same_bar_execution():
    p=(JAVA/'PaperTradingStore.java').read_text()
    assert "exchange IN ('SH','SZ','BJ')" in p
    assert 'AND day>?' in p and 'ORDER BY day LIMIT 1' in p
    assert 'signal_day<?' in p
    assert 'double maxBudget' in p
    assert 'SwingStrategy.sellTax' in p

def test_release_wiring():
    gradle=(R/'android-app/app/build.gradle').read_text()
    flow=(R/'.github/workflows/QD922_FiveLab_Build.yml').read_text()
    assert 'versionCode 922' in gradle
    for name in ('PaperTradingStore.java','PaperTradeActivity.java','SwingStrategyTest.java'):
        assert name in flow
    assert "z=Path('QD922_FiveLab_Source.zip')" in flow
