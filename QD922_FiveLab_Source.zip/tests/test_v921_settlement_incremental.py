"""Regression contracts for append-only 2-day tails and next-day paper settlement.
Offline tests never assume an online data provider returned actual bars.
"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
J=ROOT/'android-app/app/src/main/java/com/quantdesk/download'


def test_recent_incremental_not_silently_limited_to_80_and_old_database_unmodified():
    fast=(J/'ManualFastSync.java').read_text()
    db=(J/'MarketDb.java').read_text()
    assert 'db.planManualDaily(target)' in fast
    assert 'RecentGapPlanner.firstFetchDay(' in fast
    assert 'readRecentBars(db,start,target)' in fast
    assert 'DailySources.downloadFast(s.code,s.exchange,from,to)' in fast
    assert 'tails.size()-historyCompleted' in fast
    assert 'historyCompleted%10==0' in fast
    assert 'tailAttempted>=80' not in fast
    assert 'INSERT OR IGNORE INTO daily_bars' in db
    assert 'DROP TABLE' not in db


def test_refresh_and_after_sync_settle_existing_orders_without_auto_buy():
    screen=(J/'PaperTradeActivity.java').read_text()
    service=(J/'HarvestService.java').read_text()
    store=(J/'PaperTradingStore.java').read_text()
    assert 'else if("REFRESH".equals(action))' in screen
    assert 'paper.settle(market,ids[i],day)' in screen
    assert 'PaperTradingStore.asOf(db)' in service
    assert 'paper.settle(db,id,through)' in service
    assert 'placeSuggestedOrders' not in service
    assert 'signal_day<?' in store
    assert 'day>? AND day<=?' in store
    assert 'pendingReason(MarketDb market,OrderView order,String through)' in store
    assert 'current.pendingReasons.getOrDefault(o.id' in screen


def test_user_can_trial_without_waiting_for_future_date_without_fake_fills():
    screen=(J/'PaperTradeActivity.java').read_text()
    store=(J/'PaperTradingStore.java').read_text()
    assert '不等未来交易日：历史逐日回放五策略' in screen
    assert '新委托不使用今日历史开盘价成交' in screen
    assert '已完成独立历史样本回放' in screen
    assert 'validNextOpen' in store
    assert '不能倒填' in screen


def test_release_signing_identity_still_matches_old_install():
    gradle=(ROOT/'android-app/app/build.gradle').read_text()
    wf=(ROOT/'.github/workflows/QD922_FiveLab_Build.yml').read_text()
    assert "applicationId 'com.quantdesk.lab.fivestrategy917'" in gradle
    assert 'versionCode 922' in gradle
    assert 'QD922_FiveLab_Source.zip' in wf
    assert 'QD_FIVELAB01_KEYSTORE_B64' in wf
    assert 'RecentGapPlannerTest.java' in wf
