"""A-only V9.1.4 source contracts with SQLite validation on an intentionally mixed old DB.
This is offline testing; not a real provider or Android integration test.
"""
from pathlib import Path
import re,sqlite3,subprocess,tempfile
R=Path(__file__).resolve().parents[1]
J=R/'android-app/app/src/main/java/com/quantdesk/download'
DB=(J/'MarketDb.java').read_text()
SV=(J/'HarvestService.java').read_text()
UI=(J/'MainActivity.java').read_text()
UV=(J/'Universe.java').read_text()
FAST=(J/'ManualFastSync.java').read_text()
WF=(R/'.github/workflows/QD922_FiveLab_Build.yml').read_text()


def test_collectors_only_visit_a_shares_and_leave_hk_in_db():
    assert 'db.allASecurities()' in SV
    assert 'db.allSecurities()' not in SV
    assert 'installHK(context,market);' not in UV
    assert 'db.countHK()==0' not in SV
    assert 'List<String> hkSessions=db.referenceDays' not in FAST
    for fn in ('planManualDaily','planFastDaily'):
        body=DB.split(f'public FastPlan {fn}(',1)[1].split('return plan;',1)[0]
        assert "s.exchange IN ('SH','SZ','BJ')" in body
    assert 'return market.countA();' in UV
    assert 'db.referenceDays("HK",from,to)' not in SV
    assert 'Live HK provider canary' not in WF
    assert 'Download validated HK equity universe' not in WF
    assert 'network_hk_canary.py' not in WF
    assert 'downloadBars' in SV and 'INSERT OR IGNORE INTO daily_bars' in DB


def test_mixed_legacy_database_a_only_query_and_primary_key_integrity():
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE instruments(code TEXT PRIMARY KEY,name TEXT,exchange TEXT,source TEXT)')
    db.execute('CREATE TABLE daily_bars(code TEXT,day TEXT,o REAL,h REAL,l REAL,c REAL,vol REAL,vol_unit TEXT,amount REAL,provider TEXT,raw TEXT,PRIMARY KEY(code,day))')
    for code,m in [('600519','SH'),('000001','SZ'),('830799','BJ'),('00700','HK')]:
        db.execute('INSERT INTO instruments VALUES(?,?,?,?)',(code,code,m,'legacy'))
    old=('00700','2026-10-23',10,11,9,10,100,'LOTS',None,'legacy','original')
    db.execute('INSERT INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',old)
    db.execute('INSERT OR IGNORE INTO daily_bars VALUES(?,?,?,?,?,?,?,?,?,?,?)',old)
    sql="SELECT s.code,s.exchange,(SELECT max(b.day) FROM daily_bars b WHERE b.code=s.code) FROM instruments s WHERE s.exchange IN ('SH','SZ','BJ') ORDER BY s.code"
    assert {row[0] for row in db.execute(sql)}=={'600519','000001','830799'}
    assert db.execute("SELECT raw FROM daily_bars WHERE code='00700'").fetchone()[0]=='original'
    assert db.execute("SELECT count(*) FROM daily_bars WHERE code='00700'").fetchone()[0]==1
    assert 'DROP TABLE' not in DB


def test_read_only_quant_export_and_explicit_raw_unadjusted_limit():
    assert 'exportAQuantCsv' in DB
    assert 'ORDER BY day DESC LIMIT 61' in DB
    assert 'AND day<=?' in DB  # no future-data leakage
    assert 'AQuantFactors.compute(candles,asOf)' in DB
    assert 'A股数据库质量体检' in UI
    assert '未复权收盘价' in UI
    assert 'db.exportAQuantCsv' in UI
    assert 'fqt=0' in (J/'DailySources.java').read_text()


def test_quant_factor_fixtures_run_under_java_17():
    with tempfile.TemporaryDirectory() as folder:
        subprocess.run(['javac','-encoding','UTF-8','-d',folder,
                        str(J/'AQuantFactors.java'),str(R/'tests/java/AQuantFactorsTest.java')],check=True)
        result=subprocess.run(['java','-cp',folder,'com.quantdesk.download.AQuantFactorsTest'],
                              capture_output=True,text=True,check=True)
        assert 'PASS' in result.stdout


def test_scheduled_updates_a_only_including_financial_work():
    worker=(J/'DailyUpdateWorker.java').read_text()
    auto_fin=(J/'FastFinanceSync.java').read_text()
    assert 'db.allASecurities()' in auto_fin
    assert 'db.allSecurities()' not in auto_fin
    assert 'db.countHK()==0' not in worker
    assert 'db.planFastDaily(day)' in worker
    assert 'db.autoPending(day' not in worker or "java.util.Collections.emptyList()" in DB
    assert 'A股日K+财报增量总耗时' in worker


def test_incremental_and_daily_roster_import_new_a_listings():
    worker=(J/'DailyUpdateWorker.java').read_text()
    assert 'Universe.install(getApplicationContext(),db);' in SV
    assert 'Universe.install(c,db);' in worker
    assert 'INSERT OR IGNORE INTO instruments' in UV
