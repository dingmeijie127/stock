package com.quantdesk.download;

import android.database.Cursor;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

/** Foreground, append-only A-share quick sync. Latest finalized day uses batched quotes;
 * missing trading sessions in the recent tail use real per-security historical daily bars.
 * Time-limited work is resumable; NEVER labels unfinished coverage as complete.
 * MarketDb schema and existing saved daily bars are not changed.
 */
public final class ManualFastSync {
    private ManualFastSync(){}
    public interface Status {void show(String message,int processed,int total);}
    private static final int RECENT_DAYS=14;
    private static final int CONCURRENT_HISTORY=6;
    private static final long FOREGROUND_BUDGET_MS=6L*60*1000;
    private static final class Page {
        final List<String> symbols;
        final Map<String,Bar> bars;
        final String error;
        Page(List<String> s,Map<String,Bar> b,String e){symbols=s;bars=b;error=e;}
    }
    private static final class HistoryPage {
        final MarketDb.FastCandidate stock;
        final LocalDate from;
        final DailySources.Result data;
        final String error;
        HistoryPage(MarketDb.FastCandidate s,LocalDate f,DailySources.Result d,String e){
            stock=s;from=f;data=d;error=e;
        }
    }
    private static Map<String,Set<String>> readRecentBars(MarketDb db,String start,String end){
        Map<String,Set<String>> result=new HashMap<>();
        try(Cursor c=db.getReadableDatabase().rawQuery(
            "SELECT b.code,b.day FROM daily_bars b JOIN instruments i ON i.code=b.code "+
            "WHERE i.exchange IN ('SH','SZ','BJ') AND b.day>=? AND b.day<=?",new String[]{start,end})){
            while(c.moveToNext())result.computeIfAbsent(c.getString(0),k->new HashSet<>()).add(c.getString(1));
        }
        return result;
    }
    private static LinkedHashMap<String,MarketDb.FastCandidate> collectCandidates(
            MarketDb db,MarketDb.FastPlan plan,List<String> sessions,Map<String,Set<String>> saved,String target){
        LinkedHashMap<String,MarketDb.FastCandidate> work=new LinkedHashMap<>();
        for(MarketDb.FastCandidate s:plan.pending)work.put(s.code,s);
        if(sessions.isEmpty())return work;
        // Also find an internal missing day when a stock ALREADY has the target date.
        // The old implementation silently skipped these securities forever.
        try(Cursor c=db.getReadableDatabase().rawQuery(
            "SELECT code,exchange FROM instruments WHERE exchange IN ('SH','SZ','BJ') ORDER BY code",null)){
            while(c.moveToNext()){
                String code=c.getString(0);
                if(work.containsKey(code))continue;
                Set<String> days=saved.get(code);
                if(days==null||days.size()<2||!days.contains(target))continue;
                String first=Collections.min(days);
                for(String session:sessions){
                    if(session.compareTo(first)>0&&session.compareTo(target)<0&&!days.contains(session)){
                        work.put(code,new MarketDb.FastCandidate(code,c.getString(1),target,null));break;
                    }
                }
            }
        }
        return work;
    }
    private static LocalDate firstMissing(MarketDb.FastCandidate s,List<String> sessions,
            Map<String,Set<String>> saved,String target){
        return RecentGapPlanner.firstFetchDay(s.latest,target,sessions,
            saved.getOrDefault(s.code,Collections.emptySet()));
    }
    private static int recentUnresolved(Map<String,MarketDb.FastCandidate> candidates,
            List<String> sessions,Map<String,Set<String>> actual,String target){
        int count=0;
        for(MarketDb.FastCandidate s:candidates.values()){
            if(s.latest==null||s.latest.isEmpty())continue;
            Set<String> have=actual.getOrDefault(s.code,Collections.emptySet());
            boolean gap=false;
            for(String day:sessions)if(day.compareTo(s.latest)>0&&day.compareTo(target)<=0&&!have.contains(day)){
                gap=true;break;
            }
            if(s.latest.compareTo(target)>=0){
                String first=have.isEmpty()?target:Collections.min(have);
                for(String day:sessions)if(day.compareTo(first)>0&&day.compareTo(target)<0&&!have.contains(day)){
                    gap=true;break;
                }
            }
            if(gap)count++;
        }
        return count;
    }
    public static void run(MarketDb db,LocalDate day,BooleanSupplier paused,Status status) throws Exception {
        String target=day.toString(),start=day.minusDays(RECENT_DAYS).toString();
        MarketDb.FastPlan plan=db.planManualDaily(target);
        List<String> sessions=db.referenceDays("A",start,target);
        Map<String,Set<String>> before=readRecentBars(db,start,target);
        LinkedHashMap<String,MarketDb.FastCandidate> candidates=collectCandidates(db,plan,sessions,before,target);
        int total=candidates.size(),saved=0,received=0,failedPages=0,finished=0,historyCompleted=0,historyFailed=0,deferred=0;
        int latestSaved=0,historySaved=0;
        status.show("快速增量目标日 "+target+"；当日待补 "+plan.pending.size()+" 只，近期内部缺口 "+
            (total-plan.pending.size())+" 只；已有目标日K "+plan.alreadyCurrent+" 只",0,total);
        if(total==0){
            String detail="快速增量结束：目标日 "+target+" 已有收盘日K；近"+RECENT_DAYS+
                "天未识别到需补的交易日尾部缺口（并非全历史核验）";
            db.autoState(target,"done","",detail);db.log("FAST",detail);status.show(detail,0,0);return;
        }
        long deadline=System.currentTimeMillis()+FOREGROUND_BUDGET_MS;
        List<String> symbols=new ArrayList<>();
        for(MarketDb.FastCandidate s:plan.pending){
            try{symbols.add(TencentBatchQuotes.symbol(s.code,s.exchange));}
            catch(IllegalArgumentException unsupported){/* BJ uses historical API below */}
        }
        List<List<String>> pages=TencentBatchQuotes.pages(symbols);
        ExecutorService pool=Executors.newFixedThreadPool(CONCURRENT_HISTORY);
        try{
            CompletionService<Page> quotes=new ExecutorCompletionService<>(pool);
            List<Future<Page>> inflight=new ArrayList<>();int next=0;
            while(next<pages.size()&&inflight.size()<8){
                final List<String> batch=pages.get(next++);
                inflight.add(quotes.submit(()->{
                    try{return new Page(batch,TencentBatchQuotes.fetch(batch,day),null);}
                    catch(Exception ex){return new Page(batch,Collections.emptyMap(),ex.getMessage());}
                }));
            }
            while(!inflight.isEmpty()&&!paused.getAsBoolean()&&System.currentTimeMillis()<deadline){
                Future<Page> f=quotes.poll(750,TimeUnit.MILLISECONDS);if(f==null)continue;
                inflight.remove(f);Page result=f.get();finished++;
                if(result.error!=null){failedPages++;db.log("FAST_ERROR","目标日批量报价失败："+result.error);}
                else{
                    Set<String> requested=new HashSet<>();
                    for(String symbol:result.symbols)requested.add(symbol.substring(2));
                    result.bars.keySet().retainAll(requested);
                    received+=result.bars.size();
                    int n=db.saveFastQuoteBatch(result.bars,target);saved+=n;latestSaved+=n;
                }
                if(finished%5==0||finished==pages.size())status.show(
                    "最新日批量报价 "+finished+"/"+pages.size()+"；真实新增 "+latestSaved+
                    " 根，开始检查两日/近期历史缺口",Math.min(total,finished*TencentBatchQuotes.BATCH_SIZE),total);
                if(next<pages.size()){
                    final List<String> batch=pages.get(next++);
                    inflight.add(quotes.submit(()->{
                        try{return new Page(batch,TencentBatchQuotes.fetch(batch,day),null);}
                        catch(Exception ex){return new Page(batch,Collections.emptyMap(),ex.getMessage());}
                    }));
                }
            }
            for(Future<Page> f:inflight)f.cancel(true);
            // Re-check SAVED data, not merely downloaded quotes: the latest day must not hide
            // a missing prior trading session. Historical providers are requested per stock.
            Map<String,Set<String>> afterQuotes=readRecentBars(db,start,target);
            List<MarketDb.FastCandidate> tails=new ArrayList<>();
            Map<String,LocalDate> begin=new HashMap<>();
            for(MarketDb.FastCandidate s:candidates.values()){
                if(s.latest==null||s.latest.compareTo(start)<0){deferred++;continue;}
                LocalDate from=firstMissing(s,sessions,afterQuotes,target);
                if(from==null||from.isAfter(day))continue;
                boolean missing=false;
                for(String session:sessions)if(session.compareTo(from.toString())>=0&&
                        !afterQuotes.getOrDefault(s.code,Collections.emptySet()).contains(session)){
                    missing=true;break;
                }
                // No reference dates at all: the target quote can still be missing.
                if(sessions.isEmpty()&&!afterQuotes.getOrDefault(s.code,Collections.emptySet()).contains(target))missing=true;
                if(missing){tails.add(s);begin.put(s.code,from);}
            }
            // No arbitrary 80-stock cap. Real network and foreground time limits apply;
            // after a partial pass, the next tap rescans SQLite and resumes remaining gaps.
            CompletionService<HistoryPage> histories=new ExecutorCompletionService<>(pool);
            List<Future<HistoryPage>> live=new ArrayList<>();int pos=0;
            while(pos<tails.size()&&live.size()<CONCURRENT_HISTORY){
                final MarketDb.FastCandidate s=tails.get(pos++);final LocalDate from=begin.get(s.code);
                live.add(histories.submit(()->fetchHistory(s,from,day)));
            }
            while(!live.isEmpty()&&!paused.getAsBoolean()&&System.currentTimeMillis()<deadline){
                Future<HistoryPage> f=histories.poll(700,TimeUnit.MILLISECONDS);if(f==null)continue;
                live.remove(f);HistoryPage result=f.get();historyCompleted++;
                if(result.error!=null){
                    historyFailed++;if(historyFailed<=20)db.log("FAST_ERROR",result.stock.code+" 最近交易日补缺失败 "+result.error);
                }else{
                    int n=db.appendDailyBars(result.stock.code,result.from.toString(),target,result.data.bars);
                    saved+=n;historySaved+=n;
                    if(result.data.skippedBars>0){historyFailed++;db.log("FAST_PARTIAL",result.stock.code+" 无效日K "+result.data.skippedBars);}
                }
                if(historyCompleted%10==0||historyCompleted==tails.size())status.show(
                    "最近交易日缺口补齐 "+historyCompleted+"/"+tails.size()+"；历史真实新增 "+historySaved+
                    " 根，失败 "+historyFailed+"，超时可再次点快速增量继续",Math.min(total,historyCompleted),total);
                if(pos<tails.size()&&System.currentTimeMillis()<deadline){
                    final MarketDb.FastCandidate s=tails.get(pos++);final LocalDate from=begin.get(s.code);
                    live.add(histories.submit(()->fetchHistory(s,from,day)));
                }
            }
            for(Future<HistoryPage> f:live)f.cancel(true);
            deferred+=tails.size()-historyCompleted;
        }finally{pool.shutdownNow();}
        Map<String,Set<String>> after=readRecentBars(db,start,target);
        int missingRecent=recentUnresolved(candidates,sessions,after,target);
        int stillMissing=db.autoMissingBars(target);
        String detail="快速增量目标 "+target+"：本轮新增 "+saved+" 根（当日 "+latestSaved+
            " / 近期缺口 "+historySaved+"）；当日报价批次 "+finished+"/"+pages.size()+
            "，有效报价 "+received+"，报价错误 "+failedPages+" 批；近期补尾完成 "+historyCompleted+
            " 只，失败 "+historyFailed+"，超时/较长缺口待处理 "+deferred+
            " 只，近期待核实缺口股票约 "+missingRecent+" 只，目标日未取到有效K "+stillMissing+
            " 只（可能停牌/未上市/网络延迟）。如未补齐可重复点击：只追加缺的日K，不删除旧数据。";
        boolean incomplete=paused.getAsBoolean()||finished<pages.size()||failedPages>0||historyFailed>0||
            deferred>0||missingRecent>0||stillMissing>0;
        String phase=paused.getAsBoolean()?"paused":incomplete?"partial":"done";
        db.autoState(target,phase,"",detail);db.log("FAST",detail);
        status.show(detail,total-deferred,total);
    }
    private static HistoryPage fetchHistory(MarketDb.FastCandidate s,LocalDate from,LocalDate to){
        try{return new HistoryPage(s,from,DailySources.downloadFast(s.code,s.exchange,from,to),null);}
        catch(Exception e){return new HistoryPage(s,from,null,e.getClass().getSimpleName()+": "+e.getMessage());}
    }
}
