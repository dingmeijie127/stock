package com.quantdesk.download;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/** Pure, testable close-of-day gap planner. Never fabricates trading days. */
public final class RecentGapPlanner {
    private RecentGapPlanner(){}
    /** From this date onward, ask a real history provider for actual missing sessions.
     * The provider decides actual market dates, including holidays and suspensions.
     * If lastStored already equals target, only a verified internal missing session qualifies.
     */
    public static LocalDate firstFetchDay(String lastStored,String target,
            List<String> referenceSessions,Set<String> storedInWindow){
        if(lastStored==null||lastStored.isEmpty())return null;
        if(lastStored.compareTo(target)<0)return LocalDate.parse(lastStored).plusDays(1);
        if(referenceSessions==null||referenceSessions.isEmpty()||
                storedInWindow==null||storedInWindow.size()<2)return null;
        String first=Collections.min(storedInWindow);
        for(String date:referenceSessions){
            if(date.compareTo(first)>0&&date.compareTo(target)<0&&!storedInWindow.contains(date))
                return LocalDate.parse(date);
        }
        return null;
    }
}
